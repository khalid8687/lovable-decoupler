<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep delivery dates and payment terms in the shared deck project module so slides and tests cannot drift apart.
- Derive weekly presentation ranges from the shared project schedule; weeks group existing implementation phases rather than changing their dates.
- Extend the existing slide registry and slide-content typography; use one centered 1920×1080 ScaledSlide for presentation, overview and print, and the existing reflow system for phone reading.
- Store the active slide in the route search parameters; transient presentation panels stay in React state to keep shared links stable without polluting browser history.
