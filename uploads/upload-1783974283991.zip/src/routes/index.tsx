import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import oltaniLogo from "@/assets/oltani-logo.webp";
import hpOpen from "@/assets/hp-open.jpg";
import hpClosed from "@/assets/hp-closed.jpg";
import dellOpen from "@/assets/dell-open.jpg";
import dellClosed from "@/assets/dell-closed.jpg";
import lifestyleHp1 from "@/assets/lifestyle-hp-1.jpg";
import lifestyleHp2 from "@/assets/lifestyle-hp-2.jpg";
import lifestyleDell1 from "@/assets/lifestyle-dell-1.jpg";
import lifestyleDell2 from "@/assets/lifestyle-dell-2.jpg";
import featureKeyboard from "@/assets/feature-keyboard.jpg";
import featurePorts from "@/assets/feature-ports.jpg";

const laptopHp = hpOpen;
const laptopDell = dellOpen;

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { property: "og:image", content: laptopHp },
      { name: "twitter:image", content: laptopHp },
    ],
  }),
  component: QuotePage,
});

const WHATSAPP_URL = "http://wa.me/201002194451";
const CLIENT_NAME = "أ. جمال الجبالي";

type Offer = {
  id: string;
  brand: "HP" | "Dell";
  model: string;
  image: string;
  price: number;
  featured?: boolean;
  badge?: string;
  specs: { label: string; value: string; icon: string }[];
  highlights: string[];
};

const offers: Offer[] = [
  {
    id: "hp-i5-12-touch",
    brand: "HP",
    model: "HP EliteBook — الفئة الأعلى",
    image: laptopHp,
    price: 22500,
    featured: true,
    badge: "الأقوى",
    specs: [
      { label: "المعالج", value: "Intel Core i5 — الجيل 12", icon: "cpu" },
      { label: "الرامات", value: "16GB DDR5", icon: "ram" },
      { label: "التخزين", value: "SSD 256GB NVMe", icon: "ssd" },
      { label: "الشاشة", value: "تعمل باللمس Touch Screen", icon: "touch" },
    ],
    highlights: ["أداء احترافي للتصميم والبرمجة", "شاشة لمس تفاعلية", "تشغيل متعدد المهام بسلاسة"],
  },
  {
    id: "hp-i5-12-normal",
    brand: "HP",
    model: "HP EliteBook — شاشة عادية",
    image: laptopHp,
    price: 21500,
    badge: "أفضل قيمة",
    specs: [
      { label: "المعالج", value: "Intel Core i5 — الجيل 12", icon: "cpu" },
      { label: "الرامات", value: "16GB DDR5", icon: "ram" },
      { label: "التخزين", value: "SSD 256GB NVMe", icon: "ssd" },
      { label: "الشاشة", value: "شاشة FHD عادية", icon: "screen" },
    ],
    highlights: ["نفس قوة الجهاز الأعلى", "توفير 1000 جنيه", "مناسب للأعمال المكتبية الاحترافية"],
  },
  {
    id: "hp-i5-11",
    brand: "HP",
    model: "HP EliteBook — اقتصادي",
    image: laptopHp,
    price: 18000,
    specs: [
      { label: "المعالج", value: "Intel Core i5 — الجيل 11", icon: "cpu" },
      { label: "الرامات", value: "8GB DDR4", icon: "ram" },
      { label: "التخزين", value: "SSD 256GB NVMe", icon: "ssd" },
      { label: "التصميم", value: "نحيف وخفيف الوزن", icon: "design" },
    ],
    highlights: ["تصميم Premium بسعر مناسب", "خفيف وسهل التنقل", "مثالي للطلاب والعمل اليومي"],
  },
  {
    id: "dell-i5-11",
    brand: "Dell",
    model: "Dell Latitude",
    image: laptopDell,
    price: 15000,
    badge: "الأوفر",
    specs: [
      { label: "المعالج", value: "Intel Core i5 — الجيل 11", icon: "cpu" },
      { label: "الرامات", value: "8GB DDR4", icon: "ram" },
      { label: "التخزين", value: "SSD 256GB NVMe", icon: "ssd" },
      { label: "المتانة", value: "بناء قوي Business Grade", icon: "shield" },
    ],
    highlights: ["أقوى سعر في العرض", "متانة Dell الشهيرة", "مناسب للاستخدام اليومي المكثف"],
  },
];

const galleryImages = [
  { src: hpOpen, caption: "HP EliteBook — الشكل الأمامي" },
  { src: hpClosed, caption: "HP EliteBook — الغطاء الخارجي" },
  { src: dellOpen, caption: "Dell Latitude — الشكل الأمامي" },
  { src: dellClosed, caption: "Dell Latitude — الغطاء الخارجي" },
  { src: lifestyleHp1, caption: "HP EliteBook — بيئة عمل احترافية" },
  { src: lifestyleHp2, caption: "HP EliteBook — في الكافيه" },
  { src: lifestyleDell1, caption: "Dell Latitude — استخدام مريح" },
  { src: lifestyleDell2, caption: "Dell Latitude — تركيز في المكتبة" },
  { src: featureKeyboard, caption: "كيبورد بإضاءة خلفية" },
  { src: featurePorts, caption: "منافذ متكاملة USB-C و HDMI" },
];

function formatPrice(n: number) {
  return new Intl.NumberFormat("ar-EG").format(n);
}

function QuotePage() {
  const [lightbox, setLightbox] = useState<number | null>(null);

  useEffect(() => {
    if (lightbox === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setLightbox(null);
      if (e.key === "ArrowRight") setLightbox((i) => (i === null ? i : (i - 1 + galleryImages.length) % galleryImages.length));
      if (e.key === "ArrowLeft") setLightbox((i) => (i === null ? i : (i + 1) % galleryImages.length));
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [lightbox]);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <Hero />
      <ClientCard />
      <OffersSection />
      <FeatureShowcase />
      <GallerySection onOpen={(i) => setLightbox(i)} />
      <ComparisonTable />
      <WarrantySection />
      <ContactCTA />
      <Footer />
      {lightbox !== null && (
        <Lightbox
          index={lightbox}
          onClose={() => setLightbox(null)}
          onPrev={() => setLightbox((i) => (i === null ? i : (i + 1) % galleryImages.length))}
          onNext={() => setLightbox((i) => (i === null ? i : (i - 1 + galleryImages.length) % galleryImages.length))}
        />
      )}
      
    </div>
  );
}

function Header() {
  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
        <div className="flex min-w-0 items-center gap-3">
          <img src={oltaniLogo} alt="OLTANI" className="h-11 w-11 shrink-0 rounded-xl bg-white/5 object-contain p-1 sm:h-14 sm:w-14" />
          <div className="min-w-0 leading-tight">
            <div className="truncate text-lg font-black tracking-tight sm:text-xl">OLTANI</div>
            <div className="truncate text-[11px] text-muted-foreground sm:text-xs">oltani.com — Open Link Technologies</div>
          </div>
        </div>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-hero">
      <div className="pointer-events-none absolute inset-0 opacity-40" style={{ backgroundImage: "radial-gradient(circle at 50% 0%, oklch(0.72 0.19 45 / 0.35), transparent 60%)" }} />
      <div className="relative mx-auto grid max-w-7xl items-center gap-10 px-4 py-12 sm:px-6 sm:py-16 md:grid-cols-2 md:py-24">
        <div className="animate-float-in">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-xs font-bold text-primary sm:text-sm">
            <span className="h-2 w-2 rounded-full bg-primary" />
            عرض سعر رسمي
          </span>
          <h1 className="mt-5 text-4xl font-black leading-[1.15] tracking-tight sm:text-5xl md:text-6xl">
            أجهزة لاب توب <span className="text-gradient-brand">احترافية</span>
            <br />
            بجودة الشركات الكبرى
          </h1>
          <p className="mt-5 max-w-lg text-base leading-relaxed text-muted-foreground sm:text-lg">
            عرض مخصص من OLTANI يضم مجموعة مختارة من أجهزة HP EliteBook و Dell Latitude — كسر زيرو مستوردة مع ضمان استبدال.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#offers" className="inline-flex items-center gap-2 rounded-full bg-gradient-brand px-6 py-3 text-sm font-bold text-white shadow-glow transition hover:-translate-y-0.5">
              استعرض العروض
              <ArrowIcon className="h-4 w-4 rotate-180" />
            </a>
            <a href="#compare" className="inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-6 py-3 text-sm font-bold transition hover:bg-card">
              جدول المقارنة
            </a>
          </div>
          <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-3 text-xs text-muted-foreground sm:text-sm">
            <TrustPill icon="✓">كسر زيرو مستوردة</TrustPill>
            <TrustPill icon="🛡">ضمان استبدال</TrustPill>
            <TrustPill icon="⚡">تسليم فوري</TrustPill>
          </div>
        </div>
        <div className="relative animate-float-in">
          <div className="relative overflow-hidden rounded-3xl border border-border bg-card shadow-glow">
            <img
              src={hpOpen}
              alt="HP EliteBook"
              className="aspect-video w-full object-cover"
            />
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-background/50 via-transparent to-transparent" />
            <div className="absolute top-4 right-4 rounded-full border border-border/60 bg-background/80 px-3 py-1 text-[11px] font-bold backdrop-blur">HP EliteBook</div>
          </div>
          <div className="absolute -bottom-4 -left-4 rounded-2xl border border-border bg-card/95 px-5 py-3 shadow-soft backdrop-blur sm:-bottom-6 sm:-left-6">
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground">تبدأ الأسعار من</div>
            <div className="text-2xl font-black text-primary sm:text-3xl">15,000 <span className="text-sm">ج.م</span></div>
          </div>
        </div>
      </div>
    </section>
  );
}

function TrustPill({ icon, children }: { icon: string; children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-2">
      <span className="grid h-6 w-6 place-items-center rounded-full bg-primary/15 text-primary">{icon}</span>
      {children}
    </span>
  );
}

function ClientCard() {
  return (
    <section className="mx-auto max-w-7xl px-4 pt-10 sm:px-6">
      <div className="overflow-hidden rounded-3xl border border-border bg-gradient-card p-6 shadow-soft sm:p-8">
        <div className="grid gap-6 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center">
          <div className="min-w-0">
            <div className="text-xs font-bold uppercase tracking-widest text-primary">مقدم إلى</div>
            <div className="mt-2 truncate text-2xl font-black sm:text-3xl">{CLIENT_NAME}</div>
            <div className="mt-1 text-sm text-muted-foreground">عرض سعر خاص — صلاحية 7 أيام</div>
          </div>
          <div className="grid grid-cols-3 gap-3 sm:gap-6">
            <MiniStat label="أجهزة" value="4" />
            <MiniStat label="ماركات" value="HP / Dell" small />
            <MiniStat label="ضمان" value="استبدال" small />
          </div>
        </div>
      </div>
    </section>
  );
}

function MiniStat({ label, value, small }: { label: string; value: string; small?: boolean }) {
  return (
    <div className="rounded-2xl border border-border/60 bg-background/40 px-3 py-2.5 text-center">
      <div className={small ? "text-sm font-black sm:text-base" : "text-xl font-black text-primary sm:text-2xl"}>{value}</div>
      <div className="mt-0.5 text-[10px] text-muted-foreground sm:text-xs">{label}</div>
    </div>
  );
}

function OffersSection() {
  return (
    <section id="offers" className="mx-auto max-w-7xl px-4 py-14 sm:px-6 sm:py-20">
      <SectionHeader
        eyebrow="العروض"
        title="اختر الجهاز المناسب لك"
        description="أربعة عروض مختارة بعناية — من الأداء الاحترافي الأعلى إلى الخيار الاقتصادي الذكي."
      />
      <div className="mt-10 grid gap-6 md:grid-cols-2">
        {offers.map((o, idx) => (
          <OfferCard key={o.id} offer={o} index={idx} />
        ))}
      </div>
    </section>
  );
}

function OfferCard({ offer, index }: { offer: Offer; index: number }) {
  return (
    <article
      className={`group relative flex flex-col overflow-hidden rounded-3xl border bg-gradient-card shadow-soft transition hover:-translate-y-1 hover:shadow-glow ${
        offer.featured ? "border-primary/60 ring-1 ring-primary/40" : "border-border"
      }`}
    >
      {offer.badge && (
        <span className={`absolute top-4 left-4 z-10 rounded-full px-3 py-1 text-[11px] font-black uppercase tracking-widest ${
          offer.featured ? "bg-gradient-brand text-white" : "bg-accent/20 text-accent"
        }`}>
          {offer.badge}
        </span>
      )}
      <div className="relative aspect-[16/10] overflow-hidden">
        <img
          src={offer.image}
          alt={offer.model}
          loading={index < 2 ? "eager" : "lazy"}
          className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
        />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
        <div className="absolute bottom-3 right-3 rounded-full border border-border bg-background/80 px-3 py-1 text-[11px] font-bold backdrop-blur">
          {offer.brand}
        </div>
      </div>
      <div className="flex flex-1 flex-col gap-5 p-6">
        <div>
          <h3 className="text-xl font-black sm:text-2xl">{offer.model}</h3>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-primary sm:text-4xl">{formatPrice(offer.price)}</span>
            <span className="text-sm font-bold text-muted-foreground">ج.م</span>
          </div>
        </div>
        <ul className="grid gap-2.5">
          {offer.specs.map((s) => (
            <li key={s.label} className="flex items-start gap-3 rounded-xl border border-border/60 bg-background/40 px-3 py-2.5">
              <SpecIcon name={s.icon} />
              <div className="min-w-0 flex-1">
                <div className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">{s.label}</div>
                <div className="truncate text-sm font-bold">{s.value}</div>
              </div>
            </li>
          ))}
        </ul>
        <ul className="space-y-1.5 border-t border-border/60 pt-4 text-sm text-muted-foreground">
          {offer.highlights.map((h) => (
            <li key={h} className="flex items-start gap-2">
              <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
              <span>{h}</span>
            </li>
          ))}
        </ul>
      </div>
    </article>
  );
}

function FeatureShowcase() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6 sm:py-20">
      <SectionHeader eyebrow="الإمكانيات" title="أجهزة مصممة للأداء والتنقل" description="مواصفات موثوقة من فئات الأعمال — استقرار، سرعة، وتصميم يليق بك." />
      <div className="mt-10 grid gap-4 sm:gap-6 md:grid-cols-3">
        <FeatureBlock icon="⚡" title="أداء فائق" body="معالجات Intel Core i5 من الجيلين 11 و 12 مع رامات DDR5 و SSD NVMe لتشغيل سلس متعدد المهام." />
        <FeatureBlock icon="🎯" title="فئة الأعمال" body="أجهزة HP EliteBook و Dell Latitude — نفس الأجهزة التي تعتمدها الشركات العالمية." />
        <FeatureBlock icon="🔒" title="ضمان استبدال" body="جميع الأجهزة كسر زيرو مستوردة مع ضمان استبدال يمنحك راحة البال الكاملة." />
      </div>
    </section>
  );
}

function FeatureBlock({ icon, title, body }: { icon: string; title: string; body: string }) {
  return (
    <div className="rounded-3xl border border-border bg-gradient-card p-6 shadow-soft">
      <div className="grid h-14 w-14 place-items-center rounded-2xl bg-primary/15 text-3xl">{icon}</div>
      <h3 className="mt-5 text-lg font-black sm:text-xl">{title}</h3>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{body}</p>
    </div>
  );
}

function GallerySection({ onOpen }: { onOpen: (i: number) => void }) {
  return (
    <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6 sm:py-20">
      <SectionHeader eyebrow="معرض الصور" title="الأجهزة في الاستخدام اليومي" description="اضغط على أي صورة لتكبيرها والتنقل بينها." />
      <div className="mt-10 grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3">
        {galleryImages.map((img, i) => (
          <button
            key={img.src}
            type="button"
            onClick={() => onOpen(i)}
            className={`group relative overflow-hidden rounded-2xl border border-border bg-card shadow-soft transition hover:-translate-y-1 hover:shadow-glow ${
              i === 0 ? "col-span-2 row-span-2 md:col-span-2 md:row-span-2" : ""
            }`}
          >
            <img
              src={img.src}
              alt={img.caption}
              loading="lazy"
              className="aspect-[4/5] h-full w-full object-cover transition duration-500 group-hover:scale-105 md:aspect-auto"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/10 to-transparent opacity-90" />
            <div className="absolute bottom-0 right-0 left-0 flex items-end justify-between gap-2 p-3 text-right sm:p-4">
              <div className="text-[11px] font-bold text-foreground sm:text-sm">{img.caption}</div>
              <div className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground">
                <ZoomIcon className="h-4 w-4" />
              </div>
            </div>
          </button>
        ))}
      </div>
    </section>
  );
}

function Lightbox({ index, onClose, onPrev, onNext }: { index: number; onClose: () => void; onPrev: () => void; onNext: () => void }) {
  const img = galleryImages[index];
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 backdrop-blur-lg animate-float-in">
      <button type="button" onClick={onClose} className="absolute top-4 left-4 grid h-11 w-11 place-items-center rounded-full bg-white/10 text-white transition hover:bg-white/20" aria-label="إغلاق">
        ✕
      </button>
      <button type="button" onClick={onPrev} className="absolute right-2 top-1/2 grid h-12 w-12 -translate-y-1/2 place-items-center rounded-full bg-white/10 text-white transition hover:bg-white/20 sm:right-6" aria-label="السابق">
        <ArrowIcon className="h-5 w-5" />
      </button>
      <button type="button" onClick={onNext} className="absolute left-2 top-1/2 grid h-12 w-12 -translate-y-1/2 place-items-center rounded-full bg-white/10 text-white transition hover:bg-white/20 sm:left-6" aria-label="التالي">
        <ArrowIcon className="h-5 w-5 rotate-180" />
      </button>
      <figure className="flex max-h-full max-w-6xl flex-col items-center gap-4">
        <img src={img.src} alt={img.caption} className="max-h-[80vh] w-auto rounded-2xl object-contain shadow-glow" />
        <figcaption className="text-center text-sm text-white/80 sm:text-base">
          {img.caption} <span className="mx-2 text-white/40">•</span> {index + 1} / {galleryImages.length}
        </figcaption>
      </figure>
    </div>
  );
}

function ComparisonTable() {
  const rows = [
    { label: "المعالج", values: ["Core i5 - 12th", "Core i5 - 12th", "Core i5 - 11th", "Core i5 - 11th"] },
    { label: "الرامات", values: ["16GB DDR5", "16GB DDR5", "8GB DDR4", "8GB DDR4"] },
    { label: "التخزين", values: ["256GB NVMe", "256GB NVMe", "256GB NVMe", "256GB NVMe"] },
    { label: "الشاشة", values: ["Touch Screen", "شاشة عادية", "شاشة عادية", "شاشة عادية"] },
    { label: "الأنسب لـ", values: ["التصميم والبرمجة", "الأعمال المكتبية", "الطلاب والتنقل", "الاستخدام اليومي"] },
    { label: "السعر (ج.م)", values: ["22,500", "21,500", "18,000", "15,000"], strong: true },
  ];
  return (
    <section id="compare" className="mx-auto max-w-7xl px-4 py-14 sm:px-6 sm:py-20">
      <SectionHeader eyebrow="المقارنة" title="جدول المقارنة الكامل" description="نظرة سريعة على الفروقات بين الأجهزة الأربعة لمساعدتك في اتخاذ القرار." />
      <div className="mt-10 overflow-x-auto rounded-3xl border border-border bg-gradient-card shadow-soft">
        <table className="w-full min-w-[720px] text-right">
          <thead>
            <tr className="border-b border-border">
              <th className="p-4 text-sm font-black text-muted-foreground">المواصفة</th>
              {offers.map((o) => (
                <th key={o.id} className="p-4">
                  <div className="text-[10px] font-bold uppercase tracking-widest text-primary">{o.brand}</div>
                  <div className="mt-1 text-sm font-black leading-tight">{o.model.replace(/HP EliteBook — |Dell /, "")}</div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.label} className="border-b border-border/60 last:border-0">
                <td className="p-4 text-sm font-bold text-muted-foreground">{r.label}</td>
                {r.values.map((v, i) => (
                  <td key={i} className={`p-4 text-sm ${r.strong ? "font-black text-primary" : "font-bold"}`}>{v}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="mt-8 grid gap-4 md:grid-cols-2">
        <BenefitCard title="لماذا i5 الجيل 12 و 16GB DDR5؟" body="سرعة أعلى بنسبة 30-40% في المهام المتوازية، مثالي لمن يعمل على تصميم، برامج ثقيلة، أو محاكاة، مع مستقبل أطول للجهاز." />
        <BenefitCard title="لماذا شاشة Touch؟" body="تحكم أسرع وأدق في التطبيقات، مناسب للعروض التقديمية، الرسم، وتصفح المستندات بلمسة واحدة." />
        <BenefitCard title="لماذا الجيل 11 و 8GB؟" body="أداء ممتاز للاستخدام اليومي، البرامج المكتبية، والدراسة — مع توفير حقيقي في السعر دون التنازل عن الجودة." />
        <BenefitCard title="لماذا Dell Latitude؟" body="متانة أسطورية من فئة الأعمال، هيكل قوي يتحمل الاستخدام اليومي المكثف، بأفضل سعر في العرض." />
      </div>
    </section>
  );
}

function BenefitCard({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <h4 className="text-base font-black text-primary sm:text-lg">{title}</h4>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{body}</p>
    </div>
  );
}

function WarrantySection() {
  return (
    <section className="mx-auto max-w-7xl px-4 pb-6 sm:px-6">
      <div className="overflow-hidden rounded-3xl border border-primary/30 bg-gradient-card p-6 shadow-glow sm:p-10">
        <div className="grid gap-6 md:grid-cols-[auto_1fr] md:items-center">
          <div className="grid h-20 w-20 place-items-center rounded-3xl bg-gradient-brand text-4xl shadow-glow">🛡</div>
          <div>
            <h3 className="text-2xl font-black sm:text-3xl">حالة الأجهزة: كسر زيرو مستوردة</h3>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground sm:text-base">
              جميع الأجهزة مستوردة بحالة كسر زيرو (شبه جديدة، فُتحت العلبة فقط) وتأتي مع
              <span className="mx-1 font-bold text-primary">ضمان استبدال</span>
              يغطيك ضد أي عيب مصنعي — راحة بال كاملة مع صفقة ذكية.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

function ContactCTA() {
  return (
    <section id="contact" className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-24">
      <div className="relative overflow-hidden rounded-[2.5rem] bg-gradient-brand p-8 text-center shadow-glow sm:p-14">
        <div className="pointer-events-none absolute inset-0 opacity-30" style={{ backgroundImage: "radial-gradient(circle at 30% 20%, white, transparent 40%)" }} />
        <div className="relative">
          <div className="mb-3 text-sm font-bold uppercase tracking-widest text-white/80">للتواصل</div>
          <h2 className="text-3xl font-black leading-tight text-white sm:text-4xl">م/ خالد خطاب</h2>
          <div className="mx-auto mt-5 inline-flex items-center gap-3 rounded-full border border-white/30 bg-white/15 px-6 py-3 backdrop-blur">
            <PhoneIcon className="h-5 w-5 text-white" />
            <span className="text-lg font-black text-white ltr sm:text-xl" dir="ltr">+20 100 219 4451</span>
          </div>
          <div className="mt-6 flex items-center justify-center gap-4">
            <a
              href="tel:+201002194451"
              className="grid h-14 w-14 place-items-center rounded-full bg-white text-primary shadow-soft transition hover:scale-110"
              aria-label="اتصال هاتفي"
            >
              <PhoneIcon className="h-6 w-6" />
            </a>
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noreferrer"
              className="grid h-14 w-14 place-items-center rounded-full bg-white text-whatsapp shadow-soft transition hover:scale-110"
              aria-label="واتساب"
            >
              <WhatsAppIcon className="h-6 w-6" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border bg-background/60">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 py-8 sm:flex-row sm:px-6">
        <div className="flex items-center gap-3">
          <img src={oltaniLogo} alt="OLTANI" className="h-10 w-10 rounded-lg bg-white/5 object-contain p-1" />
          <div className="text-sm">
            <div className="font-black">OLTANI</div>
            <div className="text-xs text-muted-foreground">oltani.com</div>
          </div>
        </div>
        <div className="text-xs text-muted-foreground">© {new Date().getFullYear()} OLTANI — جميع الحقوق محفوظة.</div>
      </div>
    </footer>
  );
}


function SectionHeader({ eyebrow, title, description }: { eyebrow: string; title: string; description: string }) {
  return (
    <div className="mx-auto max-w-2xl text-center">
      <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-[11px] font-bold uppercase tracking-widest text-primary">
        {eyebrow}
      </div>
      <h2 className="mt-4 text-3xl font-black leading-tight sm:text-4xl md:text-5xl">{title}</h2>
      <p className="mt-3 text-sm leading-relaxed text-muted-foreground sm:text-base">{description}</p>
    </div>
  );
}

/* ---------- icons ---------- */

function WhatsAppIcon({ className = "" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M20.52 3.48A11.83 11.83 0 0 0 12.05 0C5.5 0 .17 5.33.17 11.88c0 2.1.55 4.14 1.6 5.94L0 24l6.35-1.66a11.88 11.88 0 0 0 5.7 1.45h.01c6.55 0 11.88-5.33 11.88-11.88 0-3.17-1.23-6.16-3.42-8.43ZM12.06 21.8h-.01a9.9 9.9 0 0 1-5.04-1.38l-.36-.21-3.77.99 1-3.67-.24-.38a9.9 9.9 0 1 1 18.35-5.27c0 5.46-4.45 9.92-9.93 9.92Zm5.44-7.42c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.16-.17.2-.35.22-.65.07-.3-.15-1.25-.46-2.38-1.47a8.9 8.9 0 0 1-1.64-2.04c-.17-.3-.02-.46.13-.6.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.03-.52-.07-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37s-1.04 1.02-1.04 2.48 1.06 2.88 1.21 3.08c.15.2 2.1 3.2 5.08 4.49.71.31 1.26.5 1.69.63.71.23 1.35.2 1.86.12.57-.09 1.76-.72 2-1.41.25-.7.25-1.29.17-1.41-.07-.13-.27-.2-.57-.35Z" />
    </svg>
  );
}

function ArrowIcon({ className = "" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M15 18l-6-6 6-6" />
    </svg>
  );
}

function PhoneIcon({ className = "" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z" />
    </svg>
  );
}


function ZoomIcon({ className = "" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <circle cx="11" cy="11" r="7" />
      <path d="M21 21l-4.3-4.3M11 8v6M8 11h6" />
    </svg>
  );
}

function SpecIcon({ name }: { name: string }) {
  const icons: Record<string, string> = { cpu: "🧠", ram: "⚡", ssd: "💾", touch: "👆", screen: "🖥", design: "✨", shield: "🛡" };
  return <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-primary/15 text-lg">{icons[name] ?? "•"}</span>;
}
