export type ThemeMeta = {
  id: string;
  name: string;
  tagline: string;
  vibe: string;
  palette: [string, string, string]; // bg, surface, accent
  tags: string[];
};

export const themes: ThemeMeta[] = [
  { id: "minimal-editorial", name: "Minimal Editorial", tagline: "Whitespace, serif, gallery calm.", vibe: "Refined & quiet", palette: ["#faf9f6", "#ffffff", "#1a1a1a"], tags: ["Serif", "Editorial", "Airy"] },
  { id: "dark-medical-pro", name: "Dark Medical Pro", tagline: "Deep slate, cyan clinical accents.", vibe: "Premium & technical", palette: ["#0b1220", "#131c2e", "#22d3ee"], tags: ["Dark", "Clinical", "Sleek"] },
  { id: "bold-brutalist", name: "Bold Brutalist", tagline: "Chunky borders, hard shadows.", vibe: "Loud & confident", palette: ["#f4f1ea", "#ffde59", "#111111"], tags: ["Brutalist", "High-contrast"] },
  { id: "glass-aurora", name: "Glass Aurora", tagline: "Translucent surfaces, aurora glow.", vibe: "Modern & luminous", palette: ["#0a0f1f", "#1b2544", "#a78bfa"], tags: ["Glass", "Gradient"] },
  { id: "warm-boutique", name: "Warm Boutique", tagline: "Cream, terracotta, gentle serifs.", vibe: "Human & inviting", palette: ["#faf3ea", "#f3e2d1", "#b25a3c"], tags: ["Warm", "Boutique"] },
  { id: "corporate-navy", name: "Corporate Navy", tagline: "Trusted enterprise navy & gold.", vibe: "Professional & structured", palette: ["#f7f8fb", "#0f1b3d", "#c9a84c"], tags: ["Corporate", "Navy"] },
  { id: "bento-modern", name: "Bento Modern", tagline: "Bento grid with mixed sizes.", vibe: "Playful & structured", palette: ["#f6f6f4", "#111111", "#00c853"], tags: ["Bento", "Grid"] },
  { id: "magazine-luxe", name: "Magazine Luxe", tagline: "Editorial hero, oversized type.", vibe: "Luxury & storytelling", palette: ["#0f0f0f", "#f5f0e0", "#c9a84c"], tags: ["Magazine", "Luxury"] },
  { id: "neon-tech", name: "Neon Tech", tagline: "Gradient neon on deep space.", vibe: "Futuristic & bold", palette: ["#05060f", "#0d1230", "#ff3ea5"], tags: ["Neon", "Tech"] },
  { id: "swiss-precision", name: "Swiss Precision", tagline: "Grid, Helvetica-like, exact.", vibe: "Rational & precise", palette: ["#ffffff", "#f2f2f2", "#e00b0b"], tags: ["Swiss", "Grid"] },
];
