import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";

function NotFoundComponent() {
  return (
    <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: "0 16px", background: "#0b1220", color: "#fff", fontFamily: "system-ui, sans-serif" }}>
      <div style={{ textAlign: "center", maxWidth: 420 }}>
        <div style={{ fontSize: 72, fontWeight: 800, letterSpacing: -2 }}>404</div>
        <h2 style={{ fontSize: 20, marginTop: 8 }}>Page not found</h2>
        <p style={{ opacity: 0.7, marginTop: 8 }}>This page doesn't exist in the UMS Dental theme selector.</p>
        <a href="/" style={{ display: "inline-block", marginTop: 20, background: "#22d3ee", color: "#0b1220", padding: "10px 18px", borderRadius: 10, textDecoration: "none", fontWeight: 600 }}>Back to selector</a>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: 16, background: "#0b1220", color: "#fff", fontFamily: "system-ui, sans-serif" }}>
      <div style={{ maxWidth: 480, textAlign: "center" }}>
        <h1 style={{ fontSize: 22, fontWeight: 700 }}>Something went wrong</h1>
        <p style={{ opacity: 0.7, marginTop: 8, fontSize: 14 }}>Try again or head back to the theme selector.</p>
        <div style={{ display: "flex", justifyContent: "center", gap: 8, marginTop: 20, flexWrap: "wrap" }}>
          <button onClick={() => { router.invalidate(); reset(); }} style={{ background: "#22d3ee", color: "#0b1220", padding: "10px 18px", borderRadius: 10, border: "none", fontWeight: 600, cursor: "pointer" }}>Try again</button>
          <a href="/" style={{ background: "transparent", color: "#fff", padding: "10px 18px", borderRadius: 10, textDecoration: "none", border: "1px solid #ffffff33" }}>Home</a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "UMS Dental — Website Theme Selector · by OLTANI" },
      { name: "description", content: "Ten design directions for the UMS Dental store, presented by OLTANI. Preview each theme, browse products, and pick the direction that fits UMS best." },
      { name: "author", content: "OLTANI" },
      { property: "og:title", content: "UMS Dental — Website Theme Selector · by OLTANI" },
      { property: "og:description", content: "Ten design directions for the UMS Dental store, presented by OLTANI. Preview each theme, browse products, and pick the direction that fits UMS best." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "UMS Dental — Website Theme Selector · by OLTANI" },
      { name: "twitter:description", content: "Ten design directions for the UMS Dental store, presented by OLTANI. Preview each theme, browse products, and pick the direction that fits UMS best." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/932439c9-4eb9-41bf-a87b-c08aa9357dc7/id-preview-c628e69c--45a17621-835f-4e00-8df1-8999a9fec7e1.lovable.app-1784204987045.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/932439c9-4eb9-41bf-a87b-c08aa9357dc7/id-preview-c628e69c--45a17621-835f-4e00-8df1-8999a9fec7e1.lovable.app-1784204987045.png" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:wght@400;500;600;700;800;900&family=Space+Grotesk:wght@300;400;500;600;700&family=DM+Serif+Display&family=Archivo+Black&family=JetBrains+Mono:wght@400;500;700&family=Cormorant+Garamond:wght@300;400;500;600;700&display=swap" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <Outlet />
    </QueryClientProvider>
  );
}
