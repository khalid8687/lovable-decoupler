import { useState } from "react";
import { Search, ShoppingBag, Star } from "lucide-react";
import { products, categories } from "@/data/products";
import { RatingBlock } from "@/components/RatingBlock";
import { BackBar } from "@/components/ThemeChrome";
import type { ThemeMeta } from "@/data/themes";
import hero from "@/assets/hero-clinic.jpg";

export default function Theme01MinimalEditorial({ theme }: { theme: ThemeMeta }) {
  const [cat, setCat] = useState<string>("all");
  const filtered = cat === "all" ? products : products.filter((p) => p.category === cat);

  return (
    <div style={{ background: "#faf9f6", color: "#1a1a1a", fontFamily: "'Cormorant Garamond', 'Playfair Display', Georgia, serif", minHeight: "100vh" }}>
      <BackBar themeName={theme.name} bg="#faf9f6" fg="#1a1a1a" border="#00000018" />

      {/* Top nav */}
      <header style={{ maxWidth: 1280, margin: "0 auto", padding: "32px 32px 20px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
        <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 26, fontWeight: 600, letterSpacing: -0.5 }}>UMS · <span style={{ fontStyle: "italic" }}>Dental</span></div>
        <nav style={{ display: "flex", gap: 28, fontSize: 14, fontFamily: "'Inter', sans-serif", letterSpacing: 0.5 }}>
          <span>Store</span><span>Journal</span><span>Brands</span><span>Contact</span>
        </nav>
        <div style={{ display: "inline-flex", gap: 12, alignItems: "center" }}>
          <Search size={18} strokeWidth={1.4} />
          <ShoppingBag size={18} strokeWidth={1.4} />
        </div>
      </header>

      {/* Hero */}
      <section style={{ maxWidth: 1280, margin: "0 auto", padding: "40px 32px 80px", display: "grid", gridTemplateColumns: "1.1fr 1fr", gap: 48, alignItems: "center" }} className="ums-t1-hero">
        <div>
          <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 11, letterSpacing: 3, textTransform: "uppercase", opacity: 0.6, marginBottom: 24 }}>Issue Nº 27 · Complete Dental Line</div>
          <h1 style={{ fontSize: "clamp(46px, 6vw, 84px)", lineHeight: 0.98, fontWeight: 500, letterSpacing: -2, margin: 0 }}>
            The catalogue,<br /><em style={{ fontWeight: 400 }}>reimagined</em> quietly.
          </h1>
          <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, lineHeight: 1.7, opacity: 0.7, marginTop: 28, maxWidth: 480 }}>
            Everything you need, curated with restraint. Endodontics, orthodontics, surgery, prosthetics — sourced from the world's most respected houses.
          </p>
        </div>
        <div style={{ aspectRatio: "4/5", overflow: "hidden", borderRadius: 4 }}>
          <img src={hero} alt="Clinic" style={{ width: "100%", height: "100%", objectFit: "cover", filter: "grayscale(15%)" }} loading="lazy" />
        </div>
      </section>
      <style>{`
        @media (max-width: 900px) { .ums-t1-hero { grid-template-columns: 1fr !important; padding-top: 20px !important; padding-bottom: 40px !important; } }
      `}</style>

      {/* Category rail */}
      <section style={{ maxWidth: 1280, margin: "0 auto", padding: "0 32px 40px", borderTop: "1px solid #00000012", borderBottom: "1px solid #00000012" }}>
        <div style={{ display: "flex", gap: 4, overflowX: "auto", padding: "20px 0", fontFamily: "'Inter', sans-serif" }}>
          {[{ slug: "all", name: "All items" }, ...categories].map((c) => (
            <button key={c.slug} onClick={() => setCat(c.slug)} style={{
              background: cat === c.slug ? "#1a1a1a" : "transparent",
              color: cat === c.slug ? "#faf9f6" : "#1a1a1a",
              border: "none", padding: "10px 20px", borderRadius: 100, fontSize: 13, cursor: "pointer", whiteSpace: "nowrap", letterSpacing: 0.3,
            }}>{c.name}</button>
          ))}
        </div>
      </section>

      {/* Product grid */}
      <section style={{ maxWidth: 1280, margin: "0 auto", padding: "56px 32px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: "48px 24px" }}>
          {filtered.map((p) => (
            <article key={p.id}>
              <div style={{ aspectRatio: "1", overflow: "hidden", background: "#ffffff", borderRadius: 2 }}>
                <img src={p.image} alt={p.name} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              </div>
              <div style={{ marginTop: 16, fontFamily: "'Inter', sans-serif" }}>
                <div style={{ fontSize: 11, letterSpacing: 1.4, textTransform: "uppercase", opacity: 0.55 }}>{p.brand}</div>
                <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 22, fontWeight: 500, letterSpacing: -0.3, margin: "6px 0 8px", lineHeight: 1.15 }}>{p.name}</h3>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", fontSize: 14 }}>
                  <span style={{ opacity: 0.75 }}>${p.price}</span>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 4, opacity: 0.6, fontSize: 12 }}>
                    <Star size={12} fill="currentColor" /> {p.rating}
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* Rating */}
      <section style={{ maxWidth: 900, margin: "0 auto", padding: "20px 32px 80px" }}>
        <RatingBlock themeId={theme.id} accent="#1a1a1a" surface="#ffffff" fg="#1a1a1a" />
      </section>

      <footer style={{ borderTop: "1px solid #00000012", padding: "32px", textAlign: "center", fontFamily: "'Inter', sans-serif", fontSize: 12, opacity: 0.55 }}>
        UMS · United Medical Supplies · Complete Dental Line
      </footer>
    </div>
  );
}
