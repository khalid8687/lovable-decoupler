import { useState } from "react";
import { Search, ShoppingCart, Zap, Star, ChevronRight } from "lucide-react";
import { products, categories } from "@/data/products";
import { RatingBlock } from "@/components/RatingBlock";
import { BackBar } from "@/components/ThemeChrome";
import type { ThemeMeta } from "@/data/themes";
import hero from "@/assets/hero-clinic.jpg";

export default function Theme02DarkMedicalPro({ theme }: { theme: ThemeMeta }) {
  const [cat, setCat] = useState("all");
  const filtered = cat === "all" ? products : products.filter((p) => p.category === cat);

  return (
    <div style={{ background: "#0b1220", color: "#e5eefc", fontFamily: "'Inter', system-ui, sans-serif", minHeight: "100vh" }}>
      <BackBar themeName={theme.name} bg="#0b1220ee" fg="#e5eefc" border="#ffffff14" />

      <header style={{ maxWidth: 1400, margin: "0 auto", padding: "22px 24px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: "linear-gradient(135deg,#22d3ee,#0284c7)", display: "grid", placeItems: "center", color: "#0b1220", fontWeight: 900 }}>U</div>
          <span style={{ fontWeight: 800, letterSpacing: 0.5 }}>UMS <span style={{ opacity: 0.5, fontWeight: 400 }}>/ Dental Pro</span></span>
        </div>
        <nav style={{ display: "flex", gap: 20, fontSize: 13, opacity: 0.75 }}>
          <span>Catalog</span><span>Brands</span><span>Deals</span><span>Support</span>
        </nav>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, background: "#131c2e", padding: "8px 12px", borderRadius: 10, border: "1px solid #ffffff14" }}>
            <Search size={14} opacity={0.6} />
            <input placeholder="Search 1,854 products" style={{ background: "transparent", border: "none", color: "#fff", fontSize: 13, outline: "none", width: 180 }} />
          </div>
          <button style={{ background: "#22d3ee", color: "#0b1220", border: "none", padding: "10px 14px", borderRadius: 10, fontWeight: 700, fontSize: 13, cursor: "pointer", display: "inline-flex", gap: 6, alignItems: "center" }}>
            <ShoppingCart size={14} /> Cart
          </button>
        </div>
      </header>

      {/* Hero */}
      <section style={{ maxWidth: 1400, margin: "0 auto", padding: "20px 24px 40px" }}>
        <div style={{ position: "relative", borderRadius: 24, overflow: "hidden", border: "1px solid #ffffff10", minHeight: 380 }}>
          <img src={hero} alt="" loading="lazy" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", opacity: 0.35 }} />
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(90deg,#0b1220 0%, #0b1220aa 55%, transparent 100%)" }} />
          <div style={{ position: "relative", padding: "48px 40px", maxWidth: 640 }}>
            <div style={{ display: "inline-flex", alignItems: "center", gap: 6, background: "#22d3ee1a", color: "#22d3ee", padding: "6px 12px", borderRadius: 100, fontSize: 11, fontWeight: 600, letterSpacing: 1.2, textTransform: "uppercase" }}>
              <Zap size={12} /> Fast dispatch · Cairo warehouse
            </div>
            <h1 style={{ fontSize: "clamp(34px, 5vw, 56px)", fontWeight: 800, lineHeight: 1.05, letterSpacing: -1.5, marginTop: 20 }}>
              The clinical toolkit,<br /><span style={{ color: "#22d3ee" }}>engineered for precision.</span>
            </h1>
            <p style={{ opacity: 0.75, fontSize: 15, lineHeight: 1.6, marginTop: 16, maxWidth: 460 }}>
              From rotary files to sterilization — every SKU curated for the modern practice.
            </p>
            <button style={{ marginTop: 24, background: "#22d3ee", color: "#0b1220", padding: "12px 20px", borderRadius: 12, border: "none", fontWeight: 700, fontSize: 14, cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 8 }}>
              Browse catalog <ChevronRight size={16} />
            </button>
          </div>
        </div>
      </section>

      {/* Category chips */}
      <section style={{ maxWidth: 1400, margin: "0 auto", padding: "0 24px 20px", display: "flex", gap: 8, overflowX: "auto" }}>
        {[{ slug: "all", name: "All" }, ...categories].map((c) => (
          <button key={c.slug} onClick={() => setCat(c.slug)} style={{
            padding: "10px 16px", borderRadius: 100, whiteSpace: "nowrap",
            background: cat === c.slug ? "#22d3ee" : "#131c2e",
            color: cat === c.slug ? "#0b1220" : "#e5eefc",
            border: `1px solid ${cat === c.slug ? "#22d3ee" : "#ffffff14"}`,
            fontSize: 13, fontWeight: 600, cursor: "pointer",
          }}>{c.name}</button>
        ))}
      </section>

      {/* Grid */}
      <section style={{ maxWidth: 1400, margin: "0 auto", padding: "20px 24px 40px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 18 }}>
          {filtered.map((p) => (
            <article key={p.id} style={{ background: "#131c2e", border: "1px solid #ffffff14", borderRadius: 16, overflow: "hidden", display: "flex", flexDirection: "column", transition: "transform .2s" }}>
              <div style={{ aspectRatio: "1", overflow: "hidden", position: "relative", background: "#0b1220" }}>
                <img src={p.image} alt={p.name} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                {p.tag && <span style={{ position: "absolute", top: 10, left: 10, background: "#22d3ee", color: "#0b1220", padding: "4px 10px", borderRadius: 100, fontSize: 10, fontWeight: 800, textTransform: "uppercase", letterSpacing: 1 }}>{p.tag}</span>}
              </div>
              <div style={{ padding: 14, flex: 1, display: "flex", flexDirection: "column" }}>
                <div style={{ fontSize: 10, textTransform: "uppercase", letterSpacing: 1.4, color: "#22d3ee", fontWeight: 700 }}>{p.brand}</div>
                <h3 style={{ fontSize: 14, fontWeight: 600, margin: "6px 0 auto", lineHeight: 1.3 }}>{p.name}</h3>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 14, paddingTop: 12, borderTop: "1px solid #ffffff10" }}>
                  <span style={{ fontSize: 18, fontWeight: 800 }}>${p.price}</span>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 4, fontSize: 12, opacity: 0.75 }}>
                    <Star size={12} fill="#fbbf24" color="#fbbf24" /> {p.rating}
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 900, margin: "0 auto", padding: "20px 24px 60px" }}>
        <RatingBlock themeId={theme.id} accent="#22d3ee" surface="#131c2e" fg="#e5eefc" />
      </section>

      <footer style={{ borderTop: "1px solid #ffffff10", padding: "24px", textAlign: "center", fontSize: 12, opacity: 0.5 }}>UMS · Complete Dental Line</footer>
    </div>
  );
}
