import { useState } from "react";
import { Star } from "lucide-react";
import { products, categories } from "@/data/products";
import { RatingBlock } from "@/components/RatingBlock";
import { BackBar } from "@/components/ThemeChrome";
import type { ThemeMeta } from "@/data/themes";

export default function Theme03BoldBrutalist({ theme }: { theme: ThemeMeta }) {
  const [cat, setCat] = useState("all");
  const filtered = cat === "all" ? products : products.filter((p) => p.category === cat);
  const BLACK = "#111111", YELLOW = "#ffde59", CREAM = "#f4f1ea";

  return (
    <div style={{ background: CREAM, color: BLACK, fontFamily: "'Archivo Black', 'Inter', system-ui, sans-serif", minHeight: "100vh" }}>
      <BackBar themeName={theme.name} bg={CREAM} fg={BLACK} border={`${BLACK}22`} />

      <header style={{ borderBottom: `4px solid ${BLACK}`, padding: "20px 24px", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
        <div style={{ fontSize: 26, letterSpacing: -1 }}>UMS DENTAL.</div>
        <nav style={{ display: "flex", gap: 16, fontFamily: "'Inter', sans-serif", fontWeight: 800, fontSize: 13, textTransform: "uppercase" }}>
          <span>Shop</span><span>Deals</span><span>Cart (0)</span>
        </nav>
      </header>

      {/* Hero — hero band */}
      <section style={{ background: YELLOW, borderBottom: `4px solid ${BLACK}`, padding: "60px 24px" }}>
        <div style={{ maxWidth: 1300, margin: "0 auto" }}>
          <div style={{ fontFamily: "'Inter', sans-serif", fontWeight: 800, fontSize: 12, letterSpacing: 2, textTransform: "uppercase" }}>Store · 2027 Catalog</div>
          <h1 style={{ fontSize: "clamp(56px, 11vw, 160px)", lineHeight: 0.85, margin: "20px 0 0", letterSpacing: -4, textTransform: "uppercase" }}>
            Loud tools.<br />Quiet clinics.
          </h1>
          <div style={{ display: "flex", gap: 12, marginTop: 32, flexWrap: "wrap", fontFamily: "'Inter', sans-serif" }}>
            <button style={{ background: BLACK, color: YELLOW, padding: "16px 24px", border: `3px solid ${BLACK}`, fontWeight: 900, textTransform: "uppercase", cursor: "pointer", boxShadow: `6px 6px 0 ${BLACK}` }}>Shop Now →</button>
            <button style={{ background: "transparent", color: BLACK, padding: "16px 24px", border: `3px solid ${BLACK}`, fontWeight: 900, textTransform: "uppercase", cursor: "pointer" }}>1,854 SKUs</button>
          </div>
        </div>
      </section>

      {/* Cats */}
      <section style={{ borderBottom: `4px solid ${BLACK}`, background: "#fff" }}>
        <div style={{ maxWidth: 1300, margin: "0 auto", display: "flex", overflowX: "auto" }}>
          {[{ slug: "all", name: "All" }, ...categories].map((c) => (
            <button key={c.slug} onClick={() => setCat(c.slug)} style={{
              padding: "18px 22px", fontFamily: "'Inter', sans-serif", fontWeight: 800, fontSize: 13, textTransform: "uppercase", whiteSpace: "nowrap",
              background: cat === c.slug ? BLACK : "transparent", color: cat === c.slug ? YELLOW : BLACK,
              border: "none", borderRight: `2px solid ${BLACK}22`, cursor: "pointer",
            }}>{c.name}</button>
          ))}
        </div>
      </section>

      {/* Grid */}
      <section style={{ maxWidth: 1300, margin: "0 auto", padding: "48px 24px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 24 }}>
          {filtered.map((p) => (
            <article key={p.id} style={{ background: "#fff", border: `3px solid ${BLACK}`, boxShadow: `6px 6px 0 ${BLACK}` }}>
              <div style={{ aspectRatio: "1", overflow: "hidden", borderBottom: `3px solid ${BLACK}` }}>
                <img src={p.image} alt={p.name} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              </div>
              <div style={{ padding: 16, fontFamily: "'Inter', sans-serif" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 11, fontWeight: 800, textTransform: "uppercase" }}>
                  <span>{p.brand}</span>
                  {p.tag && <span style={{ background: YELLOW, padding: "3px 8px", border: `2px solid ${BLACK}` }}>{p.tag}</span>}
                </div>
                <h3 style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 20, margin: "10px 0 12px", lineHeight: 1.1, letterSpacing: -0.5 }}>{p.name}</h3>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingTop: 12, borderTop: `2px dashed ${BLACK}44` }}>
                  <span style={{ fontFamily: "'Archivo Black', sans-serif", fontSize: 22 }}>${p.price}</span>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 4, fontWeight: 700 }}>
                    <Star size={13} fill={BLACK} /> {p.rating}
                  </span>
                </div>
                <button style={{ marginTop: 12, width: "100%", background: BLACK, color: YELLOW, padding: 12, fontFamily: "'Inter', sans-serif", fontWeight: 800, textTransform: "uppercase", border: "none", cursor: "pointer", fontSize: 12, letterSpacing: 1 }}>Add to cart</button>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 900, margin: "0 auto", padding: "0 24px 60px" }}>
        <RatingBlock themeId={theme.id} accent={BLACK} surface={YELLOW} fg={BLACK} />
      </section>

      <footer style={{ borderTop: `4px solid ${BLACK}`, background: BLACK, color: YELLOW, padding: "24px", textAlign: "center", fontFamily: "'Archivo Black', sans-serif", fontSize: 14, letterSpacing: 1 }}>UMS · COMPLETE DENTAL LINE · 2027</footer>
    </div>
  );
}
