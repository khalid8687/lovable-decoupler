import { useState } from "react";
import { Search, Sparkles, Star, ShoppingBag } from "lucide-react";
import { products, categories } from "@/data/products";
import { RatingBlock } from "@/components/RatingBlock";
import { BackBar } from "@/components/ThemeChrome";
import type { ThemeMeta } from "@/data/themes";

export default function Theme04GlassAurora({ theme }: { theme: ThemeMeta }) {
  const [cat, setCat] = useState("all");
  const filtered = cat === "all" ? products : products.filter((p) => p.category === cat);
  const glass: React.CSSProperties = {
    background: "rgba(255,255,255,0.06)",
    backdropFilter: "blur(18px) saturate(140%)",
    border: "1px solid rgba(255,255,255,0.12)",
  };

  return (
    <div style={{ position: "relative", background: "#0a0f1f", color: "#f4f6ff", fontFamily: "'Space Grotesk', system-ui, sans-serif", minHeight: "100vh", overflow: "hidden" }}>
      {/* Aurora blobs */}
      <div style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0 }}>
        <div style={{ position: "absolute", width: 600, height: 600, borderRadius: "50%", background: "#a78bfa", filter: "blur(120px)", opacity: 0.35, top: -200, left: -150 }} />
        <div style={{ position: "absolute", width: 700, height: 700, borderRadius: "50%", background: "#22d3ee", filter: "blur(140px)", opacity: 0.25, top: 200, right: -200 }} />
        <div style={{ position: "absolute", width: 500, height: 500, borderRadius: "50%", background: "#f472b6", filter: "blur(120px)", opacity: 0.3, bottom: -100, left: "40%" }} />
      </div>

      <div style={{ position: "relative", zIndex: 2 }}>
        <BackBar themeName={theme.name} bg="rgba(10,15,31,0.7)" fg="#f4f6ff" border="rgba(255,255,255,0.12)" />

        <header style={{ maxWidth: 1300, margin: "0 auto", padding: "22px 24px", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <div style={{ width: 34, height: 34, borderRadius: 12, background: "linear-gradient(135deg,#a78bfa,#22d3ee)" }} />
            <span style={{ fontWeight: 700, letterSpacing: 0.5 }}>UMS Dental</span>
          </div>
          <nav style={{ display: "flex", gap: 22, fontSize: 13, opacity: 0.85 }}>
            <span>Shop</span><span>Collections</span><span>Journal</span><span>Contact</span>
          </nav>
          <div style={{ ...glass, borderRadius: 100, padding: "8px 14px", display: "inline-flex", gap: 8, alignItems: "center" }}>
            <Search size={14} /><span style={{ fontSize: 12, opacity: 0.7 }}>Search</span>
          </div>
        </header>

        {/* Hero */}
        <section style={{ maxWidth: 1300, margin: "0 auto", padding: "60px 24px 40px", textAlign: "center" }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "6px 14px", ...glass, borderRadius: 100, fontSize: 12, marginBottom: 24 }}>
            <Sparkles size={13} /> New for 2027
          </div>
          <h1 style={{ fontSize: "clamp(44px, 7vw, 90px)", lineHeight: 1, fontWeight: 700, letterSpacing: -2.5, margin: 0 }}>
            Dentistry, in <span style={{ background: "linear-gradient(90deg,#a78bfa,#22d3ee,#f472b6)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>full spectrum</span>.
          </h1>
          <p style={{ fontSize: 17, opacity: 0.75, marginTop: 24, maxWidth: 620, marginInline: "auto", lineHeight: 1.55 }}>
            A translucent, luminous store built for the modern clinic. Browse 1,854 SKUs across 144 categories.
          </p>
        </section>

        {/* Cats */}
        <section style={{ maxWidth: 1300, margin: "0 auto", padding: "0 24px 30px", display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "center" }}>
          {[{ slug: "all", name: "All" }, ...categories].map((c) => (
            <button key={c.slug} onClick={() => setCat(c.slug)} style={{
              padding: "10px 18px", borderRadius: 100, fontSize: 13, fontWeight: 500, cursor: "pointer",
              background: cat === c.slug ? "linear-gradient(135deg,#a78bfa,#22d3ee)" : "rgba(255,255,255,0.06)",
              color: "#fff", border: "1px solid rgba(255,255,255,0.15)", backdropFilter: "blur(10px)",
            }}>{c.name}</button>
          ))}
        </section>

        <section style={{ maxWidth: 1300, margin: "0 auto", padding: "20px 24px 60px" }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 20 }}>
            {filtered.map((p) => (
              <article key={p.id} style={{ ...glass, borderRadius: 20, overflow: "hidden" }}>
                <div style={{ aspectRatio: "1", overflow: "hidden", position: "relative" }}>
                  <img src={p.image} alt={p.name} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                  {p.tag && <span style={{ position: "absolute", top: 10, left: 10, ...glass, borderRadius: 100, padding: "4px 10px", fontSize: 10, textTransform: "uppercase", letterSpacing: 1 }}>{p.tag}</span>}
                </div>
                <div style={{ padding: 16 }}>
                  <div style={{ fontSize: 10, opacity: 0.65, textTransform: "uppercase", letterSpacing: 1.4 }}>{p.brand}</div>
                  <h3 style={{ fontSize: 14, fontWeight: 600, margin: "6px 0 10px", lineHeight: 1.35 }}>{p.name}</h3>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span style={{ fontSize: 18, fontWeight: 700, background: "linear-gradient(90deg,#a78bfa,#22d3ee)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>${p.price}</span>
                    <span style={{ display: "inline-flex", alignItems: "center", gap: 4, fontSize: 12, opacity: 0.75 }}><Star size={12} fill="#fbbf24" color="#fbbf24" /> {p.rating}</span>
                  </div>
                  <button style={{ marginTop: 12, width: "100%", background: "linear-gradient(135deg,#a78bfa,#22d3ee)", color: "#0a0f1f", border: "none", padding: "10px", borderRadius: 10, fontWeight: 700, cursor: "pointer", display: "inline-flex", justifyContent: "center", gap: 6, alignItems: "center" }}>
                    <ShoppingBag size={14} /> Add
                  </button>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section style={{ maxWidth: 900, margin: "0 auto", padding: "0 24px 60px" }}>
          <RatingBlock themeId={theme.id} accent="#a78bfa" surface="rgba(255,255,255,0.06)" fg="#f4f6ff" />
        </section>

        <footer style={{ borderTop: "1px solid rgba(255,255,255,0.1)", padding: 24, textAlign: "center", fontSize: 12, opacity: 0.6 }}>UMS · Complete Dental Line</footer>
      </div>
    </div>
  );
}
