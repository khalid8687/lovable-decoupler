import { useState } from "react";
import { Star, Search } from "lucide-react";
import { products, categories } from "@/data/products";
import { RatingBlock } from "@/components/RatingBlock";
import { BackBar } from "@/components/ThemeChrome";
import type { ThemeMeta } from "@/data/themes";
import hero from "@/assets/hero-clinic.jpg";

export default function Theme05WarmBoutique({ theme }: { theme: ThemeMeta }) {
  const [cat, setCat] = useState("all");
  const filtered = cat === "all" ? products : products.filter((p) => p.category === cat);
  const CREAM = "#faf3ea", TERRA = "#b25a3c", INK = "#3b2a20";

  return (
    <div style={{ background: CREAM, color: INK, fontFamily: "'Cormorant Garamond', 'Playfair Display', Georgia, serif", minHeight: "100vh" }}>
      <BackBar themeName={theme.name} bg={CREAM} fg={INK} border={`${INK}22`} />

      <header style={{ maxWidth: 1300, margin: "0 auto", padding: "26px 24px", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
        <div style={{ fontFamily: "'DM Serif Display', serif", fontSize: 30, letterSpacing: -0.5 }}>UMS <span style={{ color: TERRA }}>Dental</span></div>
        <nav style={{ display: "flex", gap: 26, fontFamily: "'Inter', sans-serif", fontSize: 13, letterSpacing: 0.4 }}>
          <span>Boutique</span><span>Brands</span><span>Story</span><span>Contact</span>
        </nav>
        <Search size={18} strokeWidth={1.5} />
      </header>

      {/* Hero */}
      <section style={{ maxWidth: 1300, margin: "0 auto", padding: "20px 24px 60px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 40, alignItems: "center" }} className="t5-hero">
        <div style={{ position: "relative", aspectRatio: "1", borderRadius: 300, overflow: "hidden" }}>
          <img src={hero} alt="" loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover", filter: "sepia(15%) saturate(105%)" }} />
        </div>
        <div>
          <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 11, letterSpacing: 3, textTransform: "uppercase", color: TERRA, marginBottom: 20 }}>Est. curation · 2027</div>
          <h1 style={{ fontFamily: "'DM Serif Display', serif", fontSize: "clamp(44px, 6vw, 84px)", lineHeight: 1.02, margin: 0, letterSpacing: -1 }}>
            The warm side of clinical.
          </h1>
          <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 16, lineHeight: 1.75, opacity: 0.75, marginTop: 24, maxWidth: 460 }}>
            A boutique-style dental supply — every item chosen with care, from files to forceps. Rooted in craft, dispatched with warmth.
          </p>
        </div>
      </section>
      <style>{`@media (max-width:900px){.t5-hero{grid-template-columns:1fr!important}}`}</style>

      {/* cats */}
      <section style={{ maxWidth: 1300, margin: "0 auto", padding: "0 24px 30px" }}>
        <div style={{ display: "flex", gap: 8, overflowX: "auto", fontFamily: "'Inter', sans-serif" }}>
          {[{ slug: "all", name: "All" }, ...categories].map((c) => (
            <button key={c.slug} onClick={() => setCat(c.slug)} style={{
              padding: "10px 18px", borderRadius: 100, whiteSpace: "nowrap",
              background: cat === c.slug ? TERRA : "transparent",
              color: cat === c.slug ? CREAM : INK,
              border: `1px solid ${cat === c.slug ? TERRA : INK + "22"}`,
              fontSize: 13, cursor: "pointer",
            }}>{c.name}</button>
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 1300, margin: "0 auto", padding: "30px 24px 60px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: "40px 24px" }}>
          {filtered.map((p) => (
            <article key={p.id}>
              <div style={{ aspectRatio: "4/5", overflow: "hidden", borderRadius: 24, background: "#f3e2d1" }}>
                <img src={p.image} alt={p.name} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              </div>
              <div style={{ marginTop: 16 }}>
                <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 11, letterSpacing: 2, textTransform: "uppercase", color: TERRA }}>{p.brand}</div>
                <h3 style={{ fontFamily: "'DM Serif Display', serif", fontSize: 22, margin: "6px 0 8px", lineHeight: 1.15, letterSpacing: -0.3 }}>{p.name}</h3>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", fontFamily: "'Inter', sans-serif", fontSize: 14 }}>
                  <span>${p.price}</span>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 4, opacity: 0.7, fontSize: 12 }}>
                    <Star size={12} fill={TERRA} color={TERRA} /> {p.rating}
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 900, margin: "0 auto", padding: "0 24px 60px" }}>
        <RatingBlock themeId={theme.id} accent={TERRA} surface="#ffffff" fg={INK} />
      </section>

      <footer style={{ borderTop: `1px solid ${INK}20`, padding: 24, textAlign: "center", fontFamily: "'Inter', sans-serif", fontSize: 12, opacity: 0.6 }}>UMS · Complete Dental Line · Curated with warmth</footer>
    </div>
  );
}
