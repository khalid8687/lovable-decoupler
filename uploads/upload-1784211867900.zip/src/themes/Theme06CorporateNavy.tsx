import { useState } from "react";
import { Search, Star, ChevronRight, Award } from "lucide-react";
import { products, categories } from "@/data/products";
import { RatingBlock } from "@/components/RatingBlock";
import { BackBar } from "@/components/ThemeChrome";
import type { ThemeMeta } from "@/data/themes";

export default function Theme06CorporateNavy({ theme }: { theme: ThemeMeta }) {
  const [cat, setCat] = useState("all");
  const filtered = cat === "all" ? products : products.filter((p) => p.category === cat);
  const NAVY = "#0f1b3d", GOLD = "#c9a84c", BG = "#f7f8fb";

  return (
    <div style={{ background: BG, color: NAVY, fontFamily: "'Inter', system-ui, sans-serif", minHeight: "100vh" }}>
      <BackBar themeName={theme.name} bg={BG} fg={NAVY} border={`${NAVY}18`} />

      <div style={{ background: NAVY, color: BG, fontSize: 12, textAlign: "center", padding: "8px 12px", letterSpacing: 1 }}>
        Trusted since 1998 · Nationwide dispatch within 24 hours · Certified suppliers
      </div>

      <header style={{ maxWidth: 1300, margin: "0 auto", padding: "22px 24px", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 38, height: 38, background: NAVY, color: GOLD, display: "grid", placeItems: "center", fontWeight: 900, fontSize: 18 }}>U</div>
          <div style={{ lineHeight: 1.1 }}>
            <div style={{ fontWeight: 800, letterSpacing: 0.5 }}>UMS</div>
            <div style={{ fontSize: 11, opacity: 0.55, letterSpacing: 1 }}>DENTAL SUPPLIES</div>
          </div>
        </div>
        <nav style={{ display: "flex", gap: 24, fontSize: 13, fontWeight: 500 }}>
          <span>Catalog</span><span>Brands</span><span>Solutions</span><span>Enterprise</span><span>Support</span>
        </nav>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, background: "#fff", padding: "8px 12px", borderRadius: 6, border: `1px solid ${NAVY}18` }}>
            <Search size={14} opacity={0.5} /><span style={{ fontSize: 12, opacity: 0.55 }}>Search catalog</span>
          </div>
        </div>
      </header>

      {/* Hero split */}
      <section style={{ background: NAVY, color: BG }}>
        <div style={{ maxWidth: 1300, margin: "0 auto", padding: "72px 24px", display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: 40, alignItems: "center" }} className="t6-hero">
          <div>
            <div style={{ display: "inline-flex", alignItems: "center", gap: 6, background: `${GOLD}22`, color: GOLD, padding: "6px 12px", fontSize: 11, letterSpacing: 1.5, textTransform: "uppercase", fontWeight: 600, borderLeft: `2px solid ${GOLD}` }}>
              <Award size={12} /> Trusted by 4,000+ clinics
            </div>
            <h1 style={{ fontSize: "clamp(38px, 5vw, 62px)", lineHeight: 1.05, fontWeight: 800, letterSpacing: -1.5, marginTop: 20 }}>
              A reliable partner for every clinical procedure.
            </h1>
            <p style={{ fontSize: 16, opacity: 0.8, lineHeight: 1.65, marginTop: 20, maxWidth: 520 }}>
              End-to-end dental supply — from consumables to capital equipment. Enterprise pricing, dedicated support, transparent logistics.
            </p>
            <div style={{ display: "flex", gap: 12, marginTop: 28, flexWrap: "wrap" }}>
              <button style={{ background: GOLD, color: NAVY, padding: "14px 22px", border: "none", fontWeight: 700, fontSize: 14, cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 6 }}>Request quote <ChevronRight size={16} /></button>
              <button style={{ background: "transparent", color: BG, padding: "14px 22px", border: `1px solid ${BG}44`, fontWeight: 600, fontSize: 14, cursor: "pointer" }}>Browse catalog</button>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            {[{ k: "1,854", l: "SKUs" }, { k: "144", l: "Categories" }, { k: "24h", l: "Dispatch" }, { k: "4.9", l: "Rating" }].map((s) => (
              <div key={s.l} style={{ background: `${BG}0a`, border: `1px solid ${BG}22`, padding: 20 }}>
                <div style={{ fontSize: 32, fontWeight: 800, color: GOLD }}>{s.k}</div>
                <div style={{ fontSize: 12, opacity: 0.75, letterSpacing: 1, textTransform: "uppercase", marginTop: 4 }}>{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
      <style>{`@media (max-width:900px){.t6-hero{grid-template-columns:1fr!important}}`}</style>

      {/* Cats */}
      <section style={{ borderBottom: `1px solid ${NAVY}18`, background: "#fff" }}>
        <div style={{ maxWidth: 1300, margin: "0 auto", display: "flex", overflowX: "auto" }}>
          {[{ slug: "all", name: "All Categories" }, ...categories].map((c) => (
            <button key={c.slug} onClick={() => setCat(c.slug)} style={{
              padding: "16px 20px", background: "transparent", border: "none",
              borderBottom: cat === c.slug ? `3px solid ${GOLD}` : "3px solid transparent",
              color: NAVY, fontWeight: cat === c.slug ? 700 : 500, fontSize: 13, whiteSpace: "nowrap", cursor: "pointer",
            }}>{c.name}</button>
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 1300, margin: "0 auto", padding: "40px 24px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 20 }}>
          {filtered.map((p) => (
            <article key={p.id} style={{ background: "#fff", border: `1px solid ${NAVY}14`, borderRadius: 4, overflow: "hidden", display: "flex", flexDirection: "column" }}>
              <div style={{ aspectRatio: "4/3", overflow: "hidden", background: "#f0f2f7" }}>
                <img src={p.image} alt={p.name} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              </div>
              <div style={{ padding: 16, flex: 1, display: "flex", flexDirection: "column" }}>
                <div style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: 1.5, color: GOLD, fontWeight: 700 }}>{p.brand}</div>
                <h3 style={{ fontSize: 14, fontWeight: 600, margin: "4px 0 auto" }}>{p.name}</h3>
                <div style={{ marginTop: 14, paddingTop: 12, borderTop: `1px solid ${NAVY}12`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ fontSize: 10, opacity: 0.5 }}>Unit price</div>
                    <div style={{ fontWeight: 800, fontSize: 18 }}>${p.price}.00</div>
                  </div>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 4, fontSize: 12 }}>
                    <Star size={12} fill={GOLD} color={GOLD} /> {p.rating}
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 900, margin: "0 auto", padding: "20px 24px 60px" }}>
        <RatingBlock themeId={theme.id} accent={GOLD} surface="#ffffff" fg={NAVY} />
      </section>

      <footer style={{ background: NAVY, color: BG, padding: "32px 24px", textAlign: "center", fontSize: 12, letterSpacing: 0.5 }}>
        © UMS · Complete Dental Line · Compliance · Terms · Privacy
      </footer>
    </div>
  );
}
