import { useState } from "react";
import { Star, ArrowUpRight } from "lucide-react";
import { products, categories } from "@/data/products";
import { RatingBlock } from "@/components/RatingBlock";
import { BackBar } from "@/components/ThemeChrome";
import type { ThemeMeta } from "@/data/themes";

// Bento: mixed cell sizes for hero and featured products.
export default function Theme07BentoModern({ theme }: { theme: ThemeMeta }) {
  const [cat, setCat] = useState("all");
  const filtered = cat === "all" ? products : products.filter((p) => p.category === cat);
  const featured = products.filter((p) => p.tag === "Bestseller").slice(0, 3);
  const BG = "#f6f6f4", INK = "#111", GREEN = "#00c853";

  return (
    <div style={{ background: BG, color: INK, fontFamily: "'Space Grotesk', system-ui, sans-serif", minHeight: "100vh" }}>
      <BackBar themeName={theme.name} bg={BG} fg={INK} border={`${INK}18`} />

      <header style={{ maxWidth: 1300, margin: "0 auto", padding: "22px 24px", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
        <div style={{ fontSize: 22, fontWeight: 700, letterSpacing: -0.5 }}>ums.<span style={{ color: GREEN }}>dental</span></div>
        <nav style={{ display: "flex", gap: 20, fontSize: 13, fontWeight: 500 }}>
          <span>Shop</span><span>Brands</span><span>New</span><span>Cart</span>
        </nav>
      </header>

      {/* Bento hero */}
      <section style={{ maxWidth: 1300, margin: "0 auto", padding: "20px 24px 40px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gridAutoRows: "160px", gap: 14 }} className="bento-grid">
          <div style={{ gridColumn: "span 4", gridRow: "span 2", background: INK, color: BG, borderRadius: 24, padding: 32, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
            <div style={{ fontSize: 11, letterSpacing: 2, textTransform: "uppercase", opacity: 0.7 }}>UMS · 2027 Store</div>
            <div>
              <h1 style={{ fontSize: "clamp(38px, 5vw, 62px)", fontWeight: 700, letterSpacing: -2, lineHeight: 1, margin: 0 }}>
                Bento for<br /><span style={{ color: GREEN }}>dentists.</span>
              </h1>
              <p style={{ opacity: 0.7, marginTop: 16, fontSize: 14 }}>Everything in one clean grid.</p>
            </div>
          </div>
          <div style={{ gridColumn: "span 2", background: GREEN, borderRadius: 24, padding: 24, color: INK, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
            <div style={{ fontSize: 11, letterSpacing: 2, textTransform: "uppercase", fontWeight: 700 }}>Bestseller</div>
            <div style={{ fontSize: 22, fontWeight: 700, lineHeight: 1.1 }}>{featured[0]?.name}</div>
          </div>
          <div style={{ gridColumn: "span 2", background: "#fff", borderRadius: 24, overflow: "hidden" }}>
            <img src={featured[1]?.image} alt="" loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          </div>
          <div style={{ gridColumn: "span 2", background: "#fff", borderRadius: 24, padding: 20 }}>
            <div style={{ fontSize: 32, fontWeight: 800 }}>1,854</div>
            <div style={{ fontSize: 12, opacity: 0.6, marginTop: 4 }}>Products in stock</div>
            <div style={{ fontSize: 32, fontWeight: 800, marginTop: 16 }}>144</div>
            <div style={{ fontSize: 12, opacity: 0.6, marginTop: 4 }}>Categories</div>
          </div>
          <div style={{ gridColumn: "span 2", background: "#fff", borderRadius: 24, overflow: "hidden" }}>
            <img src={featured[2]?.image} alt="" loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          </div>
        </div>
      </section>
      <style>{`@media (max-width:800px){.bento-grid{grid-template-columns:repeat(2,1fr)!important;grid-auto-rows:140px!important}.bento-grid > *{grid-column:span 2!important}}`}</style>

      {/* Category chips */}
      <section style={{ maxWidth: 1300, margin: "0 auto", padding: "0 24px 24px", display: "flex", gap: 8, flexWrap: "wrap" }}>
        {[{ slug: "all", name: "All" }, ...categories].map((c) => (
          <button key={c.slug} onClick={() => setCat(c.slug)} style={{
            padding: "10px 16px", borderRadius: 12, whiteSpace: "nowrap",
            background: cat === c.slug ? INK : "#fff",
            color: cat === c.slug ? BG : INK,
            border: cat === c.slug ? "none" : `1px solid ${INK}18`,
            fontSize: 13, fontWeight: 500, cursor: "pointer",
          }}>{c.name}</button>
        ))}
      </section>

      <section style={{ maxWidth: 1300, margin: "0 auto", padding: "20px 24px 60px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 16 }}>
          {filtered.map((p) => (
            <article key={p.id} style={{ background: "#fff", borderRadius: 20, overflow: "hidden", display: "flex", flexDirection: "column" }}>
              <div style={{ aspectRatio: "1", overflow: "hidden", position: "relative" }}>
                <img src={p.image} alt={p.name} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                {p.tag && <span style={{ position: "absolute", top: 10, left: 10, background: GREEN, color: INK, padding: "4px 10px", borderRadius: 100, fontSize: 10, fontWeight: 700, textTransform: "uppercase" }}>{p.tag}</span>}
                <a style={{ position: "absolute", top: 10, right: 10, width: 34, height: 34, borderRadius: 12, background: "#fff", display: "grid", placeItems: "center", color: INK }}><ArrowUpRight size={16} /></a>
              </div>
              <div style={{ padding: 16 }}>
                <div style={{ fontSize: 10, textTransform: "uppercase", letterSpacing: 1.4, opacity: 0.55 }}>{p.brand}</div>
                <h3 style={{ fontSize: 14, fontWeight: 600, margin: "4px 0 10px", lineHeight: 1.3 }}>{p.name}</h3>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontSize: 18, fontWeight: 700 }}>${p.price}</span>
                  <span style={{ display: "inline-flex", gap: 4, alignItems: "center", fontSize: 12, opacity: 0.7 }}><Star size={12} fill={GREEN} color={GREEN} /> {p.rating}</span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 900, margin: "0 auto", padding: "0 24px 60px" }}>
        <RatingBlock themeId={theme.id} accent={GREEN} surface="#ffffff" fg={INK} />
      </section>

      <footer style={{ borderTop: `1px solid ${INK}12`, padding: 24, textAlign: "center", fontSize: 12, opacity: 0.6 }}>UMS · Complete Dental Line</footer>
    </div>
  );
}
