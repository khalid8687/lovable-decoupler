import { useState } from "react";
import { Star } from "lucide-react";
import { products, categories } from "@/data/products";
import { RatingBlock } from "@/components/RatingBlock";
import { BackBar } from "@/components/ThemeChrome";
import type { ThemeMeta } from "@/data/themes";
import hero from "@/assets/hero-clinic.jpg";

export default function Theme08MagazineLuxe({ theme }: { theme: ThemeMeta }) {
  const [cat, setCat] = useState("all");
  const filtered = cat === "all" ? products : products.filter((p) => p.category === cat);
  const INK = "#0f0f0f", CREAM = "#f5f0e0", GOLD = "#c9a84c";

  return (
    <div style={{ background: INK, color: CREAM, fontFamily: "'Playfair Display', 'DM Serif Display', Georgia, serif", minHeight: "100vh" }}>
      <BackBar themeName={theme.name} bg={INK} fg={CREAM} border={`${CREAM}22`} />

      <header style={{ borderBottom: `1px solid ${CREAM}22`, padding: "22px 24px", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
        <div style={{ fontSize: 12, letterSpacing: 3, textTransform: "uppercase", opacity: 0.65, fontFamily: "'Inter', sans-serif" }}>Vol. XXVII · MMXXVII</div>
        <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 30, fontWeight: 800, letterSpacing: -0.5 }}>UMS <em style={{ color: GOLD, fontWeight: 400 }}>Dental</em></div>
        <div style={{ display: "flex", gap: 20, fontSize: 12, letterSpacing: 1.5, textTransform: "uppercase", fontFamily: "'Inter', sans-serif", opacity: 0.7 }}>
          <span>Journal</span><span>Store</span><span>Atelier</span>
        </div>
      </header>

      {/* Editorial hero */}
      <section style={{ maxWidth: 1400, margin: "0 auto", padding: "40px 24px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 40, alignItems: "center" }} className="t8-hero">
        <div>
          <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 11, letterSpacing: 3, textTransform: "uppercase", color: GOLD }}>Feature · Issue 27</div>
          <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(56px, 9vw, 140px)", fontWeight: 800, lineHeight: 0.9, letterSpacing: -3, margin: "24px 0 0" }}>
            The<br /><em style={{ color: GOLD, fontWeight: 400 }}>quiet</em><br />excellence.
          </h1>
        </div>
        <div style={{ aspectRatio: "3/4", overflow: "hidden" }}>
          <img src={hero} alt="" loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover", filter: "sepia(20%) contrast(105%) brightness(85%)" }} />
        </div>
      </section>
      <style>{`@media (max-width:900px){.t8-hero{grid-template-columns:1fr!important}}`}</style>

      {/* Intro column */}
      <section style={{ maxWidth: 720, margin: "0 auto", padding: "20px 24px 60px", textAlign: "center", fontFamily: "'Inter', sans-serif", fontSize: 15, lineHeight: 1.75, opacity: 0.8, columnCount: 1 }}>
        In an industry defined by noise, UMS commits to a quieter kind of excellence — instruments chosen not for their marketing but for the way they feel in the hand. A curation that respects both the practitioner and the patient.
      </section>

      {/* Cats */}
      <section style={{ maxWidth: 1400, margin: "0 auto", padding: "0 24px 24px", borderTop: `1px solid ${CREAM}22`, borderBottom: `1px solid ${CREAM}22`, display: "flex", gap: 4, overflowX: "auto" }}>
        {[{ slug: "all", name: "All" }, ...categories].map((c) => (
          <button key={c.slug} onClick={() => setCat(c.slug)} style={{
            padding: "16px 18px", background: "transparent", border: "none",
            color: cat === c.slug ? GOLD : CREAM,
            fontFamily: "'Inter', sans-serif", fontSize: 12, letterSpacing: 1.4, textTransform: "uppercase",
            fontWeight: cat === c.slug ? 700 : 400, whiteSpace: "nowrap", cursor: "pointer",
          }}>{c.name}</button>
        ))}
      </section>

      <section style={{ maxWidth: 1400, margin: "0 auto", padding: "40px 24px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "56px 24px" }}>
          {filtered.map((p, i) => (
            <article key={p.id}>
              <div style={{ aspectRatio: i % 5 === 0 ? "3/4" : "4/5", overflow: "hidden" }}>
                <img src={p.image} alt={p.name} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover", filter: "sepia(10%)" }} />
              </div>
              <div style={{ marginTop: 16, fontFamily: "'Inter', sans-serif" }}>
                <div style={{ fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: GOLD }}>{p.brand}</div>
                <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, fontWeight: 500, margin: "8px 0 10px", lineHeight: 1.15 }}>{p.name}</h3>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", fontSize: 13, opacity: 0.75 }}>
                  <span>${p.price}</span>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}><Star size={11} fill={GOLD} color={GOLD} /> {p.rating}</span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 900, margin: "0 auto", padding: "0 24px 60px" }}>
        <RatingBlock themeId={theme.id} accent={GOLD} surface={`${CREAM}0f`} fg={CREAM} />
      </section>

      <footer style={{ borderTop: `1px solid ${CREAM}22`, padding: "28px 24px", textAlign: "center", fontFamily: "'Inter', sans-serif", fontSize: 11, letterSpacing: 2, textTransform: "uppercase", opacity: 0.55 }}>
        UMS · A journal of complete dental supply · MMXXVII
      </footer>
    </div>
  );
}
