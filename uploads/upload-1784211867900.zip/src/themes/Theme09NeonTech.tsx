import { useState } from "react";
import { Star, Zap, Terminal, ShoppingBag } from "lucide-react";
import { products, categories } from "@/data/products";
import { RatingBlock } from "@/components/RatingBlock";
import { BackBar } from "@/components/ThemeChrome";
import type { ThemeMeta } from "@/data/themes";

export default function Theme09NeonTech({ theme }: { theme: ThemeMeta }) {
  const [cat, setCat] = useState("all");
  const filtered = cat === "all" ? products : products.filter((p) => p.category === cat);
  const BG = "#05060f", GRID = "#0d1230", PINK = "#ff3ea5", CYAN = "#22d3ee", TXT = "#e4e6ff";
  const neon = `0 0 0 1px ${PINK}55, 0 0 24px ${PINK}55`;

  return (
    <div style={{ background: BG, color: TXT, fontFamily: "'JetBrains Mono', 'Space Grotesk', monospace", minHeight: "100vh", position: "relative", overflow: "hidden" }}>
      {/* Grid backdrop */}
      <div style={{ position: "fixed", inset: 0, backgroundImage: `linear-gradient(${TXT}0a 1px, transparent 1px), linear-gradient(90deg, ${TXT}0a 1px, transparent 1px)`, backgroundSize: "48px 48px", pointerEvents: "none" }} />
      <div style={{ position: "fixed", width: 500, height: 500, borderRadius: "50%", background: PINK, filter: "blur(160px)", opacity: 0.25, top: -100, right: -100, pointerEvents: "none" }} />
      <div style={{ position: "fixed", width: 500, height: 500, borderRadius: "50%", background: CYAN, filter: "blur(160px)", opacity: 0.22, bottom: -100, left: -100, pointerEvents: "none" }} />

      <div style={{ position: "relative", zIndex: 2 }}>
        <BackBar themeName={theme.name} bg="rgba(5,6,15,0.85)" fg={TXT} border={`${TXT}22`} />

        <header style={{ maxWidth: 1300, margin: "0 auto", padding: "22px 24px", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <Terminal size={18} color={CYAN} />
            <span style={{ fontWeight: 700, letterSpacing: 1 }}>UMS<span style={{ color: PINK }}>_</span>DENTAL</span>
          </div>
          <nav style={{ display: "flex", gap: 18, fontSize: 12, opacity: 0.75, textTransform: "uppercase", letterSpacing: 1 }}>
            <span>./shop</span><span>./brands</span><span>./deals</span><span>./cart</span>
          </nav>
          <div style={{ fontSize: 11, opacity: 0.5 }}>v2027.1 · online</div>
        </header>

        <section style={{ maxWidth: 1300, margin: "0 auto", padding: "40px 24px 20px" }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "6px 12px", border: `1px solid ${PINK}55`, color: PINK, borderRadius: 100, fontSize: 11, letterSpacing: 1.5, textTransform: "uppercase" }}>
            <Zap size={12} /> Live · 1,854 SKUs indexed
          </div>
          <h1 style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: "clamp(44px, 7vw, 92px)", fontWeight: 700, lineHeight: 1, letterSpacing: -2, margin: "24px 0 0" }}>
            Dental supply.<br />
            <span style={{ color: CYAN, textShadow: `0 0 30px ${CYAN}88` }}>Terminal</span> <span style={{ color: PINK, textShadow: `0 0 30px ${PINK}88` }}>velocity.</span>
          </h1>
          <p style={{ opacity: 0.7, marginTop: 20, fontSize: 15, maxWidth: 560, lineHeight: 1.6 }}>
            {`> Every product in the UMS catalog, engineered as a keyboard-first buying experience.`}
          </p>
        </section>

        <section style={{ maxWidth: 1300, margin: "0 auto", padding: "20px 24px", display: "flex", gap: 8, flexWrap: "wrap" }}>
          {[{ slug: "all", name: "all" }, ...categories].map((c) => (
            <button key={c.slug} onClick={() => setCat(c.slug)} style={{
              padding: "8px 14px", background: cat === c.slug ? PINK : "transparent", color: cat === c.slug ? BG : TXT,
              border: `1px solid ${cat === c.slug ? PINK : TXT + "22"}`, fontFamily: "inherit", fontSize: 12, cursor: "pointer",
              textTransform: "lowercase", letterSpacing: 0.5,
            }}>{c.name.toLowerCase()}</button>
          ))}
        </section>

        <section style={{ maxWidth: 1300, margin: "0 auto", padding: "20px 24px 60px" }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 16 }}>
            {filtered.map((p) => (
              <article key={p.id} style={{ background: GRID, border: `1px solid ${TXT}18`, position: "relative", display: "flex", flexDirection: "column" }}>
                <div style={{ aspectRatio: "1", overflow: "hidden", borderBottom: `1px solid ${TXT}18`, position: "relative" }}>
                  <img src={p.image} alt={p.name} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover", filter: "saturate(105%)" }} />
                  {p.tag && <span style={{ position: "absolute", top: 8, left: 8, background: PINK, color: BG, padding: "3px 8px", fontSize: 10, fontWeight: 700, letterSpacing: 1, textTransform: "uppercase" }}>{p.tag}</span>}
                </div>
                <div style={{ padding: 14, flex: 1, display: "flex", flexDirection: "column" }}>
                  <div style={{ fontSize: 10, color: CYAN, textTransform: "uppercase", letterSpacing: 1.5 }}>{p.brand}</div>
                  <h3 style={{ fontSize: 13, fontWeight: 600, margin: "6px 0 auto", fontFamily: "'Space Grotesk', sans-serif", lineHeight: 1.3 }}>{p.name}</h3>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 14, paddingTop: 10, borderTop: `1px dashed ${TXT}22` }}>
                    <span style={{ fontSize: 16, fontWeight: 700, color: PINK }}>${p.price}</span>
                    <span style={{ fontSize: 11, opacity: 0.75, display: "inline-flex", alignItems: "center", gap: 3 }}><Star size={11} fill={CYAN} color={CYAN} /> {p.rating}</span>
                  </div>
                  <button style={{ marginTop: 10, background: "transparent", color: PINK, border: `1px solid ${PINK}`, padding: 8, fontFamily: "inherit", fontSize: 12, cursor: "pointer", textTransform: "lowercase", letterSpacing: 1, display: "inline-flex", justifyContent: "center", gap: 6, alignItems: "center" }}
                    onMouseEnter={(e) => (e.currentTarget.style.boxShadow = neon)} onMouseLeave={(e) => (e.currentTarget.style.boxShadow = "none")}>
                    <ShoppingBag size={12} /> add
                  </button>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section style={{ maxWidth: 900, margin: "0 auto", padding: "0 24px 60px" }}>
          <RatingBlock themeId={theme.id} accent={PINK} surface={GRID} fg={TXT} />
        </section>

        <footer style={{ borderTop: `1px solid ${TXT}18`, padding: 24, textAlign: "center", fontSize: 11, opacity: 0.5, letterSpacing: 1 }}>{`# ums · complete dental line · 2027`}</footer>
      </div>
    </div>
  );
}
