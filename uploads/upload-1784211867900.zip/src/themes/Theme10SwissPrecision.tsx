import { useState } from "react";
import { Star } from "lucide-react";
import { products, categories } from "@/data/products";
import { RatingBlock } from "@/components/RatingBlock";
import { BackBar } from "@/components/ThemeChrome";
import type { ThemeMeta } from "@/data/themes";

export default function Theme10SwissPrecision({ theme }: { theme: ThemeMeta }) {
  const [cat, setCat] = useState("all");
  const filtered = cat === "all" ? products : products.filter((p) => p.category === cat);
  const RED = "#e00b0b", INK = "#111";

  return (
    <div style={{ background: "#fff", color: INK, fontFamily: "'Inter', 'Helvetica Neue', Helvetica, sans-serif", minHeight: "100vh" }}>
      <BackBar themeName={theme.name} bg="#ffffff" fg={INK} border={`${INK}18`} />

      <header style={{ borderBottom: `1px solid ${INK}`, padding: "18px 24px", display: "grid", gridTemplateColumns: "1fr auto 1fr", alignItems: "center", gap: 12 }}>
        <div style={{ fontSize: 12, letterSpacing: 1.5, textTransform: "uppercase" }}>UMS · Est. 1998</div>
        <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: -1 }}>UMS<span style={{ color: RED }}>.</span></div>
        <div style={{ fontSize: 12, letterSpacing: 1.5, textTransform: "uppercase", textAlign: "right" }}>1854 · 144 · 27</div>
      </header>

      {/* Swiss hero — big number, grid */}
      <section style={{ maxWidth: 1400, margin: "0 auto", padding: "60px 24px 40px", display: "grid", gridTemplateColumns: "repeat(12,1fr)", gap: 16 }} className="t10-hero">
        <div style={{ gridColumn: "span 8" }}>
          <div style={{ fontSize: 11, letterSpacing: 3, textTransform: "uppercase", opacity: 0.55 }}>№ 01 / Store</div>
          <h1 style={{ fontSize: "clamp(56px, 10vw, 168px)", fontWeight: 900, lineHeight: 0.85, letterSpacing: -6, margin: "16px 0 0" }}>
            Dental<br />supplies,<br /><span style={{ color: RED }}>precisely.</span>
          </h1>
        </div>
        <div style={{ gridColumn: "span 4", borderTop: `2px solid ${INK}`, paddingTop: 20, alignSelf: "end" }}>
          <p style={{ fontSize: 15, lineHeight: 1.6 }}>
            A grid-first storefront for a supply catalogue that respects the rigour of clinical work. No decoration. Only content.
          </p>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginTop: 24, fontSize: 12 }}>
            <div style={{ borderTop: `1px solid ${INK}`, paddingTop: 8 }}><div style={{ fontSize: 24, fontWeight: 800 }}>1854</div><div style={{ opacity: 0.55 }}>SKUs</div></div>
            <div style={{ borderTop: `1px solid ${INK}`, paddingTop: 8 }}><div style={{ fontSize: 24, fontWeight: 800 }}>144</div><div style={{ opacity: 0.55 }}>Categories</div></div>
            <div style={{ borderTop: `1px solid ${INK}`, paddingTop: 8 }}><div style={{ fontSize: 24, fontWeight: 800 }}>24h</div><div style={{ opacity: 0.55 }}>Dispatch</div></div>
            <div style={{ borderTop: `1px solid ${INK}`, paddingTop: 8 }}><div style={{ fontSize: 24, fontWeight: 800, color: RED }}>4.9</div><div style={{ opacity: 0.55 }}>Rating</div></div>
          </div>
        </div>
      </section>
      <style>{`@media (max-width:900px){.t10-hero > *{grid-column:span 12!important}}`}</style>

      {/* Cats — precise rail */}
      <section style={{ maxWidth: 1400, margin: "0 auto", padding: "20px 24px", borderTop: `2px solid ${INK}`, borderBottom: `1px solid ${INK}22`, display: "flex", gap: 0, overflowX: "auto" }}>
        {[{ slug: "all", name: "All" }, ...categories].map((c) => (
          <button key={c.slug} onClick={() => setCat(c.slug)} style={{
            padding: "12px 18px", background: cat === c.slug ? INK : "transparent",
            color: cat === c.slug ? "#fff" : INK, border: "none",
            fontSize: 12, letterSpacing: 1, textTransform: "uppercase", whiteSpace: "nowrap", cursor: "pointer",
          }}>{c.name}</button>
        ))}
      </section>

      <section style={{ maxWidth: 1400, margin: "0 auto", padding: "40px 24px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: 0, borderTop: `1px solid ${INK}`, borderLeft: `1px solid ${INK}` }}>
          {filtered.map((p) => (
            <article key={p.id} style={{ borderBottom: `1px solid ${INK}`, borderRight: `1px solid ${INK}`, display: "flex", flexDirection: "column" }}>
              <div style={{ aspectRatio: "1", overflow: "hidden", background: "#f2f2f2" }}>
                <img src={p.image} alt={p.name} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              </div>
              <div style={{ padding: 16, flex: 1, display: "flex", flexDirection: "column" }}>
                <div style={{ fontSize: 10, letterSpacing: 1.5, textTransform: "uppercase", opacity: 0.55 }}>{p.category.replace("-", " ")} · {p.brand}</div>
                <h3 style={{ fontSize: 15, fontWeight: 700, margin: "6px 0 auto", lineHeight: 1.3, letterSpacing: -0.3 }}>{p.name}</h3>
                <div style={{ borderTop: `1px solid ${INK}`, marginTop: 14, paddingTop: 10, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontSize: 18, fontWeight: 800 }}>${p.price}</span>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 4, fontSize: 12 }}><Star size={11} fill={RED} color={RED} /> {p.rating}</span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 900, margin: "0 auto", padding: "20px 24px 60px" }}>
        <RatingBlock themeId={theme.id} accent={RED} surface="#f2f2f2" fg={INK} />
      </section>

      <footer style={{ borderTop: `2px solid ${INK}`, padding: "24px", display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 12, fontSize: 11, letterSpacing: 1.5, textTransform: "uppercase" }}>
        <span>UMS · Complete Dental Line</span><span>MMXXVII · Cairo</span>
      </footer>
    </div>
  );
}
