# خطة إعادة تصميم كاملة — 10 ثيمز بريميوم لـ UMS Dental

**المشكلة اللي رصدتها:** الألوان مش راقية، مفيش إحساس فخامة 2027، وشكل عام "AI generic". هحل ده على 3 محاور: بواليت متكاملة كل ثيم بهويته، تايبوجرافي احترافي مقصود، وتفاصيل موشن/عمق تدي إحساس بريميوم حقيقي.

## المبادئ الحاكمة لكل الـ 10 ثيمز

- **بواليت واحدة قوية لكل ثيم** — لون خلفية + سطح + accent + accent ثانوي، مبنية بـ oklch للعمق
- **خطوط مقصودة** — لا Inter/Poppins افتراضي. كل ثيم بيستخدم pairing مختلف من Google Fonts محمّل في `__root.tsx`
- **موشن حقيقي** — framer-motion على الـ hero وscroll reveals وhover states، مش transitions باهتة
- **عمق بصري** — grain textures، gradients متعددة الطبقات، shadows دقيقة، borders رفيعة
- **صور جديدة أعلى جودة** — hero images محددة لكل ثيم بالـ mood الصح، وصور منتجات بخلفيات نظيفة استوديو
- **RTL-ready** حيث يناسب

## الـ 10 اتجاهات الجديدة

| # | Theme | Vibe | Palette (bg / surface / accent) | Font Pair |
|---|---|---|---|---|
| 1 | **Clinical Noir** | مستشفى بريميوم ليلي | `#0a0a0b` / `#141416` / `#e8e6df` + emerald `#00d9a3` | Fraunces + Geist |
| 2 | **Porcelain** | أبيض بورسلين، أنيق ياباني | `#f7f5f0` / `#ffffff` / `#1a1a1a` + copper `#b8734a` | Instrument Serif + Söhne-like (Manrope) |
| 3 | **Aurum Deep** | فخامة ذهبية غامقة (Aesop-like) | `#1c1a17` / `#2a2723` / `#d4b483` | Cormorant Garamond + Karla |
| 4 | **Meridian Blue** | طبي عالمي، ثقة زرقاء | `#f4f6fa` / `#ffffff` / `#0b1f3a` + electric `#2f6bff` | Space Grotesk + Inter Tight |
| 5 | **Sage Studio** | wellness هادئ، طبيعي | `#eef0e8` / `#ffffff` / `#2d3d2a` + terracotta `#c67856` | DM Serif Display + DM Sans |
| 6 | **Obsidian Glass** | zero-gravity، glass + aurora فعلية | `#050510` / rgba glass / `#7c5cff` + cyan `#22d3ee` | Syne + Inter |
| 7 | **Nordic Precision** | Scandi minimal، شبكة Swiss محسّنة | `#fafafa` / `#f0f0ee` / `#111111` + signal `#ff4d1a` | Söhne (Manrope) + JetBrains Mono captions |
| 8 | **Bazaar Modern** | شرقي معاصر، عربي + إنجليزي جنب بعض | `#faf3e8` / `#ffffff` / `#7a1c1c` + saffron `#e8a13a` | Marcellus + Cairo (Arabic) |
| 9 | **Neo-Editorial** | مجلة 2027، تايبوجرافي ضخم أبيض | `#ffffff` / `#f2efe9` / `#0a0a0a` + hot pink `#ff2d55` | Editorial New (Fraunces) + Neue Haas (Inter Tight) |
| 10 | **Titanium** | صناعي بريميوم، معدني بارد | `#e5e5e7` / `#ffffff` / `#1d1d1f` + ice `#a8b8c8` | Space Grotesk display + Geist body |

كل ثيم بيحافظ على نفس بنية الصفحة (Back bar → Hero → Categories → Products grid → Rating → Footer) ونفس مصادر البيانات (`products`, `categories`, `RatingBlock`, `incrementView`). التغيير كله بصري.

## الأصول الجديدة

- **10 hero images جديدة** بجودة استوديو (واحدة لكل ثيم بالـ mood المناسب) في `src/assets/`
- **8 صور منتجات محسّنة** بخلفيات نظيفة موحّدة (استبدال الحالي إذا لزم)
- **grain texture SVG** shared للثيمز الغامقة

## التنفيذ

```text
1. تحديث src/data/themes.ts       → البواليتات والـ tags الجديدة
2. تحميل الخطوط في __root.tsx     → link tags لكل الـ font pairs
3. توليد 10 hero images جديدة    → src/assets/hero-t01.jpg ... hero-t10.jpg
4. إعادة كتابة الـ 10 ملفات:      → src/themes/Theme01... حتى Theme10...
5. تحديث registry.tsx إذا لزم    → أسماء ما بتتغيرش
6. تحديث index.tsx (Theme Selector) → البواليتات الجديدة في الـ thumbnails
7. framer-motion على الأقل في:    → hero fade/scale، product cards stagger، category rail
```

**framer-motion** موجود بالفعل — هستخدمه بدل الـ CSS animations اليدوية.

## تفاصيل تقنية

- كل الخطوط عبر `<link>` في `src/routes/__root.tsx` head (مش `@import` في styles.css — Tailwind v4/Lightning CSS مبيحلش URLs)
- الألوان تفضل inline styles جوه كل Theme component (نفس النمط الحالي) عشان كل ثيم معزول تماماً
- الصور generated بـ `imagegen` بـ `model: "standard"` للـ hero shots (جودة أعلى)، ومحفوظة كـ `.jpg` في `src/assets/`
- Rating block و Back bar بيستقبلوا `accent/surface/fg` props زي دلوقتي — بس القيم بتاعتهم هتتحدث في كل ثيم
- Admin dashboard و tracking و localStorage — مش هتتغير

## Scope guardrails

- مش هغيّر: الـ routing، الـ admin page، الـ tracking، الـ product data، الـ RatingBlock logic
- هغيّر: كل ملفات `src/themes/*.tsx`، `themes.ts`، `__root.tsx` (فقط head للخطوط)، `index.tsx` (البواليتات في الـ thumbnails)، وأضيف hero images جديدة

## Deliverable

بعد التنفيذ هتلاقي 10 ثيمز مختلفين بشكل جذري عن دلوقتي، كل واحد بهويته الكاملة (لون + خط + موشن + hero image خاص)، وهيكون سهل عليك تعرضهم على العميل ويقارن.

**موافقتك على الخطة دي = ابدأ التنفيذ.** لو عايز تعدّل ثيم معيّن (تشيل واحد، تضيف اتجاه، تغيّر بواليت) قولي دلوقتي قبل ما أبدأ.
