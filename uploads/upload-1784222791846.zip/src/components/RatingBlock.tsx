import { useEffect, useState } from "react";
import { Star } from "lucide-react";
import { getStats, submitRating, avgRating, type ThemeStats } from "@/lib/tracking";

type Props = {
  themeId: string;
  accent?: string;
  surface?: string;
  fg?: string;
};

export function RatingBlock({ themeId, accent = "#111", surface = "#fff", fg = "#111" }: Props) {
  const [stats, setStats] = useState<ThemeStats | null>(null);
  const [hover, setHover] = useState(0);

  useEffect(() => {
    setStats(getStats(themeId));
  }, [themeId]);

  if (!stats) {
    return (
      <div style={{ minHeight: 120 }} aria-hidden />
    );
  }

  const submit = (n: number) => setStats(submitRating(themeId, n));
  const displayed = hover || stats.myRating;

  return (
    <div
      style={{
        background: surface,
        color: fg,
        border: `1px solid ${accent}22`,
        borderRadius: 16,
        padding: "24px 28px",
        display: "flex",
        flexDirection: "column",
        gap: 12,
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", flexWrap: "wrap", gap: 8 }}>
        <div style={{ fontSize: 18, fontWeight: 600 }}>Rate this theme</div>
        <div style={{ fontSize: 13, opacity: 0.7 }}>
          {stats.ratingCount > 0
            ? `${avgRating(stats).toFixed(1)} / 5 · ${stats.ratingCount} rating${stats.ratingCount > 1 ? "s" : ""}`
            : "Be the first to rate"}
        </div>
      </div>
      <div style={{ display: "flex", gap: 6 }} role="radiogroup" aria-label="Rate theme">
        {[1, 2, 3, 4, 5].map((n) => (
          <button
            key={n}
            type="button"
            aria-label={`${n} star`}
            onMouseEnter={() => setHover(n)}
            onMouseLeave={() => setHover(0)}
            onClick={() => submit(n)}
            style={{
              background: "transparent",
              border: "none",
              cursor: "pointer",
              padding: 4,
              lineHeight: 0,
            }}
          >
            <Star
              size={28}
              strokeWidth={1.5}
              style={{
                color: n <= displayed ? accent : `${fg}44`,
                fill: n <= displayed ? accent : "transparent",
                transition: "all .15s ease",
              }}
            />
          </button>
        ))}
      </div>
      {stats.myRating > 0 && (
        <div style={{ fontSize: 12, opacity: 0.7 }}>You rated this {stats.myRating}/5. Click again to update.</div>
      )}
    </div>
  );
}
