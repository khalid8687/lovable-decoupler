import { Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import oltaniLogo from "@/assets/oltani-logo.webp";

type Props = {
  themeName: string;
  bg?: string;
  fg?: string;
  border?: string;
};

/**
 * Sticky top strip shown on every theme page so the client can jump back to the selector.
 */
export function BackBar({ themeName, bg = "#ffffff", fg = "#111", border = "#00000018" }: Props) {
  return (
    <div
      style={{
        position: "sticky",
        top: 0,
        zIndex: 100,
        background: bg,
        color: fg,
        borderBottom: `1px solid ${border}`,
        backdropFilter: "saturate(140%) blur(8px)",
      }}
    >
      <div
        style={{
          maxWidth: 1400,
          margin: "0 auto",
          padding: "10px 20px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 12,
          fontSize: 13,
        }}
      >
        <Link
          to="/"
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 8,
            color: fg,
            textDecoration: "none",
            fontWeight: 600,
            letterSpacing: 0.2,
          }}
        >
          <ArrowLeft size={16} />
          Back to Theme Selector
        </Link>
        <div style={{ display: "flex", alignItems: "center", gap: 10, opacity: 0.85 }}>
          <span style={{ opacity: 0.6 }}>Previewing:</span>
          <span style={{ fontWeight: 600 }}>{themeName}</span>
          <span style={{ opacity: 0.4 }}>·</span>
          <img src={oltaniLogo} alt="OLTANI" style={{ height: 20, width: "auto" }} />
        </div>
      </div>
    </div>
  );
}
