import endodontics from "@/assets/cat-endodontics.jpg";
import orthodontics from "@/assets/cat-orthodontics.jpg";
import surgery from "@/assets/cat-surgery.jpg";
import restorative from "@/assets/cat-restorative.jpg";
import prosthetics from "@/assets/cat-prosthetics.jpg";
import diagnosis from "@/assets/cat-diagnosis.jpg";
import rotary from "@/assets/cat-rotary.jpg";
import disposables from "@/assets/cat-disposables.jpg";

export type Category = {
  slug: string;
  name: string;
  image: string;
  blurb: string;
};

export const categories: Category[] = [
  { slug: "endodontics", name: "Endodontics", image: endodontics, blurb: "Files, rotary systems, sealers & rubber dam." },
  { slug: "orthodontics", name: "Orthodontics", image: orthodontics, blurb: "Brackets, wires, elastics & pliers." },
  { slug: "perio-surgery", name: "Perio & Surgery", image: surgery, blurb: "Forceps, elevators, sutures & bone tools." },
  { slug: "restorative", name: "Restorative", image: restorative, blurb: "Composites, adhesives & finishing." },
  { slug: "prosthetics", name: "Prosthetics", image: prosthetics, blurb: "Impression materials, trays & articulators." },
  { slug: "diagnosis", name: "Diagnosis", image: diagnosis, blurb: "Mirrors, explorers & probes." },
  { slug: "rotary", name: "Rotary Instruments", image: rotary, blurb: "Burs, discs & handpieces." },
  { slug: "disposables", name: "Sterilization & Disposables", image: disposables, blurb: "Gloves, pouches, masks & barriers." },
];

export type Product = {
  id: string;
  name: string;
  category: string;
  brand: string;
  price: number;
  rating: number;
  reviews: number;
  image: string;
  tag?: "New" | "Bestseller" | "Sale";
  description: string;
};

export const products: Product[] = [
  // Endodontics (5)
  { id: "e1", name: "Protaper Gold Rotary Files – Assorted", category: "endodontics", brand: "Dentsply", price: 89, rating: 4.8, reviews: 128, image: endodontics, tag: "Bestseller", description: "Heat-treated NiTi rotary files with superior flexibility for curved canals." },
  { id: "e2", name: "K-Files Stainless Steel 25mm", category: "endodontics", brand: "MANI", price: 12, rating: 4.7, reviews: 342, image: endodontics, description: "Precision K-files for canal exploration and shaping. Assorted sizes." },
  { id: "e3", name: "Gutta Percha Points .04 Taper", category: "endodontics", brand: "META", price: 18, rating: 4.6, reviews: 96, image: endodontics, description: "Radiopaque gutta percha points, color-coded, 60 per box." },
  { id: "e4", name: "AH Plus Root Canal Sealer", category: "endodontics", brand: "Dentsply", price: 62, rating: 4.9, reviews: 210, image: endodontics, tag: "Bestseller", description: "Gold-standard epoxy-amine sealer with excellent radiopacity." },
  { id: "e5", name: "Rubber Dam Kit Complete", category: "endodontics", brand: "Hygenic", price: 74, rating: 4.5, reviews: 54, image: endodontics, description: "Frame, punch, forceps, clamps and 36 dam sheets." },
  // Orthodontics
  { id: "o1", name: "MBT Bracket System 0.022", category: "orthodontics", brand: "American Ortho", price: 45, rating: 4.7, reviews: 88, image: orthodontics, tag: "New", description: "Full-arch MBT prescription metal brackets with hooks on 3,4,5." },
  { id: "o2", name: "NiTi Archwire Round 0.014", category: "orthodontics", brand: "Ormco", price: 9, rating: 4.6, reviews: 240, image: orthodontics, description: "Superelastic nickel-titanium archwire, pack of 10." },
  { id: "o3", name: "Power Chain Elastics Clear", category: "orthodontics", brand: "3M Unitek", price: 14, rating: 4.4, reviews: 71, image: orthodontics, description: "Continuous power chain for space closure. 15 ft spool." },
  { id: "o4", name: "Weingart Utility Plier", category: "orthodontics", brand: "Hu-Friedy", price: 128, rating: 4.9, reviews: 44, image: orthodontics, tag: "Bestseller", description: "Serrated tips for archwire placement and adjustment." },
  { id: "o5", name: "Molar Bands Preformed Set", category: "orthodontics", brand: "American Ortho", price: 38, rating: 4.5, reviews: 62, image: orthodontics, description: "Preformed molar bands with buccal tubes, assorted sizes." },
  // Perio & Surgery
  { id: "p1", name: "Extraction Forceps #150 Upper", category: "perio-surgery", brand: "Hu-Friedy", price: 96, rating: 4.8, reviews: 118, image: surgery, tag: "Bestseller", description: "Universal upper anterior extraction forceps, German steel." },
  { id: "p2", name: "Periosteal Elevator #9 Molt", category: "perio-surgery", brand: "Hu-Friedy", price: 42, rating: 4.7, reviews: 89, image: surgery, description: "Double-ended periosteal elevator for flap reflection." },
  { id: "p3", name: "Silk Suture 3-0 with Needle", category: "perio-surgery", brand: "Ethicon", price: 22, rating: 4.6, reviews: 156, image: surgery, description: "Non-absorbable braided silk sutures, 12 per box." },
  { id: "p4", name: "Bone File Miller #12", category: "perio-surgery", brand: "Nordent", price: 54, rating: 4.5, reviews: 33, image: surgery, description: "Precision bone file for socket contouring." },
  { id: "p5", name: "Scalpel Handle #3 with Blades", category: "perio-surgery", brand: "Swann-Morton", price: 28, rating: 4.7, reviews: 74, image: surgery, description: "Stainless handle plus 20 sterile #15 blades." },
  // Restorative
  { id: "r1", name: "Filtek Universal Composite Syringe", category: "restorative", brand: "3M", price: 68, rating: 4.9, reviews: 302, image: restorative, tag: "Bestseller", description: "Single-shade nanocomposite matching all VITA shades." },
  { id: "r2", name: "Scotchbond Universal Adhesive", category: "restorative", brand: "3M", price: 84, rating: 4.8, reviews: 218, image: restorative, description: "Single-bottle bonding for all etch techniques." },
  { id: "r3", name: "Sectional Matrix System Kit", category: "restorative", brand: "Palodent V3", price: 156, rating: 4.9, reviews: 91, image: restorative, tag: "New", description: "Matrices, rings and wedges for perfect contact points." },
  { id: "r4", name: "Ionomer Cement GC Fuji IX", category: "restorative", brand: "GC", price: 44, rating: 4.6, reviews: 132, image: restorative, description: "High-strength glass ionomer for posterior restorations." },
  { id: "r5", name: "Finishing & Polishing Discs", category: "restorative", brand: "Sof-Lex", price: 32, rating: 4.5, reviews: 87, image: restorative, description: "Four-grit disc system for composite finishing." },
  // Prosthetics
  { id: "pr1", name: "Aquasil Ultra+ Impression Material", category: "prosthetics", brand: "Dentsply", price: 118, rating: 4.8, reviews: 76, image: prosthetics, description: "Fast-set VPS light body cartridges, 4-pack." },
  { id: "pr2", name: "Perforated Impression Trays Set", category: "prosthetics", brand: "Directa", price: 46, rating: 4.6, reviews: 58, image: prosthetics, description: "Metal perforated trays, upper and lower, all sizes." },
  { id: "pr3", name: "Alginate Type II Fast Set", category: "prosthetics", brand: "Kromopan", price: 24, rating: 4.5, reviews: 190, image: prosthetics, description: "Chromatic alginate with color change indicator." },
  { id: "pr4", name: "Bite Registration Silicone", category: "prosthetics", brand: "3M", price: 58, rating: 4.7, reviews: 42, image: prosthetics, description: "Fast-setting VPS for precise bite records." },
  { id: "pr5", name: "Articulator Adjustable Semi", category: "prosthetics", brand: "Bio-Art", price: 240, rating: 4.8, reviews: 21, image: prosthetics, tag: "New", description: "Semi-adjustable articulator with facebow compatibility." },
  // Diagnosis
  { id: "d1", name: "Mouth Mirror #4 Front Surface", category: "diagnosis", brand: "Hu-Friedy", price: 16, rating: 4.7, reviews: 410, image: diagnosis, tag: "Bestseller", description: "Rhodium-coated front surface mirror, distortion-free." },
  { id: "d2", name: "Explorer #23 Shepherd Hook", category: "diagnosis", brand: "Hu-Friedy", price: 22, rating: 4.8, reviews: 265, image: diagnosis, description: "Classic shepherd hook explorer for caries detection." },
  { id: "d3", name: "Periodontal Probe UNC-15", category: "diagnosis", brand: "Hu-Friedy", price: 28, rating: 4.8, reviews: 178, image: diagnosis, description: "Millimeter-marked probe for pocket depth measurement." },
  { id: "d4", name: "Cotton Pliers Locking", category: "diagnosis", brand: "Nordent", price: 18, rating: 4.6, reviews: 92, image: diagnosis, description: "Locking cotton pliers with serrated tips." },
  { id: "d5", name: "Basic Exam Kit Cassette", category: "diagnosis", brand: "Hu-Friedy", price: 64, rating: 4.7, reviews: 66, image: diagnosis, description: "Mirror, explorer, probe and pliers in a sterilization cassette." },
  // Rotary
  { id: "ro1", name: "Diamond Bur Kit FG Assorted", category: "rotary", brand: "Komet", price: 48, rating: 4.7, reviews: 154, image: rotary, description: "10 assorted diamond burs for crown prep and finishing." },
  { id: "ro2", name: "High-Speed Handpiece LED", category: "rotary", brand: "NSK", price: 420, rating: 4.9, reviews: 88, image: rotary, tag: "Bestseller", description: "Titanium body, LED optics, quattro water spray." },
  { id: "ro3", name: "Contra-Angle Low-Speed 1:1", category: "rotary", brand: "W&H", price: 285, rating: 4.8, reviews: 62, image: rotary, description: "Push-button chuck, external spray, autoclavable." },
  { id: "ro4", name: "Carbide Bur Round #4 Pack", category: "rotary", brand: "SS White", price: 26, rating: 4.6, reviews: 210, image: rotary, description: "Precision carbide burs for caries removal, 10-pack." },
  { id: "ro5", name: "Polishing Disc Mandrel Set", category: "rotary", brand: "Kerr", price: 34, rating: 4.5, reviews: 44, image: rotary, description: "Mandrels and polishing wheels for composite finishing." },
  // Disposables
  { id: "ds1", name: "Nitrile Exam Gloves Blue 100ct", category: "disposables", brand: "Halyard", price: 14, rating: 4.7, reviews: 520, image: disposables, tag: "Sale", description: "Powder-free nitrile, textured fingertips, all sizes." },
  { id: "ds2", name: "Self-Seal Sterilization Pouches", category: "disposables", brand: "Sultan", price: 22, rating: 4.6, reviews: 188, image: disposables, description: "200 pouches, color-change indicator, multiple sizes." },
  { id: "ds3", name: "Level 3 Surgical Masks 50ct", category: "disposables", brand: "Medicom", price: 18, rating: 4.5, reviews: 340, image: disposables, description: "ASTM Level 3, earloop, high fluid resistance." },
  { id: "ds4", name: "Barrier Film Roll 4x6", category: "disposables", brand: "Pinnacle", price: 32, rating: 4.6, reviews: 96, image: disposables, description: "1200 perforated sheets for surface protection." },
  { id: "ds5", name: "Patient Bibs 3-Ply 500ct", category: "disposables", brand: "Crosstex", price: 28, rating: 4.4, reviews: 152, image: disposables, description: "Poly-backed tissue bibs, absorbent and comfortable." },
];

export const featured = products.filter((p) => p.tag === "Bestseller" || p.tag === "New").slice(0, 8);
