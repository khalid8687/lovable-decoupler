export type ThemeMeta = {
  id: string;
  name: string;
  tagline: string;
  vibe: string;
  palette: [string, string, string]; // bg, surface, accent
  tags: string[];
};

// IDs are preserved from the original set so localStorage stats (views/likes/ratings) survive.
// Everything else (name, palette, vibe) is fully re-designed for a premium 2027 feel.
export const themes: ThemeMeta[] = [
  { id: "minimal-editorial", name: "Clinical Noir",       tagline: "Nocturnal precision, editorial calm.",        vibe: "Nocturnal precision",  palette: ["#0a0a0b", "#141416", "#e8e6df"], tags: ["Dark", "Editorial", "Cinematic"] },
  { id: "dark-medical-pro",  name: "Porcelain",           tagline: "Japanese calm on bone-white porcelain.",       vibe: "Porcelain calm",       palette: ["#f7f5f0", "#ffffff", "#b8734a"], tags: ["Light", "Wabi-sabi", "Serif"] },
  { id: "bold-brutalist",    name: "Aurum Deep",          tagline: "Warm amber lit apothecary luxury.",            vibe: "Apothecary warmth",    palette: ["#1c1a17", "#2a2723", "#d4b483"], tags: ["Luxury", "Warm", "Boutique"] },
  { id: "glass-aurora",      name: "Meridian Blue",       tagline: "Global medical trust, electric blue.",         vibe: "Meridian trust",       palette: ["#eef2f8", "#ffffff", "#0b1f3a"], tags: ["Corporate", "Blue", "Modern"] },
  { id: "warm-boutique",     name: "Sage Studio",         tagline: "Botanical wellness, quiet greens.",            vibe: "Botanical wellness",   palette: ["#eef0e8", "#ffffff", "#2d3d2a"], tags: ["Sage", "Wellness", "Natural"] },
  { id: "corporate-navy",    name: "Obsidian Glass",      tagline: "Aurora glass on obsidian sky.",                vibe: "Obsidian aurora",      palette: ["#050510", "#0d0d22", "#7c5cff"], tags: ["Glass", "Aurora", "Futuristic"] },
  { id: "bento-modern",      name: "Nordic Precision",    tagline: "Scandi grid, signal-orange restraint.",        vibe: "Nordic precision",     palette: ["#fafafa", "#f0f0ee", "#ff4d1a"], tags: ["Minimal", "Scandi", "Grid"] },
  { id: "magazine-luxe",     name: "Bazaar Modern",       tagline: "Contemporary Arabesque, saffron & bone.",      vibe: "Contemporary Arabesque", palette: ["#faf3e8", "#ffffff", "#7a1c1c"], tags: ["Arabic", "Contemporary", "Warm"] },
  { id: "neon-tech",         name: "Neo-Editorial",       tagline: "Oversized display type, hot pink accent.",     vibe: "Neo-editorial",        palette: ["#f4f1eb", "#ffffff", "#ff2d55"], tags: ["Magazine", "Typography", "Bold"] },
  { id: "swiss-precision",   name: "Titanium",            tagline: "Cold metal industrial, Apple-grade polish.",   vibe: "Titanium polish",      palette: ["#e5e5e7", "#ffffff", "#1d1d1f"], tags: ["Industrial", "Metallic", "Premium"] },
];
