// LocalStorage-based tracking for theme views, likes and ratings.
// Safe on SSR — every function guards against missing window.

const KEY = "ums_theme_stats_v1";

export type ThemeStats = {
  views: number;
  likes: number;
  liked: boolean;
  ratingSum: number;
  ratingCount: number;
  myRating: number; // 0 = none
};

export type StatsMap = Record<string, ThemeStats>;

const empty = (): ThemeStats => ({
  views: 0,
  likes: 0,
  liked: false,
  ratingSum: 0,
  ratingCount: 0,
  myRating: 0,
});

function read(): StatsMap {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as StatsMap) : {};
  } catch {
    return {};
  }
}

function write(map: StatsMap) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(map));
  } catch {
    /* ignore quota */
  }
}

export function getStats(themeId: string): ThemeStats {
  const map = read();
  return { ...empty(), ...(map[themeId] ?? {}) };
}

export function getAllStats(): StatsMap {
  return read();
}

export function incrementView(themeId: string): ThemeStats {
  const map = read();
  const cur = { ...empty(), ...(map[themeId] ?? {}) };
  cur.views += 1;
  map[themeId] = cur;
  write(map);
  return cur;
}

export function toggleLike(themeId: string): ThemeStats {
  const map = read();
  const cur = { ...empty(), ...(map[themeId] ?? {}) };
  if (cur.liked) {
    cur.liked = false;
    cur.likes = Math.max(0, cur.likes - 1);
  } else {
    cur.liked = true;
    cur.likes += 1;
  }
  map[themeId] = cur;
  write(map);
  return cur;
}

export function submitRating(themeId: string, stars: number): ThemeStats {
  const map = read();
  const cur = { ...empty(), ...(map[themeId] ?? {}) };
  if (cur.myRating > 0) {
    cur.ratingSum = Math.max(0, cur.ratingSum - cur.myRating);
    cur.ratingCount = Math.max(0, cur.ratingCount - 1);
  }
  cur.myRating = stars;
  cur.ratingSum += stars;
  cur.ratingCount += 1;
  map[themeId] = cur;
  write(map);
  return cur;
}

export function resetAll() {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(KEY);
}

export function avgRating(s: ThemeStats): number {
  return s.ratingCount > 0 ? s.ratingSum / s.ratingCount : 0;
}
