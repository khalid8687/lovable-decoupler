import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Lock, Trash2, ArrowLeft, Eye, Heart, Star } from "lucide-react";
import { themes } from "@/data/themes";
import { getAllStats, avgRating, resetAll, type StatsMap } from "@/lib/tracking";

const ADMIN_PASSWORD = "ums2027";

export const Route = createFileRoute("/admin-ums")({
  head: () => ({ meta: [{ title: "Admin · UMS Theme Selector" }, { name: "robots", content: "noindex" }] }),
  component: AdminPage,
});

function AdminPage() {
  const [entered, setEntered] = useState("");
  const [ok, setOk] = useState(false);
  const [error, setError] = useState("");
  const [stats, setStats] = useState<StatsMap>({});

  useEffect(() => {
    if (ok) setStats(getAllStats());
  }, [ok]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (entered === ADMIN_PASSWORD) {
      setOk(true);
      setError("");
    } else {
      setError("Incorrect password.");
    }
  };

  const reset = () => {
    if (window.confirm("Reset all analytics? This cannot be undone.")) {
      resetAll();
      setStats(getAllStats());
    }
  };

  if (!ok) {
    return (
      <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: 16, background: "#0b1220", color: "#fff", fontFamily: "'Inter', system-ui, sans-serif" }}>
        <form onSubmit={submit} style={{ width: "100%", maxWidth: 380, background: "#131c2e", border: "1px solid #ffffff14", borderRadius: 20, padding: 32 }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
            <div style={{ width: 40, height: 40, borderRadius: 12, background: "#22d3ee1a", display: "grid", placeItems: "center", color: "#22d3ee" }}>
              <Lock size={18} />
            </div>
            <div>
              <div style={{ fontWeight: 700, fontSize: 16 }}>Admin Access</div>
              <div style={{ fontSize: 12, opacity: 0.6 }}>UMS Theme Selector</div>
            </div>
          </div>
          <label style={{ display: "block", fontSize: 12, opacity: 0.7, marginBottom: 8 }}>Password</label>
          <input
            type="password"
            value={entered}
            onChange={(e) => setEntered(e.target.value)}
            autoFocus
            style={{ width: "100%", padding: "12px 14px", background: "#0b1220", border: "1px solid #ffffff20", borderRadius: 10, color: "#fff", fontSize: 14 }}
          />
          {error && <div style={{ color: "#f87171", fontSize: 12, marginTop: 10 }}>{error}</div>}
          <button type="submit" style={{ marginTop: 18, width: "100%", padding: "12px 16px", background: "#22d3ee", color: "#0b1220", border: "none", borderRadius: 10, fontWeight: 700, cursor: "pointer" }}>
            Enter
          </button>
          <Link to="/" style={{ display: "inline-flex", alignItems: "center", gap: 6, marginTop: 16, fontSize: 12, opacity: 0.65, color: "#fff" }}>
            <ArrowLeft size={12} /> Back to selector
          </Link>
        </form>
      </div>
    );
  }

  const rows = themes.map((t, i) => {
    const s = stats[t.id];
    return {
      i: i + 1,
      id: t.id,
      name: t.name,
      views: s?.views ?? 0,
      likes: s?.likes ?? 0,
      avg: s ? avgRating(s) : 0,
      count: s?.ratingCount ?? 0,
    };
  });
  const totalViews = rows.reduce((a, r) => a + r.views, 0);
  const totalLikes = rows.reduce((a, r) => a + r.likes, 0);
  const totalRatings = rows.reduce((a, r) => a + r.count, 0);

  const topByViews = [...rows].sort((a, b) => b.views - a.views);
  const topByLikes = [...rows].sort((a, b) => b.likes - a.likes);
  const topByRating = [...rows].filter((r) => r.count > 0).sort((a, b) => b.avg - a.avg);

  return (
    <div style={{ minHeight: "100vh", background: "#0b1220", color: "#fff", fontFamily: "'Inter', system-ui, sans-serif" }}>
      <header style={{ maxWidth: 1200, margin: "0 auto", padding: "24px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
        <div>
          <div style={{ fontSize: 12, letterSpacing: 2, textTransform: "uppercase", opacity: 0.55 }}>UMS · OLTANI</div>
          <h1 style={{ fontSize: 26, fontWeight: 800, margin: "4px 0 0" }}>Analytics Dashboard</h1>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <Link to="/" style={{ padding: "10px 14px", border: "1px solid #ffffff22", borderRadius: 10, color: "#fff", textDecoration: "none", fontSize: 13 }}>Selector</Link>
          <button onClick={reset} style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "10px 14px", background: "#ef4444", color: "#fff", border: "none", borderRadius: 10, cursor: "pointer", fontSize: 13, fontWeight: 600 }}>
            <Trash2 size={14} /> Reset data
          </button>
        </div>
      </header>

      <section style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px 24px", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px,1fr))", gap: 12 }}>
        <Stat label="Total views" value={totalViews} icon={<Eye size={16} />} color="#22d3ee" />
        <Stat label="Total likes" value={totalLikes} icon={<Heart size={16} />} color="#f472b6" />
        <Stat label="Total ratings" value={totalRatings} icon={<Star size={16} />} color="#fbbf24" />
        <Stat label="Themes live" value={themes.length} icon={<Lock size={16} />} color="#a78bfa" />
      </section>

      <section style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px 40px" }}>
        <div style={{ background: "#131c2e", border: "1px solid #ffffff14", borderRadius: 16, overflow: "hidden" }}>
          <div style={{ padding: "16px 20px", borderBottom: "1px solid #ffffff10", fontWeight: 700 }}>All themes</div>
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14, minWidth: 640 }}>
              <thead>
                <tr style={{ textAlign: "left", opacity: 0.6, fontSize: 12, textTransform: "uppercase", letterSpacing: 1 }}>
                  <th style={th}>#</th>
                  <th style={th}>Theme</th>
                  <th style={{ ...th, textAlign: "right" }}>Views</th>
                  <th style={{ ...th, textAlign: "right" }}>Likes</th>
                  <th style={{ ...th, textAlign: "right" }}>Avg rating</th>
                  <th style={{ ...th, textAlign: "right" }}>Ratings</th>
                  <th style={th}></th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id} style={{ borderTop: "1px solid #ffffff08" }}>
                    <td style={td}>{String(r.i).padStart(2, "0")}</td>
                    <td style={{ ...td, fontWeight: 600 }}>{r.name}</td>
                    <td style={{ ...td, textAlign: "right" }}>{r.views}</td>
                    <td style={{ ...td, textAlign: "right" }}>{r.likes}</td>
                    <td style={{ ...td, textAlign: "right" }}>{r.avg > 0 ? r.avg.toFixed(2) : "—"}</td>
                    <td style={{ ...td, textAlign: "right" }}>{r.count}</td>
                    <td style={{ ...td, textAlign: "right" }}>
                      <Link to="/theme/$id" params={{ id: r.id }} style={{ color: "#22d3ee", fontSize: 12, textDecoration: "none" }}>Open →</Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px,1fr))", gap: 16, marginTop: 24 }}>
          <Leaderboard title="Most viewed" rows={topByViews.slice(0, 5).map(r => ({ name: r.name, value: `${r.views} views` }))} />
          <Leaderboard title="Most liked" rows={topByLikes.slice(0, 5).map(r => ({ name: r.name, value: `${r.likes} likes` }))} />
          <Leaderboard title="Top rated" rows={topByRating.slice(0, 5).map(r => ({ name: r.name, value: `${r.avg.toFixed(1)} · ${r.count}` }))} />
        </div>
      </section>

      <footer style={{ padding: "24px", textAlign: "center", fontSize: 12, opacity: 0.5 }}>
        Data is stored per-browser (localStorage). Reset any time.
      </footer>
    </div>
  );
}

const th: React.CSSProperties = { padding: "12px 16px", fontWeight: 500 };
const td: React.CSSProperties = { padding: "14px 16px" };

function Stat({ label, value, icon, color }: { label: string; value: number; icon: React.ReactNode; color: string }) {
  return (
    <div style={{ background: "#131c2e", border: "1px solid #ffffff14", borderRadius: 16, padding: 18 }}>
      <div style={{ display: "inline-flex", alignItems: "center", gap: 8, color, fontSize: 12, textTransform: "uppercase", letterSpacing: 1.2, opacity: 0.9 }}>{icon} {label}</div>
      <div style={{ fontSize: 30, fontWeight: 800, marginTop: 6 }}>{value.toLocaleString()}</div>
    </div>
  );
}

function Leaderboard({ title, rows }: { title: string; rows: { name: string; value: string }[] }) {
  return (
    <div style={{ background: "#131c2e", border: "1px solid #ffffff14", borderRadius: 16, padding: 20 }}>
      <div style={{ fontSize: 12, letterSpacing: 1.4, textTransform: "uppercase", opacity: 0.6, marginBottom: 12 }}>{title}</div>
      {rows.length === 0 ? (
        <div style={{ fontSize: 13, opacity: 0.5 }}>No data yet.</div>
      ) : (
        rows.map((r, i) => (
          <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderTop: i === 0 ? "none" : "1px solid #ffffff08", fontSize: 14 }}>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 10 }}>
              <span style={{ opacity: 0.45, fontSize: 12, minWidth: 18 }}>{i + 1}.</span>
              {r.name}
            </span>
            <span style={{ opacity: 0.75, fontSize: 12 }}>{r.value}</span>
          </div>
        ))
      )}
    </div>
  );
}
