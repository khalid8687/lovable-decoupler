import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Heart, Star, ArrowUpRight, ShieldCheck, Eye } from "lucide-react";
import { themes } from "@/data/themes";
import { getAllStats, toggleLike, avgRating, type StatsMap } from "@/lib/tracking";
import oltaniLogo from "@/assets/oltani-logo.webp";
import umsLogo from "@/assets/ums-logo.jpg";

export const Route = createFileRoute("/")({
  component: SelectorPage,
});

function SelectorPage() {
  const [stats, setStats] = useState<StatsMap>({});

  useEffect(() => {
    setStats(getAllStats());
    const onFocus = () => setStats(getAllStats());
    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, []);

  const like = (id: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleLike(id);
    setStats(getAllStats());
  };

  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(180deg,#050914 0%, #0a1024 55%, #05060f 100%)", color: "#f4f6ff", fontFamily: "'Inter', system-ui, sans-serif" }}>
      <style>{`
        .ums-hero-bg { position:absolute; inset:0; overflow:hidden; pointer-events:none; }
        .ums-hero-bg::before, .ums-hero-bg::after { content:''; position:absolute; border-radius:50%; filter:blur(120px); opacity:.5; }
        .ums-hero-bg::before { width:520px; height:520px; background:#7c5cff; top:-160px; left:-120px; }
        .ums-hero-bg::after { width:600px; height:600px; background:#00d4ff; bottom:-200px; right:-160px; opacity:.35; }
        .theme-card { transition: transform .35s ease, box-shadow .35s ease, border-color .35s ease; }
        .theme-card:hover { transform: translateY(-6px); border-color:#ffffff33; box-shadow: 0 30px 60px -20px rgba(0,0,0,.6); }
      `}</style>

      {/* Top bar */}
      <header style={{ position: "relative", zIndex: 5, padding: "20px 24px", display: "flex", alignItems: "center", justifyContent: "space-between", maxWidth: 1400, margin: "0 auto", flexWrap: "wrap", gap: 16 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <img src={oltaniLogo} alt="OLTANI" style={{ height: 46, width: "auto" }} />
          <div style={{ borderLeft: "1px solid #ffffff20", paddingLeft: 12, lineHeight: 1.1 }}>
            <div style={{ fontSize: 11, letterSpacing: 2, opacity: 0.55, textTransform: "uppercase" }}>Presented by</div>
            <div style={{ fontSize: 15, fontWeight: 700, letterSpacing: 0.5 }}>OLTANI</div>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span style={{ fontSize: 12, opacity: 0.6 }}>For</span>
          <img src={umsLogo} alt="UMS Dental" style={{ height: 44, width: 44, borderRadius: "50%", objectFit: "cover" }} />
          <div style={{ lineHeight: 1.1 }}>
            <div style={{ fontSize: 14, fontWeight: 700 }}>UMS Dental</div>
            <div style={{ fontSize: 11, opacity: 0.55 }}>Complete Dental Line</div>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section style={{ position: "relative", padding: "40px 24px 60px", maxWidth: 1400, margin: "0 auto" }}>
        <div className="ums-hero-bg" />
        <div style={{ position: "relative", zIndex: 2, maxWidth: 900 }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "6px 14px", border: "1px solid #ffffff26", borderRadius: 100, fontSize: 12, letterSpacing: 1.4, textTransform: "uppercase", opacity: 0.85, marginBottom: 22 }}>
            <ShieldCheck size={14} /> UMS Dental Website Theme Selector
          </div>
          <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(38px, 6vw, 74px)", fontWeight: 700, lineHeight: 1.02, letterSpacing: -1.5, margin: 0 }}>
            Ten directions.<br />
            <span style={{ background: "linear-gradient(90deg,#a78bfa,#22d3ee,#f472b6)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>One winning store.</span>
          </h1>
          <p style={{ fontSize: 17, opacity: 0.75, marginTop: 22, maxWidth: 640, lineHeight: 1.6 }}>
            Every theme below is a fully-styled UMS Dental store built on the same product catalog. Open one, browse it end-to-end, and leave a rating. Then pick the direction that feels most like UMS in 2027.
          </p>
          <div style={{ display: "flex", gap: 20, marginTop: 26, flexWrap: "wrap", fontSize: 13, opacity: 0.7 }}>
            <span>10 themes</span><span>·</span><span>Same 40 products</span><span>·</span><span>Mobile + desktop</span><span>·</span><span>Rate & like</span>
          </div>
        </div>
      </section>

      {/* Grid */}
      <section style={{ maxWidth: 1400, margin: "0 auto", padding: "0 24px 80px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: 24 }}>
          {themes.map((t, i) => {
            const s = stats[t.id];
            const views = s?.views ?? 0;
            const likes = s?.likes ?? 0;
            const liked = s?.liked ?? false;
            const avg = s ? avgRating(s) : 0;
            const count = s?.ratingCount ?? 0;
            return (
              <Link
                key={t.id}
                to="/theme/$id"
                params={{ id: t.id }}
                className="theme-card"
                style={{
                  display: "block",
                  textDecoration: "none",
                  color: "inherit",
                  borderRadius: 20,
                  overflow: "hidden",
                  background: "linear-gradient(180deg, #ffffff08, #ffffff02)",
                  border: "1px solid #ffffff14",
                  position: "relative",
                }}
              >
                <ThemeThumbnail theme={t} index={i} />
                <div style={{ padding: 20 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
                    <div>
                      <div style={{ fontSize: 11, letterSpacing: 1.5, opacity: 0.55, textTransform: "uppercase" }}>Theme {String(i + 1).padStart(2, "0")}</div>
                      <h3 style={{ fontSize: 20, fontWeight: 700, margin: "6px 0 4px", letterSpacing: -0.3 }}>{t.name}</h3>
                      <p style={{ fontSize: 13, opacity: 0.7, margin: 0 }}>{t.tagline}</p>
                    </div>
                    <button
                      type="button"
                      onClick={(e) => like(t.id, e)}
                      aria-label={liked ? "Unlike" : "Like"}
                      style={{
                        background: liked ? "#ff3b73" : "transparent",
                        border: `1px solid ${liked ? "#ff3b73" : "#ffffff26"}`,
                        color: liked ? "#fff" : "#fff",
                        width: 40, height: 40, borderRadius: 12,
                        display: "inline-flex", alignItems: "center", justifyContent: "center",
                        cursor: "pointer", flexShrink: 0,
                        transition: "all .2s ease",
                      }}
                    >
                      <Heart size={16} fill={liked ? "#fff" : "none"} />
                    </button>
                  </div>
                  <div style={{ display: "flex", gap: 6, marginTop: 14, flexWrap: "wrap" }}>
                    {t.tags.map((tag) => (
                      <span key={tag} style={{ fontSize: 11, padding: "4px 10px", borderRadius: 100, background: "#ffffff10", opacity: 0.85 }}>{tag}</span>
                    ))}
                  </div>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 18, paddingTop: 16, borderTop: "1px solid #ffffff10", fontSize: 12, opacity: 0.75 }}>
                    <div style={{ display: "inline-flex", alignItems: "center", gap: 14 }}>
                      <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}><Eye size={13} /> {views}</span>
                      <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}><Heart size={13} /> {likes}</span>
                      <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}>
                        <Star size={13} fill={avg > 0 ? "#ffb020" : "none"} color={avg > 0 ? "#ffb020" : "currentColor"} />
                        {avg > 0 ? `${avg.toFixed(1)} · ${count}` : "—"}
                      </span>
                    </div>
                    <span style={{ display: "inline-flex", alignItems: "center", gap: 4, color: "#a5b4fc" }}>
                      Open <ArrowUpRight size={14} />
                    </span>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      <footer style={{ borderTop: "1px solid #ffffff10", padding: "28px 24px", textAlign: "center", fontSize: 12, opacity: 0.55 }}>
        © {new Date().getFullYear()} OLTANI · Open Link Technologies & Artificial Network Intelligence · Prepared for the UMS Dental Team
      </footer>
    </div>
  );
}

function ThemeThumbnail({ theme, index }: { theme: (typeof themes)[number]; index: number }) {
  const [bg, surface, accent] = theme.palette;
  // Detect light vs dark background for legible foreground color.
  const isLight = /^#([efd][0-9a-f]|[89a][0-9a-f]|f[a-f0-9])/i.test(bg);
  const fg = isLight ? "#111" : "#fff";
  const displayFont = [0, 2, 7, 8].includes(index)
    ? "'Fraunces', 'Playfair Display', serif"
    : [1, 4].includes(index)
      ? "'Instrument Serif', serif"
      : [5, 9].includes(index)
        ? "'Syne', sans-serif"
        : "'Space Grotesk', sans-serif";
  return (
    <div
      style={{
        position: "relative",
        aspectRatio: "16 / 10",
        background: index === 5
          ? `radial-gradient(circle at 30% 30%, ${accent}55, transparent 55%), ${bg}`
          : index === 3
            ? `linear-gradient(135deg, ${accent}, ${bg})`
            : bg,
        color: fg,
        overflow: "hidden",
      }}
    >
      <div style={{ position: "absolute", inset: 0, padding: 20, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, letterSpacing: 2, textTransform: "uppercase", opacity: 0.7 }}>
          <span>UMS Dental</span><span>№ {String(index + 1).padStart(2, "0")}</span>
        </div>
        <div>
          <div style={{ fontFamily: displayFont, fontSize: 26, fontWeight: 700, lineHeight: 1, letterSpacing: -0.8, color: index === 3 ? "#fff" : fg }}>
            {theme.vibe}
          </div>
          <div style={{ display: "flex", gap: 6, marginTop: 14 }}>
            {[0, 1, 2].map((k) => (
              <div key={k} style={{ flex: 1, height: 26, borderRadius: 6, background: k === 1 ? accent : `${accent}40`, border: k === 1 ? "none" : `1px solid ${accent}30` }} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
