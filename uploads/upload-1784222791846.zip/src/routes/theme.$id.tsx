import { createFileRoute, notFound } from "@tanstack/react-router";
import { useEffect } from "react";
import { themes } from "@/data/themes";
import { incrementView } from "@/lib/tracking";
import { ThemeRenderer } from "@/themes/registry";

export const Route = createFileRoute("/theme/$id")({
  loader: ({ params }) => {
    const t = themes.find((x) => x.id === params.id);
    if (!t) throw notFound();
    return { theme: t };
  },
  head: ({ loaderData }) => {
    const name = loaderData?.theme.name ?? "Theme";
    return {
      meta: [
        { title: `${name} · UMS Dental Theme Selector` },
        { name: "description", content: `Preview the "${name}" design direction for UMS Dental.` },
        { property: "og:title", content: `${name} · UMS Dental` },
      ],
    };
  },
  component: ThemeRoute,
});

function ThemeRoute() {
  const { id } = Route.useParams();
  useEffect(() => {
    incrementView(id);
  }, [id]);
  return <ThemeRenderer id={id} />;
}
