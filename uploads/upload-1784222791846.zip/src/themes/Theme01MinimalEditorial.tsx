import { useState } from "react";
import { motion } from "framer-motion";
import { Star, ArrowUpRight, Plus } from "lucide-react";
import { products, categories } from "@/data/products";
import { RatingBlock } from "@/components/RatingBlock";
import { BackBar } from "@/components/ThemeChrome";
import type { ThemeMeta } from "@/data/themes";
import hero from "@/assets/hero-dark.jpg";

/** Theme 01 · Clinical Noir — nocturnal editorial precision, emerald signal. */
export default function ThemeClinicalNoir({ theme }: { theme: ThemeMeta }) {
  const [cat, setCat] = useState("all");
  const filtered = cat === "all" ? products : products.filter((p) => p.category === cat);
  const INK = "#0a0a0b", SURF = "#141416", BONE = "#e8e6df", SIGNAL = "#00d9a3", MUTED = "#8a8a86";
  const display = "'Fraunces', 'Playfair Display', serif";
  const body = "'Inter Tight', 'Inter', sans-serif";

  return (
    <div style={{ background: INK, color: BONE, fontFamily: body, minHeight: "100vh" }}>
      <BackBar themeName={theme.name} bg={INK} fg={BONE} border={`${BONE}18`} />

      {/* Nav */}
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "26px 32px", borderBottom: `1px solid ${BONE}10` }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ width: 8, height: 8, background: SIGNAL, borderRadius: "50%", boxShadow: `0 0 12px ${SIGNAL}` }} />
          <span style={{ fontFamily: display, fontSize: 22, fontWeight: 500, letterSpacing: -0.5 }}>UMS <span style={{ opacity: 0.4 }}>·</span> Dental</span>
        </div>
        <nav style={{ display: "flex", gap: 32, fontSize: 12, letterSpacing: 2, textTransform: "uppercase", opacity: 0.7 }}>
          <span>Catalogue</span><span>Journal</span><span>Trade</span><span>Account</span>
        </nav>
      </header>

      {/* Hero — asymmetric split */}
      <section style={{ display: "grid", gridTemplateColumns: "1.1fr 1fr", minHeight: "82vh", borderBottom: `1px solid ${BONE}10` }} className="t1-hero">
        <div style={{ padding: "clamp(40px, 8vw, 100px)", display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
          <div>
            <div style={{ display: "inline-flex", alignItems: "center", gap: 10, fontSize: 11, letterSpacing: 3, textTransform: "uppercase", color: SIGNAL, marginBottom: 40 }}>
              <span style={{ width: 24, height: 1, background: SIGNAL }} /> Issue N°27 · MMXXVII
            </div>
            <motion.h1
              initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
              style={{ fontFamily: display, fontSize: "clamp(56px, 9vw, 128px)", fontWeight: 300, lineHeight: 0.92, letterSpacing: -3, margin: 0 }}
            >
              A quiet<br /><em style={{ fontStyle: "italic", fontWeight: 400 }}>excellence</em><br />in every<br />instrument.
            </motion.h1>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32, marginTop: 60, maxWidth: 520 }}>
            <p style={{ fontSize: 14, lineHeight: 1.65, color: MUTED, margin: 0 }}>Curated for the modern practitioner. Every SKU chosen for the way it performs, not the way it markets itself.</p>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <button style={{ background: BONE, color: INK, border: "none", padding: "16px 22px", fontSize: 12, letterSpacing: 2, textTransform: "uppercase", fontWeight: 600, cursor: "pointer", display: "inline-flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
                Enter Catalogue <ArrowUpRight size={16} />
              </button>
              <button style={{ background: "transparent", color: BONE, border: `1px solid ${BONE}30`, padding: "16px 22px", fontSize: 12, letterSpacing: 2, textTransform: "uppercase", cursor: "pointer" }}>Trade Access</button>
            </div>
          </div>
        </div>
        <div style={{ position: "relative", overflow: "hidden", background: "#050505" }}>
          <img src={hero} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", filter: "contrast(1.05) brightness(0.85)" }} />
          <div style={{ position: "absolute", inset: 0, background: `linear-gradient(90deg, ${INK} 0%, transparent 30%)` }} />
          <div style={{ position: "absolute", bottom: 32, right: 32, fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: MUTED, textAlign: "right" }}>
            Fig. 01<br />Diagnostic Mirror · Ref UMS-DM-01
          </div>
        </div>
      </section>
      <style>{`@media (max-width:900px){.t1-hero{grid-template-columns:1fr!important;min-height:auto!important}}`}</style>

      {/* Marquee stats */}
      <div style={{ borderBottom: `1px solid ${BONE}10`, padding: "24px 32px", display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 32 }} className="t1-stats">
        {[["1,854","SKUs curated"],["144","Categories"],["24h","Dispatch, Cairo"],["27","Years of trade"]].map(([n, l]) => (
          <div key={l}><div style={{ fontFamily: display, fontSize: 38, fontWeight: 400, letterSpacing: -1 }}>{n}</div><div style={{ fontSize: 11, letterSpacing: 2, textTransform: "uppercase", color: MUTED, marginTop: 4 }}>{l}</div></div>
        ))}
      </div>
      <style>{`@media (max-width:700px){.t1-stats{grid-template-columns:repeat(2,1fr)!important}}`}</style>

      {/* Categories */}
      <section style={{ padding: "80px 32px 40px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 40, flexWrap: "wrap", gap: 12 }}>
          <div>
            <div style={{ fontSize: 11, letterSpacing: 3, textTransform: "uppercase", color: SIGNAL }}>§ 02 · Catalogue</div>
            <h2 style={{ fontFamily: display, fontSize: "clamp(36px, 5vw, 64px)", fontWeight: 300, letterSpacing: -1.5, margin: "12px 0 0" }}>The complete line.</h2>
          </div>
          <span style={{ fontSize: 12, color: MUTED }}>{filtered.length} instruments</span>
        </div>
        <div style={{ display: "flex", gap: 0, overflowX: "auto", borderTop: `1px solid ${BONE}18`, borderBottom: `1px solid ${BONE}18` }}>
          {[{ slug: "all", name: "All" }, ...categories].map((c) => (
            <button key={c.slug} onClick={() => setCat(c.slug)} style={{
              padding: "16px 22px", background: "transparent", border: "none",
              color: cat === c.slug ? BONE : MUTED, borderBottom: `2px solid ${cat === c.slug ? SIGNAL : "transparent"}`,
              fontSize: 12, letterSpacing: 1.5, textTransform: "uppercase", whiteSpace: "nowrap", cursor: "pointer", fontFamily: body, fontWeight: cat === c.slug ? 600 : 400,
            }}>{c.name}</button>
          ))}
        </div>
      </section>

      {/* Product grid */}
      <section style={{ padding: "20px 32px 80px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 32 }}>
          {filtered.map((p, i) => (
            <motion.article key={p.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-50px" }} transition={{ duration: 0.6, delay: (i % 8) * 0.04 }} style={{ position: "relative", cursor: "pointer" }} className="t1-card">
              <div style={{ aspectRatio: "4/5", overflow: "hidden", background: SURF, position: "relative" }}>
                <img src={p.image} alt={p.name} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover", filter: "grayscale(15%) contrast(1.05)", transition: "transform .8s ease" }} className="t1-img" />
                {p.tag && <span style={{ position: "absolute", top: 14, left: 14, background: BONE, color: INK, padding: "5px 9px", fontSize: 10, letterSpacing: 1.5, textTransform: "uppercase", fontWeight: 600 }}>{p.tag}</span>}
                <button style={{ position: "absolute", bottom: 14, right: 14, background: BONE, color: INK, border: "none", width: 40, height: 40, borderRadius: "50%", display: "grid", placeItems: "center", cursor: "pointer" }}><Plus size={16} /></button>
              </div>
              <div style={{ paddingTop: 16 }}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: MUTED }}>
                  <span>{p.brand}</span><span style={{ display: "inline-flex", gap: 4, alignItems: "center" }}><Star size={10} fill={SIGNAL} color={SIGNAL} /> {p.rating}</span>
                </div>
                <h3 style={{ fontFamily: display, fontSize: 20, fontWeight: 400, margin: "10px 0 6px", lineHeight: 1.2, letterSpacing: -0.3 }}>{p.name}</h3>
                <div style={{ fontSize: 16, fontWeight: 500 }}>${p.price}</div>
              </div>
            </motion.article>
          ))}
        </div>
      </section>
      <style>{`.t1-card:hover .t1-img{transform:scale(1.06)}`}</style>

      {/* Editorial break */}
      <section style={{ padding: "80px 32px", borderTop: `1px solid ${BONE}18`, textAlign: "center" }}>
        <div style={{ fontSize: 11, letterSpacing: 3, textTransform: "uppercase", color: SIGNAL, marginBottom: 20 }}>§ 03 · Rating</div>
        <div style={{ maxWidth: 720, margin: "0 auto" }}>
          <RatingBlock themeId={theme.id} accent={SIGNAL} surface={SURF} fg={BONE} />
        </div>
      </section>

      <footer style={{ borderTop: `1px solid ${BONE}18`, padding: "40px 32px", display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 16, fontSize: 11, letterSpacing: 2, textTransform: "uppercase", color: MUTED }}>
        <span>© UMS Dental · MMXXVII</span>
        <span>Cairo · Est. 1998</span>
        <span>A quiet excellence</span>
      </footer>
    </div>
  );
}
