import { useState } from "react";
import { motion } from "framer-motion";
import { Star, ShoppingBag, Search } from "lucide-react";
import { products, categories } from "@/data/products";
import { RatingBlock } from "@/components/RatingBlock";
import { BackBar } from "@/components/ThemeChrome";
import type { ThemeMeta } from "@/data/themes";
import hero from "@/assets/hero-porcelain.jpg";

/** Theme 02 · Porcelain — Japanese calm, bone white, copper accent. */
export default function ThemePorcelain({ theme }: { theme: ThemeMeta }) {
  const [cat, setCat] = useState("all");
  const filtered = cat === "all" ? products : products.filter((p) => p.category === cat);
  const BG = "#f7f5f0", SURF = "#ffffff", INK = "#1a1a1a", COPPER = "#b8734a", MUTED = "#8a857c";
  const display = "'Instrument Serif', 'Playfair Display', serif";
  const body = "'Manrope', 'Inter', sans-serif";

  return (
    <div style={{ background: BG, color: INK, fontFamily: body, minHeight: "100vh" }}>
      <BackBar themeName={theme.name} bg={BG} fg={INK} border={`${INK}12`} />

      <header style={{ display: "grid", gridTemplateColumns: "1fr auto 1fr", alignItems: "center", padding: "22px 40px", borderBottom: `1px solid ${INK}10` }}>
        <div style={{ fontSize: 12, letterSpacing: 3, textTransform: "uppercase", color: MUTED }}>Est. 1998 · Cairo</div>
        <div style={{ fontFamily: display, fontSize: 28, fontStyle: "italic", fontWeight: 400 }}>UMS Dental</div>
        <div style={{ display: "flex", justifyContent: "flex-end", gap: 20, fontSize: 13, color: MUTED }}>
          <Search size={16} /><ShoppingBag size={16} /><span>EN | 中文 | ع</span>
        </div>
      </header>

      {/* Hero — full image + overlay type */}
      <section style={{ position: "relative", padding: "80px 40px 100px", textAlign: "center", overflow: "hidden" }}>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1.2 }} style={{ maxWidth: 900, margin: "0 auto" }}>
          <div style={{ fontSize: 11, letterSpacing: 4, textTransform: "uppercase", color: COPPER, marginBottom: 32 }}>—— Autumn Collection MMXXVII ——</div>
          <h1 style={{ fontFamily: display, fontSize: "clamp(56px, 10vw, 148px)", fontWeight: 400, lineHeight: 0.95, letterSpacing: -3, margin: 0 }}>
            The <em>quiet</em> tools<br />of a considered<br /><em>practice.</em>
          </h1>
          <p style={{ fontSize: 16, lineHeight: 1.7, color: MUTED, marginTop: 32, maxWidth: 560, margin: "32px auto 0" }}>
            A curation of dental instruments and consumables, chosen for material honesty and everyday reliability. In the tradition of <em>shibumi</em> — quiet refinement.
          </p>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1.4, delay: 0.3 }} style={{ marginTop: 60, aspectRatio: "16/9", maxWidth: 1200, marginInline: "auto", overflow: "hidden", borderRadius: 4 }}>
          <img src={hero} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        </motion.div>
      </section>

      {/* Category chips — pill style */}
      <section style={{ padding: "40px 40px 20px" }}>
        <div style={{ display: "flex", justifyContent: "center", flexWrap: "wrap", gap: 10 }}>
          {[{ slug: "all", name: "All" }, ...categories].map((c) => (
            <button key={c.slug} onClick={() => setCat(c.slug)} style={{
              padding: "10px 20px", background: cat === c.slug ? INK : "transparent", color: cat === c.slug ? BG : INK,
              border: `1px solid ${cat === c.slug ? INK : INK}25`, borderRadius: 100, fontSize: 13, cursor: "pointer", fontFamily: body,
            }}>{c.name}</button>
          ))}
        </div>
      </section>

      {/* Grid — clean cards */}
      <section style={{ padding: "40px 40px 80px", maxWidth: 1400, margin: "0 auto" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 32 }}>
          {filtered.map((p, i) => (
            <motion.article key={p.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: (i % 8) * 0.04 }} style={{ background: SURF, borderRadius: 4, overflow: "hidden", border: `1px solid ${INK}08` }}>
              <div style={{ aspectRatio: "1", overflow: "hidden", background: BG }}>
                <img src={p.image} alt={p.name} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              </div>
              <div style={{ padding: 20 }}>
                <div style={{ fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: COPPER }}>{p.brand}</div>
                <h3 style={{ fontFamily: display, fontSize: 20, fontWeight: 400, margin: "8px 0 10px", lineHeight: 1.25, fontStyle: "italic" }}>{p.name}</h3>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 14 }}>
                  <span style={{ fontWeight: 600 }}>${p.price}</span>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 4, color: MUTED, fontSize: 12 }}><Star size={11} fill={COPPER} color={COPPER} /> {p.rating}</span>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 720, margin: "0 auto", padding: "0 40px 80px" }}>
        <RatingBlock themeId={theme.id} accent={COPPER} surface={SURF} fg={INK} />
      </section>

      <footer style={{ borderTop: `1px solid ${INK}10`, padding: "40px", textAlign: "center", fontFamily: display, fontSize: 14, fontStyle: "italic", color: MUTED }}>
        UMS Dental · Cairo · MMXXVII — <span style={{ color: COPPER }}>shibumi</span>
      </footer>
    </div>
  );
}
