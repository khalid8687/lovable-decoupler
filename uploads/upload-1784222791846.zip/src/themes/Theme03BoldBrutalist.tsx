import { useState } from "react";
import { motion } from "framer-motion";
import { Star, ArrowRight } from "lucide-react";
import { products, categories } from "@/data/products";
import { RatingBlock } from "@/components/RatingBlock";
import { BackBar } from "@/components/ThemeChrome";
import type { ThemeMeta } from "@/data/themes";
import hero from "@/assets/hero-aurum.jpg";

/** Theme 03 · Aurum Deep — Aesop apothecary warmth, amber & gold. */
export default function ThemeAurumDeep({ theme }: { theme: ThemeMeta }) {
  const [cat, setCat] = useState("all");
  const filtered = cat === "all" ? products : products.filter((p) => p.category === cat);
  const BG = "#1c1a17", SURF = "#2a2723", GOLD = "#d4b483", CREAM = "#e8dcc4", MUTED = "#8a8175";
  const display = "'Cormorant Garamond', 'Playfair Display', serif";
  const body = "'Karla', 'Inter', sans-serif";

  return (
    <div style={{ background: BG, color: CREAM, fontFamily: body, minHeight: "100vh" }}>
      <BackBar themeName={theme.name} bg={BG} fg={CREAM} border={`${GOLD}20`} />

      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "28px 40px", borderBottom: `1px solid ${GOLD}20` }}>
        <div style={{ fontFamily: display, fontSize: 26, fontWeight: 500, letterSpacing: 2, color: GOLD }}>UMS · DENTAL</div>
        <nav style={{ display: "flex", gap: 32, fontSize: 12, letterSpacing: 3, textTransform: "uppercase", color: MUTED }}>
          <span>Apothecary</span><span>Instruments</span><span>Consumables</span><span>Trade</span>
        </nav>
      </header>

      <section style={{ display: "grid", gridTemplateColumns: "1fr 1.2fr", minHeight: "82vh", alignItems: "stretch" }} className="t3-hero">
        <div style={{ padding: "clamp(40px, 8vw, 100px)", display: "flex", flexDirection: "column", justifyContent: "center" }}>
          <div style={{ fontSize: 11, letterSpacing: 4, textTransform: "uppercase", color: GOLD, marginBottom: 32 }}>—— Since 1998</div>
          <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1 }}
            style={{ fontFamily: display, fontSize: "clamp(56px, 8vw, 112px)", fontWeight: 300, lineHeight: 1, letterSpacing: -2, margin: 0, color: CREAM }}>
            The apothecary<br />of <em style={{ color: GOLD }}>dental</em><br />practice.
          </motion.h1>
          <p style={{ fontSize: 15, lineHeight: 1.75, color: MUTED, marginTop: 32, maxWidth: 460 }}>
            Considered instruments, gently sourced consumables, presented as they deserve — on warm wood, under warm light, without noise.
          </p>
          <div style={{ marginTop: 40, display: "flex", gap: 16 }}>
            <button style={{ background: GOLD, color: BG, border: "none", padding: "16px 28px", fontSize: 12, letterSpacing: 2, textTransform: "uppercase", fontWeight: 700, cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 10 }}>Browse Store <ArrowRight size={14} /></button>
            <button style={{ background: "transparent", color: CREAM, border: `1px solid ${GOLD}50`, padding: "16px 28px", fontSize: 12, letterSpacing: 2, textTransform: "uppercase", cursor: "pointer" }}>Our Story</button>
          </div>
        </div>
        <div style={{ position: "relative", overflow: "hidden" }}>
          <img src={hero} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          <div style={{ position: "absolute", inset: 0, background: `linear-gradient(90deg, ${BG} 0%, transparent 25%)` }} />
        </div>
      </section>
      <style>{`@media (max-width:900px){.t3-hero{grid-template-columns:1fr!important}}`}</style>

      <section style={{ padding: "80px 40px 20px", maxWidth: 1400, margin: "0 auto" }}>
        <h2 style={{ fontFamily: display, fontSize: "clamp(36px, 5vw, 56px)", fontWeight: 300, letterSpacing: -1, textAlign: "center", margin: 0 }}>The <em style={{ color: GOLD }}>collection</em></h2>
        <div style={{ display: "flex", justifyContent: "center", gap: 4, marginTop: 40, borderTop: `1px solid ${GOLD}25`, borderBottom: `1px solid ${GOLD}25`, overflowX: "auto" }}>
          {[{ slug: "all", name: "All" }, ...categories].map((c) => (
            <button key={c.slug} onClick={() => setCat(c.slug)} style={{
              padding: "18px 20px", background: "transparent", border: "none",
              color: cat === c.slug ? GOLD : MUTED, fontFamily: display, fontStyle: cat === c.slug ? "italic" : "normal",
              fontSize: 16, cursor: "pointer", whiteSpace: "nowrap",
            }}>{c.name}</button>
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 1400, margin: "0 auto", padding: "40px 40px 80px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 40 }}>
          {filtered.map((p, i) => (
            <motion.article key={p.id} initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6, delay: (i % 8) * 0.04 }}>
              <div style={{ aspectRatio: "1", overflow: "hidden", background: SURF, borderRadius: 2 }}>
                <img src={p.image} alt={p.name} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover", filter: "sepia(15%) brightness(0.95)" }} />
              </div>
              <div style={{ paddingTop: 20 }}>
                <div style={{ fontSize: 10, letterSpacing: 3, textTransform: "uppercase", color: GOLD }}>{p.brand}</div>
                <h3 style={{ fontFamily: display, fontSize: 22, fontWeight: 400, margin: "10px 0 12px", lineHeight: 1.2, color: CREAM }}>{p.name}</h3>
                <p style={{ fontSize: 13, color: MUTED, lineHeight: 1.6, margin: "0 0 14px" }}>{p.description.slice(0, 80)}…</p>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingTop: 14, borderTop: `1px solid ${GOLD}20` }}>
                  <span style={{ fontFamily: display, fontSize: 20, color: GOLD }}>${p.price}</span>
                  <span style={{ fontSize: 12, color: MUTED, display: "inline-flex", gap: 4, alignItems: "center" }}><Star size={11} fill={GOLD} color={GOLD} /> {p.rating}</span>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 720, margin: "0 auto", padding: "40px 40px 80px" }}>
        <RatingBlock themeId={theme.id} accent={GOLD} surface={SURF} fg={CREAM} />
      </section>

      <footer style={{ borderTop: `1px solid ${GOLD}25`, padding: "50px 40px", textAlign: "center" }}>
        <div style={{ fontFamily: display, fontSize: 32, fontStyle: "italic", color: GOLD }}>UMS</div>
        <div style={{ fontSize: 11, letterSpacing: 3, textTransform: "uppercase", color: MUTED, marginTop: 8 }}>Complete Dental Line · MMXXVII</div>
      </footer>
    </div>
  );
}
