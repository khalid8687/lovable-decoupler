import { useState } from "react";
import { motion } from "framer-motion";
import { Star, ArrowUpRight, Check } from "lucide-react";
import { products, categories } from "@/data/products";
import { RatingBlock } from "@/components/RatingBlock";
import { BackBar } from "@/components/ThemeChrome";
import type { ThemeMeta } from "@/data/themes";

/** Theme 04 · Meridian Blue — global medical trust, corporate premium. */
export default function ThemeMeridianBlue({ theme }: { theme: ThemeMeta }) {
  const [cat, setCat] = useState("all");
  const filtered = cat === "all" ? products : products.filter((p) => p.category === cat);
  const BG = "#eef2f8", SURF = "#ffffff", NAVY = "#0b1f3a", BLUE = "#2f6bff", INK = "#0b1f3a", MUTED = "#5a6b82";
  const display = "'Space Grotesk', 'Inter', sans-serif";
  const body = "'Inter Tight', 'Inter', sans-serif";

  return (
    <div style={{ background: BG, color: INK, fontFamily: body, minHeight: "100vh" }}>
      <BackBar themeName={theme.name} bg={SURF} fg={INK} border={`${INK}12`} />

      <header style={{ background: SURF, borderBottom: `1px solid ${INK}10`, padding: "18px 32px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 40 }}>
          <div style={{ fontFamily: display, fontSize: 22, fontWeight: 700, letterSpacing: -0.5 }}>UMS<span style={{ color: BLUE }}>·</span>Dental</div>
          <nav style={{ display: "flex", gap: 28, fontSize: 14, color: MUTED }}>
            <span>Store</span><span>Solutions</span><span>Brands</span><span>Support</span>
          </nav>
        </div>
        <button style={{ background: NAVY, color: "#fff", border: "none", padding: "10px 20px", borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: "pointer" }}>Trade Login</button>
      </header>

      {/* Hero — gradient card style */}
      <section style={{ padding: "40px 32px" }}>
        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}
          style={{ background: `linear-gradient(135deg, ${NAVY} 0%, #12325e 100%)`, borderRadius: 32, padding: "clamp(50px, 8vw, 100px)", color: "#fff", position: "relative", overflow: "hidden" }}>
          <div style={{ position: "absolute", top: -100, right: -100, width: 400, height: 400, background: `radial-gradient(circle, ${BLUE}40, transparent 70%)`, borderRadius: "50%" }} />
          <div style={{ position: "relative", maxWidth: 800 }}>
            <div style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "#ffffff15", padding: "6px 14px", borderRadius: 100, fontSize: 12, marginBottom: 30, backdropFilter: "blur(10px)" }}>
              <span style={{ width: 6, height: 6, background: "#4ade80", borderRadius: "50%" }} /> Trusted by 2,400+ practices across MENA
            </div>
            <h1 style={{ fontFamily: display, fontSize: "clamp(44px, 7vw, 96px)", fontWeight: 700, lineHeight: 1, letterSpacing: -2.5, margin: 0 }}>
              Dental supplies,<br />engineered for the <span style={{ color: BLUE, background: `linear-gradient(90deg, ${BLUE}, #7ba3ff)`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>modern clinic.</span>
            </h1>
            <p style={{ fontSize: 17, lineHeight: 1.65, opacity: 0.75, marginTop: 24, maxWidth: 600 }}>
              1,854 SKUs. 27 years of trade. One trusted partner for every discipline — from endodontics to prosthetics.
            </p>
            <div style={{ display: "flex", gap: 12, marginTop: 36, flexWrap: "wrap" }}>
              <button style={{ background: "#fff", color: NAVY, border: "none", padding: "14px 26px", borderRadius: 10, fontSize: 14, fontWeight: 600, cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 8 }}>Browse Catalogue <ArrowUpRight size={16} /></button>
              <button style={{ background: "transparent", color: "#fff", border: "1px solid #ffffff30", padding: "14px 26px", borderRadius: 10, fontSize: 14, cursor: "pointer" }}>Request Quote</button>
            </div>
            <div style={{ display: "flex", gap: 32, marginTop: 48, flexWrap: "wrap", fontSize: 13, opacity: 0.75 }}>
              {["24h dispatch", "ISO certified", "Trade pricing", "MENA-wide delivery"].map((f) => (
                <span key={f} style={{ display: "inline-flex", alignItems: "center", gap: 6 }}><Check size={14} color={BLUE} /> {f}</span>
              ))}
            </div>
          </div>
        </motion.div>
      </section>

      {/* Categories bar */}
      <section style={{ padding: "20px 32px" }}>
        <div style={{ background: SURF, borderRadius: 16, padding: 8, display: "flex", gap: 4, overflowX: "auto", border: `1px solid ${INK}08` }}>
          {[{ slug: "all", name: "All Products" }, ...categories].map((c) => (
            <button key={c.slug} onClick={() => setCat(c.slug)} style={{
              padding: "10px 18px", background: cat === c.slug ? NAVY : "transparent", color: cat === c.slug ? "#fff" : INK,
              border: "none", borderRadius: 10, fontSize: 13, fontWeight: 500, cursor: "pointer", whiteSpace: "nowrap", fontFamily: body,
            }}>{c.name}</button>
          ))}
        </div>
      </section>

      <section style={{ padding: "20px 32px 60px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 20 }}>
          {filtered.map((p, i) => (
            <motion.article key={p.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: (i % 8) * 0.03 }}
              style={{ background: SURF, borderRadius: 20, overflow: "hidden", border: `1px solid ${INK}08`, transition: "all .3s ease", cursor: "pointer" }} className="t4-card">
              <div style={{ aspectRatio: "4/3", overflow: "hidden", background: BG }}>
                <img src={p.image} alt={p.name} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              </div>
              <div style={{ padding: 18 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontSize: 11, background: `${BLUE}15`, color: BLUE, padding: "3px 8px", borderRadius: 6, fontWeight: 600 }}>{p.brand}</span>
                  {p.tag && <span style={{ fontSize: 10, background: "#fef3c7", color: "#92400e", padding: "3px 8px", borderRadius: 6, fontWeight: 600 }}>{p.tag}</span>}
                </div>
                <h3 style={{ fontFamily: display, fontSize: 16, fontWeight: 600, margin: "12px 0 6px", lineHeight: 1.3 }}>{p.name}</h3>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 12 }}>
                  <span style={{ fontSize: 20, fontWeight: 700, color: NAVY }}>${p.price}</span>
                  <span style={{ fontSize: 12, color: MUTED, display: "inline-flex", gap: 4, alignItems: "center" }}><Star size={12} fill={BLUE} color={BLUE} /> {p.rating} ({p.reviews})</span>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </section>
      <style>{`.t4-card:hover{transform:translateY(-4px);box-shadow:0 20px 40px -20px ${NAVY}25}`}</style>

      <section style={{ maxWidth: 720, margin: "0 auto", padding: "20px 32px 60px" }}>
        <RatingBlock themeId={theme.id} accent={BLUE} surface={SURF} fg={INK} />
      </section>

      <footer style={{ background: NAVY, color: "#fff", padding: "40px 32px", display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 16, fontSize: 13 }}>
        <span>© UMS Dental 2027 — Complete Dental Line</span>
        <span style={{ opacity: 0.7 }}>Cairo · Est. 1998 · ISO 13485</span>
      </footer>
    </div>
  );
}
