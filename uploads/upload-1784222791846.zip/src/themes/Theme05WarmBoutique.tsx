import { useState } from "react";
import { motion } from "framer-motion";
import { Star, Leaf } from "lucide-react";
import { products, categories } from "@/data/products";
import { RatingBlock } from "@/components/RatingBlock";
import { BackBar } from "@/components/ThemeChrome";
import type { ThemeMeta } from "@/data/themes";
import hero from "@/assets/hero-porcelain.jpg";

/** Theme 05 · Sage Studio — botanical wellness, quiet greens, terracotta warmth. */
export default function ThemeSageStudio({ theme }: { theme: ThemeMeta }) {
  const [cat, setCat] = useState("all");
  const filtered = cat === "all" ? products : products.filter((p) => p.category === cat);
  const BG = "#eef0e8", SURF = "#ffffff", SAGE = "#2d3d2a", TERRA = "#c67856", INK = "#1a2417", MUTED = "#6b7862";
  const display = "'DM Serif Display', 'Playfair Display', serif";
  const body = "'DM Sans', 'Inter', sans-serif";

  return (
    <div style={{ background: BG, color: INK, fontFamily: body, minHeight: "100vh" }}>
      <BackBar themeName={theme.name} bg={BG} fg={INK} border={`${SAGE}20`} />

      <header style={{ padding: "24px 40px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <Leaf size={20} color={SAGE} />
          <div style={{ fontFamily: display, fontSize: 24, color: SAGE }}>UMS Botanica</div>
        </div>
        <nav style={{ display: "flex", gap: 28, fontSize: 13, color: MUTED }}>
          <span>Instruments</span><span>Consumables</span><span>Story</span><span>Cart · 0</span>
        </nav>
      </header>

      <section style={{ padding: "60px 40px 100px", maxWidth: 1400, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 60, alignItems: "center" }} className="t5-hero">
        <div>
          <div style={{ fontSize: 12, letterSpacing: 3, textTransform: "uppercase", color: TERRA, marginBottom: 24 }}>——— Made for calm practice</div>
          <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1 }}
            style={{ fontFamily: display, fontSize: "clamp(52px, 8vw, 108px)", fontWeight: 400, lineHeight: 0.98, letterSpacing: -2, margin: 0, color: SAGE }}>
            A gentler way to source your practice.
          </motion.h1>
          <p style={{ fontSize: 16, lineHeight: 1.75, color: MUTED, marginTop: 28, maxWidth: 480 }}>
            Instruments and consumables chosen with the same care you bring to your patients. Recyclable packaging. Honest sourcing. No noise.
          </p>
          <div style={{ display: "flex", gap: 12, marginTop: 36 }}>
            <button style={{ background: SAGE, color: BG, border: "none", padding: "14px 26px", borderRadius: 100, fontSize: 14, cursor: "pointer" }}>Enter Store</button>
            <button style={{ background: "transparent", color: SAGE, border: `1px solid ${SAGE}40`, padding: "14px 26px", borderRadius: 100, fontSize: 14, cursor: "pointer" }}>Our Practice</button>
          </div>
        </div>
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 1.2 }}
          style={{ borderRadius: 200, overflow: "hidden", aspectRatio: "3/4" }}>
          <img src={hero} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        </motion.div>
      </section>
      <style>{`@media (max-width:900px){.t5-hero{grid-template-columns:1fr!important}}`}</style>

      <section style={{ padding: "0 40px 40px", maxWidth: 1400, margin: "0 auto" }}>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center" }}>
          {[{ slug: "all", name: "All" }, ...categories].map((c) => (
            <button key={c.slug} onClick={() => setCat(c.slug)} style={{
              padding: "10px 20px", background: cat === c.slug ? SAGE : SURF, color: cat === c.slug ? BG : SAGE,
              border: `1px solid ${SAGE}20`, borderRadius: 100, fontSize: 13, cursor: "pointer",
            }}>{c.name}</button>
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 1400, margin: "0 auto", padding: "20px 40px 80px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 24 }}>
          {filtered.map((p, i) => (
            <motion.article key={p.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: (i % 8) * 0.04 }}
              style={{ background: SURF, borderRadius: 24, overflow: "hidden", cursor: "pointer", transition: "all .35s ease" }} className="t5-card">
              <div style={{ aspectRatio: "1", overflow: "hidden", background: BG, borderRadius: "24px 24px 0 0" }}>
                <img src={p.image} alt={p.name} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              </div>
              <div style={{ padding: 20 }}>
                <div style={{ fontSize: 11, letterSpacing: 1.5, textTransform: "uppercase", color: TERRA }}>{p.brand}</div>
                <h3 style={{ fontFamily: display, fontSize: 18, fontWeight: 400, margin: "8px 0 12px", lineHeight: 1.3, color: SAGE }}>{p.name}</h3>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingTop: 12, borderTop: `1px solid ${SAGE}15` }}>
                  <span style={{ fontSize: 18, fontWeight: 600, color: SAGE }}>${p.price}</span>
                  <span style={{ fontSize: 12, color: MUTED, display: "inline-flex", gap: 4, alignItems: "center" }}><Star size={11} fill={TERRA} color={TERRA} /> {p.rating}</span>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </section>
      <style>{`.t5-card:hover{transform:translateY(-4px);box-shadow:0 20px 40px -20px ${SAGE}30}`}</style>

      <section style={{ maxWidth: 720, margin: "0 auto", padding: "0 40px 80px" }}>
        <RatingBlock themeId={theme.id} accent={TERRA} surface={SURF} fg={SAGE} />
      </section>

      <footer style={{ background: SAGE, color: BG, padding: "50px 40px", textAlign: "center" }}>
        <Leaf size={24} style={{ margin: "0 auto 12px", display: "block" }} />
        <div style={{ fontFamily: display, fontSize: 24 }}>UMS Botanica · MMXXVII</div>
        <div style={{ fontSize: 12, letterSpacing: 2, textTransform: "uppercase", opacity: 0.7, marginTop: 8 }}>A gentler dental supply · Cairo</div>
      </footer>
    </div>
  );
}
