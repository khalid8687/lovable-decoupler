import { useState } from "react";
import { motion } from "framer-motion";
import { Star, Sparkles } from "lucide-react";
import { products, categories } from "@/data/products";
import { RatingBlock } from "@/components/RatingBlock";
import { BackBar } from "@/components/ThemeChrome";
import type { ThemeMeta } from "@/data/themes";
import hero from "@/assets/hero-aurora.jpg";

/** Theme 06 · Obsidian Glass — aurora glass on obsidian sky. */
export default function ThemeObsidianGlass({ theme }: { theme: ThemeMeta }) {
  const [cat, setCat] = useState("all");
  const filtered = cat === "all" ? products : products.filter((p) => p.category === cat);
  const BG = "#050510", VIOLET = "#7c5cff", CYAN = "#22d3ee", FG = "#f0eeff", MUTED = "#8b8ba7";
  const display = "'Syne', 'Space Grotesk', sans-serif";
  const body = "'Inter', sans-serif";

  return (
    <div style={{ background: BG, color: FG, fontFamily: body, minHeight: "100vh", position: "relative", overflow: "hidden" }}>
      {/* Ambient aurora */}
      <div style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0 }}>
        <div style={{ position: "absolute", top: "10%", left: "-10%", width: 600, height: 600, background: VIOLET, borderRadius: "50%", filter: "blur(180px)", opacity: 0.35 }} />
        <div style={{ position: "absolute", bottom: "5%", right: "-10%", width: 700, height: 700, background: CYAN, borderRadius: "50%", filter: "blur(200px)", opacity: 0.22 }} />
      </div>

      <div style={{ position: "relative", zIndex: 1 }}>
        <BackBar themeName={theme.name} bg="rgba(5,5,16,0.7)" fg={FG} border={`${FG}18`} />

        <header style={{ padding: "24px 32px", display: "flex", justifyContent: "space-between", alignItems: "center", backdropFilter: "blur(20px)", borderBottom: `1px solid ${FG}10` }}>
          <div style={{ fontFamily: display, fontSize: 22, fontWeight: 700, letterSpacing: -0.5 }}>UMS<span style={{ background: `linear-gradient(90deg,${VIOLET},${CYAN})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>·</span>Dental</div>
          <nav style={{ display: "flex", gap: 28, fontSize: 13, color: MUTED }}>
            <span>Explore</span><span>Brands</span><span>Trade</span><span>Cart</span>
          </nav>
        </header>

        <section style={{ padding: "80px 32px 100px", maxWidth: 1400, margin: "0 auto", textAlign: "center", position: "relative" }}>
          <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 1.2 }} style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "8px 18px", borderRadius: 100, background: "#ffffff08", border: `1px solid ${FG}20`, backdropFilter: "blur(20px)", fontSize: 12, letterSpacing: 2, textTransform: "uppercase", marginBottom: 40 }}>
            <Sparkles size={14} color={CYAN} /> Now shipping · MMXXVII
          </motion.div>
          <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1, delay: 0.2 }}
            style={{ fontFamily: display, fontSize: "clamp(56px, 10vw, 140px)", fontWeight: 800, lineHeight: 0.95, letterSpacing: -3, margin: 0 }}>
            Dental supply,<br /><span style={{ background: `linear-gradient(90deg,${VIOLET},${CYAN},#f0eeff)`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>reimagined for 2027.</span>
          </motion.h1>
          <p style={{ fontSize: 18, lineHeight: 1.6, color: MUTED, marginTop: 32, maxWidth: 640, margin: "32px auto 0" }}>
            A liquid glass storefront over the complete UMS catalogue. 1,854 SKUs. 144 categories. One frictionless purchase flow.
          </p>
          <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1, delay: 0.5 }} style={{ marginTop: 60, aspectRatio: "16/8", maxWidth: 1100, marginInline: "auto", borderRadius: 32, overflow: "hidden", border: `1px solid ${FG}20`, boxShadow: `0 40px 100px -20px ${VIOLET}40` }}>
            <img src={hero} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          </motion.div>
        </section>

        <section style={{ padding: "0 32px", maxWidth: 1400, margin: "0 auto" }}>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center", padding: 8, background: "#ffffff05", border: `1px solid ${FG}12`, borderRadius: 100, backdropFilter: "blur(20px)" }}>
            {[{ slug: "all", name: "All" }, ...categories].map((c) => (
              <button key={c.slug} onClick={() => setCat(c.slug)} style={{
                padding: "8px 18px", background: cat === c.slug ? `linear-gradient(90deg,${VIOLET},${CYAN})` : "transparent",
                color: cat === c.slug ? "#fff" : FG, border: "none", borderRadius: 100, fontSize: 13, cursor: "pointer", fontFamily: body, fontWeight: cat === c.slug ? 600 : 400,
              }}>{c.name}</button>
            ))}
          </div>
        </section>

        <section style={{ maxWidth: 1400, margin: "0 auto", padding: "40px 32px 80px" }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 20 }}>
            {filtered.map((p, i) => (
              <motion.article key={p.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: (i % 8) * 0.04 }}
                style={{ background: "linear-gradient(180deg, #ffffff0a, #ffffff02)", border: `1px solid ${FG}14`, borderRadius: 20, overflow: "hidden", backdropFilter: "blur(20px)", transition: "all .35s ease" }} className="t6-card">
                <div style={{ aspectRatio: "4/3", overflow: "hidden", background: "#0f0f24" }}>
                  <img src={p.image} alt={p.name} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover", filter: "brightness(0.95) contrast(1.1)" }} />
                </div>
                <div style={{ padding: 18 }}>
                  <div style={{ fontSize: 11, letterSpacing: 1.5, textTransform: "uppercase", color: CYAN, opacity: 0.8 }}>{p.brand}</div>
                  <h3 style={{ fontFamily: display, fontSize: 17, fontWeight: 600, margin: "10px 0 12px", lineHeight: 1.3 }}>{p.name}</h3>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingTop: 12, borderTop: `1px solid ${FG}12` }}>
                    <span style={{ fontSize: 20, fontWeight: 700, background: `linear-gradient(90deg,${VIOLET},${CYAN})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>${p.price}</span>
                    <span style={{ fontSize: 12, color: MUTED, display: "inline-flex", gap: 4, alignItems: "center" }}><Star size={12} fill={CYAN} color={CYAN} /> {p.rating}</span>
                  </div>
                </div>
              </motion.article>
            ))}
          </div>
        </section>
        <style>{`.t6-card:hover{transform:translateY(-4px);border-color:${FG}30;box-shadow:0 20px 60px -20px ${VIOLET}50}`}</style>

        <section style={{ maxWidth: 720, margin: "0 auto", padding: "0 32px 80px" }}>
          <RatingBlock themeId={theme.id} accent={CYAN} surface="#ffffff08" fg={FG} />
        </section>

        <footer style={{ borderTop: `1px solid ${FG}10`, padding: "40px 32px", textAlign: "center", fontSize: 12, color: MUTED, letterSpacing: 2, textTransform: "uppercase" }}>
          UMS · Dental · MMXXVII · Cairo
        </footer>
      </div>
    </div>
  );
}
