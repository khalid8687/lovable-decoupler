import { useState } from "react";
import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { products, categories } from "@/data/products";
import { RatingBlock } from "@/components/RatingBlock";
import { BackBar } from "@/components/ThemeChrome";
import type { ThemeMeta } from "@/data/themes";

/** Theme 07 · Nordic Precision — Scandi grid, signal orange restraint. */
export default function ThemeNordicPrecision({ theme }: { theme: ThemeMeta }) {
  const [cat, setCat] = useState("all");
  const filtered = cat === "all" ? products : products.filter((p) => p.category === cat);
  const BG = "#fafafa", SURF = "#f0f0ee", INK = "#111111", SIGNAL = "#ff4d1a", MUTED = "#6b6b68";
  const display = "'Manrope', 'Inter', sans-serif";
  const mono = "'JetBrains Mono', monospace";

  return (
    <div style={{ background: BG, color: INK, fontFamily: display, minHeight: "100vh" }}>
      <BackBar themeName={theme.name} bg={BG} fg={INK} border={`${INK}12`} />

      <header style={{ display: "grid", gridTemplateColumns: "1fr auto 1fr", alignItems: "center", padding: "22px 40px", borderBottom: `1px solid ${INK}10` }}>
        <div style={{ fontFamily: mono, fontSize: 11, letterSpacing: 1, color: MUTED }}>UMS/DENTAL/v2027</div>
        <div style={{ fontSize: 20, fontWeight: 800, letterSpacing: -1 }}>UMS<span style={{ color: SIGNAL }}>.</span></div>
        <div style={{ fontFamily: mono, fontSize: 11, letterSpacing: 1, color: MUTED, textAlign: "right" }}>1854 SKU · 144 CAT</div>
      </header>

      {/* Hero grid */}
      <section style={{ padding: "60px 40px", maxWidth: 1400, margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(12,1fr)", gap: 24 }}>
        <div style={{ gridColumn: "span 7" }}>
          <div style={{ fontFamily: mono, fontSize: 11, letterSpacing: 1, color: SIGNAL, marginBottom: 24 }}>[01] STORE / CAIRO / 2027</div>
          <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}
            style={{ fontSize: "clamp(56px, 10vw, 148px)", fontWeight: 800, lineHeight: 0.9, letterSpacing: -5, margin: 0 }}>
            Precise<br />supply.<br /><span style={{ color: SIGNAL }}>Zero</span> noise.
          </motion.h1>
        </div>
        <div style={{ gridColumn: "span 5", alignSelf: "end", borderTop: `2px solid ${INK}`, paddingTop: 20 }}>
          <p style={{ fontSize: 15, lineHeight: 1.7 }}>
            A grid-first storefront for the complete UMS catalogue. Every SKU, three clicks away. Nothing extra.
          </p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 12, marginTop: 32, fontFamily: mono }}>
            {[["1854","SKU"],["144","CAT"],["24h","SHIP"],["4.9","RATE"]].map(([n,l]) => (
              <div key={l} style={{ borderTop: `1px solid ${INK}30`, paddingTop: 8 }}>
                <div style={{ fontSize: 22, fontWeight: 800, color: l === "RATE" ? SIGNAL : INK }}>{n}</div>
                <div style={{ fontSize: 10, color: MUTED, marginTop: 2 }}>{l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section style={{ padding: "20px 40px", maxWidth: 1400, margin: "0 auto", borderTop: `1px solid ${INK}15`, borderBottom: `1px solid ${INK}15` }}>
        <div style={{ display: "flex", gap: 0, overflowX: "auto", fontFamily: mono }}>
          {[{ slug: "all", name: "ALL" }, ...categories].map((c) => (
            <button key={c.slug} onClick={() => setCat(c.slug)} style={{
              padding: "16px 20px", background: cat === c.slug ? INK : "transparent", color: cat === c.slug ? BG : INK,
              border: "none", fontSize: 11, letterSpacing: 1.5, textTransform: "uppercase", whiteSpace: "nowrap", cursor: "pointer",
            }}>{c.name.toUpperCase()}</button>
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 1400, margin: "0 auto", padding: "40px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 24 }}>
          {filtered.map((p, i) => (
            <motion.article key={p.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: (i % 8) * 0.03 }}
              style={{ background: SURF, padding: 16, transition: "all .3s ease", cursor: "pointer" }} className="t7-card">
              <div style={{ aspectRatio: "1", overflow: "hidden", background: BG, marginBottom: 14 }}>
                <img src={p.image} alt={p.name} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              </div>
              <div style={{ fontFamily: mono, fontSize: 10, letterSpacing: 1, color: MUTED, marginBottom: 6 }}>[{p.category.slice(0,3).toUpperCase()}] {p.brand.toUpperCase()}</div>
              <h3 style={{ fontSize: 15, fontWeight: 700, margin: "0 0 12px", lineHeight: 1.3, letterSpacing: -0.3 }}>{p.name}</h3>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingTop: 12, borderTop: `1px solid ${INK}20` }}>
                <span style={{ fontFamily: mono, fontSize: 16, fontWeight: 700, color: SIGNAL }}>${p.price}</span>
                <span style={{ fontFamily: mono, fontSize: 11, color: MUTED }}>★ {p.rating}</span>
              </div>
            </motion.article>
          ))}
        </div>
      </section>
      <style>{`.t7-card:hover{background:${INK};color:${BG}}.t7-card:hover h3{color:${BG}}`}</style>

      <section style={{ maxWidth: 720, margin: "0 auto", padding: "0 40px 60px" }}>
        <RatingBlock themeId={theme.id} accent={SIGNAL} surface={SURF} fg={INK} />
      </section>

      <footer style={{ borderTop: `2px solid ${INK}`, padding: "24px 40px", display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 12, fontFamily: mono, fontSize: 10, letterSpacing: 1.5, textTransform: "uppercase" }}>
        <span>UMS.DENTAL/2027</span><span>CAIRO · EST.1998</span><span>END//</span>
      </footer>
    </div>
  );
}
