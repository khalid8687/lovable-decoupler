import { useState } from "react";
import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { products, categories } from "@/data/products";
import { RatingBlock } from "@/components/RatingBlock";
import { BackBar } from "@/components/ThemeChrome";
import type { ThemeMeta } from "@/data/themes";
import hero from "@/assets/hero-aurum.jpg";

/** Theme 08 · Bazaar Modern — contemporary Arabesque, saffron & bone. */
export default function ThemeBazaarModern({ theme }: { theme: ThemeMeta }) {
  const [cat, setCat] = useState("all");
  const filtered = cat === "all" ? products : products.filter((p) => p.category === cat);
  const BG = "#faf3e8", SURF = "#ffffff", CRIMSON = "#7a1c1c", SAFFRON = "#e8a13a", INK = "#2a1f14", MUTED = "#7a6a54";
  const display = "'Marcellus', 'Playfair Display', serif";
  const body = "'Cairo', 'Inter', sans-serif";

  return (
    <div style={{ background: BG, color: INK, fontFamily: body, minHeight: "100vh" }}>
      <BackBar themeName={theme.name} bg={BG} fg={INK} border={`${CRIMSON}20`} />

      {/* Ornamental strip */}
      <div style={{ height: 8, background: `repeating-linear-gradient(90deg, ${CRIMSON} 0 8px, ${SAFFRON} 8px 16px, ${INK} 16px 24px, ${SAFFRON} 24px 32px)` }} />

      <header style={{ padding: "24px 40px", display: "grid", gridTemplateColumns: "1fr auto 1fr", alignItems: "center" }}>
        <div style={{ fontSize: 12, letterSpacing: 2, color: MUTED }}>القاهرة · Cairo · Since 1998</div>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontFamily: display, fontSize: 28, letterSpacing: 4, color: CRIMSON }}>UMS · DENTAL</div>
          <div style={{ fontFamily: body, fontSize: 13, color: SAFFRON, marginTop: 2 }}>يو إم إس · طب الأسنان</div>
        </div>
        <div style={{ textAlign: "right", fontSize: 13, color: MUTED }}>EN · العربية</div>
      </header>

      {/* Hero — arch shape */}
      <section style={{ padding: "60px 40px 80px", maxWidth: 1400, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 60, alignItems: "center" }} className="t8-hero">
        <div>
          <div style={{ fontFamily: display, fontSize: 13, letterSpacing: 3, textTransform: "uppercase", color: SAFFRON, marginBottom: 24 }}>❖ Bazaar of instruments</div>
          <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1 }}
            style={{ fontFamily: display, fontSize: "clamp(52px, 8vw, 108px)", fontWeight: 400, lineHeight: 1, letterSpacing: -1.5, margin: 0, color: CRIMSON }}>
            An honest<br />bazaar for the<br />modern <em style={{ color: SAFFRON }}>practice.</em>
          </motion.h1>
          <p style={{ fontSize: 16, lineHeight: 1.75, color: MUTED, marginTop: 28, maxWidth: 460 }}>
            بأصالة الشرق ودقة العصر — دنتال سبلاي بيوصلك أي أداة تحتاجها في نفس اليوم من القاهرة لكل الوطن العربي.
          </p>
          <div style={{ display: "flex", gap: 12, marginTop: 32 }}>
            <button style={{ background: CRIMSON, color: BG, border: "none", padding: "14px 28px", fontSize: 14, cursor: "pointer", fontFamily: display, letterSpacing: 1 }}>Enter Bazaar</button>
            <button style={{ background: "transparent", color: CRIMSON, border: `1px solid ${CRIMSON}`, padding: "14px 28px", fontSize: 14, cursor: "pointer", fontFamily: display, letterSpacing: 1 }}>Wholesale</button>
          </div>
        </div>
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 1.2 }}
          style={{ position: "relative", aspectRatio: "3/4", borderRadius: "50% 50% 0 0 / 40% 40% 0 0", overflow: "hidden", border: `2px solid ${SAFFRON}` }}>
          <img src={hero} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          <div style={{ position: "absolute", inset: 0, background: `linear-gradient(180deg, transparent 50%, ${CRIMSON}40)` }} />
        </motion.div>
      </section>
      <style>{`@media (max-width:900px){.t8-hero{grid-template-columns:1fr!important}}`}</style>

      <section style={{ padding: "0 40px 20px", maxWidth: 1400, margin: "0 auto" }}>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center", padding: "20px 0", borderTop: `1px solid ${CRIMSON}25`, borderBottom: `1px solid ${CRIMSON}25` }}>
          {[{ slug: "all", name: "All / الكل" }, ...categories].map((c) => (
            <button key={c.slug} onClick={() => setCat(c.slug)} style={{
              padding: "8px 20px", background: cat === c.slug ? CRIMSON : "transparent", color: cat === c.slug ? BG : CRIMSON,
              border: "none", fontFamily: display, fontSize: 14, letterSpacing: 1, cursor: "pointer",
            }}>{c.name}</button>
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 1400, margin: "0 auto", padding: "40px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 24 }}>
          {filtered.map((p, i) => (
            <motion.article key={p.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: (i % 8) * 0.04 }}
              style={{ background: SURF, border: `1px solid ${CRIMSON}20`, overflow: "hidden", cursor: "pointer", transition: "all .3s ease" }} className="t8-card">
              <div style={{ aspectRatio: "1", overflow: "hidden" }}>
                <img src={p.image} alt={p.name} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              </div>
              <div style={{ padding: 18, borderTop: `1px solid ${CRIMSON}20` }}>
                <div style={{ fontFamily: display, fontSize: 11, letterSpacing: 2, textTransform: "uppercase", color: SAFFRON }}>{p.brand}</div>
                <h3 style={{ fontFamily: display, fontSize: 18, fontWeight: 400, margin: "8px 0 12px", lineHeight: 1.3, color: CRIMSON }}>{p.name}</h3>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontFamily: display, fontSize: 20, color: CRIMSON }}>${p.price}</span>
                  <span style={{ fontSize: 12, color: MUTED, display: "inline-flex", gap: 4, alignItems: "center" }}><Star size={11} fill={SAFFRON} color={SAFFRON} /> {p.rating}</span>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </section>
      <style>{`.t8-card:hover{border-color:${CRIMSON};box-shadow:0 20px 40px -20px ${CRIMSON}40}`}</style>

      <section style={{ maxWidth: 720, margin: "0 auto", padding: "20px 40px 60px" }}>
        <RatingBlock themeId={theme.id} accent={CRIMSON} surface={SURF} fg={INK} />
      </section>

      <div style={{ height: 8, background: `repeating-linear-gradient(90deg, ${CRIMSON} 0 8px, ${SAFFRON} 8px 16px, ${INK} 16px 24px, ${SAFFRON} 24px 32px)` }} />

      <footer style={{ padding: "40px", textAlign: "center", fontFamily: display }}>
        <div style={{ fontSize: 22, color: CRIMSON, letterSpacing: 3 }}>UMS · DENTAL · 2027</div>
        <div style={{ fontSize: 13, color: MUTED, marginTop: 8 }}>القاهرة · مصر · Cairo, Egypt</div>
      </footer>
    </div>
  );
}
