import { useState } from "react";
import { motion } from "framer-motion";
import { Star, ArrowRight } from "lucide-react";
import { products, categories } from "@/data/products";
import { RatingBlock } from "@/components/RatingBlock";
import { BackBar } from "@/components/ThemeChrome";
import type { ThemeMeta } from "@/data/themes";
import hero from "@/assets/hero-porcelain.jpg";

/** Theme 09 · Neo-Editorial — oversized display type, hot pink accent, magazine 2027. */
export default function ThemeNeoEditorial({ theme }: { theme: ThemeMeta }) {
  const [cat, setCat] = useState("all");
  const filtered = cat === "all" ? products : products.filter((p) => p.category === cat);
  const BG = "#f4f1eb", SURF = "#ffffff", INK = "#0a0a0a", HOT = "#ff2d55", MUTED = "#7a7770";
  const display = "'Fraunces', 'Playfair Display', serif";
  const body = "'Inter Tight', 'Inter', sans-serif";

  return (
    <div style={{ background: BG, color: INK, fontFamily: body, minHeight: "100vh" }}>
      <BackBar themeName={theme.name} bg={BG} fg={INK} border={`${INK}15`} />

      <header style={{ padding: "20px 32px", display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: `1px solid ${INK}15` }}>
        <div style={{ fontFamily: display, fontSize: 26, fontWeight: 900, letterSpacing: -1 }}>UMS<span style={{ color: HOT }}>.</span></div>
        <div style={{ fontSize: 11, letterSpacing: 3, textTransform: "uppercase", color: MUTED }}>Vol. XXVII · The Dental Issue · MMXXVII</div>
        <div style={{ fontSize: 13 }}>Buy</div>
      </header>

      {/* Massive editorial hero */}
      <section style={{ padding: "40px 32px" }}>
        <div style={{ position: "relative" }}>
          <motion.h1 initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1 }}
            style={{ fontFamily: display, fontSize: "clamp(72px, 18vw, 320px)", fontWeight: 900, lineHeight: 0.82, letterSpacing: -12, margin: 0, textAlign: "center" }}>
            Every<br /><em style={{ fontStyle: "italic", fontWeight: 400, color: HOT }}>tool</em> tells
          </motion.h1>
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 1.2, delay: 0.3 }}
            style={{ maxWidth: 700, margin: "20px auto", aspectRatio: "16/9", overflow: "hidden", borderRadius: 4 }}>
            <img src={hero} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          </motion.div>
          <motion.h1 initial={{ opacity: 0, y: -40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1, delay: 0.2 }}
            style={{ fontFamily: display, fontSize: "clamp(72px, 18vw, 320px)", fontWeight: 900, lineHeight: 0.82, letterSpacing: -12, margin: 0, textAlign: "center" }}>
            a <em style={{ fontStyle: "italic", fontWeight: 400 }}>story.</em>
          </motion.h1>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 40, maxWidth: 1000, margin: "60px auto 0" }} className="t9-intro">
          <p style={{ fontFamily: display, fontSize: 22, lineHeight: 1.4, fontStyle: "italic", margin: 0 }}>
            "A store is a magazine. A magazine is a museum. A museum is where you choose the instruments that will hold your career."
          </p>
          <div>
            <p style={{ fontSize: 15, lineHeight: 1.7, color: MUTED, margin: 0 }}>Twenty-seven years, one obsession — the complete dental line. Every SKU curated, photographed, and delivered by a house that knows the trade from the inside.</p>
            <button style={{ marginTop: 20, background: INK, color: BG, border: "none", padding: "14px 24px", fontSize: 13, letterSpacing: 1.5, textTransform: "uppercase", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 8 }}>Read the issue <ArrowRight size={14} /></button>
          </div>
        </div>
        <style>{`@media (max-width:900px){.t9-intro{grid-template-columns:1fr!important}}`}</style>
      </section>

      {/* Categories — big serif buttons */}
      <section style={{ padding: "60px 32px 20px", maxWidth: 1400, margin: "0 auto", borderTop: `2px solid ${INK}` }}>
        <div style={{ fontSize: 11, letterSpacing: 3, textTransform: "uppercase", color: HOT, padding: "20px 0" }}>§ The Catalogue</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 20, borderTop: `1px solid ${INK}20`, borderBottom: `1px solid ${INK}20`, padding: "20px 0" }}>
          {[{ slug: "all", name: "All" }, ...categories].map((c) => (
            <button key={c.slug} onClick={() => setCat(c.slug)} style={{
              background: "transparent", border: "none", cursor: "pointer",
              fontFamily: display, fontSize: cat === c.slug ? 28 : 22, fontWeight: cat === c.slug ? 700 : 400,
              fontStyle: cat === c.slug ? "italic" : "normal", color: cat === c.slug ? HOT : INK,
              padding: 0, letterSpacing: -0.5, transition: "all .3s ease",
            }}>{c.name}</button>
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 1400, margin: "0 auto", padding: "40px 32px 80px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 48 }}>
          {filtered.map((p, i) => (
            <motion.article key={p.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: (i % 8) * 0.04 }}>
              <div style={{ aspectRatio: i % 5 === 0 ? "3/4" : "4/5", overflow: "hidden", background: SURF }}>
                <img src={p.image} alt={p.name} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover", transition: "transform .8s ease" }} className="t9-img" />
              </div>
              <div style={{ paddingTop: 16 }}>
                <div style={{ fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: HOT }}>Nº {String(i+1).padStart(2,"0")} · {p.brand}</div>
                <h3 style={{ fontFamily: display, fontSize: 24, fontWeight: 400, margin: "8px 0 8px", lineHeight: 1.15, letterSpacing: -0.5 }}>{p.name}</h3>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", fontSize: 13, borderTop: `1px solid ${INK}15`, paddingTop: 10 }}>
                  <span style={{ fontFamily: display, fontSize: 20, fontWeight: 500 }}>${p.price}</span>
                  <span style={{ color: MUTED, display: "inline-flex", gap: 4, alignItems: "center" }}><Star size={11} fill={HOT} color={HOT} /> {p.rating}</span>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 720, margin: "0 auto", padding: "0 32px 80px" }}>
        <RatingBlock themeId={theme.id} accent={HOT} surface={SURF} fg={INK} />
      </section>

      <footer style={{ borderTop: `2px solid ${INK}`, padding: "40px 32px", textAlign: "center" }}>
        <div style={{ fontFamily: display, fontSize: 40, fontWeight: 900, letterSpacing: -2 }}>UMS<span style={{ color: HOT }}>.</span></div>
        <div style={{ fontSize: 11, letterSpacing: 3, textTransform: "uppercase", color: MUTED, marginTop: 12 }}>The Dental Issue · Vol. XXVII · MMXXVII</div>
      </footer>
    </div>
  );
}
