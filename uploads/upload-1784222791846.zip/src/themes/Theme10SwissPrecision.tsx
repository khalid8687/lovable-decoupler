import { useState } from "react";
import { motion } from "framer-motion";
import { Star, ChevronRight } from "lucide-react";
import { products, categories } from "@/data/products";
import { RatingBlock } from "@/components/RatingBlock";
import { BackBar } from "@/components/ThemeChrome";
import type { ThemeMeta } from "@/data/themes";
import hero from "@/assets/hero-dark.jpg";

/** Theme 10 · Titanium — cold industrial metallic, Apple-grade polish. */
export default function ThemeTitanium({ theme }: { theme: ThemeMeta }) {
  const [cat, setCat] = useState("all");
  const filtered = cat === "all" ? products : products.filter((p) => p.category === cat);
  const BG = "#e5e5e7", SURF = "#ffffff", INK = "#1d1d1f", ICE = "#a8b8c8", MUTED = "#6e6e73";
  const display = "'Space Grotesk', 'Inter', sans-serif";
  const body = "'Inter', sans-serif";

  return (
    <div style={{ background: BG, color: INK, fontFamily: body, minHeight: "100vh" }}>
      <BackBar themeName={theme.name} bg={SURF} fg={INK} border={`${INK}12`} />

      <header style={{ padding: "16px 32px", background: `${SURF}cc`, backdropFilter: "blur(20px)", borderBottom: `1px solid ${INK}10`, display: "flex", justifyContent: "space-between", alignItems: "center", position: "sticky", top: 44, zIndex: 40 }}>
        <div style={{ fontFamily: display, fontSize: 20, fontWeight: 600, letterSpacing: -0.5 }}>UMS</div>
        <nav style={{ display: "flex", gap: 28, fontSize: 13, color: INK }}>
          <span>Store</span><span>Instruments</span><span>Consumables</span><span>Support</span>
        </nav>
        <div style={{ fontSize: 13, color: MUTED }}>Search · Bag</div>
      </header>

      {/* Hero — Apple product page */}
      <section style={{ padding: "80px 32px 60px", textAlign: "center", background: `linear-gradient(180deg, ${SURF} 0%, ${BG} 100%)` }}>
        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
          <div style={{ fontSize: 12, letterSpacing: 2, color: MUTED, marginBottom: 16 }}>NEW · MMXXVII EDITION</div>
          <h1 style={{ fontFamily: display, fontSize: "clamp(56px, 9vw, 120px)", fontWeight: 600, lineHeight: 1, letterSpacing: -3, margin: 0 }}>
            The complete<br />dental line.<br /><span style={{ background: `linear-gradient(90deg, ${ICE}, ${INK})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>Titanium finish.</span>
          </h1>
          <p style={{ fontSize: 22, color: MUTED, marginTop: 24, maxWidth: 640, margin: "24px auto 0", lineHeight: 1.4 }}>
            1,854 instruments. 27 years of trade. Engineered for the modern practice.
          </p>
          <div style={{ display: "inline-flex", gap: 12, marginTop: 32 }}>
            <button style={{ background: INK, color: SURF, border: "none", padding: "12px 24px", borderRadius: 100, fontSize: 15, cursor: "pointer" }}>Shop the catalogue</button>
            <button style={{ background: "transparent", color: INK, border: "none", padding: "12px 8px", fontSize: 15, cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 4 }}>Learn more <ChevronRight size={16} /></button>
          </div>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 60 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1.2, delay: 0.3 }}
          style={{ marginTop: 60, maxWidth: 1000, marginInline: "auto", aspectRatio: "16/9", overflow: "hidden", borderRadius: 24, boxShadow: "0 40px 80px -20px rgba(0,0,0,0.3)" }}>
          <img src={hero} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        </motion.div>
      </section>

      {/* Feature strip */}
      <section style={{ padding: "60px 32px", background: SURF, borderTop: `1px solid ${INK}10`, borderBottom: `1px solid ${INK}10` }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 32, textAlign: "center" }} className="t10-feat">
          {[["1854","Instruments"],["144","Categories"],["24h","Cairo dispatch"],["ISO","13485 certified"]].map(([n,l]) => (
            <div key={l}>
              <div style={{ fontFamily: display, fontSize: 48, fontWeight: 600, letterSpacing: -1.5, background: `linear-gradient(180deg, ${INK}, ${MUTED})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>{n}</div>
              <div style={{ fontSize: 14, color: MUTED, marginTop: 4 }}>{l}</div>
            </div>
          ))}
        </div>
        <style>{`@media (max-width:700px){.t10-feat{grid-template-columns:repeat(2,1fr)!important}}`}</style>
      </section>

      <section style={{ padding: "60px 32px 20px", maxWidth: 1400, margin: "0 auto", textAlign: "center" }}>
        <h2 style={{ fontFamily: display, fontSize: "clamp(36px, 5vw, 56px)", fontWeight: 600, letterSpacing: -1.5, margin: 0 }}>Every category.</h2>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center", marginTop: 32 }}>
          {[{ slug: "all", name: "All" }, ...categories].map((c) => (
            <button key={c.slug} onClick={() => setCat(c.slug)} style={{
              padding: "8px 18px", background: cat === c.slug ? INK : SURF, color: cat === c.slug ? SURF : INK,
              border: `1px solid ${INK}18`, borderRadius: 100, fontSize: 13, cursor: "pointer",
            }}>{c.name}</button>
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 1400, margin: "0 auto", padding: "40px 32px 80px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 20 }}>
          {filtered.map((p, i) => (
            <motion.article key={p.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: (i % 8) * 0.03 }}
              style={{ background: SURF, borderRadius: 20, overflow: "hidden", cursor: "pointer", transition: "all .35s ease", border: `1px solid ${INK}0a` }} className="t10-card">
              <div style={{ aspectRatio: "1", overflow: "hidden", background: `linear-gradient(135deg, ${BG}, ${SURF})`, padding: 20 }}>
                <img src={p.image} alt={p.name} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: 12 }} />
              </div>
              <div style={{ padding: 18 }}>
                <div style={{ fontSize: 11, color: MUTED, textTransform: "uppercase", letterSpacing: 1 }}>{p.brand}</div>
                <h3 style={{ fontFamily: display, fontSize: 16, fontWeight: 600, margin: "6px 0 12px", lineHeight: 1.3, letterSpacing: -0.3 }}>{p.name}</h3>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontFamily: display, fontSize: 18, fontWeight: 600 }}>${p.price}</span>
                  <span style={{ fontSize: 12, color: MUTED, display: "inline-flex", gap: 4, alignItems: "center" }}><Star size={11} fill={INK} color={INK} /> {p.rating}</span>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </section>
      <style>{`.t10-card:hover{transform:translateY(-6px);box-shadow:0 20px 50px -20px rgba(0,0,0,0.25)}`}</style>

      <section style={{ maxWidth: 720, margin: "0 auto", padding: "0 32px 60px" }}>
        <RatingBlock themeId={theme.id} accent={INK} surface={SURF} fg={INK} />
      </section>

      <footer style={{ background: SURF, borderTop: `1px solid ${INK}10`, padding: "32px", textAlign: "center", fontSize: 12, color: MUTED }}>
        Copyright © 2027 UMS Dental · All rights reserved · Cairo, Egypt
      </footer>
    </div>
  );
}
