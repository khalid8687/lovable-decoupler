import { lazy, Suspense, type ComponentType } from "react";
import { themes, type ThemeMeta } from "@/data/themes";

// Lazy-load each theme so the initial selector bundle stays lean.
const registry: Record<string, ComponentType<{ theme: ThemeMeta }>> = {
  "minimal-editorial": lazy(() => import("./Theme01MinimalEditorial").then((m) => ({ default: m.default }))),
  "dark-medical-pro": lazy(() => import("./Theme02DarkMedicalPro").then((m) => ({ default: m.default }))),
  "bold-brutalist": lazy(() => import("./Theme03BoldBrutalist").then((m) => ({ default: m.default }))),
  "glass-aurora": lazy(() => import("./Theme04GlassAurora").then((m) => ({ default: m.default }))),
  "warm-boutique": lazy(() => import("./Theme05WarmBoutique").then((m) => ({ default: m.default }))),
  "corporate-navy": lazy(() => import("./Theme06CorporateNavy").then((m) => ({ default: m.default }))),
  "bento-modern": lazy(() => import("./Theme07BentoModern").then((m) => ({ default: m.default }))),
  "magazine-luxe": lazy(() => import("./Theme08MagazineLuxe").then((m) => ({ default: m.default }))),
  "neon-tech": lazy(() => import("./Theme09NeonTech").then((m) => ({ default: m.default }))),
  "swiss-precision": lazy(() => import("./Theme10SwissPrecision").then((m) => ({ default: m.default }))),
};

export function ThemeRenderer({ id }: { id: string }) {
  const meta = themes.find((t) => t.id === id);
  const Component = registry[id];
  if (!meta || !Component) {
    return (
      <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", fontFamily: "system-ui" }}>
        <div style={{ textAlign: "center" }}>
          <h1 style={{ fontSize: 22, fontWeight: 700 }}>Theme not found</h1>
          <a href="/" style={{ color: "#0ea5e9" }}>Back to selector</a>
        </div>
      </div>
    );
  }
  return (
    <Suspense fallback={<div style={{ minHeight: "100vh", display: "grid", placeItems: "center", fontFamily: "system-ui" }}>Loading theme…</div>}>
      <Component theme={meta} />
    </Suspense>
  );
}
