import logo from "@/assets/menu/logo.webp";
import juiceWatermelon from "@/assets/menu/juice-watermelon.webp";
import juicePomegranate from "@/assets/menu/juice-pomegranate.webp";
import juiceKiwi from "@/assets/menu/juice-kiwi.webp";
import juiceAvocado from "@/assets/menu/juice-avocado.webp";
import juiceGuava from "@/assets/menu/juice-guava.webp";
import juiceMango from "@/assets/menu/juice-mango.webp";
import smoothieWatermelon from "@/assets/menu/smoothie-watermelon.webp";
import smoothiePomegranate from "@/assets/menu/smoothie-pomegranate.webp";
import smoothieKiwi from "@/assets/menu/smoothie-kiwi.webp";
import smoothieAvocado from "@/assets/menu/smoothie-avocado.webp";
import smoothieGuava from "@/assets/menu/smoothie-guava.webp";
import smoothieMango from "@/assets/menu/smoothie-mango.webp";
import milkshakeWatermelon from "@/assets/menu/milkshake-watermelon.webp";
import milkshakePomegranate from "@/assets/menu/milkshake-pomegranate.webp";
import milkshakeKiwi from "@/assets/menu/milkshake-kiwi.webp";
import milkshakeAvocado from "@/assets/menu/milkshake-avocado.webp";
import milkshakeGuava from "@/assets/menu/milkshake-guava.webp";
import milkshakeMango from "@/assets/menu/milkshake-mango.webp";
import iceCreamPistachio from "@/assets/menu/icecream-pistachio.webp";
import iceCreamChocolate from "@/assets/menu/icecream-chocolate.webp";
import iceCreamNutella from "@/assets/menu/icecream-nutella.webp";
import iceCreamVanilla from "@/assets/menu/icecream-vanilla.webp";
import iceCreamMango from "@/assets/menu/icecream-mango.webp";
import iceCreamStrawberry from "@/assets/menu/icecream-strawberry.webp";

export { logo };

export type MenuItem = {
  id: string;
  nameAr: string;
  nameEn: string;
  price: number;
  image: string;
};

export type MenuCategory = {
  id: string;
  titleAr: string;
  titleEn: string;
  items: MenuItem[];
};

export const categories: MenuCategory[] = [
  {
    id: "juices",
    titleAr: "عصائر طازجة",
    titleEn: "Fresh Juices",
    items: [
      { id: "j-watermelon", nameAr: "عصير بطيخ", nameEn: "Watermelon Juice", price: 100, image: juiceWatermelon },
      { id: "j-pomegranate", nameAr: "عصير رمان", nameEn: "Pomegranate Juice", price: 100, image: juicePomegranate },
      { id: "j-kiwi", nameAr: "عصير كيوي", nameEn: "Kiwi Juice", price: 100, image: juiceKiwi },
      { id: "j-avocado", nameAr: "عصير أفوكادو", nameEn: "Avocado Juice", price: 100, image: juiceAvocado },
      { id: "j-guava", nameAr: "عصير جوافة", nameEn: "Guava Juice", price: 100, image: juiceGuava },
      { id: "j-mango", nameAr: "عصير مانجو", nameEn: "Mango Juice", price: 100, image: juiceMango },
    ],
  },
  {
    id: "smoothies",
    titleAr: "سموزي",
    titleEn: "Smoothies",
    items: [
      { id: "s-watermelon", nameAr: "سموزي بطيخ", nameEn: "Watermelon Smoothie", price: 100, image: smoothieWatermelon },
      { id: "s-pomegranate", nameAr: "سموزي رمان", nameEn: "Pomegranate Smoothie", price: 100, image: smoothiePomegranate },
      { id: "s-kiwi", nameAr: "سموزي كيوي", nameEn: "Kiwi Smoothie", price: 100, image: smoothieKiwi },
      { id: "s-avocado", nameAr: "سموزي أفوكادو", nameEn: "Avocado Smoothie", price: 100, image: smoothieAvocado },
      { id: "s-guava", nameAr: "سموزي جوافة", nameEn: "Guava Smoothie", price: 100, image: smoothieGuava },
      { id: "s-mango", nameAr: "سموزي مانجو", nameEn: "Mango Smoothie", price: 100, image: smoothieMango },
    ],
  },
  {
    id: "milkshakes",
    titleAr: "ميلك شيك",
    titleEn: "Milkshakes",
    items: [
      { id: "m-watermelon", nameAr: "ميلك شيك بطيخ", nameEn: "Watermelon Shake", price: 50, image: milkshakeWatermelon },
      { id: "m-pomegranate", nameAr: "ميلك شيك رمان", nameEn: "Pomegranate Shake", price: 50, image: milkshakePomegranate },
      { id: "m-kiwi", nameAr: "ميلك شيك كيوي", nameEn: "Kiwi Shake", price: 50, image: milkshakeKiwi },
      { id: "m-avocado", nameAr: "ميلك شيك أفوكادو", nameEn: "Avocado Shake", price: 50, image: milkshakeAvocado },
      { id: "m-guava", nameAr: "ميلك شيك جوافة", nameEn: "Guava Shake", price: 50, image: milkshakeGuava },
      { id: "m-mango", nameAr: "ميلك شيك مانجو", nameEn: "Mango Shake", price: 50, image: milkshakeMango },
    ],
  },
  {
    id: "icecream",
    titleAr: "آيس كريم",
    titleEn: "Ice Cream",
    items: [
      { id: "i-pistachio", nameAr: "آيس كريم فسدق", nameEn: "Pistachio Ice Cream", price: 50, image: iceCreamPistachio },
      { id: "i-chocolate", nameAr: "آيس كريم شوكليت", nameEn: "Chocolate Ice Cream", price: 50, image: iceCreamChocolate },
      { id: "i-nutella", nameAr: "آيس كريم نوتيلا", nameEn: "Nutella Ice Cream", price: 50, image: iceCreamNutella },
      { id: "i-vanilla", nameAr: "آيس كريم فانيليا", nameEn: "Vanilla Ice Cream", price: 50, image: iceCreamVanilla },
      { id: "i-mango", nameAr: "آيس كريم مانجو", nameEn: "Mango Ice Cream", price: 50, image: iceCreamMango },
      { id: "i-strawberry", nameAr: "آيس كريم فراولة", nameEn: "Strawberry Ice Cream", price: 50, image: iceCreamStrawberry },
    ],
  },
];