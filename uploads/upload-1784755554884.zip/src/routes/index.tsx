import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { categories, logo, type MenuItem } from "@/lib/menu-data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "المعصرة — Taste the Best | عصائر وسموزي وآيس كريم" },
      {
        name: "description",
        content:
          "منيو المعصرة: عصائر طازجة، سموزي، ميلك شيك، وآيس كريم بأجود المكونات. اضغط على أي صنف لتكبيره ورؤيته بالتفصيل.",
      },
      { property: "og:title", content: "المعصرة — Taste the Best" },
      {
        property: "og:description",
        content: "منيو تفاعلي كامل بالصور: عصائر، سموزي، ميلك شيك، وآيس كريم.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const [active, setActive] = useState<MenuItem | null>(null);

  return (
    <div dir="rtl" className="min-h-screen bg-background text-foreground">
      <header className="relative overflow-hidden border-b border-border">
        <div className="absolute inset-0 opacity-40 [background-image:radial-gradient(circle_at_20%_20%,var(--brand)_0,transparent_35%),radial-gradient(circle_at_80%_60%,oklch(0.85_0.12_60)_0,transparent_40%)]" />
        <div className="relative mx-auto flex max-w-6xl flex-col items-center px-6 py-14 text-center">
          <img
            src={logo}
            alt="المعصرة - Taste the Best"
            className="h-40 w-auto sm:h-52 drop-shadow-sm"
            width={520}
            height={520}
          />
          <p className="mt-4 max-w-xl text-sm sm:text-base text-muted-foreground">
            كل صنف مصور بالتفصيل — اضغط على الصورة لتكبيرها ومشاهدتها عن قرب.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-2">
            {categories.map((c) => (
              <a
                key={c.id}
                href={`#${c.id}`}
                className="rounded-full border border-border bg-card px-4 py-1.5 text-sm font-medium transition hover:border-primary hover:text-primary"
              >
                {c.titleAr}
              </a>
            ))}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-10 sm:py-14">
        {categories.map((cat) => (
          <section key={cat.id} id={cat.id} className="mb-14 scroll-mt-6">
            <div className="mb-6 flex items-end justify-between border-b border-border pb-3">
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">
                <span className="text-primary">{cat.titleAr}</span>
                <span className="mr-3 text-sm font-normal text-muted-foreground">{cat.titleEn}</span>
              </h2>
              <span className="text-xs text-muted-foreground">اضغط على الصورة للتكبير</span>
            </div>

            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 sm:gap-5 lg:grid-cols-4">
              {cat.items.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActive(item)}
                  className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card text-right shadow-sm transition hover:-translate-y-1 hover:shadow-xl focus:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <div className="relative aspect-square overflow-hidden bg-muted">
                    <img
                      src={item.image}
                      alt={item.nameAr}
                      loading="lazy"
                      width={900}
                      height={900}
                      className="h-full w-full object-cover transition duration-500 group-hover:scale-110"
                    />
                    <div className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-black/50 to-transparent opacity-0 transition group-hover:opacity-100" />
                    <span className="absolute bottom-2 left-2 rounded-full bg-white/95 px-2.5 py-1 text-[11px] font-semibold text-primary opacity-0 shadow transition group-hover:opacity-100">
                      عرض بالحجم الكامل
                    </span>
                  </div>
                  <div className="flex items-center justify-between gap-2 p-3">
                    <div className="min-w-0">
                      <h3 className="truncate text-sm font-bold sm:text-base">{item.nameAr}</h3>
                      <p className="truncate text-[11px] text-muted-foreground">{item.nameEn}</p>
                    </div>
                    <span className="shrink-0 rounded-lg bg-primary/10 px-2 py-1 text-xs font-bold text-primary">
                      {item.price} LE
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </section>
        ))}
      </main>

      <footer className="border-t border-border bg-card">
        <div className="mx-auto flex max-w-6xl flex-col items-center gap-2 px-6 py-8 text-center">
          <p className="text-sm font-semibold">كن على تواصل</p>
          <p className="text-sm text-muted-foreground">www.almaasara.com · +123-456-7890</p>
          <p className="mt-2 text-xs text-muted-foreground">© {new Date().getFullYear()} المعصرة — Taste the Best</p>
        </div>
      </footer>

      <Dialog open={!!active} onOpenChange={(o) => !o && setActive(null)}>
        <DialogContent className="max-w-3xl overflow-hidden border-border bg-card p-0" dir="rtl">
          {active && (
            <div className="flex flex-col">
              <div className="relative aspect-square w-full bg-muted sm:aspect-[4/3]">
                <img
                  src={active.image}
                  alt={active.nameAr}
                  className="h-full w-full object-cover"
                  width={900}
                  height={900}
                />
              </div>
              <div className="flex items-center justify-between gap-4 p-5">
                <div>
                  <DialogTitle className="text-xl font-bold sm:text-2xl">{active.nameAr}</DialogTitle>
                  <DialogDescription className="text-sm text-muted-foreground">
                    {active.nameEn}
                  </DialogDescription>
                </div>
                <span className="rounded-xl bg-primary px-4 py-2 text-lg font-bold text-primary-foreground shadow">
                  {active.price} LE
                </span>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
