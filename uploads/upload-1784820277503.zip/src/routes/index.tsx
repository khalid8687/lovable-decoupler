import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

import logo from "@/assets/logo.png";
import imgRouter2921 from "@/assets/products/router-cisco-2921.jpg";
import imgRouter2800 from "@/assets/products/router-cisco.jpg";
import img7911 from "@/assets/products/cisco-7911.webp";
import img7841 from "@/assets/products/cisco-7841.jpg";
import imgServer from "@/assets/products/server-hp.webp";
import imgIssabel from "@/assets/products/issabel-pbx.webp";
import imgCmeSystem from "@/assets/products/cme-system.jpg";

export const Route = createFileRoute("/")({
  component: QuotePage,
});

type Lang = "en" | "ar";

const CLIENT_NAME_EN = "Mr. Hamdy";
const CLIENT_NAME_AR = "الاستاذ حمدي";
const PHONE = "201002194451";
const WHATSAPP = `https://wa.me/${PHONE}`;
const TEL = `tel:+${PHONE}`;

type Item = { name_en: string; name_ar: string; img: string; qty: number; price: number };

const CME_ITEMS: Item[] = [
  { name_en: "Cisco Router 2921 (CUCM Gateway)", name_ar: "راوتر سيسكو 2921 (بوابة CUCM)", img: imgRouter2921, qty: 1, price: 9100 },
  { name_en: "CME System Setup & Configuration", name_ar: "تنصيب وضبط نظام CME", img: imgCmeSystem, qty: 1, price: 8000 },
];

const PBX_ITEMS: Item[] = [
  { name_en: "Cisco Router 2800 (VoIP Gateway)", name_ar: "راوتر سيسكو 2800 (بوابة VoIP)", img: imgRouter2800, qty: 1, price: 6600 },
  { name_en: "PBX Server (HP Desktop, i5, 12GB RAM, 256GB SSD)", name_ar: "سيرفر PBX (HP، i5، رام 12، SSD 256)", img: imgServer, qty: 1, price: 6100 },
  { name_en: "Issabel PBX System — Full Configuration", name_ar: "نظام Issabel PBX — تنصيب كامل", img: imgIssabel, qty: 1, price: 14000 },
];

const OPTIONAL_PHONES: Item[] = [
  { name_en: "Cisco IP Phone 7911", name_ar: "تليفون سيسكو IP 7911", img: img7911, qty: 1, price: 750 },
  { name_en: "Cisco IP Phone 7841", name_ar: "تليفون سيسكو IP 7841", img: img7841, qty: 1, price: 2250 },
];

const CME_FEATURES = {
  en: {
    included: [
      "Simple internal calling between extensions",
      "Basic external calling (incoming & outgoing)",
      "Cisco enterprise-grade router hardware",
      "Lightweight setup — low maintenance",
      "Ideal for small teams (up to ~10 extensions)",
    ],
    excluded: [
      "No dedicated PBX server",
      "No call recording",
      "No IVR (auto-attendant menus)",
      "No advanced call analytics or CDR reports",
      "No voicemail-to-email or ring groups",
    ],
  },
  ar: {
    included: [
      "مكالمات داخلية بسيطة بين التحويلات",
      "مكالمات خارجية أساسية (وارد وصادر)",
      "راوتر سيسكو مؤسسي عالي الجودة",
      "تنصيب خفيف ومصاريف صيانة أقل",
      "مناسب للفرق الصغيرة (حتى ~10 تحويلات)",
    ],
    excluded: [
      "لا يوجد سيرفر سنترال مخصص",
      "لا يوجد تسجيل مكالمات",
      "لا يوجد IVR (الرد الآلي)",
      "لا توجد تقارير تحليلية متقدمة CDR",
      "لا يوجد بريد صوتي أو Ring Groups",
    ],
  },
};

const PBX_FEATURES = {
  en: {
    included: [
      "Full-featured Issabel PBX server",
      "Unlimited extensions & internal calls",
      "IVR — professional auto-attendant menus",
      "Full call recording for all lines",
      "CDR reports & call analytics dashboard",
      "Voicemail with email delivery",
      "Ring groups, queues & time conditions",
      "Call transfer, hold, park & conferencing",
      "Backup & restore of full configuration",
      "AI-ready platform for future automation",
      "Scalable to hundreds of users",
    ],
    excluded: [],
  },
  ar: {
    included: [
      "سيرفر Issabel PBX متكامل بكل المزايا",
      "تحويلات غير محدودة ومكالمات داخلية مجانية",
      "IVR — قوائم رد آلي احترافية",
      "تسجيل كامل لكل المكالمات",
      "تقارير CDR ولوحة تحليلات مكالمات",
      "بريد صوتي مع إرسال على الإيميل",
      "Ring Groups وطوابير انتظار وشروط وقت",
      "تحويل ومسك وحجز مكالمات ومؤتمرات",
      "نسخ احتياطي واستعادة كاملة للإعدادات",
      "منصة جاهزة لإضافة الذكاء الاصطناعي",
      "قابل للتوسع لمئات المستخدمين",
    ],
    excluded: [],
  },
};

const T = {
  en: {
    dir: "ltr" as const,
    company: "Switches Market",
    tagline: "Networking · VoIP · AI Solutions",
    switchLang: "العربية",
    heroTitle: "Choose Your Communication System",
    heroSub: "Two tailored offers — compare and pick what fits your business.",
    preparedFor: "Prepared for",
    clientName: CLIENT_NAME_EN,
    issued: "Issued",
    validUntil: "Valid until",
    validNote: "Both offers are valid for one week from the issue date.",
    cmeTitle: "CME System",
    cmeSubtitle: "Simple & Efficient",
    cmeBadge: "Entry Level",
    pbxTitle: "PBX System",
    pbxSubtitle: "Professional & Complete",
    pbxBadge: "Recommended",
    included: "What's Included",
    limitations: "Limitations",
    devices: "Devices & Components",
    total: "Total Price",
    qty: "Qty",
    unit: "Unit (EGP)",
    line: "Line Total",
    downloadCme: "Download CME Offer (PDF)",
    downloadPbx: "Download PBX Offer (PDF)",
    call: "Call",
    whatsapp: "WhatsApp",
    comparison: "Quick Comparison",
    feature: "Feature",
    termsTitle: "Terms & Conditions",
    terms: [
      "Both offers are valid for ONE WEEK from the issue date.",
      "Prices are in Egyptian Pounds (EGP).",
      "Payment: 60% advance before work begins, 40% on delivery/commissioning.",
      "Delivery & installation timeline: 5–10 business days from advance receipt.",
      "Hardware warranty: 1-month replacement on imported hardware parts only.",
      "Software warranty: starts from the first system startup / go-live date.",
      "Any additional scope beyond this quotation will be quoted separately.",
    ],
    optionalPhones: "Optional Phones — Choose What You Need",
    optionalNote: "Phones are not included in the offer total. Select any quantity and we will add it to the final invoice.",
  },
  ar: {
    dir: "rtl" as const,
    company: "Switches Market",
    tagline: "شبكات · فويب · حلول ذكاء اصطناعي",
    switchLang: "English",
    heroTitle: "اختر نظام الاتصالات المناسب لك",
    heroSub: "عرضان مخصصان — قارن واختر ما يناسب شركتك.",
    preparedFor: "مُعدّ للعميل",
    clientName: CLIENT_NAME_AR,
    issued: "تاريخ الإصدار",
    validUntil: "صالح حتى",
    validNote: "كلا العرضين ساري لمدة أسبوع واحد من تاريخ الإصدار.",
    cmeTitle: "نظام CME",
    cmeSubtitle: "بسيط وفعّال",
    cmeBadge: "المستوى الأساسي",
    pbxTitle: "نظام PBX",
    pbxSubtitle: "احترافي ومتكامل",
    pbxBadge: "الأنسب لك",
    included: "ما يشمله العرض",
    limitations: "القيود",
    devices: "الأجهزة والمكونات",
    total: "السعر الإجمالي",
    qty: "الكمية",
    unit: "السعر (ج.م)",
    line: "الإجمالي",
    downloadCme: "تحميل عرض CME (PDF)",
    downloadPbx: "تحميل عرض PBX (PDF)",
    call: "اتصل",
    whatsapp: "واتساب",
    comparison: "مقارنة سريعة",
    feature: "الخاصية",
    termsTitle: "الشروط والأحكام",
    terms: [
      "كلا العرضين ساري لمدة أسبوع واحد من تاريخ الإصدار.",
      "الأسعار بالجنيه المصري.",
      "الدفع: 60% مقدم قبل بدء العمل، و 40% عند التسليم.",
      "مدة التركيب والتشغيل: من 5 إلى 10 أيام عمل من استلام المقدم.",
      "ضمان الهاردوير: استبدال لمدة شهر على القطع الاستيراد فقط.",
      "ضمان السوفت وير: يبدأ من أول تشغيل للسيستم.",
      "أي أعمال إضافية خارج هذا العرض تُحسب بعرض منفصل.",
    ],
    optionalPhones: "تليفونات اختيارية — اختار اللى تحتاجه",
    optionalNote: "التليفونات مش متضمنة في إجمالي العرض. اختار أي كمية ونضيفها للفاتورة النهائية.",
  },
};

const COMPARISON_ROWS = [
  { key: "server", en: "Dedicated PBX Server", ar: "سيرفر سنترال مخصص", cme: false, pbx: true },
  { key: "recording", en: "Call Recording", ar: "تسجيل المكالمات", cme: false, pbx: true },
  { key: "ivr", en: "IVR / Auto-Attendant", ar: "IVR / الرد الآلي", cme: false, pbx: true },
  { key: "voicemail", en: "Voicemail to Email", ar: "بريد صوتي على الإيميل", cme: false, pbx: true },
  { key: "cdr", en: "CDR & Analytics", ar: "تقارير وتحليلات المكالمات", cme: false, pbx: true },
  { key: "ring", en: "Ring Groups & Queues", ar: "Ring Groups وطوابير", cme: false, pbx: true },
  { key: "internal", en: "Internal Calling", ar: "مكالمات داخلية", cme: true, pbx: true },
  { key: "external", en: "External Calling", ar: "مكالمات خارجية", cme: true, pbx: true },
  { key: "scale", en: "Scalable to Hundreds", ar: "قابل للتوسع لمئات المستخدمين", cme: false, pbx: true },
  { key: "ai", en: "AI-Ready Platform", ar: "منصة جاهزة للـ AI", cme: false, pbx: true },
];

function todayString(): string {
  return new Date().toLocaleDateString("en-GB", { year: "numeric", month: "long", day: "numeric" });
}
function validUntilString(): string {
  const d = new Date();
  d.setDate(d.getDate() + 7);
  return d.toLocaleDateString("en-GB", { year: "numeric", month: "long", day: "numeric" });
}
function sumItems(items: Item[]): number {
  return items.reduce((a, b) => a + b.qty * b.price, 0);
}

function makeOfferPdf(opts: {
  title: string;
  subtitle: string;
  items: Item[];
  included: string[];
  excluded: string[];
  filename: string;
  issued: string;
  valid: string;
  accent: [number, number, number];
}) {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const pageW = doc.internal.pageSize.getWidth();
  const pageH = doc.internal.pageSize.getHeight();

  // Header
  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, pageW, 34, "F");
  doc.setFillColor(opts.accent[0], opts.accent[1], opts.accent[2]);
  doc.rect(0, 34, pageW, 1.5, "F");
  try { doc.addImage(logo, "PNG", 12, 6, 22, 22); } catch { /* ignore */ }
  doc.setTextColor(255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(18);
  doc.text("Switches Market", 38, 16);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text("Networking · VoIP · AI Solutions", 38, 22);
  doc.text(`Phone: +${PHONE}`, pageW - 12, 16, { align: "right" });
  doc.text(`WhatsApp: wa.me/${PHONE}`, pageW - 12, 22, { align: "right" });

  // Title
  doc.setTextColor(15, 23, 42);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(22);
  doc.text(opts.title, 12, 50);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(11);
  doc.setTextColor(opts.accent[0], opts.accent[1], opts.accent[2]);
  doc.text(opts.subtitle, 12, 58);

  doc.setTextColor(80);
  doc.setFontSize(10);
  doc.text(`Prepared for: ${CLIENT_NAME_EN}`, 12, 68);
  doc.text(`Issued: ${opts.issued}`, 12, 74);
  doc.text(`Valid until: ${opts.valid}`, 12, 80);

  // Devices table
  autoTable(doc, {
    startY: 90,
    head: [["#", "Item", "Qty", "Unit (EGP)", "Total (EGP)"]],
    body: opts.items.map((it, i) => [
      String(i + 1),
      it.name_en,
      String(it.qty),
      it.price.toLocaleString(),
      (it.qty * it.price).toLocaleString(),
    ]),
    styles: { font: "helvetica", fontSize: 10, cellPadding: 3 },
    headStyles: { fillColor: opts.accent, textColor: 255, fontStyle: "bold" },
    alternateRowStyles: { fillColor: [241, 245, 249] },
    columnStyles: {
      0: { cellWidth: 10, halign: "center" },
      2: { cellWidth: 16, halign: "center" },
      3: { cellWidth: 32, halign: "right" },
      4: { cellWidth: 34, halign: "right" },
    },
  });

  let y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 8;
  const total = sumItems(opts.items);

  // Total box
  doc.setFillColor(opts.accent[0], opts.accent[1], opts.accent[2]);
  doc.rect(pageW - 90, y, 78, 14, "F");
  doc.setTextColor(255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.text("Grand Total:", pageW - 86, y + 9);
  doc.setFontSize(14);
  doc.text(`EGP ${total.toLocaleString()}`, pageW - 14, y + 9, { align: "right" });

  y += 22;

  // Included
  doc.setTextColor(15, 23, 42);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(12);
  doc.text("What's Included:", 12, y);
  y += 6;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(50);
  opts.included.forEach((line) => {
    if (y > pageH - 40) { doc.addPage(); y = 20; }
    const wrapped = doc.splitTextToSize(`• ${line}`, pageW - 24);
    doc.text(wrapped, 12, y);
    y += wrapped.length * 5 + 1;
  });

  if (opts.excluded.length) {
    y += 4;
    if (y > pageH - 40) { doc.addPage(); y = 20; }
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.setTextColor(15, 23, 42);
    doc.text("Limitations:", 12, y);
    y += 6;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.setTextColor(180, 60, 60);
    opts.excluded.forEach((line) => {
      if (y > pageH - 40) { doc.addPage(); y = 20; }
      const wrapped = doc.splitTextToSize(`× ${line}`, pageW - 24);
      doc.text(wrapped, 12, y);
      y += wrapped.length * 5 + 1;
    });
  }

  // Terms on new page if needed
  y += 6;
  if (y > pageH - 60) { doc.addPage(); y = 20; }
  doc.setDrawColor(200);
  doc.line(12, y, pageW - 12, y);
  y += 6;
  doc.setFont("helvetica", "bold");
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(11);
  doc.text("Terms & Conditions", 12, y);
  y += 6;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(70);
  T.en.terms.forEach((line, i) => {
    if (y > pageH - 25) { doc.addPage(); y = 20; }
    const wrapped = doc.splitTextToSize(`${i + 1}. ${line}`, pageW - 24);
    doc.text(wrapped, 12, y);
    y += wrapped.length * 5;
  });

  // Footer on every page
  const pageCount = doc.getNumberOfPages();
  for (let p = 1; p <= pageCount; p++) {
    doc.setPage(p);
    doc.setFillColor(15, 23, 42);
    doc.rect(0, pageH - 14, pageW, 14, "F");
    doc.setTextColor(255);
    doc.setFontSize(9);
    doc.text("Switches Market — Networking · VoIP · AI Solutions", 12, pageH - 5);
    doc.text(`+${PHONE}  ·  wa.me/${PHONE}`, pageW - 12, pageH - 5, { align: "right" });
  }

  doc.save(opts.filename);
}

function QuotePage() {
  const [lang, setLang] = useState<Lang>("ar");
  const [zoomImg, setZoomImg] = useState<{ src: string; alt: string } | null>(null);
  const t = T[lang];
  const issued = todayString();
  const valid = validUntilString();

  const cmeTotal = useMemo(() => sumItems(CME_ITEMS), []);
  const pbxTotal = useMemo(() => sumItems(PBX_ITEMS), []);

  const downloadCme = () => {
    makeOfferPdf({
      title: "CME System Offer",
      subtitle: "Simple & Efficient Communication",
      items: CME_ITEMS,
      included: CME_FEATURES.en.included,
      excluded: CME_FEATURES.en.excluded,
      filename: `SwitchesMarket-CME-Offer-${new Date().toISOString().slice(0, 10)}.pdf`,
      issued, valid,
      accent: [59, 130, 246],
    });
  };
  const downloadPbx = () => {
    makeOfferPdf({
      title: "PBX System Offer",
      subtitle: "Professional & Complete Communication Suite",
      items: PBX_ITEMS,
      included: PBX_FEATURES.en.included,
      excluded: PBX_FEATURES.en.excluded,
      filename: `SwitchesMarket-PBX-Offer-${new Date().toISOString().slice(0, 10)}.pdf`,
      issued, valid,
      accent: [16, 185, 129],
    });
  };

  return (
    <div dir={t.dir} className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-50 glass backdrop-blur-xl border-b border-border/50">
        <div className="mx-auto max-w-7xl px-4 md:px-8 py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <img src={logo} alt="Switches Market" className="h-10 w-10 md:h-12 md:w-12 object-contain animate-glow rounded-lg" />
            <div className="leading-tight">
              <div className="font-display font-bold text-base md:text-lg text-gradient">{t.company}</div>
              <div className="text-[10px] md:text-xs text-muted-foreground">{t.tagline}</div>
            </div>
          </div>
          <button
            onClick={() => setLang(lang === "en" ? "ar" : "en")}
            className="px-3 md:px-4 py-2 rounded-lg text-xs md:text-sm font-semibold border border-primary/40 hover:bg-primary/10 transition"
          >
            {t.switchLang}
          </button>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 grid-bg opacity-40" />
        <div className="absolute top-20 -left-20 w-96 h-96 rounded-full bg-primary/20 blur-3xl animate-float" />
        <div className="absolute bottom-0 -right-20 w-96 h-96 rounded-full bg-accent/20 blur-3xl animate-float" style={{ animationDelay: "1.5s" }} />

        <div className="relative mx-auto max-w-7xl px-4 md:px-8 py-14 md:py-20">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass text-xs font-semibold text-cyan mb-6">
              <span className="w-2 h-2 rounded-full bg-cyan animate-pulse" />
              {t.company}
            </div>
            <h1 className="text-4xl md:text-6xl font-bold leading-tight">
              <span className="text-gradient">{t.heroTitle}</span>
            </h1>
            <p className="mt-4 text-lg md:text-xl text-muted-foreground max-w-2xl">{t.heroSub}</p>

            <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-3xl">
              <div className="glass rounded-xl p-4">
                <div className="text-xs text-muted-foreground">{t.preparedFor}</div>
                <div className="text-xl font-bold mt-1">{t.clientName}</div>
              </div>
              <div className="glass rounded-xl p-4">
                <div className="text-xs text-muted-foreground">{t.issued}</div>
                <div className="text-sm font-semibold mt-1">{issued}</div>
              </div>
              <div className="glass rounded-xl p-4 border-accent/40">
                <div className="text-xs text-muted-foreground">{t.validUntil}</div>
                <div className="text-sm font-semibold mt-1 text-accent">{valid}</div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Two Offers side by side */}
      <section className="mx-auto max-w-7xl px-4 md:px-8 py-8 md:py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
          <OfferCard
            variant="cme"
            lang={lang}
            title={t.cmeTitle}
            subtitle={t.cmeSubtitle}
            badge={t.cmeBadge}
            items={CME_ITEMS}
            included={CME_FEATURES[lang].included}
            excluded={CME_FEATURES[lang].excluded}
            total={cmeTotal}
            t={t}
            onDownload={downloadCme}
            downloadLabel={t.downloadCme}
            onImageClick={(src, alt) => setZoomImg({ src, alt })}
          />
          <OfferCard
            variant="pbx"
            lang={lang}
            title={t.pbxTitle}
            subtitle={t.pbxSubtitle}
            badge={t.pbxBadge}
            items={PBX_ITEMS}
            included={PBX_FEATURES[lang].included}
            excluded={PBX_FEATURES[lang].excluded}
            total={pbxTotal}
            t={t}
            onDownload={downloadPbx}
            downloadLabel={t.downloadPbx}
            onImageClick={(src, alt) => setZoomImg({ src, alt })}
          />
        </div>
      </section>

      {/* Optional Phones */}
      <section className="mx-auto max-w-7xl px-4 md:px-8 py-8 md:py-12">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="glass rounded-2xl border border-border/50 overflow-hidden">
          <div className="p-6 md:p-8 border-b border-border/50 bg-secondary/30">
            <h2 className="text-2xl md:text-3xl font-bold text-gradient">{t.optionalPhones}</h2>
            <p className="mt-2 text-sm md:text-base text-muted-foreground">{t.optionalNote}</p>
          </div>
          <div className="p-6 md:p-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {OPTIONAL_PHONES.map((it, i) => (
                <div key={i} className="flex items-center gap-3 p-4 rounded-xl bg-secondary/30 border border-border/40">
                  <button
                    type="button"
                    onClick={() => setZoomImg({ src: it.img, alt: lang === "ar" ? it.name_ar : it.name_en })}
                    className="w-20 h-20 flex-shrink-0 bg-white rounded-lg flex items-center justify-center overflow-hidden cursor-zoom-in ring-1 ring-border/60 hover:ring-2 hover:ring-primary transition-all group relative"
                    aria-label={lang === "ar" ? "تكبير الصورة" : "Zoom image"}
                  >
                    <img src={it.img} alt={lang === "ar" ? it.name_ar : it.name_en} className="max-h-16 max-w-16 object-contain group-hover:scale-110 transition-transform" />
                    <span className="absolute bottom-0.5 right-0.5 text-[9px] bg-black/60 text-white rounded px-1 opacity-0 group-hover:opacity-100 transition-opacity">🔍</span>
                  </button>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold leading-snug truncate">{lang === "ar" ? it.name_ar : it.name_en}</div>
                    <div className="text-xs text-muted-foreground mt-0.5">{t.qty}: {it.qty} × EGP {it.price.toLocaleString()}</div>
                  </div>
                  <div className="text-sm font-bold tabular-nums text-primary">EGP {(it.qty * it.price).toLocaleString()}</div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </section>

      {/* Comparison table */}
      <section className="mx-auto max-w-7xl px-4 md:px-8 py-8 md:py-12">
        <motion.h2 initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-2xl md:text-4xl font-bold mb-8">
          <span className="text-gradient">{t.comparison}</span>
        </motion.h2>
        <div className="glass rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-secondary/50">
                  <th className={`p-4 ${t.dir === "rtl" ? "text-right" : "text-left"} font-semibold`}>{t.feature}</th>
                  <th className="p-4 text-center font-semibold text-primary">{t.cmeTitle}</th>
                  <th className="p-4 text-center font-semibold text-accent">{t.pbxTitle}</th>
                </tr>
              </thead>
              <tbody>
                {COMPARISON_ROWS.map((row) => (
                  <tr key={row.key} className="border-t border-border/50 hover:bg-primary/5 transition">
                    <td className={`p-4 ${t.dir === "rtl" ? "text-right" : "text-left"} font-medium`}>
                      {lang === "ar" ? row.ar : row.en}
                    </td>
                    <td className="p-4 text-center">
                      {row.cme ? <Check /> : <Cross />}
                    </td>
                    <td className="p-4 text-center">
                      {row.pbx ? <Check /> : <Cross />}
                    </td>
                  </tr>
                ))}
                <tr className="border-t-2 border-border bg-secondary/30 font-bold">
                  <td className={`p-4 ${t.dir === "rtl" ? "text-right" : "text-left"}`}>{t.total}</td>
                  <td className="p-4 text-center text-primary text-lg tabular-nums">EGP {cmeTotal.toLocaleString()}</td>
                  <td className="p-4 text-center text-accent text-lg tabular-nums">EGP {pbxTotal.toLocaleString()}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div className="mt-6 glass rounded-xl p-4 border-accent/40 flex items-center gap-3">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-accent flex-shrink-0"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
          <span className="text-sm font-medium">{t.validNote}</span>
        </div>
      </section>

      {/* Terms */}
      <section className="mx-auto max-w-7xl px-4 md:px-8 py-8 md:py-12">
        <motion.h2 initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-2xl md:text-4xl font-bold mb-8">
          <span className="text-gradient">{t.termsTitle}</span>
        </motion.h2>
        <div className="glass rounded-xl p-6 md:p-8 border-accent/40">
          <ul className="space-y-4">
            {t.terms.map((term, i) => (
              <li key={i} className={`flex items-start gap-3 ${t.dir === "rtl" ? "flex-row-reverse text-right" : "text-left"}`}>
                <span className="flex-shrink-0 w-6 h-6 rounded-full btn-primary flex items-center justify-center text-xs font-bold text-primary-foreground">{i + 1}</span>
                <span className="leading-relaxed text-sm md:text-base text-muted-foreground">{term}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="relative py-14 md:py-20 overflow-hidden">
        <div className="absolute inset-0 grid-bg opacity-30" />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/10 to-transparent" />
        <div className="relative mx-auto max-w-4xl px-4 md:px-8 text-center">
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href={TEL} className="btn-primary hover:btn-primary-hover px-8 py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-3">
              {t.call} · +{PHONE}
            </a>
            <a href={WHATSAPP} target="_blank" rel="noopener noreferrer"
               className="px-8 py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-3 border-2 border-[#25D366] text-[#25D366] hover:bg-[#25D366] hover:text-white transition">
              {t.whatsapp}
            </a>
          </div>
        </div>
      </section>

      <footer className="border-t border-border/50 py-8 text-center text-sm text-muted-foreground">
        <div className="mx-auto max-w-7xl px-4">
          <div className="font-display font-bold text-gradient text-lg mb-1">{t.company}</div>
          <div>{t.tagline}</div>
          <div className="mt-2">+{PHONE}</div>
        </div>
      </footer>
      {zoomImg && (
        <div
          onClick={() => setZoomImg(null)}
          className="fixed inset-0 z-[100] bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 cursor-zoom-out"
        >
          <button
            onClick={() => setZoomImg(null)}
            aria-label="Close"
            className="absolute top-4 right-4 w-11 h-11 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center text-2xl"
          >
            ×
          </button>
          <img
            src={zoomImg.src}
            alt={zoomImg.alt}
            onClick={(e) => e.stopPropagation()}
            className="max-h-[90vh] max-w-[92vw] object-contain rounded-xl bg-white p-4 shadow-2xl"
          />
          <div className="absolute bottom-6 left-0 right-0 text-center text-white/90 text-sm font-medium px-4 pointer-events-none">
            {zoomImg.alt}
          </div>
        </div>
      )}
    </div>
  );
}

function Check() {
  return (
    <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-accent/20 text-accent">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>
    </span>
  );
}
function Cross() {
  return (
    <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-destructive/20 text-destructive">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
    </span>
  );
}

function OfferCard(props: {
  variant: "cme" | "pbx";
  lang: Lang;
  title: string;
  subtitle: string;
  badge: string;
  items: Item[];
  included: string[];
  excluded: string[];
  total: number;
  t: (typeof T)[Lang];
  onDownload: () => void;
  downloadLabel: string;
  onImageClick: (src: string, alt: string) => void;
}) {
  const { variant, lang, title, subtitle, badge, items, included, excluded, total, t, onDownload, downloadLabel, onImageClick } = props;
  const accentClass = variant === "pbx" ? "text-accent" : "text-primary";
  const borderClass = variant === "pbx" ? "border-accent/60" : "border-primary/60";
  const ringGlow = variant === "pbx" ? "shadow-[0_0_40px_-10px_oklch(0.7_0.2_170/0.4)]" : "";

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className={`glass rounded-2xl overflow-hidden border-2 ${borderClass} flex flex-col ${ringGlow}`}
    >
      <div className={`p-6 md:p-8 border-b border-border/50 ${variant === "pbx" ? "bg-accent/5" : "bg-primary/5"}`}>
        <div className="flex items-center justify-between gap-3 mb-3">
          <span className={`inline-block px-3 py-1 rounded-full text-[11px] font-bold ${variant === "pbx" ? "bg-accent/20 text-accent" : "bg-primary/20 text-primary"}`}>
            {badge}
          </span>
          {variant === "pbx" && (
            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-accent">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
              PRO
            </span>
          )}
        </div>
        <h3 className={`text-3xl md:text-4xl font-bold ${accentClass}`}>{title}</h3>
        <p className="text-sm text-muted-foreground mt-2">{subtitle}</p>
        <div className={`mt-5 flex items-baseline gap-2 ${t.dir === "rtl" ? "flex-row-reverse justify-end" : ""}`}>
          <span className={`text-4xl md:text-5xl font-black tabular-nums ${accentClass}`}>EGP {total.toLocaleString()}</span>
        </div>
      </div>

      <div className="p-6 md:p-8 flex-1 space-y-6">
        {/* Devices */}
        <div>
          <div className="text-sm font-bold uppercase tracking-wide text-muted-foreground mb-3">{t.devices}</div>
          <div className="space-y-3">
            {items.map((it, i) => (
              <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-secondary/30 border border-border/40">
                <button
                  type="button"
                  onClick={() => onImageClick(it.img, lang === "ar" ? it.name_ar : it.name_en)}
                  className="w-20 h-20 flex-shrink-0 bg-white rounded-lg flex items-center justify-center overflow-hidden cursor-zoom-in ring-1 ring-border/60 hover:ring-2 hover:ring-primary transition-all group relative"
                  aria-label={lang === "ar" ? "تكبير الصورة" : "Zoom image"}
                >
                  <img src={it.img} alt={lang === "ar" ? it.name_ar : it.name_en} className="max-h-16 max-w-16 object-contain group-hover:scale-110 transition-transform" />
                  <span className="absolute bottom-0.5 right-0.5 text-[9px] bg-black/60 text-white rounded px-1 opacity-0 group-hover:opacity-100 transition-opacity">🔍</span>
                </button>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold leading-snug truncate">{lang === "ar" ? it.name_ar : it.name_en}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    {t.qty}: {it.qty} × EGP {it.price.toLocaleString()}
                  </div>
                </div>
                <div className={`text-sm font-bold tabular-nums ${accentClass}`}>
                  EGP {(it.qty * it.price).toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Included */}
        <div>
          <div className="text-sm font-bold uppercase tracking-wide text-muted-foreground mb-3">{t.included}</div>
          <ul className="space-y-2">
            {included.map((f, i) => (
              <li key={i} className={`flex items-start gap-2 ${t.dir === "rtl" ? "flex-row-reverse text-right" : ""}`}>
                <Check />
                <span className="text-sm leading-relaxed pt-1">{f}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Excluded */}
        {excluded.length > 0 && (
          <div>
            <div className="text-sm font-bold uppercase tracking-wide text-muted-foreground mb-3">{t.limitations}</div>
            <ul className="space-y-2">
              {excluded.map((f, i) => (
                <li key={i} className={`flex items-start gap-2 ${t.dir === "rtl" ? "flex-row-reverse text-right" : ""}`}>
                  <Cross />
                  <span className="text-sm leading-relaxed pt-1 text-muted-foreground">{f}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      <div className="p-6 md:p-8 border-t border-border/50 bg-secondary/20">
        <button
          onClick={onDownload}
          className={`w-full px-6 py-4 rounded-xl font-bold text-base flex items-center justify-center gap-2 transition ${variant === "pbx" ? "bg-accent text-accent-foreground hover:opacity-90" : "btn-primary hover:btn-primary-hover"}`}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
          {downloadLabel}
        </button>
      </div>
    </motion.div>
  );
}
