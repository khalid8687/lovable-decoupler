import pricingConfig from "./pricing-config.json";

export type PricingPayload = {
  flutter: {
    total: string;
    milestones: { title: string; detail: string; amount: string }[];
  };
  pwa: {
    total: string;
    milestones: { title: string; detail: string; amount: string }[];
  };
  operating: {
    monthly: { label: string; amount: string }[];
    monthlyTotal: string;
    stores: { label: string; amount: string }[];
  };
};

export const PRICING_PAYLOAD: PricingPayload = {
  flutter: {
    total: "230,000 جنيه مصري",
    milestones: [
      { title: "الدفعة الأولى", detail: "التخطيط الهندسي للنظام وتصميم واجهات المستخدم (UI/UX).", amount: "70,000" },
      { title: "الدفعة الثانية", detail: "الانتهاء من برمجة الواجهات الأساسية للتطبيق (iOS & Android).", amount: "50,000" },
      { title: "الدفعة الثالثة", detail: "برمجة الخوادم (Backend) ودمج أنظمة تشفير الفيديوهات (DRM).", amount: "52,000" },
      { title: "الدفعة الرابعة", detail: "تفعيل تقنيات الحماية (AI وربط الأجهزة) وإصدار نسخة تجريبية.", amount: "42,000" },
      { title: "الدفعة الأخيرة", detail: "الاختبار النهائي، التسليم، والرفع الرسمي على متاجر آبل وجوجل.", amount: "16,000" },
    ],
  },
  pwa: {
    total: "62,000 جنيه مصري",
    milestones: [
      { title: "الدفعة الأولى", detail: "التخطيط الهندسي وتصميم واجهات المنصة (UI/UX).", amount: "18,500" },
      { title: "الدفعة الثانية", detail: "برمجة النظام الأساسي (PWA) وواجهات المستخدم الشاملة.", amount: "12,500" },
      { title: "الدفعة الثالثة", detail: "برمجة الخوادم ودمج خوارزميات التشفير والبث (DRM).", amount: "14,000" },
      { title: "الدفعة الرابعة", detail: "تغليف التطبيق بتقنيات Capacitor و TWA وتفعيل حماية الذكاء الاصطناعي.", amount: "12,000" },
      { title: "الدفعة الأخيرة", detail: "الاختبار النهائي للنسخ المجمعة، والرفع الرسمي على متاجر آبل وجوجل.", amount: "5,000" },
    ],
  },
  operating: {
    monthly: [
      { label: "تخزين الفيديوهات (300 جيجابايت)", amount: "≈ 3 $ / شهرياً" },
      { label: "استهلاك البث والمشاهدة (Bandwidth)", amount: "≈ 30 $ / شهرياً" },
      { label: "خادم إدارة الحسابات / CDN", amount: "≈ 15 $ / شهرياً" },
    ],
    monthlyTotal: "≈ 48 $ شهرياً",
    stores: [
      { label: "متجر Apple (App Store)", amount: "99 $ سنوياً" },
      { label: "متجر Google (Play Store)", amount: "25 $ مرة واحدة" },
    ],
  },
};

function normalizePassword(value: string) {
  return value.replace(/[\u200B-\u200D\uFEFF]/g, "").trim();
}

export function unlockPricing(password: string): { ok: true; payload: PricingPayload } | { ok: false } {
  if (normalizePassword(password) !== normalizePassword(pricingConfig.password)) return { ok: false };
  return { ok: true, payload: PRICING_PAYLOAD };
}