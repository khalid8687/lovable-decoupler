import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";

import logoUrl from "@/assets/oltani-logo.webp";
import heroImg from "@/assets/hero-main.jpg";
import imgFace from "@/assets/feature-face-detection.jpg";
import imgDrm from "@/assets/feature-drm.jpg";
import imgScreen from "@/assets/feature-screen-block.jpg";
import imgDevice from "@/assets/feature-device-binding.jpg";
import imgWatermark from "@/assets/feature-watermark.jpg";

import { unlockPricing, type PricingPayload } from "@/lib/pricing-data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "OLTANI | عرض منصة الكورسات الطبية الآمنة" },
      {
        name: "description",
        content:
          "عرض فني ومالي من OLTANI لمنصة كورسات طبية آمنة للدكتور محمد هاشم، مع مقارنة Flutter و PWA وحماية DRM والذكاء الاصطناعي.",
      },
      { property: "og:title", content: "OLTANI | عرض منصة الكورسات الطبية الآمنة" },
      {
        property: "og:description",
        content: "عرض مخصص لمنصة كورسات طبية آمنة مع اختيار Flutter أو PWA وتسعير خاص محمي بكلمة سر.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProposalPage,
});

const PHONE = "201002194451";
const WHATSAPP_URL = `https://wa.me/${PHONE}`;
const TEL_URL = `tel:+${PHONE}`;

type FeatureDef = {
  title: string;
  en: string;
  image: string;
  desc: string;
  simple: string;
};

const FEATURES: FeatureDef[] = [
  {
    title: "التعرف على الوجوه بالذكاء الاصطناعي",
    en: "AI Face Detection",
    image: imgFace,
    desc: "الكاميرا تتحقق أثناء المشاهدة من وجود وجه الطالب فقط، وتوقف الفيديو فوراً عند اكتشاف أي وجه آخر أو غياب الطالب.",
    simple:
      "ببساطة: الكاميرا تتأكد إن اللي بيتفرج فعلاً هو الطالب صاحب الحساب — لو حد تاني قعد جنبه أو مسك موبايله، الفيديو بيقف لوحده.",
  },
  {
    title: "تشفير الفيديوهات DRM & HLS",
    en: "DRM Streaming",
    image: imgDrm,
    desc: "الفيديوهات مُقطّعة ومُشفّرة بنظام بث معقد يمنع تحميلها ببرامج مثل IDM أو إضافات المتصفحات.",
    simple:
      "ببساطة: الفيديو مش ملف واحد ممكن يتنزّل، ده مقسّم لآلاف القطع المشفّرة اللي بتتجمّع لحظياً على شاشة الطالب فقط.",
  },
  {
    title: "منع تصوير وتسجيل الشاشة",
    en: "Screen Record Prevention",
    image: imgScreen,
    desc: "حظر برمجي صارم للسكرين شوت وتسجيل الشاشة، وعند المحاولة تظهر الشاشة سوداء بالكامل.",
    simple:
      "ببساطة: لو الطالب حاول ياخد صورة للشاشة أو يسجل فيديو، هيلاقي الشاشة سودا خالص، ومش هيقدر يحفظ أي حاجة من المحتوى.",
  },
  {
    title: "ربط الحساب بالجهاز",
    en: "Device Binding",
    image: imgDevice,
    desc: "الحساب مرتبط بالمعرف الرقمي للهاتف — لا يمكن فتحه من أي جهاز آخر، فلا مشاركة للحسابات بين الطلاب.",
    simple:
      "ببساطة: كل حساب مربوط بموبايل واحد بس. لو طالب حاول يدي بياناته لصاحبه ليدخل من موبايل تاني، النظام مش هيسمح.",
  },
  {
    title: "علامة مائية ديناميكية",
    en: "Dynamic Watermark",
    image: imgWatermark,
    desc: "رقم هاتف الطالب يتحرك بشفافية على الشاشة، فأي محاولة تصوير خارجي تُثبت هوية المُسرّب ويُحظر حسابه تلقائياً.",
    simple:
      "ببساطة: رقم موبايل كل طالب بيظهر متحرك بشفافية فوق الفيديو. لو حد صوّر الشاشة بموبايل تاني ونشرها، هنعرف من فوراً السبب ونحظره.",
  },
];

const PROJECT_STEPS = [
  {
    n: "01",
    title: "التخطيط الهندسي وتصميم الواجهات",
    desc: "بنقعد معاك، نفهم رؤيتك بالظبط، ونرسم شكل التطبيق وكل شاشة فيه قبل ما نبدأ برمجة أي حاجة. بتشوف شكل المنتج النهائي على ورق قبل ما ندفع جنيه في التطوير.",
  },
  {
    n: "02",
    title: "بناء واجهات التطبيق (Front-end)",
    desc: "بنبرمج الشاشات اللي شفتها في التصميم وتشتغل فعلاً — تسجيل الدخول، قائمة الكورسات، مشغّل الفيديو، صفحة الطالب — وكلها تعمل على موبايلك.",
  },
  {
    n: "03",
    title: "بناء الخوادم وأنظمة التشفير (Back-end + DRM)",
    desc: "ده جوهر الحماية: بنعمل السيرفرات اللي تخزن الفيديوهات مشفّرة، ونظام البث اللي مش بيسمح بالتحميل، وقاعدة بيانات الطلاب والمشتريات.",
  },
  {
    n: "04",
    title: "تفعيل طبقات الحماية الذكية",
    desc: "بندمج الذكاء الاصطناعي للتعرف على الوجه، منع سكرين شوت، ربط الحساب بالجهاز، والعلامة المائية المتحركة. النسخة التجريبية الكاملة بتوصلك للاختبار.",
  },
  {
    n: "05",
    title: "الاختبار النهائي والنشر الرسمي",
    desc: "بنختبر التطبيق تحت ضغط عالي، بنصلح أي ملاحظة، وبعدين بنرفعه رسمياً على App Store و Google Play باسم شركتك، ونسلمك مفاتيح الملكية الكاملة.",
  },
];

const WHY_QA = [
  {
    q: "ليه محتاجين تشفير DRM؟",
    a: "لأن الفيديو العادي أي حد يقدر ينزّله ببرنامج مجاني من على النت في ثواني. DRM بيخلي الفيديو مستحيل ينزّل — بيبقى مقطّع لآلاف القطع المشفّرة، وكل قطعة محتاجة مفتاح لحظي من السيرفر.",
  },
  {
    q: "ليه محتاجين نمنع سكرين شوت؟",
    a: "عشان لو طالب أخد صور للسلايدات المهمة وباعها لطلاب تانيين، ده ضرر مباشر على مبيعاتك. النظام بيمنع الصورة نهائياً، والشاشة بتبقى سودا لو حد جرّب.",
  },
  {
    q: "ليه محتاجين التعرف على الوجه؟",
    a: "عشان تضمن إن اللي بيتفرج فعلاً هو الطالب اللي دفع، مش صاحبه أو أخوه. ده بيحمي محتواك من إن حساب واحد يستفيد منه ٥ ناس.",
  },
  {
    q: "ليه في عرضين مختلفين؟",
    a: "عشان نديك حرية الاختيار: Flutter بيبني تطبيق أصلي بأداء أعلى وأسعار أعلى، و PWA بيبني منصة أرخص وأسرع في التحديث لكن بنفس الحماية.",
  },
  {
    q: "بعد التسليم، الملكية لمين؟",
    a: "الملكية الكاملة ليك أنت شخصياً: الكود، الحسابات، السيرفرات، اسم التطبيق على المتاجر — كله باسمك ومفاتيحه في يدك.",
  },
];

function useReveal(dep?: unknown) {
  useEffect(() => {
    const els = document.querySelectorAll(".reveal:not(.in)");
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("in");
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12 },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [dep]);
}

function todayArabic() {
  try {
    return new Intl.DateTimeFormat("ar-EG", {
      day: "2-digit",
      month: "long",
      year: "numeric",
    }).format(new Date());
  } catch {
    return new Date().toISOString().slice(0, 10);
  }
}


function ProposalPage() {
  const [pricing, setPricing] = useState<PricingPayload | null>(null);
  const [gateOpen, setGateOpen] = useState(false);
  useReveal(pricing);
  const date = todayArabic();

  return (
    <>
      <div className="oltani-bg" aria-hidden="true" />

      <Header />

      <main className="mx-auto max-w-6xl px-4 pb-32 pt-6 md:pt-10">
        <Hero />

        <SectionDivider label="طبقات الحماية المتقدمة" />
        <FeaturesGrid />

        <SectionDivider label="ليه محتاجين كل ده؟" />
        <WhyQA />

        <SectionDivider label="خطوات تنفيذ المشروع" />
        <ProjectSteps />

        <SectionDivider label="اختر الحل المناسب لك" />
        <OffersIntro />

        <div id="pricing" className="mt-8 grid gap-8 lg:grid-cols-2 scroll-mt-24">
          <OfferCard
            variant="flutter"
            title="Flutter + Dart"
            subtitle="تطبيق أصلي متكامل (iOS & Android)"
            summary="خزنة إلكترونية أصلية بأعلى مستوى حماية ممكن، مبنية بلغة Dart وإطار Flutter، تعمل على أنظمة iOS و Android بأداء أصلي."
            bullets={[
              "أداء أصلي (Native) على iOS و Android",
              "الوصول الكامل لحماية النظام (DRM / منع التصوير / AI)",
              "تجربة سلسة بدون اعتماد على المتصفح",
              "قابل للنشر الرسمي على App Store و Google Play",
            ]}
            forWho="الأنسب لو: عايز أعلى مستوى حماية وأداء ممكن، ومستعد للاستثمار الأكبر في مقابل تطبيق أصلي كامل."
            pricing={pricing?.flutter}
          />
          <OfferCard
            variant="pwa"
            title="PWA + Capacitor / TWA"
            subtitle="ويب تقدمي مغلّف كتطبيق"
            summary="بديل اقتصادي وسريع: منصة PWA مركزية تُغلَّف بتقنيات Capacitor و TWA لتُحمَّل من متاجر Apple و Google مع تحديثات لحظية للمحتوى."
            bullets={[
              "تحديثات لحظية للمحتوى بدون انتظار مراجعة المتاجر",
              "منصة مركزية موحّدة تعمل على كل الأجهزة",
              "طبقات حماية متكاملة داخل الغلاف الرسمي",
              "تكلفة تطوير أقل بكثير ونشر أسرع",
            ]}
            forWho="الأنسب لو: عايز تبدأ بأسرع وقت وتكلفة أقل، وبتحدّث الكورسات بشكل مستمر."
            pricing={pricing?.pwa}
          />
        </div>

        {pricing && <OperatingCosts data={pricing.operating} />}

        <SectionDivider label="الضمان والصيانة" />
        <Warranty />

        <Footer date={date} onOpenGate={() => setGateOpen(true)} unlocked={!!pricing} />
      </main>

      <FloatingButtons />
      {gateOpen && (
        <PricingGate
          onClose={() => setGateOpen(false)}
          onUnlock={(payload) => {
            setPricing(payload);
            setGateOpen(false);
            setTimeout(() => {
              document.getElementById("pricing")?.scrollIntoView({ behavior: "smooth", block: "start" });
            }, 120);
          }}
        />
      )}
    </>
  );
}

function Header() {
  return (
    <header className="sticky top-0 z-30 border-b border-white/5 bg-[rgba(5,6,13,0.7)] backdrop-blur-xl">
      <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
        <img
          src={logoUrl}
          alt="OLTANI"
          width={40}
          height={40}
          className="h-9 w-9 shrink-0 rounded-lg object-contain"
        />
        <div className="min-w-0 leading-tight">
          <div className="text-sm font-black text-white sm:text-base">OLTANI</div>
          <div className="truncate text-[10px] text-white/60 sm:text-[11px]">
            Open Link Technologies & Artificial Network Intelligence
          </div>
        </div>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section className="reveal mt-4 overflow-hidden rounded-3xl border border-white/10 bg-[rgba(11,16,36,0.5)]">
      <div className="grid gap-0 md:grid-cols-2">
        {/* Text */}
        <div className="order-2 flex flex-col items-start gap-4 p-6 md:order-1 md:p-10">
          <span className="pill">عرض حصري ومخصص</span>
          <h1 className="text-2xl font-black leading-tight text-white sm:text-3xl md:text-4xl lg:text-5xl">
            منصة الكورسات الطبية الآمنة
            <br />
            <span className="gradient-text">للدكتور محمد هاشم</span>
          </h1>
          <p className="text-sm leading-relaxed text-white/80 sm:text-base">
            خزنة إلكترونية متكاملة لحماية محتواك العلمي من القرصنة والتسريب وإعادة البيع،
            مبنية بأحدث تقنيات الذكاء الاصطناعي والتشفير الرقمي.
          </p>
          <div className="mt-1 flex flex-wrap gap-2">
            <span className="pill">iOS · Android · PWA</span>
            <span className="pill">AI + DRM</span>
            <span className="pill">Anti-Piracy</span>
          </div>
        </div>
        {/* Hero image */}
        <div className="order-1 aspect-video w-full overflow-hidden md:order-2 md:aspect-auto">
          <img src={heroImg} alt="منصة الكورسات الطبية" className="h-full w-full object-cover" loading="eager" />
        </div>
      </div>
    </section>
  );
}

function SectionDivider({ label }: { label: string }) {
  return (
    <div className="reveal my-12 flex items-center gap-4 md:my-16">
      <div className="h-px flex-1 bg-gradient-to-l from-transparent via-white/20 to-transparent" />
      <div className="pill">{label}</div>
      <div className="h-px flex-1 bg-gradient-to-r from-transparent via-white/20 to-transparent" />
    </div>
  );
}

function FeaturesGrid() {
  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {FEATURES.map((f) => (
        <article key={f.en} className="reveal glass-card overflow-hidden p-0">
          <div className="scan-frame">
            <img src={f.image} alt={f.title} className="h-48 w-full object-cover" loading="lazy" />
          </div>
          <div className="p-5">
            <div className="mb-1 text-[11px] font-bold uppercase tracking-wider text-[color:var(--oltani-blue)]">
              {f.en}
            </div>
            <h3 className="text-lg font-black text-white">{f.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-white/75">{f.desc}</p>
            <div className="mt-3 rounded-xl border border-white/10 bg-white/[0.03] p-3 text-[13px] leading-relaxed text-white/85">
              {f.simple}
            </div>
          </div>
        </article>
      ))}
    </div>
  );
}

function WhyQA() {
  return (
    <div className="reveal grid gap-4 md:grid-cols-2">
      {WHY_QA.map((item) => (
        <div key={item.q} className="glass-card p-5 md:p-6">
          <div className="flex items-start gap-3">
            <div className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-[var(--oltani-gradient)] text-sm font-black text-white">
              ؟
            </div>
            <div className="min-w-0 flex-1">
              <h4 className="text-base font-black text-white">{item.q}</h4>
              <p className="mt-2 text-sm leading-relaxed text-white/80">{item.a}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function ProjectSteps() {
  return (
    <div className="reveal relative">
      <ol className="space-y-5">
        {PROJECT_STEPS.map((s) => (
          <li key={s.n} className="relative">
            <div className="glass-card grid grid-cols-[auto_minmax(0,1fr)] items-start gap-4 p-5 md:gap-6 md:p-6">
              <div className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-[var(--oltani-gradient)] text-lg font-black text-white shadow-lg">
                {s.n}
              </div>
              <div className="min-w-0">
                <h4 className="text-base font-black text-white md:text-lg">{s.title}</h4>
                <p className="mt-2 text-sm leading-relaxed text-white/80">{s.desc}</p>
              </div>
            </div>
          </li>
        ))}
      </ol>
    </div>
  );
}

function OffersIntro() {
  return (
    <div className="reveal glass-card p-6 md:p-8">
      <p className="text-center text-sm leading-relaxed text-white/85 md:text-base">
        نقدّم لسيادتكم عرضين متكاملين — كلاهما يحقق نفس الهدف من الحماية والأمان،
        ولكن يختلفان في المعمارية والتكلفة وسرعة التحديث. اختر الحل الذي يناسبك
        وسنبدأ التنفيذ فوراً.
      </p>
    </div>
  );
}

function OfferCard({
  variant,
  title,
  subtitle,
  summary,
  bullets,
  forWho,
  pricing,
}: {
  variant: "flutter" | "pwa";
  title: string;
  subtitle: string;
  summary: string;
  bullets: string[];
  forWho: string;
  pricing?: { total: string; milestones: { title: string; detail: string; amount: string }[] };
}) {
  const accent = variant === "flutter" ? "var(--oltani-blue)" : "var(--oltani-orange)";
  return (
    <article className="reveal glass-card overflow-hidden p-0">
      <div
        className="h-3 w-full"
        style={{ background: `linear-gradient(90deg, ${accent}, transparent)` }}
      />
      <div className="p-6 md:p-8">
        <div className="flex items-center gap-2">
          <span
            className="inline-block h-2 w-2 rounded-full"
            style={{ background: accent, boxShadow: `0 0 12px ${accent}` }}
          />
          <span className="text-xs font-bold uppercase tracking-wider text-white/60">
            {subtitle}
          </span>
        </div>
        <h3 className="mt-2 text-2xl font-black gradient-text">{title}</h3>
        <p className="mt-3 text-sm leading-relaxed text-white/80">{summary}</p>

        <ul className="mt-5 space-y-2">
          {bullets.map((b) => (
            <li key={b} className="flex items-start gap-2 text-sm text-white/85">
              <span
                className="mt-1 inline-block h-1.5 w-1.5 shrink-0 rounded-full"
                style={{ background: accent }}
              />
              <span>{b}</span>
            </li>
          ))}
        </ul>

        <div
          className="mt-5 rounded-xl border p-3 text-[13px] leading-relaxed text-white/85"
          style={{ borderColor: `${accent}40`, background: `${accent}0f` }}
        >
          {forWho}
        </div>

        {pricing ? (
          <div className="mt-6 rounded-2xl border border-white/10 bg-white/[0.03] p-5 no-select">
            <div className="mb-2 text-xs font-bold uppercase tracking-wider text-white/60">
              إجمالي تكلفة التطوير (تُدفع لمرة واحدة)
            </div>
            <div className="text-2xl font-black gradient-text">{pricing.total}</div>
            <div className="mt-4 space-y-2">
              {pricing.milestones.map((m, i) => (
                <div
                  key={i}
                  className="flex items-start justify-between gap-3 rounded-xl border border-white/5 bg-white/[0.02] p-3"
                >
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-bold text-white">{m.title}</div>
                    <div className="text-[11px] leading-relaxed text-white/60">{m.detail}</div>
                  </div>
                  <div className="shrink-0 text-sm font-black text-white">
                    {m.amount}
                    <span className="mr-1 text-[10px] font-normal text-white/50">ج.م</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : null}
      </div>
    </article>
  );
}

function OperatingCosts({ data }: { data: PricingPayload["operating"] }) {
  return (
    <>
      <SectionDivider label="المصروفات التشغيلية" />
      <div className="reveal glass-card p-6 md:p-8 no-select">
        <p className="text-sm leading-relaxed text-white/75">
          هذه التكاليف <strong>لا تدخل ضمن أتعاب التطوير</strong>، بل هي اشتراكات تُدفع مباشرة
          لمزودي الخدمات العالميين عبر البطاقة الائتمانية الخاصة بالدكتور لضمان الملكية التامة للمنصة.
        </p>

        <div className="mt-6 grid gap-6 md:grid-cols-2">
          <div>
            <div className="mb-3 text-xs font-bold uppercase tracking-wider text-[color:var(--oltani-blue)]">
              الاستضافة (شهرياً)
            </div>
            <ul className="space-y-2">
              {data.monthly.map((r, i) => (
                <li
                  key={i}
                  className="flex items-center justify-between rounded-xl border border-white/10 bg-white/[0.02] p-3 text-sm"
                >
                  <span className="text-white/85">{r.label}</span>
                  <span className="font-black text-white">{r.amount}</span>
                </li>
              ))}
              <li className="flex items-center justify-between rounded-xl border border-[color:var(--oltani-orange)]/40 bg-[color:var(--oltani-orange)]/10 p-3 text-sm">
                <span className="font-bold text-white">الإجمالي التقريبي</span>
                <span className="font-black gradient-text">{data.monthlyTotal}</span>
              </li>
            </ul>
          </div>

          <div>
            <div className="mb-3 text-xs font-bold uppercase tracking-wider text-[color:var(--oltani-orange)]">
              تراخيص متاجر التطبيقات
            </div>
            <ul className="space-y-2">
              {data.stores.map((r, i) => (
                <li
                  key={i}
                  className="flex items-center justify-between rounded-xl border border-white/10 bg-white/[0.02] p-3 text-sm"
                >
                  <span className="text-white/85">{r.label}</span>
                  <span className="font-black text-white">{r.amount}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </>
  );
}

function Warranty() {
  return (
    <div className="reveal grid gap-6 md:grid-cols-2">
      <div className="glass-card p-6">
        <div className="text-xs font-bold uppercase tracking-wider text-[color:var(--oltani-blue)]">
          Free Warranty
        </div>
        <h3 className="mt-1 text-xl font-black text-white">فترة الضمان المجاني</h3>
        <p className="mt-2 text-sm leading-relaxed text-white/80">
          دعم فني مجاني لمدة <strong>3 أشهر</strong> من تاريخ التسليم النهائي لضمان استقرار التطبيق
          وحل أي مشكلات تقنية طارئة.
        </p>
      </div>
      <div className="glass-card p-6">
        <div className="text-xs font-bold uppercase tracking-wider text-[color:var(--oltani-orange)]">
          Annual Maintenance
        </div>
        <h3 className="mt-1 text-xl font-black text-white">عقد الصيانة السنوي (اختياري)</h3>
        <p className="mt-2 text-sm leading-relaxed text-white/80">
          يغطي تحديثات التطبيق لتوافق أحدث إصدارات iOS و Android، متابعة استقرار الخوادم،
          والدعم التقني المستمر.
        </p>
      </div>
    </div>
  );
}

function Footer({
  date,
  onOpenGate,
  unlocked,
}: {
  date: string;
  onOpenGate: () => void;
  unlocked: boolean;
}) {
  return (
    <footer className="reveal mt-16">
      <div className="glass-card flex flex-col items-start justify-between gap-6 p-6 md:flex-row md:items-center">
        <div>
          <div className="text-xs text-white/60">تاريخ العرض</div>
          <div className="text-lg font-black text-white">{date}</div>
        </div>
        <div className="flex items-center gap-3">
          <img src={logoUrl} alt="OLTANI" width={40} height={40} className="h-10 w-10 rounded-lg" />
          <div className="text-xs text-white/70">
            هذا العرض مُقدَّم من شركة <strong className="text-white">OLTANI</strong> للدكتور
            <strong className="text-white"> محمد هاشم</strong>
          </div>
        </div>
      </div>
      <div className="mt-4 flex items-end justify-start px-2">
        <div className="text-left">
          <span className="signature">خالد خطاب</span>
          <div className="text-[10px] text-white/40">تم بواسطة</div>
        </div>
      </div>
      <div className="mt-6 text-center text-[11px] text-white/40">
        © {new Date().getFullYear()} OLTANI — Open Link Technologies & Artificial Network Intelligence ·
        <a
          href="https://oltani.com"
          target="_blank"
          rel="noreferrer"
          className="mx-1 text-white/70 hover:text-white"
        >
          oltani.com
        </a>
      </div>
      <div className="mt-6 flex justify-center">
        <button
          onClick={onOpenGate}
          className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.02] px-3 py-1.5 text-[10px] text-white/40 transition hover:border-white/20 hover:text-white/70"
          title="Dr. Hashem Private Message"
        >
          <span aria-hidden>🔒</span>
          <span>Dr. Hashem Private Message</span>
          {unlocked && <span className="text-[9px] text-emerald-400">✓</span>}
        </button>
      </div>
    </footer>
  );
}

function FloatingButtons() {
  return (
    <>
      <a
        href={WHATSAPP_URL}
        target="_blank"
        rel="noreferrer"
        aria-label="WhatsApp"
        className="fab fab-whatsapp"
        title="واتساب"
      >
        <svg width="26" height="26" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
          <path d="M20.52 3.48A11.86 11.86 0 0 0 12.02 0C5.4 0 .02 5.38.02 12c0 2.11.55 4.16 1.6 5.97L0 24l6.2-1.62A11.94 11.94 0 0 0 12.02 24c6.62 0 12-5.38 12-12 0-3.2-1.24-6.21-3.5-8.52ZM12.02 22a9.94 9.94 0 0 1-5.07-1.39l-.36-.21-3.68.96.98-3.59-.24-.37A9.96 9.96 0 1 1 22 12c0 5.52-4.48 10-9.98 10Zm5.47-7.48c-.3-.15-1.77-.87-2.05-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.65.07-.3-.15-1.26-.47-2.4-1.49-.89-.79-1.49-1.77-1.66-2.07-.17-.3-.02-.46.13-.61.14-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51l-.57-.01c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48s1.06 2.88 1.21 3.08c.15.2 2.09 3.2 5.07 4.49.71.31 1.26.49 1.69.63.71.22 1.35.19 1.86.12.57-.08 1.77-.72 2.02-1.42.25-.7.25-1.3.17-1.42-.07-.12-.27-.19-.57-.34Z" />
        </svg>
      </a>
      <a href={TEL_URL} aria-label="Call" className="fab fab-call" title="اتصال هاتفي">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
          <path d="M6.62 10.79a15.05 15.05 0 0 0 6.59 6.59l2.2-2.2a1 1 0 0 1 1.05-.24c1.16.39 2.4.6 3.7.6a1 1 0 0 1 1 1V20a1 1 0 0 1-1 1C10.85 21 3 13.15 3 3.99A1 1 0 0 1 4 3h3.46a1 1 0 0 1 1 1c0 1.3.21 2.54.6 3.7a1 1 0 0 1-.24 1.05l-2.2 2.04Z" />
        </svg>
      </a>
    </>
  );
}

function PricingGate({
  onClose,
  onUnlock,
}: {
  onClose: () => void;
  onUnlock: (payload: PricingPayload) => void;
}) {
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (loading) return;
    setLoading(true);
    setError(null);
    try {
      await new Promise((resolve) => window.setTimeout(resolve, 180));
      const res = unlockPricing(password);
      if (res.ok) {
        onUnlock(res.payload);
      } else {
        setError("كلمة السر غير صحيحة.");
      }
    } catch {
      setError("حدث خطأ، حاول مرة أخرى.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-md"
      onClick={onClose}
    >
      <form
        onSubmit={submit}
        onClick={(e) => e.stopPropagation()}
        className="glass-card w-full max-w-md p-6 md:p-8"
      >
        <div className="flex items-center gap-3">
          <div className="grid h-12 w-12 place-items-center rounded-full bg-[var(--oltani-gradient)] text-xl">
            🔐
          </div>
          <div className="min-w-0">
            <div className="text-[11px] font-bold uppercase tracking-wider text-white/60">
              Private Access
            </div>
            <h3 className="text-lg font-black text-white">Dr. Hashem Private Message</h3>
          </div>
        </div>

        <p className="mt-4 text-sm text-white/75">
          هذا العرض متاح لجميع الزوار للاطلاع على التفاصيل التقنية، لكن التسعير محمي
          ومخصّص للدكتور محمد هاشم فقط. من فضلك أدخل كلمة السر الخاصة بك.
        </p>

        <label className="mt-5 block text-xs font-bold text-white/70">كلمة السر</label>
        <input
          ref={inputRef}
          type="password"
          autoComplete="off"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="mt-1 w-full rounded-xl border border-white/15 bg-black/40 px-4 py-3 text-sm text-white outline-none focus:border-[color:var(--oltani-blue)]"
          placeholder="••••••••••••"
        />
        {error && <div className="mt-2 text-xs font-bold text-red-400">{error}</div>}

        <div className="mt-5 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="rounded-full border border-white/15 px-4 py-2 text-xs text-white/70 hover:text-white"
          >
            إلغاء
          </button>
          <button type="submit" disabled={loading || !password} className="btn-oltani text-sm">
            {loading ? "جارٍ التحقق..." : "فتح التسعير"}
          </button>
        </div>
      </form>
    </div>
  );
}
