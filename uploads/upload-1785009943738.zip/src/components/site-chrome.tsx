import logo from "@/assets/oltani-logo.webp";

const NAV = [
  { href: "#software", label: "السوفت وير" },
  { href: "#hardware", label: "الهاردوير" },
  { href: "#totals", label: "الإجمالي" },
  { href: "#terms", label: "الشروط" },
];

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-3">
        <a href="#top" className="flex items-center gap-3">
          <img
            src={logo}
            alt="شعار شركة OLTANI"
            width={48}
            height={48}
            className="h-11 w-11 object-contain"
          />
          <span className="leading-tight">
            <span className="block text-lg font-extrabold tracking-tight">OLTANI</span>
            <span className="block text-[10px] text-muted-foreground">
              Open Link Technologies &amp; AI
            </span>
          </span>
        </a>

        <nav className="hidden items-center gap-1 md:flex">
          {NAV.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="rounded-full px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <a href="tel:+201002194451" className="btn-brand !px-4 !py-2 text-sm">
            201002194451
          </a>
        </div>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="border-t border-border/60 py-12">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-5 px-5 text-center">
        <img
          src={logo}
          alt="شعار OLTANI"
          width={72}
          height={72}
          loading="lazy"
          className="h-16 w-16 object-contain"
        />
        <p className="max-w-xl text-sm text-muted-foreground">
          OLTANI — Open Link Technologies &amp; Artificial Network Intelligence. حلول متكاملة
          لنقاط البيع والمطاعم والتجزئة: برمجيات، أجهزة، تركيب، تدريب ودعم فني.
        </p>
        <div className="flex flex-wrap items-center justify-center gap-3 text-sm">
          <a href="https://oltani.com" className="chip" target="_blank" rel="noreferrer">
            oltani.com
          </a>
          <a href="tel:+201002194451" className="chip-orange">
            201002194451
          </a>
        </div>
        <p className="text-xs text-muted-foreground/70">
          © {new Date().getFullYear()} OLTANI. جميع الحقوق محفوظة.
        </p>
      </div>
    </footer>
  );
}
