import { createFileRoute } from "@tanstack/react-router";

import { SiteHeader, SiteFooter } from "@/components/site-chrome";
import {
  CLIENT,
  HARDWARE,
  HARDWARE_INCLUDED,
  SOFTWARE,
  SOFTWARE_INCLUDED,
  egp,
  grandTotal,
  hardwareTotal,
  softwareTotal,
  type LineItem,
} from "@/data/quote";

import ecosystem from "@/assets/graphics/ecosystem.jpg";
import qrMenu from "@/assets/graphics/qr-menu.jpg";
import adminShot from "@/assets/graphics/admin.jpg";
import hpFront from "@/assets/products/hp-front.jpeg";
import hpDual from "@/assets/products/hp-dual.jpeg";
import hpSide from "@/assets/products/hp-side.jpeg";
import dellAio from "@/assets/products/dell-aio.jpeg";
import dualScreen from "@/assets/products/dual-screen.jpeg";
import xprinter from "@/assets/products/xprinter.jpeg";
import cashdrawer from "@/assets/products/cashdrawer.jpeg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "عرض سعر OLTANI — نظام POS ومخازن ومنيو ذكي QR" },
      {
        name: "description",
        content:
          "عرض سعر متكامل من OLTANI: نظام نقاط بيع POS، إدارة مخازن، تطبيق PWA، منيو ذكي بالـ QR ولوحة أدمن، مع أجهزة كاشير وطابعات ودروج نقود.",
      },
      { property: "og:title", content: "عرض سعر OLTANI — حل متكامل لنقاط البيع والمطاعم" },
      {
        property: "og:description",
        content:
          "سوفت وير POS + مخازن + PWA + منيو QR ولوحة أدمن، وأجهزة كاشير احترافية مع تركيب وتدريب وضمان.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: QuotePage,
});

const HARDWARE_IMAGES = [hpFront, dellAio, xprinter, cashdrawer, cashdrawer];
const HARDWARE_ALT = [
  "جهاز كاشير HP All-in-One بشاشة لمس على قاعدة معدنية",
  "جهاز كاشير Dell All-in-One يعمل بنظام ويندوز",
  "طابعة فواتير حرارية Xprinter بمنفذ USB و LAN",
  'درج نقود معدني Cash Drawer مقاس 14 بوصة بخمس خانات',
  'درج نقود معدني Cash Drawer مقاس 8 بوصة بخمس خانات',
];

function Section({
  id,
  children,
  className = "",
}: {
  id?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section id={id} className={`mx-auto max-w-6xl px-5 py-14 md:py-20 ${className}`}>
      {children}
    </section>
  );
}

function SectionTitle({
  kicker,
  title,
  desc,
}: {
  kicker: string;
  title: string;
  desc?: string;
}) {
  return (
    <div className="mb-10 max-w-3xl">
      <span className="chip">{kicker}</span>
      <h2 className="mt-4 text-3xl leading-tight md:text-4xl">{title}</h2>
      {desc ? <p className="mt-3 text-muted-foreground md:text-lg">{desc}</p> : null}
    </div>
  );
}

function Check() {
  return (
    <span className="mt-1.5 inline-block size-1.5 shrink-0 rounded-full bg-accent" aria-hidden />
  );
}

function ItemCard({
  item,
  index,
  image,
  alt,
}: {
  item: LineItem;
  index: number;
  image?: string;
  alt?: string;
}) {
  const total = item.unit * item.qty;
  return (
    <article className="panel overflow-hidden">
      <div className={image ? "grid items-start gap-0 md:grid-cols-[320px_1fr]" : ""}>
        {image ? (
          <div className="relative bg-secondary/40 p-4">
            <img
              src={image}
              alt={alt ?? item.title}
              loading="lazy"
              className="h-56 w-full rounded-xl object-cover md:h-64"
            />
          </div>
        ) : null}

        <div className="p-6 md:p-7">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="min-w-0">
              <div className="flex items-center gap-3">
                <span className="grid size-8 place-items-center rounded-lg bg-secondary text-sm font-bold text-accent">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <h3 className="text-xl">{item.title}</h3>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">{item.spec}</p>
            </div>

            <div className="rounded-xl border border-border bg-secondary/60 px-4 py-3 text-left">
              <div className="text-xs text-muted-foreground">
                {item.qty > 1 ? `${item.qty} × ${egp(item.unit)}` : "السعر"}
              </div>
              <div className="font-display text-2xl font-extrabold text-gradient">
                {egp(total)}
              </div>
              <div className="text-[11px] text-muted-foreground">جنيه مصري</div>
            </div>
          </div>

          <ul className="mt-5 grid gap-2.5 sm:grid-cols-2">
            {item.bullets.map((b) => (
              <li key={b} className="flex gap-2.5 text-sm text-muted-foreground">
                <Check />
                <span>{b}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </article>
  );
}

function QuotePage() {
  return (
    <div id="top" className="min-h-screen">
      <SiteHeader />

      {/* Hero */}
      <Section className="!pt-10">
        <div className="grid items-center gap-10 lg:grid-cols-[1.05fr_1fr]">
          <div>
            <span className="chip-orange">عرض سعر رسمي — {CLIENT.quoteNo}</span>
            <h1 className="mt-5 text-4xl leading-[1.15] md:text-6xl">
              حل متكامل لإدارة مطعمك
              <span className="block text-gradient">من الكاشير للمخزن للمنيو الذكي</span>
            </h1>
            <p className="mt-5 max-w-xl text-lg text-muted-foreground">
              مُقدَّم إلى <strong className="text-foreground">{CLIENT.name}</strong> — منظومة واحدة
              تربط نقطة البيع بالمخزون وبالمنيو الأونلاين وتطبيق الموبايل، مع أجهزة كاشير
              احترافية جاهزة للتشغيل من أول يوم.
            </p>

            <div className="mt-7 flex flex-wrap gap-3">
              <a href="#totals" className="btn-brand">
                إجمالي العرض {egp(grandTotal)} جنيه
              </a>
              <a href="tel:+201002194451" className="btn-ghost">
                اتصل بنا: 201002194451
              </a>
            </div>

            <dl className="mt-9 grid grid-cols-2 gap-4 sm:grid-cols-4">
              {[
                ["5", "أنظمة برمجية"],
                ["6", "أجهزة وملحقات"],
                ["3", "أشهر دعم مجاني"],
                ["100%", "تركيب وتدريب"],
              ].map(([v, l]) => (
                <div key={l} className="panel px-4 py-3">
                  <dt className="font-display text-2xl font-extrabold text-gradient">{v}</dt>
                  <dd className="text-xs text-muted-foreground">{l}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="panel-glow overflow-hidden">
            <img
              src={ecosystem}
              alt="منظومة OLTANI المتكاملة: كاشير POS وطابعة ودرج نقود ومنيو QR وتطبيق موبايل ومخزن"
              width={1600}
              height={1008}
              className="w-full object-cover"
            />
          </div>
        </div>
      </Section>

      {/* Why */}
      <Section>
        <SectionTitle
          kicker="لماذا OLTANI"
          title="مش مجرد برنامج كاشير… منظومة تشغيل كاملة"
          desc="كل جزء في العرض مربوط بالجزء الآخر: البيعة تخصم من المخزن، والمنيو الأونلاين يظهر المتاح فقط، والإدارة تشوف كل حاجة لحظياً من الموبايل."
        />
        <div className="grid gap-5 md:grid-cols-3">
          {[
            {
              t: "قرار أسرع",
              d: "تقارير لحظية للمبيعات والأرباح وأعلى الأصناف تساعدك تقرر بالأرقام لا بالتخمين.",
            },
            {
              t: "تحكم في التكلفة",
              d: "خصم المكونات تلقائياً من المخزن وحساب تكلفة كل طبق ونسبة الفاقد يقلل الهالك والسرقات.",
            },
            {
              t: "تجربة عميل مميزة",
              d: "منيو QR بالصور وطلب من الموبايل ورقم تجهيز يقلل الزحام ويرفع متوسط الفاتورة.",
            },
            {
              t: "يعمل بدون إنترنت",
              d: "الكاشير لا يتوقف عند انقطاع النت، والبيانات تتزامن تلقائياً بعد رجوعه.",
            },
            {
              t: "قابل للتوسع",
              d: "تبدأ بنقطتي بيع وتزوّد فروع ومستخدمين ومخازن بدون تغيير النظام.",
            },
            {
              t: "دعم مصري قريب منك",
              d: "تركيب وتدريب ودعم فني مباشر من فريق OLTANI عبر الهاتف والزيارات.",
            },
          ].map((f) => (
            <div key={f.t} className="panel p-6">
              <h3 className="text-lg">{f.t}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{f.d}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Software */}
      <Section id="software">
        <SectionTitle
          kicker="القسم الأول — السوفت وير"
          title="أنظمة OLTANI البرمجية"
          desc="خمسة أنظمة متكاملة تُسلَّم مُركَّبة ومُجرَّبة وجاهزة للعمل، مع إدخال المنيو وتدريب الفريق."
        />

        <div className="mb-8 grid gap-5 md:grid-cols-2">
          <figure className="panel-glow overflow-hidden">
            <img
              src={qrMenu}
              alt="المنيو الذكي على الموبايل مع كود QR للطاولة ورقم تجهيز الطلب"
              width={1200}
              height={912}
              loading="lazy"
              className="w-full object-cover"
            />
            <figcaption className="p-5 text-sm text-muted-foreground">
              <strong className="text-foreground">المنيو الذكي + تطبيق PWA:</strong> العميل يقرأ
              الـ QR من الطاولة، يختار طلبه بالصور، يبعته للكاشير والمطبخ، ويأخذ رقم تجهيز يتابع
              بيه حالة الطلب.
            </figcaption>
          </figure>
          <figure className="panel-glow overflow-hidden">
            <img
              src={adminShot}
              alt="لوحة الأدمن لإدارة المبيعات والمخزون والمنيو والتقارير"
              width={1200}
              height={912}
              loading="lazy"
              className="w-full object-cover"
            />
            <figcaption className="p-5 text-sm text-muted-foreground">
              <strong className="text-foreground">لوحة الأدمن:</strong> إدارة المنيو والأسعار
              والمخزون والمستخدمين، وتقارير مبيعات وربحية لحظية من أي مكان.
            </figcaption>
          </figure>
        </div>

        <div className="grid gap-5">
          {SOFTWARE.map((item, i) => (
            <ItemCard key={item.title} item={item} index={i} />
          ))}
        </div>

        <div className="mt-6 grid gap-5 md:grid-cols-[1fr_auto] md:items-center">
          <div className="panel p-6">
            <h3 className="text-lg">مشمول مجاناً مع قسم السوفت وير</h3>
            <ul className="mt-3 grid gap-2 sm:grid-cols-2">
              {SOFTWARE_INCLUDED.map((x) => (
                <li key={x} className="flex gap-2.5 text-sm text-muted-foreground">
                  <Check />
                  <span>{x}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="panel-glow p-7 text-center md:min-w-64">
            <div className="text-sm text-muted-foreground">إجمالي السوفت وير</div>
            <div className="font-display text-4xl font-extrabold text-gradient">
              {egp(softwareTotal)}
            </div>
            <div className="text-xs text-muted-foreground">جنيه مصري</div>
          </div>
        </div>
      </Section>

      {/* Hardware */}
      <Section id="hardware">
        <SectionTitle
          kicker="القسم الثاني — الهاردوير"
          title="الأجهزة والملحقات"
          desc="أجهزة مختارة ومُجرَّبة على أنظمتنا، تُسلَّم مُركَّبة ومُهيَّأة بالكامل مع ضمان 3 أشهر ضد عيوب الصناعة."
        />

        <div className="mb-8 grid gap-4 sm:grid-cols-3">
          {[
            [hpDual, "شاشة كاشير أمامية وشاشة عرض للعميل من نفس الجهاز"],
            [hpSide, "قاعدة معدنية ثابتة وزاوية لمس مريحة للكاشير"],
            [dualScreen, "تشغيل شاشتين: شاشة الكاشير وشاشة عرض الطلب للعميل"],
          ].map(([src, alt]) => (
            <figure key={alt as string} className="panel overflow-hidden">
              <img
                src={src as string}
                alt={alt as string}
                loading="lazy"
                className="h-52 w-full object-cover"
              />
              <figcaption className="px-4 py-3 text-xs text-muted-foreground">{alt}</figcaption>
            </figure>
          ))}
        </div>

        <div className="grid gap-5">
          {HARDWARE.map((item, i) => (
            <ItemCard
              key={item.title}
              item={item}
              index={i}
              image={HARDWARE_IMAGES[i]}
              alt={HARDWARE_ALT[i]}
            />
          ))}
        </div>

        <div className="mt-6 grid gap-5 md:grid-cols-[1fr_auto] md:items-center">
          <div className="panel p-6">
            <h3 className="text-lg">مشمول مع قسم الهاردوير</h3>
            <ul className="mt-3 grid gap-2 sm:grid-cols-2">
              {HARDWARE_INCLUDED.map((x) => (
                <li key={x} className="flex gap-2.5 text-sm text-muted-foreground">
                  <Check />
                  <span>{x}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="panel-glow p-7 text-center md:min-w-64">
            <div className="text-sm text-muted-foreground">إجمالي الهاردوير</div>
            <div className="font-display text-4xl font-extrabold text-gradient">
              {egp(hardwareTotal)}
            </div>
            <div className="text-xs text-muted-foreground">جنيه مصري</div>
          </div>
        </div>
      </Section>

      {/* Totals */}
      <Section id="totals">
        <SectionTitle kicker="ملخص العرض" title="الإجمالي النهائي" />
        <div className="panel-glow overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-right text-sm">
              <thead className="bg-secondary/70 text-muted-foreground">
                <tr>
                  <th className="px-5 py-4 font-semibold">البيان</th>
                  <th className="px-5 py-4 font-semibold">العدد</th>
                  <th className="px-5 py-4 font-semibold">سعر الوحدة</th>
                  <th className="px-5 py-4 font-semibold">الإجمالي</th>
                </tr>
              </thead>
              <tbody>
                <tr className="bg-secondary/30">
                  <td colSpan={4} className="px-5 py-3 font-bold text-accent">
                    القسم الأول: السوفت وير
                  </td>
                </tr>
                {SOFTWARE.map((i) => (
                  <tr key={i.title} className="border-t border-border">
                    <td className="px-5 py-3">{i.title}</td>
                    <td className="px-5 py-3 text-muted-foreground">{i.qty}</td>
                    <td className="px-5 py-3 text-muted-foreground">{egp(i.unit)}</td>
                    <td className="px-5 py-3 font-bold">{egp(i.unit * i.qty)}</td>
                  </tr>
                ))}
                <tr className="border-t border-border bg-secondary/40">
                  <td colSpan={3} className="px-5 py-3 font-bold">
                    إجمالي السوفت وير
                  </td>
                  <td className="px-5 py-3 font-display text-lg font-extrabold text-gradient">
                    {egp(softwareTotal)}
                  </td>
                </tr>

                <tr className="bg-secondary/30">
                  <td colSpan={4} className="px-5 py-3 font-bold text-primary">
                    القسم الثاني: الهاردوير
                  </td>
                </tr>
                {HARDWARE.map((i) => (
                  <tr key={i.title} className="border-t border-border">
                    <td className="px-5 py-3">{i.title}</td>
                    <td className="px-5 py-3 text-muted-foreground">{i.qty}</td>
                    <td className="px-5 py-3 text-muted-foreground">{egp(i.unit)}</td>
                    <td className="px-5 py-3 font-bold">{egp(i.unit * i.qty)}</td>
                  </tr>
                ))}
                <tr className="border-t border-border bg-secondary/40">
                  <td colSpan={3} className="px-5 py-3 font-bold">
                    إجمالي الهاردوير
                  </td>
                  <td className="px-5 py-3 font-display text-lg font-extrabold text-gradient">
                    {egp(hardwareTotal)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="grid gap-6 border-t border-border p-7 md:grid-cols-[1fr_auto] md:items-center">
            <p className="text-sm text-muted-foreground">
              الإجمالي غير شامل ضريبة القيمة المضافة. الأسعار بالجنيه المصري.
              <br />
              {CLIENT.validity} — تاريخ العرض: {CLIENT.date}
            </p>
            <div className="rounded-2xl bg-secondary/60 px-8 py-6 text-center">
              <div className="text-sm text-muted-foreground">الإجمالي الكلي</div>
              <div className="font-display text-5xl font-extrabold text-gradient">
                {egp(grandTotal)}
              </div>
              <div className="mt-1 text-xs text-muted-foreground">جنيه مصري فقط</div>
            </div>
          </div>
        </div>
      </Section>

      {/* Timeline + terms */}
      <Section id="terms">
        <SectionTitle kicker="خطة التنفيذ والشروط" title="من التوقيع للتشغيل في 10 أيام عمل" />
        <div className="grid gap-5 lg:grid-cols-2">
          <ol className="panel divide-y divide-border p-2">
            {[
              ["اليوم 1–2", "توريد الأجهزة وتركيبها وتجهيز الشبكة والطابعات والدروج"],
              ["اليوم 3–5", "تثبيت نظام POS والمخازن وإدخال المنيو والأسعار والمخزون الافتتاحي"],
              ["اليوم 6–7", "تشغيل المنيو الذكي بالـ QR وتطبيق الـ PWA وربطهما بالكاشير والمطبخ"],
              ["اليوم 8–9", "تدريب الكاشير والمخزن والإدارة وتشغيل تجريبي مراقَب"],
              ["اليوم 10", "التسليم النهائي وبدء فترة الدعم المجاني (3 أشهر)"],
            ].map(([d, t]) => (
              <li key={d} className="flex gap-4 p-4">
                <span className="chip whitespace-nowrap">{d}</span>
                <span className="text-sm text-muted-foreground">{t}</span>
              </li>
            ))}
          </ol>

          <div className="panel p-6">
            <h3 className="text-lg">الشروط والأحكام</h3>
            <ul className="mt-3 grid gap-2.5">
              {[
                "الدفع: 60% مقدماً عند التعاقد و40% عند التسليم والتشغيل.",
                "الأسعار غير شاملة ضريبة القيمة المضافة.",
                "ضمان 3 أشهر ضد عيوب الصناعة على الأجهزة، ولا يشمل سوء الاستخدام أو مشاكل الكهرباء.",
                "دعم فني مجاني 3 أشهر على البرمجيات، ويُجدَّد سنوياً بعقد صيانة اختياري.",
                "تطويرات أو تقارير خارج نطاق هذا العرض تُسعَّر بشكل منفصل.",
                "إنترنت المحل وأي رسوم استضافة نطاق خاص بالعميل تُوفَّر من جهة العميل.",
              ].map((t) => (
                <li key={t} className="flex gap-2.5 text-sm text-muted-foreground">
                  <Check />
                  <span>{t}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Section>

      {/* CTA */}
      <Section className="!pt-0">
        <div className="panel-glow p-8 text-center md:p-12">
          <h2 className="text-3xl md:text-4xl">
            جاهزين نبدأ معك يا <span className="text-gradient">أستاذ أحمد</span>
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            كل ما تحتاجه في عرض واحد: أنظمة برمجية متكاملة + أجهزة احترافية + تركيب وتدريب ودعم.
            كلمنا لتحديد موعد المعاينة وبدء التنفيذ.
          </p>
          <div className="mt-7 flex flex-wrap justify-center gap-3">
            <a href="tel:+201002194451" className="btn-brand">
              اتصل الآن: 201002194451
            </a>
            <a href="https://oltani.com" target="_blank" rel="noreferrer" className="btn-ghost">
              زيارة oltani.com
            </a>
          </div>
        </div>
      </Section>

      <SiteFooter />
    </div>
  );
}
