import { useEffect, useState } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

function useHydrated() {
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => setHydrated(true), []);
  return hydrated;
}

const axisStyle = { fill: "var(--muted-foreground)", fontSize: 12 };

const tooltipStyle = {
  backgroundColor: "var(--card)",
  border: "1px solid var(--border)",
  borderRadius: "12px",
  color: "var(--foreground)",
  fontSize: "13px",
};

function ChartFrame({ children }: { children: React.ReactNode }) {
  const hydrated = useHydrated();
  if (!hydrated) {
    return <div className="h-[300px] w-full animate-pulse rounded-xl bg-muted/40" />;
  }
  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        {children as React.ReactElement}
      </ResponsiveContainer>
    </div>
  );
}

const roiValues = [
  { traditional: 100, smart: 92 },
  { traditional: 104, smart: 84 },
  { traditional: 108, smart: 74 },
  { traditional: 110, smart: 68 },
  { traditional: 113, smart: 63 },
  { traditional: 116, smart: 60 },
];

export type ChartLabels = {
  traditional: string;
  smart: string;
  revenue: string;
  cost: string;
  months: string[];
  shortMonths: string[];
  workflows: string[];
  saved: string;
};

const fallbackLabels: ChartLabels = {
  traditional: "Traditional",
  smart: "Smart",
  revenue: "Revenue",
  cost: "Cost",
  months: ["1", "2", "3", "4", "5", "6"],
  shortMonths: ["1", "2", "3", "4", "5", "6"],
  workflows: ["1", "2", "3", "4", "5"],
  saved: "%",
};

const safe = (labels?: Partial<ChartLabels>): ChartLabels => ({
  ...fallbackLabels,
  ...(labels ?? {}),
});

export function RoiChart({ labels: raw, rtl }: { labels?: ChartLabels; rtl: boolean }) {
  const labels = safe(raw);
  const roiData = roiValues.map((v, i) => ({ month: labels.months[i] ?? `${i + 1}`, ...v }));
  return (
    <ChartFrame>
      <AreaChart data={roiData} margin={{ left: -18, right: 8, top: 10 }}>
        <defs>
          <linearGradient id="gTrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--muted-foreground)" stopOpacity={0.45} />
            <stop offset="100%" stopColor="var(--muted-foreground)" stopOpacity={0} />
          </linearGradient>
          <linearGradient id="gSmart" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--gold)" stopOpacity={0.7} />
            <stop offset="100%" stopColor="var(--gold)" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
        <XAxis
          dataKey="month"
          tick={axisStyle}
          axisLine={false}
          tickLine={false}
          reversed={rtl}
        />
        <YAxis
          tick={axisStyle}
          axisLine={false}
          tickLine={false}
          orientation={rtl ? "right" : "left"}
        />
        <Tooltip contentStyle={tooltipStyle} cursor={{ stroke: "var(--accent)" }} />
        <Legend wrapperStyle={{ fontSize: 12, color: "var(--muted-foreground)" }} />
        <Area
          type="monotone"
          dataKey="traditional"
          name={labels.traditional}
          stroke="var(--muted-foreground)"
          fill="url(#gTrad)"
          strokeWidth={2}
        />
        <Area
          type="monotone"
          dataKey="smart"
          name={labels.smart}
          stroke="var(--gold)"
          fill="url(#gSmart)"
          strokeWidth={3}
        />
      </AreaChart>
    </ChartFrame>
  );
}

const workloadValues = [46, 38, 52, 34, 30];

export function EfficiencyBars({ labels: raw, rtl }: { labels?: ChartLabels; rtl: boolean }) {
  const labels = safe(raw);
  const workloadData = workloadValues.map((value, i) => ({
    name: labels.workflows[i] ?? `${i + 1}`,
    value,
  }));
  return (
    <ChartFrame>
      <BarChart data={workloadData} margin={{ left: -18, right: 8, top: 10 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
        <XAxis dataKey="name" tick={axisStyle} axisLine={false} tickLine={false} reversed={rtl} />
        <YAxis
          tick={axisStyle}
          axisLine={false}
          tickLine={false}
          orientation={rtl ? "right" : "left"}
          tickFormatter={(v) => `${v}%`}
        />
        <Tooltip
          contentStyle={tooltipStyle}
          cursor={{ fill: "color-mix(in oklab, var(--accent) 12%, transparent)" }}
          formatter={(v: number) => [`${v}${labels.saved}`, ""]}
        />
        <Bar dataKey="value" radius={[8, 8, 0, 0]}>
          {workloadData.map((entry, i) => (
            <Cell key={entry.name} fill={i % 2 === 0 ? "var(--accent)" : "var(--primary)"} />
          ))}
        </Bar>
      </BarChart>
    </ChartFrame>
  );
}

const revenueValues = [
  { revenue: 42, cost: 28 },
  { revenue: 48, cost: 27 },
  { revenue: 55, cost: 26 },
  { revenue: 61, cost: 25 },
  { revenue: 69, cost: 24 },
  { revenue: 78, cost: 23 },
];

export function FinancialChart({ labels: raw, rtl }: { labels?: ChartLabels; rtl: boolean }) {
  const labels = safe(raw);
  const revenueData = revenueValues.map((v, i) => ({ m: labels.shortMonths[i] ?? `${i + 1}`, ...v }));
  return (
    <ChartFrame>
      <LineChart data={revenueData} margin={{ left: -18, right: 8, top: 10 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
        <XAxis dataKey="m" tick={axisStyle} axisLine={false} tickLine={false} reversed={rtl} />
        <YAxis
          tick={axisStyle}
          axisLine={false}
          tickLine={false}
          orientation={rtl ? "right" : "left"}
        />
        <Tooltip contentStyle={tooltipStyle} />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        <Line
          type="monotone"
          dataKey="revenue"
          name={labels.revenue}
          stroke="var(--gold)"
          strokeWidth={3}
          dot={false}
        />
        <Line
          type="monotone"
          dataKey="cost"
          name={labels.cost}
          stroke="var(--cyan)"
          strokeWidth={2}
          strokeDasharray="5 4"
          dot={false}
        />
      </LineChart>
    </ChartFrame>
  );
}