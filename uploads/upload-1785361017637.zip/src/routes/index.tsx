import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  Activity,
  BadgeCheck,
  BarChart3,
  Bot,
  Building2,
  CalendarClock,
  Camera,
  CheckCircle2,
  Clock,
  CloudOff,
  Database,
  Gauge,
  Globe,
  Languages,
  LayoutDashboard,
  MapPin,
  MessageSquare,
  PenLine,
  Phone,
  RefreshCw,
  Route as RouteIcon,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Timer,
  TrendingUp,
  Users,
  Wrench,
} from "lucide-react";

import logo from "@/assets/oltani-logo.webp";
import heroVisual from "@/assets/hero-visual.jpg";
import adminDashboard from "@/assets/admin-dashboard.jpg";
import technicianApp from "@/assets/technician-app.jpg";
import customerApp from "@/assets/customer-app.jpg";
import { EfficiencyBars, FinancialChart, RoiChart } from "@/components/proposal/Charts";
import { content, type Lang } from "@/lib/proposal-content";

const TITLE = "Kangaroo Home Care — Smart Facility Management Proposal | OLTANI";
const DESC =
  "A premium bilingual proposal by OLTANI: an AI-powered, offline-ready PWA facility management platform for Kangaroo Home Care — 3 portals, 4 phases, $2,100 total.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Proposal,
});

const PHONE = "201002194451";
const WHATSAPP = `https://wa.me/${PHONE}`;

const customerIcons = [Sparkles, CalendarClock, Camera, MapPin];
const adminIcons = [CalendarClock, ShieldCheck, Activity, Users, BarChart3];
const techIcons = [CloudOff, RouteIcon, Timer, PenLine, RefreshCw];
const phaseIcons = [Database, Wrench, Bot, LayoutDashboard];
const roiIcons = [Clock, BadgeCheck, Building2];

function SectionTitle({
  eyebrow,
  title,
  subtitle,
}: {
  eyebrow: string;
  title: string;
  subtitle?: string;
}) {
  return (
    <div className="mx-auto max-w-3xl text-center">
      <span className="inline-flex items-center gap-2 rounded-full border border-border bg-surface px-4 py-1.5 text-xs font-semibold tracking-widest text-accent uppercase">
        {eyebrow}
      </span>
      <h2 className="mt-5 text-3xl leading-tight font-bold text-balance sm:text-4xl md:text-5xl">
        {title}
      </h2>
      {subtitle ? (
        <p className="mt-4 text-base text-pretty text-muted-foreground sm:text-lg">{subtitle}</p>
      ) : null}
    </div>
  );
}

function PortalCard({
  icon: Icon,
  tone,
  title,
  body,
  points,
  icons,
  children,
}: {
  icon: typeof Bot;
  tone: string;
  title: string;
  body: string;
  points: readonly string[];
  icons: (typeof Bot)[];
  children: React.ReactNode;
}) {
  return (
    <article className="card-elevated overflow-hidden p-6">
      <div className="flex items-center gap-3">
        <span className={`grid size-11 shrink-0 place-items-center rounded-xl ${tone}`}>
          <Icon className="size-5" />
        </span>
        <h3 className="text-lg font-bold">{title}</h3>
      </div>
      <p className="mt-4 text-sm text-muted-foreground">{body}</p>
      <ul className="mt-5 space-y-3">
        {points.map((p, i) => {
          const PointIcon = icons[i] ?? CheckCircle2;
          return (
            <li key={p} className="flex items-start gap-3 text-sm text-muted-foreground">
              <PointIcon className="mt-0.5 size-4 shrink-0 text-accent" />
              <span>{p}</span>
            </li>
          );
        })}
      </ul>
      {children}
    </article>
  );
}

function Proposal() {
  const [lang, setLang] = useState<Lang>("en");
  const t = content[lang];
  const rtl = t.dir === "rtl";

  return (
    <div
      dir={t.dir}
      lang={lang}
      className={`min-h-screen bg-background ${rtl ? "font-arabic" : ""}`}
    >
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border/70 bg-background/85 backdrop-blur-xl">
        <div className="mx-auto grid max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-4 py-3 sm:px-6">
          <a
            href="https://oltani.com"
            target="_blank"
            rel="noreferrer"
            className="flex min-w-0 items-center gap-3"
          >
            <img src={logo} alt="OLTANI logo" width={44} height={44} className="size-10 sm:size-11" />
            <span className="min-w-0 text-sm leading-tight font-semibold">
              OLTANI
              <span className="line-clamp-1 block text-[10px] font-medium tracking-wider text-muted-foreground">
                {t.brandSub}
              </span>
            </span>
          </a>

          <nav className="hidden items-center gap-6 text-sm text-muted-foreground lg:flex lg:justify-self-center">
            <a href="#scope" className="transition-colors hover:text-accent">{t.nav.scope}</a>
            <a href="#technology" className="transition-colors hover:text-accent">{t.nav.technology}</a>
            <a href="#roi" className="transition-colors hover:text-accent">{t.nav.roi}</a>
            <a href="#pricing" className="transition-colors hover:text-accent">{t.nav.pricing}</a>
          </nav>

          <div className="flex shrink-0 items-center gap-2">
            <button
              type="button"
              onClick={() => setLang(lang === "en" ? "ar" : "en")}
              className="inline-flex items-center gap-2 rounded-full border border-border px-3 py-2 text-xs font-semibold whitespace-nowrap transition-colors hover:border-accent hover:text-accent"
            >
              <Languages className="size-4 shrink-0" />
              {t.switchTo}
            </button>
            <a
              href={`tel:+${PHONE}`}
              className="hidden items-center gap-2 rounded-full border border-border px-3 py-2 text-xs font-semibold transition-colors hover:border-accent hover:text-accent sm:inline-flex"
            >
              <Phone className="size-4" />
              <span dir="ltr">+{PHONE}</span>
            </a>
            <a
              href={WHATSAPP}
              target="_blank"
              rel="noreferrer"
              aria-label={t.whatsapp}
              className="inline-flex items-center gap-2 rounded-full bg-accent px-3 py-2 text-xs font-semibold text-accent-foreground shadow-[var(--shadow-gold)] transition-transform hover:scale-[1.03] sm:px-4"
            >
              <MessageSquare className="size-4 shrink-0" />
              <span className="hidden sm:inline">{t.whatsapp}</span>
            </a>
          </div>
        </div>
      </header>

      <main>
        {/* Hero */}
        <section className="relative overflow-hidden bg-hero-glow">
          <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:py-24">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full border border-accent/40 bg-accent/10 px-4 py-1.5 text-xs font-semibold tracking-wide text-accent">
                <Sparkles className="size-3.5" /> {t.hero.badge}
              </span>
              <h1 className="mt-6 text-4xl leading-[1.15] font-extrabold text-balance sm:text-5xl lg:text-6xl">
                {t.hero.title1}{" "}
                <span className="text-gradient-gold">{t.hero.title2}</span>
              </h1>
              <p className="mt-6 max-w-xl text-base leading-relaxed text-pretty text-muted-foreground sm:text-lg">
                {t.hero.body}
              </p>
              <div className="mt-8 grid gap-3 sm:flex sm:flex-wrap">
                <a
                  href="#pricing"
                  className="inline-flex items-center justify-center gap-2 rounded-full bg-accent px-6 py-3.5 text-sm font-bold text-accent-foreground shadow-[var(--shadow-gold)] transition-transform hover:scale-[1.03]"
                >
                  {t.hero.cta1}
                </a>
                <a
                  href="#scope"
                  className="inline-flex items-center justify-center gap-2 rounded-full border border-border px-6 py-3.5 text-sm font-semibold transition-colors hover:border-accent hover:text-accent"
                >
                  {t.hero.cta2}
                </a>
              </div>
              <dl className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-4">
                {t.hero.stats.map((s) => (
                  <div key={s.v} className="rounded-xl border border-border bg-surface/70 p-4">
                    <dt className="text-2xl font-bold text-gradient-gold">{s.k}</dt>
                    <dd className="mt-1 text-xs text-muted-foreground">{s.v}</dd>
                  </div>
                ))}
              </dl>
            </div>

            <div className="relative">
              <div className="animate-float overflow-hidden rounded-3xl border border-border shadow-[var(--shadow-elegant)]">
                <img
                  src={heroVisual}
                  alt="Smart connected facility network visualization"
                  width={1600}
                  height={1008}
                  className="w-full"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Scope */}
        <section id="scope" className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
          <SectionTitle
            eyebrow={t.scope.eyebrow}
            title={t.scope.title}
            subtitle={t.scope.subtitle}
          />

          <div className="mt-14 grid gap-6 lg:grid-cols-3">
            <PortalCard
              icon={Bot}
              tone="bg-cyan/15 text-cyan"
              title={t.scope.customer.title}
              body={t.scope.customer.body}
              points={t.scope.customer.points}
              icons={customerIcons}
            >
              <img
                src={customerApp}
                alt={t.scope.customer.alt}
                loading="lazy"
                width={1200}
                height={1200}
                className="mt-6 w-full rounded-xl border border-border"
              />
            </PortalCard>

            <PortalCard
              icon={LayoutDashboard}
              tone="bg-accent/15 text-accent"
              title={t.scope.admin.title}
              body={t.scope.admin.body}
              points={t.scope.admin.points}
              icons={adminIcons}
            >
              <div className="mt-6 rounded-xl border border-border bg-background/50 p-3">
                <p className="mb-2 text-xs font-semibold tracking-wide text-muted-foreground uppercase">
                  {t.scope.admin.chartLabel}
                </p>
                <FinancialChart labels={t.charts} rtl={rtl} />
              </div>
            </PortalCard>

            <PortalCard
              icon={Smartphone}
              tone="bg-primary/20 text-primary"
              title={t.scope.tech.title}
              body={t.scope.tech.body}
              points={t.scope.tech.points}
              icons={techIcons}
            >
              <img
                src={technicianApp}
                alt={t.scope.tech.alt}
                loading="lazy"
                width={1200}
                height={1200}
                className="mt-6 w-full rounded-xl border border-border"
              />
            </PortalCard>
          </div>

          <div className="mt-14 overflow-hidden rounded-3xl border border-border bg-surface shadow-[var(--shadow-elegant)]">
            <div className="flex items-center gap-2 border-b border-border px-4 py-3">
              <span className="size-3 rounded-full bg-destructive/70" />
              <span className="size-3 rounded-full bg-gold/70" />
              <span className="size-3 rounded-full bg-cyan/70" />
              <p className="mx-3 text-xs text-muted-foreground">{t.scope.admin.mockupLabel}</p>
            </div>
            <img
              src={adminDashboard}
              alt={t.scope.admin.alt}
              loading="lazy"
              width={1600}
              height={1008}
              className="w-full"
            />
          </div>
        </section>

        {/* Technology comparison table */}
        <section id="technology" className="border-y border-border bg-surface/40 py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6">
            <SectionTitle
              eyebrow={t.tech.eyebrow}
              title={t.tech.title}
              subtitle={t.tech.subtitle}
            />

            {/* Mobile: stacked cards */}
            <div className="mt-10 grid gap-4 md:hidden">
              {t.tech.rows.map((row) => (
                <div key={row[0]} className="rounded-2xl border border-border bg-background p-4">
                  <p className="text-sm font-semibold">{row[0]}</p>
                  <div className="mt-3 grid gap-3">
                    <div className="rounded-xl border border-accent/30 bg-accent/5 p-3">
                      <p className="text-[11px] font-bold tracking-wide text-accent uppercase">
                        {t.tech.colPwa}
                      </p>
                      <p className="mt-1 text-sm text-foreground/90">{row[1]}</p>
                    </div>
                    <div className="rounded-xl border border-cyan/30 bg-cyan/5 p-3">
                      <p className="text-[11px] font-bold tracking-wide text-cyan uppercase">
                        {t.tech.colNative}
                      </p>
                      <p className="mt-1 text-sm text-muted-foreground">{row[2]}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-14 hidden overflow-hidden rounded-2xl border border-border bg-background md:block">
              <div>
                <table className="w-full text-start text-sm">
                  <thead className="bg-surface">
                    <tr>
                      <th className="px-5 py-4 text-start font-semibold">{t.tech.colCriteria}</th>
                      <th className="px-5 py-4 text-start font-semibold text-accent">
                        {t.tech.colPwa}
                      </th>
                      <th className="px-5 py-4 text-start font-semibold text-cyan">
                        {t.tech.colNative}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {t.tech.rows.map((row) => (
                      <tr
                        key={row[0]}
                        className="border-t border-border transition-colors hover:bg-accent/5"
                      >
                        <td className="px-5 py-4 font-medium">{row[0]}</td>
                        <td className="px-5 py-4 text-foreground/90">{row[1]}</td>
                        <td className="px-5 py-4 text-muted-foreground">{row[2]}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="mt-8 flex gap-4 rounded-2xl border border-cyan/40 bg-cyan/5 p-5 sm:p-6">
              <Globe className="mt-1 size-6 shrink-0 text-cyan" />
              <div className="min-w-0">
                <p className="font-semibold">{t.tech.noteTitle}</p>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {t.tech.noteBody}
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ROI */}
        <section id="roi" className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
          <SectionTitle eyebrow={t.roi.eyebrow} title={t.roi.title} subtitle={t.roi.subtitle} />
          <div className="mt-14 grid gap-6 lg:grid-cols-5">
            <div className="card-elevated p-6 lg:col-span-3">
              <div className="mb-4 flex items-center gap-2">
                <TrendingUp className="size-5 text-accent" />
                <h3 className="font-semibold">{t.roi.chart1}</h3>
              </div>
              <RoiChart labels={t.charts} rtl={rtl} />
            </div>
            <div className="card-elevated p-6 lg:col-span-2">
              <div className="mb-4 flex items-center gap-2">
                <Gauge className="size-5 text-accent" />
                <h3 className="font-semibold">{t.roi.chart2}</h3>
              </div>
              <EfficiencyBars labels={t.charts} rtl={rtl} />
            </div>
          </div>
          <div className="mt-6 grid gap-4 sm:grid-cols-3">
            {t.roi.cards.map((s, i) => {
              const Icon = roiIcons[i];
              return (
                <div key={s.v} className="card-elevated flex items-center gap-4 p-6">
                  <Icon className="size-8 shrink-0 text-accent" />
                  <div>
                    <p className="text-2xl font-bold text-gradient-gold">{s.k}</p>
                    <p className="text-xs text-muted-foreground">{s.v}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Pricing table */}
        <section id="pricing" className="border-t border-border bg-surface/40 py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6">
            <SectionTitle
              eyebrow={t.pricing.eyebrow}
              title={t.pricing.title}
              subtitle={t.pricing.subtitle}
            />

            {/* Mobile: phase cards */}
            <div className="mt-10 grid gap-4 md:hidden">
              {t.pricing.phases.map((p, i) => {
                const Icon = phaseIcons[i];
                return (
                  <div key={p.n} className="rounded-2xl border border-border bg-background p-5">
                    <div className="flex items-start gap-3">
                      <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-accent/15 text-accent">
                        <Icon className="size-5" />
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="text-[11px] tracking-widest text-muted-foreground uppercase">
                          {p.n}
                        </p>
                        <p className="font-semibold text-pretty">{p.title}</p>
                      </div>
                      <p className="shrink-0 text-lg font-extrabold text-gradient-gold">{p.price}</p>
                    </div>
                    <ul className="mt-4 space-y-2">
                      {p.points.map((pt) => (
                        <li key={pt} className="flex items-start gap-2 text-xs text-muted-foreground">
                          <CheckCircle2 className="mt-0.5 size-3.5 shrink-0 text-accent" />
                          <span>{pt}</span>
                        </li>
                      ))}
                    </ul>
                    <p className="mt-4 border-t border-border pt-3 text-xs text-muted-foreground">
                      {t.pricing.colTimeline}: {p.days}
                    </p>
                  </div>
                );
              })}
            </div>

            <div className="mt-14 hidden overflow-hidden rounded-2xl border border-border bg-background md:block">
              <div>
                <table className="w-full text-start text-sm">
                  <thead className="bg-surface">
                    <tr>
                      <th className="px-5 py-4 text-start font-semibold">{t.pricing.colPhase}</th>
                      <th className="px-5 py-4 text-start font-semibold">
                        {t.pricing.colDeliverables}
                      </th>
                      <th className="px-5 py-4 text-start font-semibold">
                        {t.pricing.colTimeline}
                      </th>
                      <th className="px-5 py-4 text-start font-semibold text-accent">
                        {t.pricing.colPrice}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {t.pricing.phases.map((p, i) => {
                      const Icon = phaseIcons[i];
                      return (
                        <tr
                          key={p.n}
                          className="group border-t border-border align-top transition-colors hover:bg-accent/5"
                        >
                          <td className="px-5 py-5">
                            <div className="flex items-center gap-3">
                              <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-accent/15 text-accent transition-colors group-hover:bg-accent group-hover:text-accent-foreground">
                                <Icon className="size-5" />
                              </span>
                              <div>
                                <p className="text-xs tracking-widest text-muted-foreground uppercase">
                                  {p.n}
                                </p>
                                <p className="font-semibold">{p.title}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-5 py-5">
                            <ul className="space-y-2">
                              {p.points.map((pt) => (
                                <li
                                  key={pt}
                                  className="flex items-start gap-2 text-xs text-muted-foreground"
                                >
                                  <CheckCircle2 className="mt-0.5 size-3.5 shrink-0 text-accent" />
                                  <span>{pt}</span>
                                </li>
                              ))}
                            </ul>
                          </td>
                          <td className="px-5 py-5 text-muted-foreground">{p.days}</td>
                          <td className="px-5 py-5 text-xl font-extrabold text-gradient-gold">
                            {p.price}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="mt-8 flex flex-col items-center justify-between gap-6 rounded-3xl border-2 border-accent bg-background p-6 text-center shadow-[var(--shadow-gold)] sm:flex-row sm:p-8 sm:text-start">
              <div className="min-w-0">
                <p className="text-xs font-semibold tracking-widest text-muted-foreground uppercase">
                  {t.pricing.total}
                </p>
                <p className="mt-2 text-4xl font-extrabold text-gradient-gold sm:text-5xl">$2,100</p>
                <p className="mt-2 text-sm text-muted-foreground">{t.pricing.totalNote}</p>
              </div>
              <div className="grid w-full gap-3 sm:flex sm:w-auto sm:flex-row">
                <a
                  href={WHATSAPP}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center justify-center gap-2 rounded-full bg-accent px-7 py-3.5 text-sm font-bold text-accent-foreground transition-transform hover:scale-[1.03]"
                >
                  <MessageSquare className="size-4" /> {t.pricing.approve}
                </a>
                <a
                  href={`tel:+${PHONE}`}
                  className="inline-flex items-center justify-center gap-2 rounded-full border border-border px-7 py-3.5 text-sm font-semibold transition-colors hover:border-accent hover:text-accent"
                >
                  <Phone className="size-4" /> {t.pricing.call}
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-background pt-14 pb-24 sm:pb-14">
        <div className="mx-auto grid max-w-7xl gap-8 px-4 sm:grid-cols-2 sm:px-6 md:grid-cols-3">
          <div className="sm:col-span-2 md:col-span-1">
            <img src={logo} alt="OLTANI logo" width={64} height={64} loading="lazy" className="size-14" />
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground">
              {t.footer.about}
            </p>
          </div>
          <div className="text-sm">
            <p className="font-semibold">{t.footer.proposal}</p>
            <ul className="mt-3 space-y-2 text-muted-foreground">
              <li><a href="#scope" className="hover:text-accent">{t.nav.scope}</a></li>
              <li><a href="#technology" className="hover:text-accent">{t.nav.technology}</a></li>
              <li><a href="#roi" className="hover:text-accent">{t.nav.roi}</a></li>
              <li><a href="#pricing" className="hover:text-accent">{t.nav.pricing}</a></li>
            </ul>
          </div>
          <div className="text-sm">
            <p className="font-semibold">{t.footer.contact}</p>
            <ul className="mt-3 space-y-2 text-muted-foreground">
              <li>
                <a href="https://oltani.com" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 hover:text-accent">
                  <Globe className="size-4" /> oltani.com
                </a>
              </li>
              <li>
                <a href={`tel:+${PHONE}`} className="inline-flex items-center gap-2 hover:text-accent">
                  <Phone className="size-4" /> <span dir="ltr">+{PHONE}</span>
                </a>
              </li>
              <li>
                <a href={WHATSAPP} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 hover:text-accent">
                  <MessageSquare className="size-4" /> {t.footer.whatsappUs}
                </a>
              </li>
            </ul>
          </div>
        </div>
        <p className="mx-auto mt-10 max-w-7xl px-4 text-xs text-muted-foreground sm:px-6">
          © {new Date().getFullYear()} {t.footer.rights}
        </p>
      </footer>

      <a
        href={WHATSAPP}
        target="_blank"
        rel="noreferrer"
        aria-label="WhatsApp"
        className="fixed bottom-5 z-50 grid size-14 place-items-center rounded-full bg-accent text-accent-foreground shadow-[var(--shadow-gold)] transition-transform hover:scale-110 ltr:right-5 rtl:left-5"
      >
        <MessageSquare className="size-6" />
      </a>
    </div>
  );
}
