import { createServerFn } from "@tanstack/react-start";

import {
  menuSchema,
  orderKeySchema,
  placeOrderSchema,
  markPaidSchema,
  proposeSchema,
  respondSchema,
  setStatusSchema,
  sumLines,
  toCustomerView,
  type OnlineOrderRow,
  type PublicMenu,
} from "./online-schemas";

export const publishMenu = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => menuSchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("menu_snapshot")
      .upsert({ id: "current", data: data as never, updated_at: new Date().toISOString() });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const getPublicMenu = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  
  const { data } = await supabaseAdmin
    .from("menu_snapshot")
    .select("data, updated_at")
    .eq("id", "current")
    .maybeSingle();
  const parsed = menuSchema.safeParse(data?.data);
  return {
    menu: parsed.success ? parsed.data : ({ groups: [], items: [] } as PublicMenu),
    updatedAt: data?.updated_at ?? null,
  };
});

export const placeOrder = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => placeOrderSchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row, error } = await supabaseAdmin
      .from("online_orders")
      .insert({
        customer_name: data.name,
        customer_phone: data.phone,
        items: data.lines as never,
        total: sumLines(data.lines),
        status: "new",
      })
      .select("id, token, order_no")
      .single();
    if (error || !row) throw new Error(error?.message ?? "تعذر إرسال الطلب");
    return { id: row.id, token: row.token, orderNo: row.order_no };
  });

export const getOrderStatus = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => orderKeySchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row } = await supabaseAdmin
      .from("online_orders")
      .select("*")
      .eq("id", data.id)
      .eq("token", data.token)
      .maybeSingle();
    if (!row) return null;
    return toCustomerView(row as Record<string, unknown>);
  });

export const respondToProposal = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => respondSchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row } = await supabaseAdmin
      .from("online_orders")
      .select("*")
      .eq("id", data.id)
      .eq("token", data.token)
      .maybeSingle();
    if (!row || row.status !== "awaiting_customer") {
      throw new Error("لا يوجد تعديل بانتظار الموافقة");
    }
    const patch = data.accept
      ? {
          items: row.proposed_items,
          total: row.proposed_total,
          status: "approved",
          proposed_items: null,
          proposed_total: null,
          proposed_at: null,
        }
      : {
          status: "rejected",
          proposed_items: null,
          proposed_total: null,
          proposed_at: null,
        };
    const { data: updated, error } = await supabaseAdmin
      .from("online_orders")
      .update(patch as never)
      .eq("id", data.id)
      .select("*")
      .single();
    if (error) throw new Error(error.message);
    return toCustomerView(updated as Record<string, unknown>);
  });

export const posListOrders = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const since = new Date(Date.now() - 24 * 3600 * 1000).toISOString();
  const { data, error } = await supabaseAdmin
    .from("online_orders")
    .select("*")
    .gte("created_at", since)
    .order("created_at", { ascending: false })
    .limit(100);
  if (error) throw new Error(error.message);
  return (data ?? []) as unknown as OnlineOrderRow[];
});

export const posProposeEdit = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => proposeSchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("online_orders")
      .update({
        proposed_items: data.lines as never,
        proposed_total: sumLines(data.lines),
        proposed_note: data.note ?? null,
        proposed_at: new Date().toISOString(),
        status: "awaiting_customer",
      })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const posSetStatus = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => setStatusSchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const patch: Record<string, unknown> = { status: data.status };
    if (data.applyProposed) {
      const { data: row } = await supabaseAdmin
        .from("online_orders")
        .select("proposed_items, proposed_total")
        .eq("id", data.id)
        .maybeSingle();
      if (row?.proposed_items) {
        patch["items"] = row.proposed_items;
        patch["total"] = row.proposed_total;
        patch["proposed_items"] = null;
        patch["proposed_total"] = null;
        patch["proposed_at"] = null;
      }
    }
    const { data: updated, error } = await supabaseAdmin
      .from("online_orders")
      .update(patch as never)
      .eq("id", data.id)
      .select("*")
      .single();
    if (error) throw new Error(error.message);
    return updated as unknown as OnlineOrderRow;
  });

export const posMarkPaid = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => markPaidSchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: updated, error } = await supabaseAdmin
      .from("online_orders")
      .update({
        payment_method: data.method,
        paid_amount: data.amount,
        paid_at: new Date().toISOString(),
      } as never)
      .eq("id", data.id)
      .select("*")
      .single();
    if (error) throw new Error(error.message);
    return updated as unknown as OnlineOrderRow;
  });
