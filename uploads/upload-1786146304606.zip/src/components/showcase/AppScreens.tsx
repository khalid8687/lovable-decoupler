import type { DesignTheme } from "@/lib/designs";
import { Card, Chip, StatusBar, surfaceStyle } from "./kit";
import { COURSES, LECTURES, PLANS, VIOLATIONS } from "@/lib/content";
import logo from "@/assets/track-logo.png";
import doctor1 from "@/assets/doctor-1.jpg";
import doctor2 from "@/assets/doctor-2.jpg";
import studentNight from "@/assets/student-night.jpg";
import heroSecure from "@/assets/hero-secure.jpg";
import {
  AlertTriangle,
  BookOpen,
  Camera,
  CheckCircle2,
  ChevronLeft,
  CreditCard,
  Fingerprint,
  Home,
  Lock,
  Play,
  Search,
  Shield,
  ShieldAlert,
  User,
} from "lucide-react";

type P = { d: DesignTheme };

const soft = (c: string, p = 14) => `color-mix(in oklab, ${c} ${p}%, transparent)`;

function Screen({ children, pad = true }: { children: React.ReactNode; pad?: boolean }) {
  return (
    <div className={`flex min-h-0 flex-1 flex-col ${pad ? "px-4" : ""} overflow-hidden`}>
      {children}
    </div>
  );
}

function TabBar({ d, active = 0 }: P & { active?: number }) {
  const items = [
    { icon: Home, label: "الرئيسية" },
    { icon: BookOpen, label: "موادي" },
    { icon: Shield, label: "الحماية" },
    { icon: User, label: "حسابي" },
  ];
  return (
    <div
      className="mt-auto flex shrink-0 items-center justify-around px-2 pt-2 pb-4"
      style={{
        borderTop: `1px solid var(--d-border)`,
        background: d.cards === "brutal" ? "var(--d-surface)" : "var(--d-surface)",
        backdropFilter: "blur(16px)",
      }}
    >
      {items.map((it, i) => (
        <div key={it.label} className="flex flex-col items-center gap-1">
          <it.icon
            size={17}
            style={{ color: i === active ? "var(--d-primary)" : "var(--d-muted)" }}
          />
          <span
            className="text-[9px] font-bold"
            style={{ color: i === active ? "var(--d-primary)" : "var(--d-muted)" }}
          >
            {it.label}
          </span>
        </div>
      ))}
    </div>
  );
}

function TopBar({ d, title, sub }: P & { title: string; sub?: string }) {
  return (
    <div className="flex shrink-0 items-center justify-between px-4 pt-1 pb-3">
      <div className="min-w-0">
        <div className="truncate text-[15px] font-black" style={{ fontFamily: "var(--d-head)" }}>
          {title}
        </div>
        {sub ? (
          <div className="truncate text-[10px]" style={{ color: "var(--d-muted)" }}>
            {sub}
          </div>
        ) : null}
      </div>
      <div
        className="grid h-8 w-8 shrink-0 place-items-center"
        style={{
          borderRadius: d.cards === "brutal" ? "var(--d-radius-sm)" : "999px",
          background: "var(--d-surface2)",
          border: "1px solid var(--d-border)",
        }}
      >
        <ChevronLeft size={15} style={{ color: "var(--d-muted)" }} />
      </div>
    </div>
  );
}

/* 1 — Splash / Onboarding */
export function ScreenSplash({ d }: P) {
  return (
    <Screen pad={false}>
      <StatusBar d={d} />
      <div className="relative flex flex-1 flex-col items-center justify-center px-6 text-center">
        <div
          className="absolute inset-x-6 top-16 bottom-24 opacity-40"
          style={{ background: "var(--d-grad)", filter: "blur(70px)", borderRadius: "50%" }}
        />
        <img src={logo} alt="Track Academy" className="relative z-10 w-32" />
        <div
          className="relative z-10 mt-5 text-[22px] font-black"
          style={{ fontFamily: "var(--d-head)" }}
        >
          Track Academy
        </div>
        <p className="relative z-10 mt-2 text-[12px]" style={{ color: "var(--d-muted)" }}>
          محاضرات دكاترتك في مكان واحد
        </p>
        <div className="relative z-10 mt-8 flex flex-wrap justify-center gap-2">
          <Chip d={d}>محاضرات HD</Chip>
          <Chip d={d} tone="accent">
            بانك أسئلة
          </Chip>
          <Chip d={d} tone="ok">
            ملازم PDF
          </Chip>
        </div>
      </div>
      <div className="px-6 pb-8">
        <div
          className="w-full py-3 text-center text-[13px] font-black"
          style={{
            background: "var(--d-grad)",
            color: "var(--d-primary-fg)",
            borderRadius: "var(--d-radius-sm)",
            border: d.cards === "brutal" ? "2px solid var(--d-border)" : undefined,
          }}
        >
          ابدأ الآن
        </div>
      </div>
    </Screen>
  );
}

/* 2 — Google login */
export function ScreenLogin({ d }: P) {
  return (
    <Screen pad={false}>
      <StatusBar d={d} />
      <div className="flex flex-1 flex-col justify-center px-6">
        <img src={logo} alt="" className="mb-6 w-16" />
        <div className="text-[20px] leading-tight font-black" style={{ fontFamily: "var(--d-head)" }}>
          أهلاً بيك في تراك
        </div>
        <p className="mt-2 text-[12px] leading-relaxed" style={{ color: "var(--d-muted)" }}>
          سجّل دخولك بحساب جوجل في خطوة واحدة، ومحاضرات فرقتك تفتح لك على طول.
        </p>

        <div
          className="mt-7 flex items-center justify-center gap-3 py-3.5"
          style={{
            background: d.cards === "brutal" ? "var(--d-surface)" : "#ffffff",
            color: "#1f1f1f",
            borderRadius: "var(--d-radius-sm)",
            border: `${d.cards === "brutal" ? 2 : 1}px solid var(--d-border)`,
            boxShadow: d.cards === "brutal" ? "4px 4px 0 var(--d-border)" : "var(--d-shadow)",
          }}
        >
          <svg viewBox="0 0 48 48" className="h-5 w-5">
            <path
              fill="#EA4335"
              d="M24 9.5c3.5 0 6.6 1.2 9 3.6l6.7-6.7C35.6 2.6 30.2.5 24 .5 14.6.5 6.5 5.9 2.6 13.8l7.8 6C12.3 14 17.6 9.5 24 9.5z"
            />
            <path
              fill="#4285F4"
              d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.9 7.2l7.6 5.9c4.4-4.1 7.1-10.2 7.1-17.6z"
            />
            <path
              fill="#FBBC05"
              d="M10.4 28.2A14.6 14.6 0 0 1 9.6 24c0-1.5.3-2.9.8-4.2l-7.8-6A23.5 23.5 0 0 0 .5 24c0 3.8.9 7.4 2.1 10.2l7.8-6z"
            />
            <path
              fill="#34A853"
              d="M24 47.5c6.2 0 11.5-2 15.4-5.6l-7.6-5.9c-2.1 1.4-4.8 2.3-7.8 2.3-6.4 0-11.7-4.5-13.6-10.1l-7.8 6C6.5 42.1 14.6 47.5 24 47.5z"
            />
          </svg>
          <span className="text-[13px] font-black">تسجيل الدخول بحساب Google</span>
        </div>

        <div
          className="mt-4 flex items-start gap-2 p-3 text-[10px] leading-relaxed"
          style={{
            borderRadius: "var(--d-radius-sm)",
            background: soft("var(--d-warn)", 12),
            border: `1px solid ${soft("var(--d-warn)", 40)}`,
            color: "var(--d-fg)",
          }}
        >
          <ShieldAlert size={22} style={{ color: "var(--d-warn)" }} />
          <span>
            بتسجيلك أنت موافق إن الكاميرا تفضل مفتوحة وقت المشاهدة — خطوة بسيطة تحمي حسابك
            ومجهود دكاترتك، ومحدش بيشوف اللقطات.
          </span>
        </div>
      </div>
      <div className="px-6 pb-8 text-center text-[10px]" style={{ color: "var(--d-muted)" }}>
        دخول آمن · بياناتك محفوظة
      </div>
    </Screen>
  );
}

/* 3 — Camera verification gate */
export function ScreenCameraCheck({ d }: P) {
  return (
    <Screen pad={false}>
      <StatusBar d={d} />
      <TopBar d={d} title="تأكيد سريع" sub="ثانيتين ونبدأ المحاضرة" />
      <div className="px-4">
        <div
          className="relative overflow-hidden"
          style={{ borderRadius: "var(--d-radius)", border: "1px solid var(--d-border)" }}
        >
          <img src={studentNight} alt="" className="h-56 w-full object-cover" loading="lazy" />
          <div
            className="absolute inset-6 border-2"
            style={{ borderColor: "var(--d-ok)", borderRadius: "var(--d-radius)" }}
          />
          <div
            className="absolute right-3 bottom-3 flex items-center gap-1.5 px-2.5 py-1 text-[10px] font-black"
            style={{ background: "var(--d-ok)", color: "#02150c", borderRadius: "999px" }}
          >
            <CheckCircle2 size={12} /> تمام — أنت جاهز
          </div>
        </div>
      </div>
      <div className="mt-4 space-y-2 px-4">
        {[
          { t: "وجه واحد في الإطار", ok: true },
          { t: "الصورة واضحة وأنت قدام الشاشة", ok: true },
          { t: "مفيش موبايل قدام الكاميرا", ok: true },
          { t: "الإضاءة كافية للتحليل", ok: true },
        ].map((r) => (
          <div
            key={r.t}
            className="flex items-center gap-2 px-3 py-2.5 text-[11px]"
            style={{
              ...surfaceStyle(d.cards),
              borderRadius: "var(--d-radius-sm)",
              boxShadow: "none",
            }}
          >
            <CheckCircle2 size={14} style={{ color: "var(--d-ok)" }} />
            <span>{r.t}</span>
          </div>
        ))}
      </div>
      <div className="mt-auto px-4 pb-6">
        <div
          className="py-3 text-center text-[13px] font-black"
          style={{
            background: "var(--d-primary)",
            color: "var(--d-primary-fg)",
            borderRadius: "var(--d-radius-sm)",
            border: d.cards === "brutal" ? "2px solid var(--d-border)" : undefined,
          }}
        >
          تشغيل المحاضرة
        </div>
      </div>
    </Screen>
  );
}

/* 4 — Home dashboard */
export function ScreenHome({ d }: P) {
  return (
    <Screen pad={false}>
      <StatusBar d={d} />
      <div className="flex shrink-0 items-center gap-3 px-4 pt-1 pb-3">
        <img src={logo} alt="" className="h-8 w-8 object-contain" />
        <div className="min-w-0 flex-1">
          <div className="text-[13px] font-black" style={{ fontFamily: "var(--d-head)" }}>
            مساء الخير، يوسف
          </div>
          <div className="truncate text-[10px]" style={{ color: "var(--d-muted)" }}>
            الفرقة الثالثة · طب بشري
          </div>
        </div>
        <div
          className="grid h-8 w-8 place-items-center"
          style={{
            borderRadius: d.cards === "brutal" ? "var(--d-radius-sm)" : "999px",
            background: soft("var(--d-ok)", 18),
          }}
        >
          <Camera size={14} style={{ color: "var(--d-ok)" }} />
        </div>
      </div>

      <div className="min-h-0 flex-1 space-y-3 overflow-hidden px-4">
        <div
          className="flex items-center gap-2 px-3 py-2.5 text-[11px]"
          style={{
            borderRadius: "var(--d-radius-sm)",
            background: "var(--d-surface2)",
            border: "1px solid var(--d-border)",
            color: "var(--d-muted)",
          }}
        >
          <Search size={13} /> ابحث عن محاضرة أو مادة…
        </div>

        <div
          className="relative overflow-hidden p-4"
          style={{
            borderRadius: "var(--d-radius)",
            background: "var(--d-grad)",
            color: "var(--d-primary-fg)",
          }}
        >
          <div className="text-[10px] font-black opacity-80">أكمل من حيث توقفت</div>
          <div className="mt-1 text-[15px] leading-tight font-black">
            المخ: الفصوص والوظائف
          </div>
          <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-black/25">
            <div className="h-full w-[62%] rounded-full bg-black/60" />
          </div>
          <div className="mt-2 flex items-center justify-between text-[10px] font-bold">
            <span>٦٢٪ · باقي ٢٤ دقيقة</span>
            <span className="flex items-center gap-1">
              <Play size={11} /> استكمال
            </span>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {[
            { v: "٤", l: "مواد نشطة" },
            { v: "٧٠س", l: "مشاهدة/شهر" },
            { v: "٤١٨", l: "سؤال محلول" },
          ].map((s) => (
            <div
              key={s.l}
              className="px-2 py-3 text-center"
              style={{ ...surfaceStyle(d.cards), boxShadow: "none" }}
            >
              <div
                className="text-[15px] font-black"
                style={{ color: "var(--d-primary)", fontFamily: "var(--d-head)" }}
              >
                {s.v}
              </div>
              <div className="mt-0.5 text-[9px]" style={{ color: "var(--d-muted)" }}>
                {s.l}
              </div>
            </div>
          ))}
        </div>

        <div className="space-y-2">
          {COURSES.slice(0, 3).map((c) => (
            <div
              key={c.name}
              className="flex items-center gap-3 p-2.5"
              style={{ ...surfaceStyle(d.cards), boxShadow: "none" }}
            >
              <div
                className="grid h-10 w-10 shrink-0 place-items-center"
                style={{
                  borderRadius: "var(--d-radius-sm)",
                  background: soft("var(--d-primary)", 16),
                }}
              >
                <BookOpen size={16} style={{ color: "var(--d-primary)" }} />
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-[11.5px] font-black">{c.name}</div>
                <div className="truncate text-[9.5px]" style={{ color: "var(--d-muted)" }}>
                  {c.doctor} · {c.lectures} محاضرة
                </div>
              </div>
              <div className="text-[10px] font-black" style={{ color: "var(--d-primary)" }}>
                {c.progress}٪
              </div>
            </div>
          ))}
        </div>
      </div>
      <TabBar d={d} active={0} />
    </Screen>
  );
}

/* 5 — Course lectures */
export function ScreenCourse({ d }: P) {
  return (
    <Screen pad={false}>
      <StatusBar d={d} />
      <div className="relative shrink-0">
        <img src={heroSecure} alt="" className="h-36 w-full object-cover" loading="lazy" />
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(to top, var(--d-app-bg), transparent)" }}
        />
        <div className="absolute right-4 bottom-3 left-4">
          <div className="text-[15px] font-black" style={{ fontFamily: "var(--d-head)" }}>
            تشريح الجهاز العصبي
          </div>
          <div className="text-[10px]" style={{ color: "var(--d-muted)" }}>
            د. أحمد سالم · ١٨ محاضرة · ملزمة + أسئلة
          </div>
        </div>
      </div>
      <div className="min-h-0 flex-1 space-y-2 overflow-hidden px-4 pt-3">
        {LECTURES.map((l) => (
          <div
            key={l.n}
            className="flex items-center gap-3 p-2.5"
            style={{ ...surfaceStyle(d.cards), boxShadow: "none" }}
          >
            <div
              className="grid h-9 w-9 shrink-0 place-items-center text-[10px] font-black"
              style={{
                borderRadius: "var(--d-radius-sm)",
                background:
                  l.state === "now"
                    ? "var(--d-primary)"
                    : l.state === "lock"
                      ? "var(--d-surface2)"
                      : soft("var(--d-ok)", 16),
                color:
                  l.state === "now"
                    ? "var(--d-primary-fg)"
                    : l.state === "lock"
                      ? "var(--d-muted)"
                      : "var(--d-ok)",
              }}
            >
              {l.state === "lock" ? <Lock size={13} /> : l.state === "now" ? <Play size={13} /> : l.n}
            </div>
            <div className="min-w-0 flex-1">
              <div className="truncate text-[11.5px] font-black">{l.title}</div>
              <div className="text-[9.5px]" style={{ color: "var(--d-muted)" }}>
                {l.dur} · إعادة {l.views}
              </div>
            </div>
          </div>
        ))}
      </div>
      <TabBar d={d} active={1} />
    </Screen>
  );
}

/* 6 — Secure player */
export function ScreenPlayer({ d }: P) {
  return (
    <Screen pad={false}>
      <StatusBar d={d} />
      <div className="relative shrink-0">
        <img src={heroSecure} alt="" className="h-48 w-full object-cover" loading="lazy" />
        <div className="absolute inset-0 grid place-items-center">
          <div
            className="grid h-12 w-12 place-items-center"
            style={{
              borderRadius: "999px",
              background: "var(--d-primary)",
              color: "var(--d-primary-fg)",
            }}
          >
            <Play size={18} />
          </div>
        </div>
        {/* lecture meta overlay */}
        <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-3 opacity-45">
          <span className="self-end text-[8px] font-bold text-white">
            محاضرة ٠٣ · تشريح الجهاز العصبي
          </span>
          <span className="self-start text-[8px] font-bold text-white">TRACK ACADEMY</span>
        </div>
        {/* camera PIP */}
        <div
          className="absolute top-8 right-3 h-16 w-12 overflow-hidden"
          style={{ borderRadius: "10px", border: "2px solid var(--d-ok)" }}
        >
          <img src={studentNight} alt="" className="h-full w-full object-cover" loading="lazy" />
        </div>
        <div className="absolute right-3 bottom-3 left-3">
          <div className="h-1 w-full rounded-full bg-white/30">
            <div className="h-full w-1/3 rounded-full" style={{ background: "var(--d-primary)" }} />
          </div>
        </div>
      </div>

      <div className="min-h-0 flex-1 space-y-3 overflow-hidden px-4 pt-3">
        <div className="text-[13px] font-black" style={{ fontFamily: "var(--d-head)" }}>
          المخ: الفصوص والوظائف
        </div>
        <div className="flex flex-wrap gap-1.5">
          <Chip d={d} tone="ok">
            جودة HD
          </Chip>
          <Chip d={d} tone="primary">
            سرعة ١.٥x
          </Chip>
          <Chip d={d} tone="accent">
            إعادة ١ / ٣
          </Chip>
        </div>
        <div
          className="p-3"
          style={{ ...surfaceStyle(d.cards, "raised"), boxShadow: "none" }}
        >
          <div className="mb-2 flex items-center gap-2 text-[11px] font-black">
            <Fingerprint size={14} style={{ color: "var(--d-primary)" }} />
            ملزمة المحاضرة جاهزة
          </div>
          <p className="text-[10px] leading-relaxed" style={{ color: "var(--d-muted)" }}>
            افتح الملزمة جانب الفيديو، وعلّم على الأجزاء المهمة وإنت بتسمع الشرح.
          </p>
        </div>
        <div
          className="flex items-center gap-2 p-3 text-[10px]"
          style={{
            borderRadius: "var(--d-radius-sm)",
            background: soft("var(--d-warn)", 14),
            border: `1px solid ${soft("var(--d-warn)", 40)}`,
          }}
        >
          <AlertTriangle size={16} style={{ color: "var(--d-warn)" }} />
          تقدمك بيتحفظ تلقائي — تقدر تكمّل من نفس الدقيقة في أي وقت.
        </div>
      </div>
    </Screen>
  );
}


/* 7 — Friendly pause notice */
export function ScreenViolation({ d }: P) {
  return (
    <Screen pad={false}>
      <StatusBar d={d} />
      <div className="flex flex-1 flex-col items-center justify-center px-6 text-center">
        <div
          className="grid h-20 w-20 place-items-center"
          style={{
            borderRadius: d.cards === "brutal" ? "var(--d-radius)" : "999px",
            background: soft("var(--d-warn)", 16),
            border: `2px solid var(--d-warn)`,
          }}
        >
          <ShieldAlert size={34} style={{ color: "var(--d-warn)" }} />
        </div>
        <div
          className="mt-5 text-[17px] font-black"
          style={{ fontFamily: "var(--d-head)", color: "var(--d-warn)" }}
        >
          وقّفنا المحاضرة مؤقتاً
        </div>
        <p className="mt-2 text-[11.5px] leading-relaxed" style={{ color: "var(--d-muted)" }}>
          مفيش وش قدام الشاشة من شوية، فالمحاضرة اتوقفت لحد ما ترجع — علشان إعادات المشاهدة
          بتاعتك ما تضيعش وإنت مش موجود.
        </p>
        <div
          className="mt-5 w-full p-3 text-right"
          style={{ ...surfaceStyle(d.cards), boxShadow: "none" }}
        >
          {[
            ["الحالة", "متوقفة مؤقتاً"],
            ["الوقت", "٢١:١٤ · محاضرة ٠٣"],
            ["إعاداتك", "١ / ٣ (ما اتأثرتش)"],
            ["تقدمك", "محفوظ عند ٢٤:١٠"],
          ].map(([k, v]) => (
            <div key={k} className="flex justify-between py-1 text-[10.5px]">
              <span style={{ color: "var(--d-muted)" }}>{k}</span>
              <span className="font-black">{v}</span>
            </div>
          ))}
        </div>
        <div
          className="mt-4 w-full py-3 text-[12px] font-black"
          style={{
            background: "var(--d-primary)",
            color: "var(--d-primary-fg)",
            borderRadius: "var(--d-radius-sm)",
            border: d.cards === "brutal" ? "2px solid var(--d-border)" : undefined,
          }}
        >
          كمّل المحاضرة
        </div>
      </div>
    </Screen>
  );
}


/* 8 — Security center */
export function ScreenSecurity({ d }: P) {
  return (
    <Screen pad={false}>
      <StatusBar d={d} />
      <TopBar d={d} title="حسابي وأجهزتي" sub="حالة حسابك وسجل التنبيهات" />
      <div className="min-h-0 flex-1 space-y-3 overflow-hidden px-4">
        <div
          className="flex items-center gap-3 p-3"
          style={{
            borderRadius: "var(--d-radius)",
            background: soft("var(--d-ok)", 12),
            border: `1px solid ${soft("var(--d-ok)", 40)}`,
          }}
        >
          <Shield size={22} style={{ color: "var(--d-ok)" }} />
          <div>
            <div className="text-[12px] font-black">حسابك في حالة سليمة</div>
            <div className="text-[9.5px]" style={{ color: "var(--d-muted)" }}>
              مفيش أي مشاكل على حسابك
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {[
            { l: "الجهاز النشط", v: "iPhone 15", i: "🔒" },
            { l: "محاضرات اتفرجت عليها", v: "٧٠", i: "🎬" },
            { l: "أسئلة حليتها", v: "٤١٨", i: "📝" },
            { l: "طلبات إعادة", v: "١ قيد المراجعة", i: "🔁" },
          ].map((c) => (
            <div key={c.l} className="p-3" style={{ ...surfaceStyle(d.cards), boxShadow: "none" }}>
              <div className="text-[14px]">{c.i}</div>
              <div className="mt-1 text-[11px] font-black">{c.v}</div>
              <div className="text-[9px]" style={{ color: "var(--d-muted)" }}>
                {c.l}
              </div>
            </div>
          ))}
        </div>

        <div className="pt-1 text-[11px] font-black" style={{ fontFamily: "var(--d-head)" }}>
          سجل التنبيهات
        </div>
        {VIOLATIONS.map((v) => (
          <div
            key={v.type}
            className="flex items-center gap-2.5 p-2.5"
            style={{ ...surfaceStyle(d.cards), boxShadow: "none" }}
          >
            <span
              className="h-2 w-2 shrink-0 rounded-full"
              style={{
                background:
                  v.sev === "danger"
                    ? "var(--d-danger)"
                    : v.sev === "warn"
                      ? "var(--d-warn)"
                      : "var(--d-muted)",
              }}
            />
            <div className="min-w-0 flex-1">
              <div className="truncate text-[11px] font-bold">{v.type}</div>
              <div className="text-[9px]" style={{ color: "var(--d-muted)" }}>
                {v.time}
              </div>
            </div>
          </div>
        ))}
      </div>
      <TabBar d={d} active={2} />
    </Screen>
  );
}

/* 9 — Subscription */
export function ScreenPlans({ d }: P) {
  return (
    <Screen pad={false}>
      <StatusBar d={d} />
      <TopBar d={d} title="الاشتراك" sub="اختار خطتك وادفع بأمان" />
      <div className="min-h-0 flex-1 space-y-2.5 overflow-hidden px-4">
        {PLANS.map((p) => (
          <div
            key={p.name}
            className="p-3"
            style={{
              ...surfaceStyle(d.cards, p.highlight ? "raised" : "base"),
              boxShadow: p.highlight ? "var(--d-glow)" : "none",
              borderColor: p.highlight ? "var(--d-primary)" : undefined,
            }}
          >
            <div className="flex items-center justify-between">
              <span className="text-[12px] font-black">{p.name}</span>
              {p.highlight ? <Chip d={d}>الأكثر اختياراً</Chip> : null}
            </div>
            <div className="mt-1 flex items-baseline gap-1">
              <span
                className="text-[20px] font-black"
                style={{ color: "var(--d-primary)", fontFamily: "var(--d-head)" }}
              >
                {p.price}
              </span>
              <span className="text-[9.5px]" style={{ color: "var(--d-muted)" }}>
                {p.unit}
              </span>
            </div>
            <div className="mt-2 space-y-1">
              {p.features.slice(0, 3).map((f) => (
                <div key={f} className="flex items-center gap-1.5 text-[9.5px]">
                  <CheckCircle2 size={11} style={{ color: "var(--d-ok)" }} />
                  <span style={{ color: "var(--d-muted)" }}>{f}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
        <div
          className="flex items-center justify-center gap-2 py-3 text-[12px] font-black"
          style={{
            background: "var(--d-grad)",
            color: "var(--d-primary-fg)",
            borderRadius: "var(--d-radius-sm)",
            border: d.cards === "brutal" ? "2px solid var(--d-border)" : undefined,
          }}
        >
          <CreditCard size={14} /> إتمام الدفع
        </div>
      </div>
      <TabBar d={d} active={3} />
    </Screen>
  );
}

/* 10 — Admin panel */
export function ScreenAdmin({ d }: P) {
  return (
    <Screen pad={false}>
      <StatusBar d={d} />
      <TopBar d={d} title="لوحة المشرف" sub="تقرير اليوم · ٢٤ ساعة" />
      <div className="min-h-0 flex-1 space-y-3 overflow-hidden px-4">
        <div className="grid grid-cols-2 gap-2">
          {[
            { v: "١٬٢٤٠", l: "طالب نشط", c: "var(--d-primary)" },
            { v: "١٨", l: "محاضرة جديدة", c: "var(--d-accent)" },
            { v: "٣١٢", l: "ساعة مشاهدة", c: "var(--d-accent)" },
            { v: "٤", l: "طلبات إعادة", c: "var(--d-warn)" },
          ].map((s) => (
            <div key={s.l} className="p-3" style={{ ...surfaceStyle(d.cards), boxShadow: "none" }}>
              <div
                className="text-[16px] font-black"
                style={{ color: s.c, fontFamily: "var(--d-head)" }}
              >
                {s.v}
              </div>
              <div className="text-[9px]" style={{ color: "var(--d-muted)" }}>
                {s.l}
              </div>
            </div>
          ))}
        </div>

        <div className="p-3" style={{ ...surfaceStyle(d.cards), boxShadow: "none" }}>
          <div className="mb-2 text-[11px] font-black">ساعات المشاهدة آخر ٧ أيام</div>
          <div className="flex h-16 items-end gap-1.5">
            {[35, 55, 22, 78, 44, 90, 30].map((h, i) => (
              <div
                key={i}
                className="flex-1"
                style={{
                  height: `${h}%`,
                  background: i === 5 ? "var(--d-danger)" : "var(--d-grad)",
                  borderRadius: "4px 4px 0 0",
                  opacity: i === 5 ? 1 : 0.75,
                }}
              />
            ))}
          </div>
        </div>

        <div className="text-[11px] font-black">طلبات محتاجة موافقة</div>
        {[
          { n: "منة ط.", id: "ST-20871", v: "طلب إعادة ×٢", img: doctor2 },
          { n: "كريم ع.", id: "ST-19340", v: "تغيير جهاز", img: doctor1 },
        ].map((s) => (
          <div
            key={s.id}
            className="flex items-center gap-2.5 p-2.5"
            style={{ ...surfaceStyle(d.cards), boxShadow: "none" }}
          >
            <img
              src={s.img}
              alt=""
              className="h-8 w-8 rounded-full object-cover"
              loading="lazy"
            />
            <div className="min-w-0 flex-1">
              <div className="text-[11px] font-black">{s.n}</div>
              <div className="text-[9px]" style={{ color: "var(--d-muted)" }}>
                {s.id}
              </div>
            </div>
            <span
              className="px-2 py-0.5 text-[9px] font-black"
              style={{
                borderRadius: "999px",
                background: soft("var(--d-danger)", 16),
                color: "var(--d-danger)",
              }}
            >
              {s.v}
            </span>
          </div>
        ))}
      </div>
    </Screen>
  );
}

/* 11 — Question bank */
export function ScreenQuiz({ d }: P) {
  return (
    <Screen pad={false}>
      <StatusBar d={d} />
      <TopBar d={d} title="أسئلة المحاضرة" sub="المخ: الفصوص والوظائف · سؤال ٤ من ١٠" />
      <div className="min-h-0 flex-1 space-y-3 overflow-hidden px-4">
        <div className="h-1.5 w-full overflow-hidden" style={{ borderRadius: 999, background: "var(--d-surface2)" }}>
          <div className="h-full w-[40%]" style={{ borderRadius: 999, background: "var(--d-grad)" }} />
        </div>
        <div className="p-3.5" style={{ ...surfaceStyle(d.cards), boxShadow: "none" }}>
          <div className="text-[11.5px] leading-relaxed font-black">
            أي فص من فصوص المخ مسؤول عن معالجة الإحساس البصري بشكل أساسي؟
          </div>
        </div>
        {[
          { t: "الفص الجبهي (Frontal)", state: "idle" },
          { t: "الفص القذالي (Occipital)", state: "ok" },
          { t: "الفص الصدغي (Temporal)", state: "bad" },
          { t: "الفص الجداري (Parietal)", state: "idle" },
        ].map((o) => (
          <div
            key={o.t}
            className="flex items-center gap-2 px-3 py-2.5 text-[11px] font-bold"
            style={{
              ...surfaceStyle(d.cards),
              boxShadow: "none",
              borderRadius: "var(--d-radius-sm)",
              background:
                o.state === "ok"
                  ? soft("var(--d-ok)", 16)
                  : o.state === "bad"
                    ? soft("var(--d-danger)", 14)
                    : "var(--d-surface)",
              borderColor:
                o.state === "ok"
                  ? soft("var(--d-ok)", 55)
                  : o.state === "bad"
                    ? soft("var(--d-danger)", 45)
                    : "var(--d-border)",
            }}
          >
            {o.state === "ok" ? (
              <CheckCircle2 size={14} style={{ color: "var(--d-ok)" }} />
            ) : o.state === "bad" ? (
              <AlertTriangle size={14} style={{ color: "var(--d-danger)" }} />
            ) : (
              <span
                className="h-3.5 w-3.5 shrink-0 rounded-full"
                style={{ border: "1.5px solid var(--d-border)" }}
              />
            )}
            <span>{o.t}</span>
          </div>
        ))}
        <div
          className="p-3 text-[10px] leading-relaxed"
          style={{
            borderRadius: "var(--d-radius-sm)",
            background: soft("var(--d-primary)", 12),
            border: `1px solid ${soft("var(--d-primary)", 35)}`,
          }}
        >
          <span className="font-black">شرح الإجابة: </span>
          القشرة البصرية الأولية موجودة في الفص القذالي حول التلم الكلكاريني، وهي أول مكان بيستقبل
          الإشارات من العصب البصري.
        </div>
        <div
          className="py-2.5 text-center text-[12px] font-black"
          style={{
            background: "var(--d-grad)",
            color: "var(--d-primary-fg)",
            borderRadius: "var(--d-radius-sm)",
            border: d.cards === "brutal" ? "2px solid var(--d-border)" : undefined,
          }}
        >
          السؤال التالي
        </div>
      </div>
      <TabBar d={d} active={1} />
    </Screen>
  );
}

export const APP_SCREENS: { key: string; label: string; Comp: (p: P) => React.ReactElement }[] = [
  { key: "splash", label: "شاشة البداية", Comp: ScreenSplash },
  { key: "login", label: "الدخول بجوجل", Comp: ScreenLogin },
  { key: "camera", label: "تأكيد سريع بالكاميرا", Comp: ScreenCameraCheck },
  { key: "home", label: "الرئيسية", Comp: ScreenHome },
  { key: "course", label: "المادة والمحاضرات", Comp: ScreenCourse },
  { key: "player", label: "مشغّل المحاضرة", Comp: ScreenPlayer },
  { key: "quiz", label: "بانك الأسئلة", Comp: ScreenQuiz },
  { key: "violation", label: "تنبيه بسيط في المشغّل", Comp: ScreenViolation },
  { key: "security", label: "حسابي وأجهزتي", Comp: ScreenSecurity },
  { key: "plans", label: "الاشتراكات", Comp: ScreenPlans },
  { key: "admin", label: "لوحة المشرف", Comp: ScreenAdmin },
];

export { Card };
