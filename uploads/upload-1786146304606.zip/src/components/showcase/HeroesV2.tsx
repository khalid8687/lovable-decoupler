import type { DesignTheme } from "@/lib/designs";
import { BRAND, PILLARS, STATS, STEPS, TESTIMONIALS } from "@/lib/content";
import { Btn, Chip, PhoneFrame, surfaceStyle } from "./kit";
import { ScreenHome, ScreenCourse, ScreenPlayer, ScreenQuiz } from "./AppScreens";
import heroSecure from "@/assets/hero-secure.jpg";
import studentNight from "@/assets/student-night.jpg";
import softMesh from "@/assets/soft-mesh.jpg";
import doctor1 from "@/assets/doctor-1.jpg";
import doctor2 from "@/assets/doctor-2.jpg";
import { ArrowLeft, CheckCircle2, GraduationCap, Play, Quote, Star } from "lucide-react";

type P = { d: DesignTheme };
const soft = (c: string, p = 14) => `color-mix(in oklab, ${c} ${p}%, transparent)`;

function StatsRow({ d, cols = 4 }: P & { cols?: number }) {
  return (
    <div className={`grid gap-4 ${cols === 4 ? "grid-cols-2 sm:grid-cols-4" : "grid-cols-3"}`}>
      {STATS.slice(0, cols).map((s) => (
        <div key={s.label}>
          <div
            className="text-2xl font-black sm:text-3xl"
            style={{ color: "var(--d-primary)", fontFamily: "var(--d-head)" }}
          >
            {s.value}
          </div>
          <div className="text-[11px]" style={{ color: "var(--d-muted)" }}>
            {s.label}
          </div>
        </div>
      ))}
    </div>
  );
}

/* ---------- 06 · Sunrise Campus ---------- */
export function HeroCampus({ d }: P) {
  return (
    <section className="relative overflow-hidden px-5 pt-12 pb-16 lg:pt-20">
      <img
        src={softMesh}
        alt=""
        className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-60"
      />
      <div
        className="pointer-events-none absolute -top-32 right-1/4 h-[420px] w-[420px] opacity-45"
        style={{ background: "var(--d-grad)", filter: "blur(130px)", borderRadius: "50%" }}
      />
      <div className="relative mx-auto grid max-w-7xl items-center gap-12 lg:grid-cols-[1.05fr_0.95fr]">
        <div>
          <Chip d={d}>
            <GraduationCap size={13} /> لطلبة الطب — الفرقة الأولى لحد الخامسة
          </Chip>
          <h1
            className="mt-5 text-balance text-4xl leading-[1.12] font-black sm:text-5xl lg:text-[3.6rem]"
            style={{ fontFamily: "var(--d-head)", letterSpacing: "-0.02em" }}
          >
            محاضرات دكاترتك
            <br />
            <span
              style={{
                background: "var(--d-grad)",
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                color: "transparent",
              }}
            >
              في جيبك، منظّمة ومفهومة.
            </span>
          </h1>
          <p className="mt-5 max-w-xl text-[15px] leading-relaxed sm:text-base" style={{ color: "var(--d-muted)" }}>
            {BRAND.promise}. تفتح التطبيق، تلاقي مادتك، تكمّل من نفس الدقيقة، وتحل أسئلة على اللي
            ذاكرته — كل ده من الموبايل أو اللاب.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Btn d={d} variant="grad">
              <Play size={15} /> ابدأ أول محاضرة مجاناً
            </Btn>
            <Btn d={d} variant="ghost">
              شوف مواد فرقتك <ArrowLeft size={15} />
            </Btn>
          </div>
          <div className="mt-7 flex flex-wrap items-center gap-3 text-[12px]" style={{ color: "var(--d-muted)" }}>
            <span className="flex gap-0.5">
              {[0, 1, 2, 3, 4].map((i) => (
                <Star key={i} size={13} fill="var(--d-primary)" style={{ color: "var(--d-primary)" }} />
              ))}
            </span>
            <span>٤.٩ من ٥ — تقييم ٤٨٠٠+ طالب</span>
          </div>
          <div className="mt-9">
            <StatsRow d={d} />
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-[1fr_auto] sm:items-end">
          <div className="space-y-4">
            <img
              src={studentNight}
              alt="طالبة طب بتذاكر من التطبيق"
              className="w-full object-cover"
              style={{
                borderRadius: "var(--d-radius)",
                border: "1px solid var(--d-border)",
                boxShadow: "var(--d-shadow)",
                aspectRatio: "4/3",
              }}
            />
            <div className="p-4" style={{ ...surfaceStyle(d.cards) }}>
              <div className="text-[13px] font-black" style={{ fontFamily: "var(--d-head)" }}>
                آخر محاضرة اتفرجت عليها
              </div>
              <div className="mt-1 text-[12px]" style={{ color: "var(--d-muted)" }}>
                المخ: الفصوص والوظائف · باقي ٢٤ دقيقة
              </div>
              <div className="mt-3 h-1.5 w-full overflow-hidden" style={{ borderRadius: 999, background: soft("var(--d-primary)", 18) }}>
                <div className="h-full w-[62%]" style={{ borderRadius: 999, background: "var(--d-grad)" }} />
              </div>
            </div>
          </div>
          <PhoneFrame d={d} className="mx-auto !max-w-[215px]">
            <ScreenHome d={d} />
          </PhoneFrame>
        </div>
      </div>
    </section>
  );
}

/* ---------- 07 · Midnight Scholar ---------- */
export function HeroSpotlight({ d }: P) {
  return (
    <section className="relative overflow-hidden px-5 pt-14 pb-20 text-center lg:pt-20">
      <div
        className="pointer-events-none absolute inset-x-0 -top-56 mx-auto h-[560px] max-w-3xl opacity-70"
        style={{
          background: "radial-gradient(closest-side, var(--d-primary), transparent 72%)",
          filter: "blur(70px)",
        }}
      />
      <div className="relative mx-auto max-w-5xl">
        <Chip d={d}>مذاكرة الليل بقت أهدى · Track Academy</Chip>
        <h1
          className="mt-6 text-balance text-4xl leading-[1.1] font-black sm:text-5xl lg:text-6xl"
          style={{ fontFamily: "var(--d-head)", letterSpacing: "-0.025em" }}
        >
          افتح المحاضرة،
          <br />
          <span style={{ color: "var(--d-primary)" }}>وسيب الباقي علينا.</span>
        </h1>
        <p className="mx-auto mt-5 max-w-2xl text-[15px] leading-relaxed sm:text-lg" style={{ color: "var(--d-muted)" }}>
          مشغّل خفيف بيكمّل من نفس الدقيقة، ملزمة PDF جانب الفيديو، وأسئلة بعد كل جزء. وضع ليلي
          مريح للعين لمذاكرة طويلة.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Btn d={d} variant="grad">
            سجّل بحساب جوجل
          </Btn>
          <Btn d={d} variant="ghost">
            جولة في التطبيق
          </Btn>
        </div>

        <div className="relative mt-14">
          <img
            src={heroSecure}
            alt="مشغّل المحاضرات"
            className="mx-auto w-full max-w-4xl object-cover"
            style={{
              borderRadius: "var(--d-radius)",
              border: "1px solid var(--d-border)",
              boxShadow: "var(--d-glow), var(--d-shadow)",
              aspectRatio: "16/9",
            }}
          />
          <div className="mt-6 flex flex-wrap items-end justify-center gap-4">
            <PhoneFrame d={d} className="!max-w-[190px] sm:translate-y-2">
              <ScreenCourse d={d} />
            </PhoneFrame>
            <PhoneFrame d={d} className="!max-w-[210px]">
              <ScreenPlayer d={d} />
            </PhoneFrame>
            <PhoneFrame d={d} className="!hidden !max-w-[190px] sm:!flex sm:translate-y-2">
              <ScreenQuiz d={d} />
            </PhoneFrame>
          </div>
        </div>

        <div className="mt-14 grid gap-4 sm:grid-cols-3">
          {PILLARS.map((p) => (
            <div key={p.title} className="p-6 text-right" style={{ ...surfaceStyle(d.cards) }}>
              <div className="text-[15px] font-black" style={{ fontFamily: "var(--d-head)" }}>
                {p.title}
              </div>
              <p className="mt-2 text-[13px] leading-relaxed" style={{ color: "var(--d-muted)" }}>
                {p.body}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- 08 · Mint Focus ---------- */
export function HeroStack({ d }: P) {
  return (
    <section className="px-5 pt-12 pb-16 lg:pt-20">
      <div className="mx-auto max-w-6xl">
        <div
          className="flex flex-wrap items-center justify-between gap-3 pb-5 text-[11px] font-bold tracking-[0.22em] uppercase"
          style={{ borderBottom: "1px solid var(--d-border)", color: "var(--d-muted)" }}
        >
          <span style={{ color: "var(--d-primary)" }}>Track Academy · Medical Lectures</span>
          <span>الترم الثاني ٢٠٢٧ — التسجيل مفتوح</span>
        </div>
        <h1
          className="mt-10 max-w-3xl text-balance text-4xl leading-[1.14] font-black sm:text-5xl lg:text-6xl"
          style={{ fontFamily: "var(--d-head)", letterSpacing: "-0.02em" }}
        >
          مادة واحدة. خطة واضحة.
          <span style={{ color: "var(--d-primary)" }}> صفر تشتيت.</span>
        </h1>
        <div className="mt-8 grid gap-10 lg:grid-cols-[1fr_auto]">
          <div>
            <p className="max-w-xl text-[15px] leading-loose sm:text-base" style={{ color: "var(--d-muted)" }}>
              كل مادة مقسّمة لمحاضرات قصيرة ومعاها ملزمة وأسئلة. تدخل تعرف بالظبط تذاكر إيه النهاردة،
              وتخرج وأنت شايف تقدمك زاد.
            </p>
            <div className="mt-9 grid gap-px" style={{ background: "var(--d-border)" }}>
              {STEPS.map((s) => (
                <div
                  key={s.n}
                  className="flex flex-wrap items-baseline gap-4 p-5"
                  style={{ background: "var(--d-bg)" }}
                >
                  <span
                    className="text-[13px] font-black tabular-nums"
                    style={{ color: "var(--d-primary)", fontFamily: "var(--d-head)" }}
                  >
                    {s.n}
                  </span>
                  <div className="min-w-[200px] flex-1">
                    <div className="text-[15px] font-black">{s.t}</div>
                    <div className="mt-1 text-[13px] leading-relaxed" style={{ color: "var(--d-muted)" }}>
                      {s.b}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              <Btn d={d} variant="primary">
                ابدأ الترم معانا
              </Btn>
              <Btn d={d} variant="ghost">
                حمّل التطبيق
              </Btn>
            </div>
            <div className="mt-10">
              <StatsRow d={d} />
            </div>
          </div>
          <PhoneFrame d={d} className="mx-auto !max-w-[230px] lg:sticky lg:top-24">
            <ScreenCourse d={d} />
          </PhoneFrame>
        </div>
      </div>
    </section>
  );
}

/* ---------- 09 · Coral Pulse ---------- */
export function HeroOrbit({ d }: P) {
  return (
    <section className="relative overflow-hidden px-5 pt-14 pb-16">
      <div
        className="pointer-events-none absolute -top-40 left-1/2 h-[560px] w-[560px] -translate-x-1/2 opacity-40"
        style={{ background: "var(--d-grad)", filter: "blur(120px)", borderRadius: "50%" }}
      />
      <div className="relative mx-auto max-w-7xl">
        <div className="grid items-center gap-10 lg:grid-cols-[0.95fr_1.05fr]">
          <div className="relative order-2 lg:order-1">
            <div
              className="pointer-events-none absolute inset-2 opacity-60"
              style={{
                borderRadius: "50%",
                border: "1px dashed var(--d-border)",
              }}
            />
            <div className="relative flex items-center justify-center py-6">
              <PhoneFrame d={d} className="!max-w-[235px]">
                <ScreenQuiz d={d} />
              </PhoneFrame>
              <div
                className="absolute top-4 right-0 px-3 py-2 text-[11px] font-black"
                style={{
                  ...surfaceStyle(d.cards),
                  boxShadow: "var(--d-glow)",
                }}
              >
                ٨٥٪ إجابات صح 🎯
              </div>
              <div
                className="absolute bottom-6 left-0 px-3 py-2 text-[11px] font-black"
                style={{ ...surfaceStyle(d.cards) }}
              >
                ٧ محاضرات هذا الأسبوع 🔥
              </div>
            </div>
          </div>

          <div className="order-1 lg:order-2">
            <Chip d={d}>خليك مستمر · Streak يومي</Chip>
            <h1
              className="mt-5 text-balance text-4xl leading-[1.08] font-black sm:text-5xl lg:text-[3.8rem]"
              style={{ fontFamily: "var(--d-head)", letterSpacing: "-0.03em" }}
            >
              ذاكر بنظام،
              <br />
              <span
                style={{
                  background: "var(--d-grad)",
                  WebkitBackgroundClip: "text",
                  backgroundClip: "text",
                  color: "transparent",
                }}
              >
                وشوف درجاتك بتطلع.
              </span>
            </h1>
            <p className="mt-5 max-w-xl text-[15px] leading-relaxed sm:text-base" style={{ color: "var(--d-muted)" }}>
              محاضرة، أسئلة، ونسبة تقدم بتزيد كل يوم. التطبيق بيفكّرك باللي فاتك وبيوريك نقط ضعفك
              قبل الامتحان بوقت كفاية.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Btn d={d} variant="grad">
                ابدأ دلوقتي
              </Btn>
              <Btn d={d} variant="ghost">
                الأسعار <ArrowLeft size={15} />
              </Btn>
            </div>
            <div className="mt-9 grid gap-3 sm:grid-cols-3">
              {STATS.slice(0, 3).map((s) => (
                <div key={s.label} className="p-4 text-center" style={{ ...surfaceStyle(d.cards) }}>
                  <div
                    className="text-2xl font-black"
                    style={{
                      fontFamily: "var(--d-head)",
                      background: "var(--d-grad)",
                      WebkitBackgroundClip: "text",
                      backgroundClip: "text",
                      color: "transparent",
                    }}
                  >
                    {s.value}
                  </div>
                  <div className="mt-1 text-[11px]" style={{ color: "var(--d-muted)" }}>
                    {s.label}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-12 grid gap-4 md:grid-cols-3">
          {TESTIMONIALS.map((t) => (
            <div key={t.name} className="p-6" style={{ ...surfaceStyle(d.cards) }}>
              <Quote size={18} style={{ color: "var(--d-primary)" }} />
              <p className="mt-3 text-[13.5px] leading-relaxed">{t.text}</p>
              <div className="mt-4 text-[12px] font-black">{t.name}</div>
              <div className="text-[11px]" style={{ color: "var(--d-muted)" }}>
                {t.year}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- 10 · Ivory Press ---------- */
export function HeroMagazine({ d }: P) {
  return (
    <section className="px-5 pt-10 pb-16">
      <div className="mx-auto max-w-6xl">
        <div
          className="flex flex-wrap items-center justify-between gap-3 py-4 text-[11px] tracking-[0.28em] uppercase"
          style={{
            borderTop: "2px solid var(--d-fg)",
            borderBottom: "1px solid var(--d-border)",
            color: "var(--d-muted)",
          }}
        >
          <span>Track Academy — دليل الطالب</span>
          <span>العدد ٠١ · الترم الثاني</span>
        </div>

        <div className="mt-8 grid gap-8 lg:grid-cols-[1.15fr_0.85fr]">
          <div>
            <h1
              className="text-balance text-4xl leading-[1.06] font-black sm:text-5xl lg:text-[4rem]"
              style={{ fontFamily: "var(--d-head)", letterSpacing: "-0.01em" }}
            >
              محاضراتك مكتوبة ومشروحة
              <br />
              <span style={{ color: "var(--d-accent)" }}>ومرتبة زي الكتاب.</span>
            </h1>
            <p
              className="mt-6 max-w-xl text-[16px] leading-loose"
              style={{ color: "var(--d-muted)", columnGap: "2rem" }}
            >
              كل مادة عندها صفحة كاملة: المحاضرات بالترتيب، الملزمة، الأسئلة، وملاحظات الدكتور.
              تفتح، تقرأ، تسمع، وتحل — من غير لف ولا دوران في جروبات.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Btn d={d} variant="primary">
                اقرأ وذاكر دلوقتي
              </Btn>
              <Btn d={d} variant="ghost">
                مواد الفرقة التالتة
              </Btn>
            </div>
            <img
              src={heroSecure}
              alt="صفحة المادة داخل التطبيق"
              className="mt-9 w-full object-cover"
              style={{
                borderRadius: "var(--d-radius)",
                border: "1px solid var(--d-border)",
                aspectRatio: "16/9",
              }}
            />
            <div className="mt-8">
              <StatsRow d={d} />
            </div>
          </div>

          <aside className="space-y-5">
            <div className="p-5" style={{ ...surfaceStyle(d.cards) }}>
              <div className="text-[11px] tracking-[0.24em] uppercase" style={{ color: "var(--d-accent)" }}>
                إزاي تبدأ
              </div>
              <div className="mt-4 space-y-4">
                {STEPS.map((s) => (
                  <div key={s.n} className="flex gap-3">
                    <CheckCircle2 size={16} className="mt-0.5 shrink-0" style={{ color: "var(--d-accent)" }} />
                    <div>
                      <div className="text-[14px] font-black">{s.t}</div>
                      <div className="text-[12.5px] leading-relaxed" style={{ color: "var(--d-muted)" }}>
                        {s.b}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex gap-3">
              {[doctor1, doctor2].map((img, i) => (
                <img
                  key={i}
                  src={img}
                  alt=""
                  loading="lazy"
                  className="h-32 w-full object-cover"
                  style={{ borderRadius: "var(--d-radius-sm)", border: "1px solid var(--d-border)" }}
                />
              ))}
            </div>

            <div className="p-5" style={{ ...surfaceStyle(d.cards) }}>
              <Quote size={18} style={{ color: "var(--d-accent)" }} />
              <p className="mt-3 text-[13.5px] leading-relaxed">{TESTIMONIALS[0]!.text}</p>
              <div className="mt-3 text-[12px] font-black">{TESTIMONIALS[0]!.name}</div>
              <div className="text-[11px]" style={{ color: "var(--d-muted)" }}>
                {TESTIMONIALS[0]!.year}
              </div>
            </div>

            <PhoneFrame d={d} className="mx-auto !max-w-[210px]">
              <ScreenHome d={d} />
            </PhoneFrame>
          </aside>
        </div>
      </div>
    </section>
  );
}
