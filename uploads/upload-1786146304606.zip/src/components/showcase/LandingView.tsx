import type { DesignTheme } from "@/lib/designs";
import { BRAND, FAQ, FEATURES, INCLUDED, NAV, PILLARS, PLANS, STATS, STEPS, TESTIMONIALS } from "@/lib/content";
import { Btn, Chip, Eyebrow, H2, ICONS, Lead, PhoneFrame, surfaceStyle } from "./kit";
import { ScreenHome, ScreenPlayer, ScreenQuiz, ScreenSecurity } from "./AppScreens";
import logo from "@/assets/track-logo.png";
import heroSecure from "@/assets/hero-secure.jpg";
import studentNight from "@/assets/student-night.jpg";
import watermarkArt from "@/assets/watermark-art.jpg";
import softMesh from "@/assets/soft-mesh.jpg";
import doctor1 from "@/assets/doctor-1.jpg";
import doctor2 from "@/assets/doctor-2.jpg";
import { ArrowLeft, CheckCircle2, Play, Quote, Sparkles } from "lucide-react";
import { HeroCampus, HeroMagazine, HeroOrbit, HeroSpotlight, HeroStack } from "./HeroesV2";

type P = { d: DesignTheme };
const soft = (c: string, p = 14) => `color-mix(in oklab, ${c} ${p}%, transparent)`;

function Nav({ d }: P) {
  return (
    <header
      className="sticky top-0 z-40 w-full"
      style={{
        background: `color-mix(in oklab, var(--d-bg) 78%, transparent)`,
        backdropFilter: "blur(20px)",
        borderBottom: `1px solid var(--d-border)`,
      }}
    >
      <div className="mx-auto grid max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-5 py-3.5 lg:flex lg:justify-between">
        <div className="flex min-w-0 items-center gap-2.5">
          <img src={logo} alt="Track Academy" className="h-9 w-9 shrink-0 object-contain" />
          <div className="min-w-0">
            <div className="truncate text-[15px] font-black" style={{ fontFamily: "var(--d-head)" }}>
              Track Academy
            </div>
            <div className="truncate text-[9px]" style={{ color: "var(--d-muted)" }}>
              {BRAND.parent}
            </div>
          </div>
        </div>
        <nav className="hidden items-center gap-7 text-[13px] font-bold lg:flex">
          {NAV.map((n) => (
            <a key={n.href} href={n.href} style={{ color: "var(--d-muted)" }}>
              {n.label}
            </a>
          ))}
        </nav>
        <div className="flex shrink-0 items-center gap-2">
          <Btn d={d} variant="ghost" className="!hidden !px-4 !py-2 !text-xs sm:!inline-flex">
            دخول الطلبة
          </Btn>
          <Btn d={d} variant="grad" className="!px-4 !py-2 !text-xs">
            اشترك الآن
          </Btn>
        </div>
      </div>
    </header>
  );
}

function HeroSplit({ d }: P) {
  return (
    <section className="relative overflow-hidden px-5 py-16 lg:py-24">
      <div
        className="pointer-events-none absolute -top-40 left-1/4 h-[520px] w-[520px] opacity-40"
        style={{ background: "var(--d-grad)", filter: "blur(140px)", borderRadius: "50%" }}
      />
      <div className="relative mx-auto grid max-w-7xl items-center gap-12 lg:grid-cols-2">
        <div>
          <Chip d={d}>
            <Sparkles size={12} /> منصة محاضرات الطب · ٢٠٢٧
          </Chip>
          <h1
            className="mt-5 text-balance text-4xl leading-[1.1] font-black sm:text-5xl lg:text-6xl"
            style={{ fontFamily: "var(--d-head)", letterSpacing: "-0.03em" }}
          >
            كل محاضراتك
            <br />
            <span
              style={{
                background: "var(--d-grad)",
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                color: "transparent",
              }}
            >
              في تطبيق واحد.
            </span>
          </h1>
          <Lead d={d}>
            {BRAND.claim} — محاضرات دكاترتك بجودة عالية، ملازم PDF، وبانك أسئلة بعد كل محاضرة،
            وتقدمك محفوظ تكمّل من نفس الدقيقة في أي وقت.
          </Lead>

          <div className="mt-8 flex flex-wrap gap-3">
            <Btn d={d} variant="grad">
              <Play size={15} /> شوف المنصة
            </Btn>
            <Btn d={d} variant="ghost">
              للدكاترة والمراكز <ArrowLeft size={15} />
            </Btn>
          </div>
          <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-4">
            {STATS.map((s) => (
              <div key={s.label}>
                <div
                  className="text-2xl font-black"
                  style={{ color: "var(--d-primary)", fontFamily: "var(--d-head)" }}
                >
                  {s.value}
                </div>
                <div className="text-[11px]" style={{ color: "var(--d-muted)" }}>
                  {s.label}
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="relative grid items-end gap-5 sm:grid-cols-[1.35fr_0.65fr]">
          <img
            src={heroSecure}
            alt="مشغّل محاضرات طبية"
            width={1600}
            height={1104}
            className="w-full object-cover"
            style={{
              borderRadius: "var(--d-radius)",
              border: `1px solid var(--d-border)`,
              boxShadow: "var(--d-shadow)",
              aspectRatio: "4/3",
            }}
          />
          <PhoneFrame d={d} className="mx-auto !max-w-[200px]">
            <ScreenPlayer d={d} />
          </PhoneFrame>
        </div>

      </div>
    </section>
  );
}

function HeroCenter({ d }: P) {
  return (
    <section className="relative overflow-hidden px-5 pt-16 pb-20 text-center lg:pt-24 lg:pb-28">
      <img
        src={softMesh}
        alt=""
        className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-70"
      />
      <div className="relative mx-auto max-w-4xl">
        <Chip d={d}>
          <Sparkles size={12} /> {BRAND.parent}
        </Chip>
        <h1
          className="mt-6 text-balance text-4xl leading-[1.12] font-black sm:text-5xl lg:text-6xl"
          style={{ fontFamily: "var(--d-head)", letterSpacing: "-0.03em" }}
        >
          محاضرات طبية بجودة عالية،
          <br />
          <span style={{ color: "var(--d-primary)" }}>ومذاكرة أسهل بمرّة.</span>
        </h1>
        <p
          className="mx-auto mt-5 max-w-2xl text-base leading-relaxed sm:text-lg"
          style={{ color: "var(--d-muted)" }}
        >
          {BRAND.promise}. مواد فرقتك كلها مرتبة بالترم والدكتور، مع ملازم وأسئلة وبار تقدم
          يوريك إنت واصل لفين.
        </p>

        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Btn d={d} variant="primary">
            ابدأ اشتراكك
          </Btn>
          <Btn d={d} variant="ghost">
            جولة داخل التطبيق
          </Btn>
        </div>
        <div className="mt-14 flex flex-wrap items-end justify-center gap-4">
          <PhoneFrame d={d} className="!hidden !max-w-[200px] translate-y-6 opacity-90 sm:!flex">
            <ScreenSecurity d={d} />
          </PhoneFrame>
          <PhoneFrame d={d} className="!max-w-[240px]">
            <ScreenHome d={d} />
          </PhoneFrame>
          <PhoneFrame d={d} className="!hidden !max-w-[200px] translate-y-6 opacity-90 sm:!flex">
            <ScreenPlayer d={d} />
          </PhoneFrame>
        </div>
      </div>
    </section>
  );
}

function HeroPoster({ d }: P) {
  return (
    <section className="px-5 py-12">
      <div
        className="mx-auto max-w-7xl overflow-hidden"
        style={{
          border: "2px solid var(--d-border)",
          borderRadius: "var(--d-radius)",
          boxShadow: "var(--d-shadow)",
          background: "var(--d-surface)",
        }}
      >
        <div className="grid lg:grid-cols-[1.15fr_0.85fr]">
          <div className="p-7 sm:p-12" style={{ borderLeft: "2px solid var(--d-border)" }}>
            <div
              className="inline-block px-3 py-1 text-[11px] font-black"
              style={{ background: "var(--d-primary)", color: "var(--d-primary-fg)" }}
            >
              MEDICAL · LECTURES · NOTES · MCQ
            </div>
            <h1
              className="mt-6 text-5xl leading-[0.98] font-black sm:text-6xl lg:text-7xl"
              style={{ fontFamily: "var(--d-head)", letterSpacing: "-0.045em" }}
            >
              ذاكر.
              <br />
              <span style={{ color: "var(--d-accent)" }}>واتفوق.</span>
            </h1>
            <p className="mt-6 max-w-xl text-base leading-relaxed" style={{ color: "var(--d-muted)" }}>
              كل محاضرة على تراك أكاديمي معاها ملزمة PDF وبانك أسئلة MCQ بتصحيح فوري، والمشغّل
              بيكمّل من نفس الدقيقة اللي وقفت فيها. {BRAND.promise}.
            </p>

            <div className="mt-8 flex flex-wrap gap-3">
              <Btn d={d} variant="primary">
                اشترك دلوقتي
              </Btn>
              <Btn d={d} variant="ghost">
                اعرف إزاي بيشتغل
              </Btn>
            </div>
          </div>
          <div className="relative min-h-[320px]">
            <img src={studentNight} alt="" className="h-full w-full object-cover" />
            <div
              className="absolute inset-x-0 bottom-0 grid grid-cols-2"
              style={{ borderTop: "2px solid var(--d-border)" }}
            >
              {STATS.slice(0, 2).map((s, i) => (
                <div
                  key={s.label}
                  className="p-4 text-center"
                  style={{
                    background: i === 0 ? "var(--d-primary)" : "var(--d-accent)",
                    color: i === 0 ? "var(--d-primary-fg)" : "#111111",
                    borderLeft: i === 0 ? "2px solid var(--d-border)" : undefined,
                  }}
                >
                  <div className="text-2xl font-black">{s.value}</div>
                  <div className="text-[11px] font-bold">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function HeroEditorial({ d }: P) {
  return (
    <section className="px-5 py-16 lg:py-24">
      <div className="mx-auto max-w-6xl">
        <div
          className="mb-10 flex flex-wrap items-center justify-between gap-4 pb-6 text-[11px] tracking-[0.3em] uppercase"
          style={{ borderBottom: "1px solid var(--d-border)", color: "var(--d-primary)" }}
        >
          <span>Track Academy · Cairo</span>
          <span>Volume 01 — Medical Lectures & Notes</span>
        </div>
        <h1
          className="text-balance text-4xl leading-[1.08] font-black sm:text-6xl lg:text-7xl"
          style={{ fontFamily: "var(--d-head)", letterSpacing: "-0.02em" }}
        >
          مذاكرة الطب تستحق
          <br />
          <span style={{ color: "var(--d-primary)" }}>تجربة بمستوى أعلى.</span>
        </h1>
        <div className="mt-10 grid gap-10 lg:grid-cols-[1.1fr_0.9fr]">
          <div>
            <img
              src={watermarkArt}
              alt="محاضرات وملازم منظمة"
              className="w-full object-cover"
              style={{
                borderRadius: "var(--d-radius)",
                border: "1px solid var(--d-border)",
                aspectRatio: "16/10",
              }}
            />
          </div>
          <div>
            <p className="text-lg leading-loose" style={{ color: "var(--d-muted)" }}>
              كل محاضرة بتوصلك مرتبة: فيديو واضح مقسّم لأجزاء قصيرة، ملزمة PDF جاهزة للقراءة على
              الموبايل، وأسئلة بعدها تتأكد بيها إنك فهمت.
            </p>

            <div className="mt-8 space-y-4">
              {PILLARS.map((p, i) => (
                <div key={p.title} className="flex gap-4">
                  <span
                    className="shrink-0 text-2xl font-black"
                    style={{ color: "var(--d-primary)", fontFamily: "var(--d-head)" }}
                  >
                    0{i + 1}
                  </span>
                  <div>
                    <div className="text-[15px] font-black">{p.title}</div>
                    <div className="text-[13px] leading-relaxed" style={{ color: "var(--d-muted)" }}>
                      {p.body}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              <Btn d={d} variant="primary">
                اطلب عرض للمركز
              </Btn>
              <Btn d={d} variant="ghost">
                تسجيل طالب
              </Btn>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function HeroBento({ d }: P) {
  return (
    <section className="px-5 py-14 lg:py-20">
      <div className="mx-auto grid max-w-7xl auto-rows-[minmax(120px,auto)] grid-cols-1 gap-4 md:grid-cols-4">
        <div
          className="relative overflow-hidden p-7 md:col-span-2 md:row-span-2"
          style={{ ...surfaceStyle(d.cards) }}
        >
          <div
            className="pointer-events-none absolute -top-24 -left-24 h-72 w-72 opacity-50"
            style={{ background: "var(--d-grad)", filter: "blur(90px)", borderRadius: "50%" }}
          />
          <Chip d={d}>Track Academy · Student App</Chip>
          <h1
            className="relative mt-5 text-4xl leading-[1.08] font-black sm:text-5xl"
            style={{ fontFamily: "var(--d-head)", letterSpacing: "-0.03em" }}
          >
            محاضراتك ومراجعاتك
            <br />
            <span
              style={{
                background: "var(--d-grad)",
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                color: "transparent",
              }}
            >
              في مكان واحد.
            </span>
          </h1>
          <p className="relative mt-4 text-sm leading-relaxed" style={{ color: "var(--d-muted)" }}>
            {BRAND.claim}. محاضرات HD، ملازم PDF، بانك أسئلة، وتتبّع لتقدمك في كل مادة.
          </p>

          <div className="relative mt-6 flex flex-wrap gap-3">
            <Btn d={d} variant="grad">
              ابدأ الآن
            </Btn>
            <Btn d={d} variant="ghost">
              شوف المواد المتاحة
            </Btn>
          </div>
        </div>

        <div className="overflow-hidden md:col-span-2" style={{ ...surfaceStyle(d.cards) }}>
          <img src={heroSecure} alt="" className="h-full min-h-[180px] w-full object-cover" />
        </div>

        {STATS.map((s) => (
          <div key={s.label} className="p-5" style={{ ...surfaceStyle(d.cards) }}>
            <div
              className="text-3xl font-black"
              style={{
                fontFamily: "var(--d-head)",
                background: "var(--d-grad)",
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                color: "transparent",
              }}
            >
              {s.value}
            </div>
            <div className="mt-1 text-[12px]" style={{ color: "var(--d-muted)" }}>
              {s.label}
            </div>
          </div>
        ))}

        <div
          className="flex items-center justify-center p-4 md:col-span-2 md:row-span-2"
          style={{ ...surfaceStyle(d.cards) }}
        >
          <PhoneFrame d={d} className="!max-w-[230px]">
            <ScreenHome d={d} />
          </PhoneFrame>
        </div>
        <div className="overflow-hidden md:col-span-2" style={{ ...surfaceStyle(d.cards) }}>
          <img src={watermarkArt} alt="" className="h-full min-h-[160px] w-full object-cover" />
        </div>
        <div className="p-5 md:col-span-2" style={{ ...surfaceStyle(d.cards) }}>
          <div className="text-[13px] font-black">{BRAND.promise}</div>
          <p className="mt-2 text-[12px] leading-relaxed" style={{ color: "var(--d-muted)" }}>
            محاضرات جديدة كل أسبوع، ملازم متجدّدة، ومراجعات نهائية قبل الامتحان.
          </p>
        </div>
      </div>
    </section>
  );
}

function Section({
  d,
  id,
  eyebrow,
  title,
  lead,
  children,
  alt,
}: P & {
  id?: string;
  eyebrow: string;
  title: React.ReactNode;
  lead?: string;
  children: React.ReactNode;
  alt?: boolean;
}) {
  return (
    <section
      id={id}
      className="px-5 py-16 lg:py-24"
      style={alt ? { background: "var(--d-bg2)" } : undefined}
    >
      <div className="mx-auto max-w-7xl">
        <Eyebrow d={d}>{eyebrow}</Eyebrow>
        <H2 d={d}>{title}</H2>
        {lead ? <Lead d={d}>{lead}</Lead> : null}
        <div className="mt-10">{children}</div>
      </div>
    </section>
  );
}

export default function LandingView({ d }: P) {
  const HEROES: Record<string, (p: P) => React.ReactElement> = {
    split: HeroSplit,
    center: HeroCenter,
    poster: HeroPoster,
    editorial: HeroEditorial,
    bento: HeroBento,
    campus: HeroCampus,
    spotlight: HeroSpotlight,
    stack: HeroStack,
    orbit: HeroOrbit,
    magazine: HeroMagazine,
  };
  const Hero = HEROES[d.hero] ?? HeroSplit;


  return (
    <div dir="rtl">
      <Nav d={d} />
      <Hero d={d} />

      <Section
        d={d}
        id="pillars"
        eyebrow="ليه تراك أكاديمي"
        title="تلاقي كل حاجة محتاجها للمذاكرة في مكان واحد"
        lead="مش محتاج تلف على جروبات ولا لينكات. مادتك، محاضرتك، ملزمتك، وأسئلتك كلهم قدامك مرتبين."
        alt
      >
        <div className="grid gap-5 md:grid-cols-3">
          {PILLARS.map((p, i) => {
            const Icon = ICONS[p.icon]!;
            return (
              <div key={p.title} className="p-7" style={{ ...surfaceStyle(d.cards) }}>
                <div
                  className="grid h-12 w-12 place-items-center"
                  style={{
                    borderRadius: d.cards === "brutal" ? "var(--d-radius-sm)" : "16px",
                    background: "var(--d-grad)",
                    color: "var(--d-primary-fg)",
                  }}
                >
                  <Icon size={20} />
                </div>
                <div
                  className="mt-5 text-xl font-black"
                  style={{ fontFamily: "var(--d-head)" }}
                >
                  {i + 1}. {p.title}
                </div>
                <p className="mt-3 text-sm leading-relaxed" style={{ color: "var(--d-muted)" }}>
                  {p.body}
                </p>
              </div>
            );
          })}
        </div>
      </Section>

      <Section
        d={d}
        id="features"
        eyebrow="المميزات"
        title="ستة حاجات هتحس بفرقها من أول يوم"
        lead="كل تفصيلة في التطبيق معمولة عشان توفر وقتك وتخليك مركّز في المذاكرة نفسها."
      >
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => {
            const Icon = ICONS[f.icon]!;
            return (
              <div key={f.title} className="p-6" style={{ ...surfaceStyle(d.cards) }}>
                <div className="flex items-center justify-between gap-3">
                  <Icon size={22} style={{ color: "var(--d-primary)" }} />
                  <Chip d={d} tone="muted">
                    {f.tag}
                  </Chip>
                </div>
                <div className="mt-4 text-[17px] font-black" style={{ fontFamily: "var(--d-head)" }}>
                  {f.title}
                </div>
                <p className="mt-2 text-[13.5px] leading-relaxed" style={{ color: "var(--d-muted)" }}>
                  {f.body}
                </p>
              </div>
            );
          })}
        </div>
      </Section>

      <Section
        d={d}
        eyebrow="داخل التطبيق"
        title="شكل التطبيق من جوه"
        lead="دخول بجوجل، مادتك ومحاضراتها، مشغّل بيكمّل من نفس الدقيقة، وأسئلة بعد كل محاضرة."
        alt
      >
        <div className="flex flex-wrap justify-center gap-8 lg:justify-between">
          <PhoneFrame d={d} label="الرئيسية">
            <ScreenHome d={d} />
          </PhoneFrame>
          <PhoneFrame d={d} label="مشغّل المحاضرة">
            <ScreenPlayer d={d} />
          </PhoneFrame>
          <PhoneFrame d={d} label="بانك الأسئلة">
            <ScreenQuiz d={d} />
          </PhoneFrame>
          <PhoneFrame d={d} label="حسابي وأجهزتي">
            <ScreenSecurity d={d} />
          </PhoneFrame>
        </div>
      </Section>

      <Section
        d={d}
        eyebrow="الاشتراك بيشمل إيه"
        title="اللي بتاخده معانا بالتفصيل"
        lead="كل حاجة واضحة من الأول — من غير مفاجآت ولا رسوم مخفية."
      >
        <div style={{ ...surfaceStyle(d.cards), overflow: "hidden" }}>
          {INCLUDED.map((a, i) => (
            <div
              key={a.item}
              className="flex flex-wrap items-center justify-between gap-3 px-6 py-4"
              style={{ borderTop: i === 0 ? undefined : "1px solid var(--d-border)" }}
            >
              <span className="text-[14px] font-bold">{a.item}</span>
              <span
                className="flex items-center gap-2 text-[13px] font-black"
                style={{ color: a.tone === "ok" ? "var(--d-ok)" : "var(--d-warn)" }}
              >
                <CheckCircle2 size={15} /> {a.value}
              </span>
            </div>
          ))}
        </div>
      </Section>

      <Section
        d={d}
        id="doctors"
        eyebrow="الدكاترة"
        title="دكاترتك اللي بتذاكر معاهم"
        alt
      >
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { img: doctor1, n: "د. أحمد سالم", s: "أستاذ التشريح", c: "١٨ كورس" },
            { img: doctor2, n: "د. مروة عبد الله", s: "أستاذ الفسيولوجي", c: "١٢ كورس" },
            { img: doctor1, n: "د. طارق منير", s: "أستاذ الباثولوجي", c: "٩ كورسات" },
            { img: doctor2, n: "د. هبة رأفت", s: "أستاذ الهستولوجي", c: "١٤ كورس" },
          ].map((p, i) => (
            <div key={i} className="overflow-hidden" style={{ ...surfaceStyle(d.cards) }}>
              <img src={p.img} alt={p.n} className="h-56 w-full object-cover" loading="lazy" />
              <div className="p-5">
                <div className="text-[16px] font-black" style={{ fontFamily: "var(--d-head)" }}>
                  {p.n}
                </div>
                <div className="text-[12px]" style={{ color: "var(--d-muted)" }}>
                  {p.s} · {p.c}
                </div>
              </div>
            </div>
          ))}
        </div>
      </Section>

      <Section
        d={d}
        id="steps"
        eyebrow="إزاي بتشتغل"
        title="أربع خطوات وتكون بدأت"
        lead="من غير تعقيد: حساب جوجل، مادتك، تأكيد سريع، وابدأ."
        alt
      >
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {STEPS.map((st) => (
            <div key={st.n} className="p-6" style={{ ...surfaceStyle(d.cards) }}>
              <div
                className="text-3xl font-black"
                style={{ color: "var(--d-primary)", fontFamily: "var(--d-head)" }}
              >
                {st.n}
              </div>
              <div className="mt-3 text-[16px] font-black" style={{ fontFamily: "var(--d-head)" }}>
                {st.t}
              </div>
              <p className="mt-2 text-[13px] leading-relaxed" style={{ color: "var(--d-muted)" }}>
                {st.b}
              </p>
            </div>
          ))}
        </div>
      </Section>

      <Section d={d} eyebrow="رأي الطلبة" title="طلبة زيك بيقولوا إيه؟">
        <div className="grid gap-4 md:grid-cols-3">
          {TESTIMONIALS.map((t) => (
            <div key={t.name} className="p-6" style={{ ...surfaceStyle(d.cards) }}>
              <Quote size={20} style={{ color: "var(--d-primary)" }} />
              <p className="mt-3 text-[14px] leading-relaxed">{t.text}</p>
              <div className="mt-4 text-[13px] font-black" style={{ fontFamily: "var(--d-head)" }}>
                {t.name}
              </div>
              <div className="text-[11.5px]" style={{ color: "var(--d-muted)" }}>
                {t.year}
              </div>
            </div>
          ))}
        </div>
      </Section>

      <Section d={d} id="plans" eyebrow="الاشتراكات" title="خطط واضحة، من غير رسوم مخفية">
        <div className="grid gap-5 lg:grid-cols-3">
          {PLANS.map((p) => (
            <div
              key={p.name}
              className="p-7"
              style={{
                ...surfaceStyle(d.cards, p.highlight ? "raised" : "base"),
                borderColor: p.highlight ? "var(--d-primary)" : undefined,
                boxShadow: p.highlight ? "var(--d-glow)" : undefined,
              }}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-[17px] font-black" style={{ fontFamily: "var(--d-head)" }}>
                  {p.name}
                </span>
                {p.highlight ? <Chip d={d}>الأكثر اختياراً</Chip> : null}
              </div>
              <div className="mt-4 flex items-baseline gap-2">
                <span
                  className="text-4xl font-black"
                  style={{ color: "var(--d-primary)", fontFamily: "var(--d-head)" }}
                >
                  {p.price}
                </span>
                <span className="text-[12px]" style={{ color: "var(--d-muted)" }}>
                  {p.unit}
                </span>
              </div>
              <div className="mt-5 space-y-2.5">
                {p.features.map((f) => (
                  <div key={f} className="flex items-center gap-2 text-[13px]">
                    <CheckCircle2 size={15} style={{ color: "var(--d-ok)" }} />
                    <span style={{ color: "var(--d-muted)" }}>{f}</span>
                  </div>
                ))}
              </div>
              <div className="mt-7">
                <Btn d={d} variant={p.highlight ? "grad" : "ghost"} className="w-full">
                  اختر الخطة
                </Btn>
              </div>
            </div>
          ))}
        </div>
      </Section>

      <Section d={d} id="faq" eyebrow="أسئلة شائعة" title="أسئلة الطلبة المتكررة" alt>
        <div className="grid gap-4 md:grid-cols-2">
          {FAQ.map((f) => (
            <div key={f.q} className="p-6" style={{ ...surfaceStyle(d.cards) }}>
              <div className="text-[15px] font-black" style={{ fontFamily: "var(--d-head)" }}>
                {f.q}
              </div>
              <p className="mt-2.5 text-[13.5px] leading-relaxed" style={{ color: "var(--d-muted)" }}>
                {f.a}
              </p>
            </div>
          ))}
        </div>
      </Section>

      <section className="px-5 pb-16">
        <div
          className="relative mx-auto max-w-7xl overflow-hidden p-10 text-center sm:p-16"
          style={{
            borderRadius: "var(--d-radius)",
            background: "var(--d-grad)",
            color: "var(--d-primary-fg)",
            border: d.cards === "brutal" ? "2px solid var(--d-border)" : undefined,
            boxShadow: "var(--d-shadow)",
          }}
        >
          <h2
            className="text-balance text-3xl leading-tight font-black sm:text-5xl"
            style={{ fontFamily: "var(--d-head)", letterSpacing: "-0.03em" }}
          >
            جاهز تبدأ ترمك صح؟
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-sm opacity-85 sm:text-base">
            سجّل بحساب جوجل في أقل من دقيقة، وأول محاضرة عليك — تجربها قبل ما تشترك.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <div
              className="px-7 py-3 text-sm font-black"
              style={{
                background: "var(--d-bg)",
                color: "var(--d-fg)",
                borderRadius: "var(--d-radius-sm)",
                border: d.cards === "brutal" ? "2px solid var(--d-border)" : undefined,
              }}
            >
              سجّل بحساب جوجل
            </div>
            <div
              className="px-7 py-3 text-sm font-black"
              style={{
                border: "2px solid currentColor",
                borderRadius: "var(--d-radius-sm)",
              }}
            >
              كلّم الدعم على واتساب
            </div>
          </div>
        </div>
      </section>

      <footer className="px-5 pb-14" style={{ borderTop: "1px solid var(--d-border)" }}>
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 pt-8">
          <div className="flex items-center gap-3">
            <img src={logo} alt="" className="h-9 w-9 object-contain" />
            <div>
              <div className="text-[14px] font-black">Track Academy</div>
              <div className="text-[10px]" style={{ color: "var(--d-muted)" }}>
                © ٢٠٢٧ {BRAND.parent}
              </div>
            </div>
          </div>
          <div className="flex flex-wrap gap-5 text-[12px]" style={{ color: "var(--d-muted)" }}>
            <span>سياسة الخصوصية</span>
            <span>شروط الاستخدام</span>
            <span>أسئلة شائعة</span>
            <span>تواصل معنا</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
