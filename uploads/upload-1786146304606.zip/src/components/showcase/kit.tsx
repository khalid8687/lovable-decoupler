import type { ReactNode } from "react";
import type { CardStyle, DesignTheme } from "@/lib/designs";
import {
  BarChart3,
  Camera,
  Clock,
  FileText,
  Headphones,
  HelpCircle,
  Play,
  Eye,
  Fingerprint,
  Lock,
  Monitor,
  Repeat,
  Shield,
  Smartphone,
  Users,
} from "lucide-react";

export const ICONS: Record<string, React.ComponentType<{ size?: number; style?: React.CSSProperties }>> = {
  lock: Lock,
  fingerprint: Fingerprint,
  shield: Shield,
  camera: Camera,
  users: Users,
  smartphone: Smartphone,
  eye: Eye,
  monitor: Monitor,
  repeat: Repeat,
  play: Play,
  clock: Clock,
  help: HelpCircle,
  file: FileText,
  chart: BarChart3,
  headphones: Headphones,
};

export function surfaceStyle(cards: CardStyle, tone: "base" | "raised" = "base") {
  const bg = tone === "raised" ? "var(--d-surface2)" : "var(--d-surface)";
  switch (cards) {
    case "glass":
      return {
        background: bg,
        border: "1px solid var(--d-border)",
        backdropFilter: "blur(18px)",
        borderRadius: "var(--d-radius)",
        boxShadow: "var(--d-shadow)",
      };
    case "soft":
      return {
        background: bg,
        border: "1px solid var(--d-border)",
        borderRadius: "var(--d-radius)",
        boxShadow: "var(--d-shadow)",
      };
    case "brutal":
      return {
        background: bg,
        border: "2px solid var(--d-border)",
        borderRadius: "var(--d-radius)",
        boxShadow: "var(--d-shadow)",
      };
    case "outline":
      return {
        background: bg,
        border: "1px solid var(--d-border)",
        borderRadius: "var(--d-radius)",
      };
    case "gradient":
      return {
        background: bg,
        border: "1px solid var(--d-border)",
        borderRadius: "var(--d-radius)",
        boxShadow: "var(--d-shadow)",
        backdropFilter: "blur(14px)",
      };
  }
}

export function Card({
  d,
  children,
  className = "",
  tone = "base",
  style,
}: {
  d: DesignTheme;
  children: ReactNode;
  className?: string;
  tone?: "base" | "raised";
  style?: React.CSSProperties;
}) {
  return (
    <div className={className} style={{ ...surfaceStyle(d.cards, tone), ...style }}>
      {children}
    </div>
  );
}

export function Btn({
  d,
  children,
  variant = "primary",
  className = "",
  as = "button",
  href,
}: {
  d: DesignTheme;
  children: ReactNode;
  variant?: "primary" | "ghost" | "grad";
  className?: string;
  as?: "button" | "a" | "div";
  href?: string;
}) {
  const base: React.CSSProperties = {
    borderRadius: "var(--d-radius-sm)",
    fontFamily: "var(--d-head)",
    fontWeight: 700,
    letterSpacing: "-0.01em",
    transition: "transform .18s ease, box-shadow .18s ease, opacity .18s ease",
  };
  const styles: Record<string, React.CSSProperties> = {
    primary: {
      ...base,
      background: "var(--d-primary)",
      color: "var(--d-primary-fg)",
      boxShadow: d.cards === "brutal" ? "var(--d-glow)" : "var(--d-glow)",
      border: d.cards === "brutal" ? "2px solid var(--d-border)" : "1px solid transparent",
    },
    grad: {
      ...base,
      background: "var(--d-grad)",
      color: d.cards === "brutal" ? "var(--d-fg)" : "var(--d-primary-fg)",
      border: d.cards === "brutal" ? "2px solid var(--d-border)" : "1px solid transparent",
      boxShadow: "var(--d-glow)",
    },
    ghost: {
      ...base,
      background: "transparent",
      color: "var(--d-fg)",
      border: `${d.cards === "brutal" ? 2 : 1}px solid var(--d-border)`,
    },
  };
  const cls = `inline-flex items-center justify-center gap-2 px-6 py-3 text-sm hover:-translate-y-0.5 ${className}`;
  if (as === "a")
    return (
      <a href={href} className={cls} style={styles[variant]}>
        {children}
      </a>
    );
  if (as === "div")
    return (
      <div className={cls} style={styles[variant]}>
        {children}
      </div>
    );
  return (
    <button type="button" className={cls} style={styles[variant]}>
      {children}
    </button>
  );
}

export function Chip({
  d,
  children,
  tone = "primary",
}: {
  d: DesignTheme;
  children: ReactNode;
  tone?: "primary" | "accent" | "ok" | "warn" | "danger" | "muted";
}) {
  const color = tone === "muted" ? "var(--d-muted)" : `var(--d-${tone})`;
  return (
    <span
      className="inline-flex items-center gap-1.5 px-3 py-1 text-[11px] font-bold"
      style={{
        borderRadius: d.cards === "brutal" ? "var(--d-radius-sm)" : "999px",
        border: `${d.cards === "brutal" ? 2 : 1}px solid ${color}`,
        color,
        background:
          d.cards === "brutal" ? "transparent" : `color-mix(in oklab, ${color} 12%, transparent)`,
        fontFamily: "var(--d-head)",
      }}
    >
      {children}
    </span>
  );
}

export function Eyebrow({ d, children }: { d: DesignTheme; children: ReactNode }) {
  return (
    <div
      className="mb-4 text-[12px] font-black tracking-[0.28em] uppercase"
      style={{ color: "var(--d-primary)", fontFamily: "var(--d-head)" }}
    >
      {children}
    </div>
  );
}

export function H2({
  d,
  children,
  className = "",
}: {
  d: DesignTheme;
  children: ReactNode;
  className?: string;
}) {
  return (
    <h2
      className={`text-balance text-3xl leading-[1.15] font-black sm:text-4xl lg:text-5xl ${className}`}
      style={{ fontFamily: "var(--d-head)", letterSpacing: "-0.02em" }}
    >
      {children}
    </h2>
  );
}

export function Lead({ d, children }: { d: DesignTheme; children: ReactNode }) {
  return (
    <p className="mt-4 max-w-2xl text-base leading-relaxed sm:text-lg" style={{ color: "var(--d-muted)" }}>
      {children}
    </p>
  );
}

/** Realistic phone shell — the app mockups live inside this. */
export function PhoneFrame({
  d,
  children,
  label,
  className = "",
}: {
  d: DesignTheme;
  children: ReactNode;
  label?: string;
  className?: string;
}) {
  return (
    <figure className={`flex w-full max-w-[300px] shrink-0 flex-col items-center ${className}`}>
      <div
        className="relative w-full"
        style={{
          borderRadius: "42px",
          padding: "9px",
          background:
            d.cards === "brutal"
              ? "var(--d-fg)"
              : "linear-gradient(160deg, rgba(255,255,255,0.35), rgba(120,120,140,0.25))",
          border: d.cards === "brutal" ? "2px solid var(--d-border)" : "1px solid var(--d-border)",
          boxShadow: d.cards === "brutal" ? "10px 10px 0 var(--d-border)" : "var(--d-shadow)",
        }}
      >
        <div
          className="relative overflow-hidden"
          style={{
            borderRadius: "34px",
            background: "var(--d-app-bg)",
            aspectRatio: "9 / 19.5",
          }}
        >
          <div
            className="pointer-events-none absolute top-2 left-1/2 z-30 h-5 w-20 -translate-x-1/2"
            style={{ borderRadius: "999px", background: "rgba(0,0,0,0.85)" }}
          />
          <div className="absolute inset-0 flex flex-col overflow-hidden" dir="rtl">
            {children}
          </div>
        </div>
      </div>
      {label ? (
        <figcaption
          className="mt-4 text-center text-[13px] font-bold"
          style={{ color: "var(--d-muted)", fontFamily: "var(--d-head)" }}
        >
          {label}
        </figcaption>
      ) : null}
    </figure>
  );
}

export function StatusBar({ d }: { d: DesignTheme }) {
  return (
    <div
      className="flex shrink-0 items-center justify-between px-5 pt-3 pb-1 text-[10px] font-bold"
      style={{ color: "var(--d-muted)" }}
    >
      <span>٩:٤١</span>
      <span className="flex items-center gap-1">
        <span>▮▮▮</span>
        <span>Wi-Fi</span>
        <span>٨٧٪</span>
      </span>
    </div>
  );
}

export function BrowserChrome({ d, children }: { d: DesignTheme; children: ReactNode }) {
  return (
    <div
      className="overflow-hidden"
      style={{
        borderRadius: "var(--d-radius)",
        border: `${d.cards === "brutal" ? 2 : 1}px solid var(--d-border)`,
        boxShadow: "var(--d-shadow)",
        background: "var(--d-bg)",
      }}
    >
      <div
        className="flex items-center gap-2 px-4 py-3"
        style={{ borderBottom: "1px solid var(--d-border)", background: "var(--d-surface)" }}
      >
        <span className="flex gap-1.5">
          {["#ff5f57", "#febc2e", "#28c840"].map((c) => (
            <span key={c} className="h-2.5 w-2.5 rounded-full" style={{ background: c }} />
          ))}
        </span>
        <span
          className="mx-auto max-w-[60%] truncate px-4 py-1 text-[11px]"
          style={{
            borderRadius: "999px",
            background: "var(--d-surface2)",
            color: "var(--d-muted)",
          }}
        >
          trackacademy.app
        </span>
      </div>
      {children}
    </div>
  );
}
