import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { DESIGNS, getDesign, themeStyle } from "@/lib/designs";
import LandingView from "@/components/showcase/LandingView";
import { APP_SCREENS } from "@/components/showcase/AppScreens";
import { PhoneFrame } from "@/components/showcase/kit";
import logo from "@/assets/track-logo.png";
import { ArrowRight, LayoutGrid, Smartphone } from "lucide-react";

export const Route = createFileRoute("/design/$slug")({
  loader: ({ params }) => {
    const design = getDesign(params.slug);
    if (!design) throw notFound();
    return { slug: design.slug, name: design.name, tagline: design.tagline };
  },
  head: ({ loaderData }) => {
    const title = `${loaderData?.name ?? "تصميم"} — Track Academy UI/UX`;
    const description =
      loaderData?.tagline ?? "عرض تصميم كامل للموقع وتطبيق الموبايل لمنصة محاضرات الطب Track Academy.";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: DesignPage,
});

function DesignPage() {
  const { slug } = Route.useParams();
  const d = getDesign(slug)!;
  const [tab, setTab] = useState<"web" | "app">("web");

  return (
    <div style={themeStyle(d)} className="min-h-screen overflow-x-hidden">
      {/* Presenter toolbar */}
      <div
        dir="rtl"
        className="sticky top-0 z-50 w-full"
        style={{
          background: "color-mix(in oklab, var(--d-bg) 82%, transparent)",
          backdropFilter: "blur(20px)",
          borderBottom: "1px solid var(--d-border)",
        }}
      >
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-2.5">
          <div className="flex min-w-0 items-center gap-3">
            <Link
              to="/"
              className="inline-flex shrink-0 items-center gap-1.5 px-3 py-1.5 text-[12px] font-black"
              style={{
                border: "1px solid var(--d-border)",
                borderRadius: "var(--d-radius-sm)",
                color: "var(--d-fg)",
              }}
            >
              <ArrowRight size={13} /> كل التصاميم
            </Link>
            <img src={logo} alt="" className="h-7 w-7 shrink-0 object-contain" />
            <span className="truncate text-[13px] font-black" style={{ fontFamily: "var(--d-head)" }}>
              {d.name}
            </span>
          </div>

          <div
            className="flex shrink-0 items-center gap-1 p-1"
            style={{ background: "var(--d-surface)", borderRadius: "999px", border: "1px solid var(--d-border)" }}
          >
            {(
              [
                { k: "web", label: "الموقع", icon: LayoutGrid },
                { k: "app", label: "التطبيق", icon: Smartphone },
              ] as const
            ).map((t) => (
              <button
                key={t.k}
                type="button"
                onClick={() => setTab(t.k)}
                className="inline-flex items-center gap-1.5 px-4 py-1.5 text-[12px] font-black"
                style={{
                  borderRadius: "999px",
                  background: tab === t.k ? "var(--d-primary)" : "transparent",
                  color: tab === t.k ? "var(--d-primary-fg)" : "var(--d-muted)",
                }}
              >
                <t.icon size={13} /> {t.label}
              </button>
            ))}
          </div>

          <div className="hidden shrink-0 gap-1.5 lg:flex">
            {DESIGNS.map((o) => (
              <Link
                key={o.slug}
                to="/design/$slug"
                params={{ slug: o.slug }}
                title={o.name}
                className="h-7 w-7"
                style={{
                  borderRadius: "8px",
                  background: o.vars["--d-grad"],
                  outline: o.slug === d.slug ? "2px solid var(--d-fg)" : "1px solid var(--d-border)",
                  outlineOffset: "2px",
                }}
              />
            ))}
          </div>
        </div>
      </div>

      {tab === "web" ? <LandingView d={d} /> : <AppGallery slug={slug} />}
    </div>
  );
}

function AppGallery({ slug }: { slug: string }) {
  const d = getDesign(slug)!;
  return (
    <div dir="rtl" className="px-5 py-14">
      <div className="mx-auto max-w-7xl">
        <div
          className="text-[12px] font-black tracking-[0.28em] uppercase"
          style={{ color: "var(--d-primary)" }}
        >
          Mobile App · {d.nameEn}
        </div>
        <h2
          className="mt-3 text-3xl leading-tight font-black sm:text-4xl lg:text-5xl"
          style={{ fontFamily: "var(--d-head)", letterSpacing: "-0.02em" }}
        >
كل شاشات تطبيق تراك أكاديمي
        </h2>
        <p className="mt-4 max-w-2xl text-sm leading-relaxed sm:text-base" style={{ color: "var(--d-muted)" }}>
١١ شاشة كاملة بنفس الهوية البصرية: من البداية والدخول بحساب جوجل، لتأكيد سريع بالكاميرا،
          لمشغّل المحاضرة والملزمة، لبانك الأسئلة وتقدمك في المواد، للاشتراك ولوحة المشرف.
        </p>

        <div className="mt-12 grid justify-items-center gap-x-6 gap-y-14 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {APP_SCREENS.map((s, i) => (
            <PhoneFrame key={s.key} d={d} label={`${String(i + 1).padStart(2, "0")} — ${s.label}`}>
              <s.Comp d={d} />
            </PhoneFrame>
          ))}
        </div>
      </div>
    </div>
  );
}
