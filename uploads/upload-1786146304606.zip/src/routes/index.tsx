import { createFileRoute, Link } from "@tanstack/react-router";
import { DESIGNS } from "@/lib/designs";
import { BRAND } from "@/lib/content";
import logo from "@/assets/track-logo.png";
import heroSecure from "@/assets/hero-secure.jpg";
import { ArrowLeft, Layers, MonitorSmartphone, Palette, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Track Academy — ١٠ تصاميم لموقع وتطبيق محاضرات الطب" },
      {
        name: "description",
        content:
          "معرض تصاميم Track Academy: عشر هويات بصرية كاملة للاندنج بيدج وتطبيق الموبايل لمنصة محاضرات الطب للطلبة.",
      },
      { property: "og:title", content: "Track Academy — ١٠ تصاميم UI/UX" },
      {
        property: "og:description",
        content: "عشر هويات بصرية كاملة للموقع وتطبيق الموبايل لمنصة محاضرات الطب.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Gallery,
});

function Gallery() {
  return (
    <div dir="rtl" className="min-h-screen bg-[#06070c] text-white" style={{ fontFamily: '"IBM Plex Sans Arabic", system-ui, sans-serif' }}>
      <div className="relative overflow-hidden px-5 pt-14 pb-10">
        <img
          src={heroSecure}
          alt=""
          width={1600}
          height={1104}
          className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-25"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#06070c] via-[#06070c]/70 to-transparent" />
        <div className="relative mx-auto max-w-6xl">
          <div className="flex items-center gap-3">
            <img src={logo} alt="Track Education Center" className="h-12 w-12 object-contain" />
            <div>
              <div className="text-lg font-black">Track Academy</div>
              <div className="text-[11px] text-white/55">{BRAND.parent}</div>
            </div>
          </div>
          <h1 className="mt-8 max-w-3xl text-balance text-4xl leading-[1.12] font-black sm:text-5xl lg:text-6xl">
عشر تصاميم كاملة
            <span className="bg-gradient-to-l from-[#22d3ee] via-[#a78bfa] to-[#ff8a3d] bg-clip-text text-transparent">
              {" "}
              للموقع والتطبيق
            </span>
          </h1>
          <p className="mt-5 max-w-2xl text-sm leading-relaxed text-white/65 sm:text-base">
            كل تصميم عرض بصري كامل (Design Preview) للاندنج بيدج + كل صفحات تطبيق الموبايل، بلغة
            بتخاطب الطالب: محاضرات دكاترته، ملازم، بانك أسئلة، تقدمه في المواد، والاشتراك. الخمسة
            الأخيرة تصاميم جديدة أقوى وأدق. العرض ديزاين فقط وغير مربوط بأي باك إند.
          </p>
          <div className="mt-7 flex flex-wrap gap-2 text-[12px] font-bold text-white/70">
            {[
              { i: Palette, t: "١٠ هويات بصرية مختلفة" },
              { i: MonitorSmartphone, t: "متوافق موبايل + لاب" },
              { i: Layers, t: "١١ شاشة موبايل لكل تصميم" },
              { i: ShieldCheck, t: "ديزاين ٢٠٢٧ بلغة الطالب" },
            ].map((c) => (
              <span
                key={c.t}
                className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 px-3 py-1.5"
              >
                <c.i size={13} /> {c.t}
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-6xl px-5 pb-20">
        <div className="grid gap-5 sm:grid-cols-2">
          {DESIGNS.map((d, i) => (
            <Link
              key={d.slug}
              to="/design/$slug"
              params={{ slug: d.slug }}
              className="group relative overflow-hidden rounded-3xl border border-white/12 bg-white/[0.04] p-6 transition-transform hover:-translate-y-1"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="text-[11px] font-black tracking-[0.25em] text-white/40 uppercase">
                    Design {String(i + 1).padStart(2, "0")}
                  </div>
                  <div className="mt-2 flex items-center gap-2 text-2xl font-black">
                    {d.name}
                    {d.isNew ? (
                      <span className="rounded-full bg-[#22d3ee] px-2 py-0.5 text-[10px] font-black text-[#04121a]">
                        جديد
                      </span>
                    ) : null}
                  </div>
                  <div className="text-[12px] text-white/45">{d.nameEn}</div>
                </div>
                <div className="flex shrink-0 gap-1.5">
                  {d.swatch.map((c) => (
                    <span
                      key={c}
                      className="h-8 w-8 rounded-lg border border-white/15"
                      style={{ background: c }}
                    />
                  ))}
                </div>
              </div>
              <p className="mt-4 text-[13.5px] leading-relaxed text-white/60">{d.tagline}</p>
              <div
                className="mt-5 h-24 w-full rounded-2xl border border-white/10"
                style={{ background: d.vars["--d-grad"] }}
              />
              <div className="mt-5 flex items-center justify-between text-[12px]">
                <span className="rounded-full border border-white/15 px-3 py-1 text-white/60">
                  {d.vibe}
                </span>
                <span className="inline-flex items-center gap-1.5 font-black text-white">
                  افتح العرض <ArrowLeft size={14} className="transition-transform group-hover:-translate-x-1" />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
