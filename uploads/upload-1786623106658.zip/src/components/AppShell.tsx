import { Link, useRouterState } from "@tanstack/react-router";
import type { ReactNode } from "react";
import {
  LayoutDashboard,
  FileSignature,
  FolderKanban,
  Wallet,
  Percent,
  Users,
  BarChart3,
  LifeBuoy,
  Ticket,
  ShieldCheck,
  Target,
  Settings,
  LogOut,
  Bell,
} from "lucide-react";
import logo from "@/assets/logo.png";
import type { Role } from "@/lib/mock";

type NavItem = { to: string; label: string; icon: typeof LayoutDashboard };

const NAV: Record<Role, NavItem[]> = {
  employee: [
    { to: "/employee", label: "لوحتي", icon: LayoutDashboard },
    { to: "/employee/sales", label: "البيعات", icon: FileSignature },
    { to: "/employee/projects", label: "المشاريع", icon: FolderKanban },
    { to: "/employee/collections", label: "التحصيلات", icon: Wallet },
    { to: "/employee/commissions", label: "العمولات", icon: Percent },
  ],
  manager: [
    { to: "/manager", label: "لوحة الفريق", icon: LayoutDashboard },
    { to: "/manager/team", label: "الفريق", icon: Users },
    { to: "/manager/sales", label: "التعاقدات", icon: FileSignature },
    { to: "/manager/reports", label: "التقارير", icon: BarChart3 },
  ],
  support: [
    { to: "/support", label: "لوحة الدعم", icon: LifeBuoy },
    { to: "/support/tickets", label: "الطلبات", icon: Ticket },
    { to: "/support/records", label: "السجلات", icon: FolderKanban },
  ],
  admin: [
    { to: "/admin", label: "لوحة الإدارة", icon: LayoutDashboard },
    { to: "/admin/employees", label: "الموظفون", icon: Users },
    { to: "/admin/targets", label: "التارجت", icon: Target },
    { to: "/admin/reports", label: "التقارير", icon: BarChart3 },
    { to: "/admin/settings", label: "الإعدادات", icon: Settings },
  ],
};

const META: Record<Role, { title: string; person: string; badge: string }> = {
  employee: { title: "بوابة الموظف", person: "أحمد سالم", badge: "Sales Person" },
  manager: { title: "بوابة مدير المجموعة", person: "خالد منصور", badge: "Sales Manager" },
  support: { title: "بوابة الدعم", person: "فريق الدعم", badge: "Support" },
  admin: { title: "بوابة الإدارة", person: "منال حسن", badge: "Super Admin" },
};

export function AppShell({ role, children }: { role: Role; children: ReactNode }) {
  const items = NAV[role];
  const meta = META[role];
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 start-0 z-30 hidden w-64 flex-col border-e border-border bg-card lg:flex">
        <div className="flex items-center gap-3 px-5 py-5">
          <img src={logo} alt="شعار النظام" width={40} height={40} className="size-10" />
          <div className="min-w-0">
            <p className="truncate text-sm font-extrabold">SalesTrack</p>
            <p className="truncate text-[11px] text-muted-foreground">إدارة ومتابعة المبيعات</p>
          </div>
        </div>
        <nav className="flex-1 space-y-1 px-3">
          {items.map((it) => {
            const active = pathname === it.to;
            return (
              <Link
                key={it.to}
                to={it.to}
                className={
                  "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-bold transition-all " +
                  (active
                    ? "brand-gradient text-primary-foreground shadow-[var(--shadow-card)]"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground")
                }
              >
                <it.icon className="size-[18px] shrink-0" />
                <span className="truncate">{it.label}</span>
              </Link>
            );
          })}
        </nav>
        <div className="p-3">
          <Link
            to="/"
            className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-bold text-muted-foreground transition-colors hover:bg-muted"
          >
            <LogOut className="size-[18px]" />
            تغيير الدور
          </Link>
        </div>
      </aside>

      <div className="lg:ps-64">
        {/* Top bar */}
        <header className="brand-gradient sticky top-0 z-20 px-4 pt-4 pb-5 text-primary-foreground sm:px-6">
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
            <div className="flex min-w-0 items-center gap-3">
              <img
                src={logo}
                alt="شعار النظام"
                width={36}
                height={36}
                className="size-9 shrink-0 rounded-lg bg-white/90 p-0.5 lg:hidden"
              />
              <div className="min-w-0">
                <p className="truncate text-[11px] font-semibold opacity-85">{meta.badge}</p>
                <h2 className="truncate text-base font-extrabold sm:text-lg">{meta.title}</h2>
              </div>
            </div>
            <div className="flex shrink-0 items-center gap-2">
              <button
                aria-label="التنبيهات"
                className="relative grid size-9 place-items-center rounded-xl bg-white/15"
              >
                <Bell className="size-4" />
                <span className="absolute end-2 top-2 size-1.5 rounded-full bg-warning" />
              </button>
              <div className="hidden items-center gap-2 rounded-xl bg-white/15 py-1.5 pe-3 ps-1.5 sm:flex">
                <span className="grid size-7 place-items-center rounded-lg bg-white/25 text-[11px] font-bold">
                  {meta.person.slice(0, 1)}
                </span>
                <span className="text-xs font-bold whitespace-nowrap">{meta.person}</span>
              </div>
            </div>
          </div>
        </header>

        <main className="mx-auto max-w-6xl space-y-5 px-4 pt-5 pb-28 sm:px-6 lg:pb-10">
          {children}
        </main>
      </div>

      {/* Mobile bottom nav */}
      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-card/95 backdrop-blur lg:hidden">
        <div className="no-scrollbar flex items-stretch justify-between gap-1 overflow-x-auto px-2 py-2">
          {items.map((it) => {
            const active = pathname === it.to;
            return (
              <Link
                key={it.to}
                to={it.to}
                className={
                  "flex min-w-[68px] flex-1 flex-col items-center gap-1 rounded-xl px-2 py-1.5 text-[10px] font-bold transition-colors " +
                  (active ? "text-primary-deep" : "text-muted-foreground")
                }
              >
                <span
                  className={
                    "grid size-8 place-items-center rounded-xl " +
                    (active ? "brand-gradient text-primary-foreground" : "bg-muted")
                  }
                >
                  <it.icon className="size-4" />
                </span>
                <span className="truncate">{it.label}</span>
              </Link>
            );
          })}
          <Link
            to="/"
            className="flex min-w-[68px] flex-col items-center gap-1 rounded-xl px-2 py-1.5 text-[10px] font-bold text-muted-foreground"
          >
            <span className="grid size-8 place-items-center rounded-xl bg-muted">
              <ShieldCheck className="size-4" />
            </span>
            الأدوار
          </Link>
        </div>
      </nav>
    </div>
  );
}
