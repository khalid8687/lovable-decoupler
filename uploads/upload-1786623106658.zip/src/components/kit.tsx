import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function PageHeader({
  title,
  subtitle,
  action,
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
}) {
  return (
    <header className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="min-w-0">
        <h1 className="truncate text-xl font-bold sm:text-2xl">{title}</h1>
        {subtitle ? (
          <p className="mt-1 text-xs text-muted-foreground sm:text-sm">{subtitle}</p>
        ) : null}
      </div>
      {action}
    </header>
  );
}

export function Card({
  children,
  className,
  title,
  action,
}: {
  children: ReactNode;
  className?: string;
  title?: string;
  action?: ReactNode;
}) {
  return (
    <section className={cn("card-surface p-4 sm:p-5", className)}>
      {title ? (
        <div className="mb-4 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2">
          <h2 className="truncate text-sm font-bold sm:text-base">{title}</h2>
          {action}
        </div>
      ) : null}
      {children}
    </section>
  );
}

export function Stat({
  label,
  value,
  hint,
  tone = "plain",
  icon,
}: {
  label: string;
  value: string;
  hint?: string;
  tone?: "plain" | "brand" | "success" | "warning";
  icon?: ReactNode;
}) {
  const brand = tone === "brand";
  return (
    <div
      className={cn(
        "card-surface p-4",
        brand && "brand-gradient border-transparent text-primary-foreground",
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <p className={cn("text-xs font-semibold", brand ? "opacity-90" : "text-muted-foreground")}>
          {label}
        </p>
        {icon ? (
          <span
            className={cn(
              "grid size-8 shrink-0 place-items-center rounded-xl",
              brand ? "bg-white/20" : "brand-gradient-soft text-primary-deep",
            )}
          >
            {icon}
          </span>
        ) : null}
      </div>
      <p className="mt-2 text-lg font-extrabold tracking-tight sm:text-xl">{value}</p>
      {hint ? (
        <p
          className={cn(
            "mt-1 text-[11px] font-medium",
            brand
              ? "opacity-85"
              : tone === "success"
                ? "text-success"
                : tone === "warning"
                  ? "text-warning"
                  : "text-muted-foreground",
          )}
        >
          {hint}
        </p>
      ) : null}
    </div>
  );
}

export function Progress({ value, label }: { value: number; label?: string }) {
  return (
    <div>
      {label ? (
        <div className="mb-1.5 flex items-center justify-between text-xs font-semibold">
          <span className="text-muted-foreground">{label}</span>
          <span>{value}%</span>
        </div>
      ) : null}
      <div className="h-2.5 w-full overflow-hidden rounded-full bg-muted">
        <div
          className="brand-gradient h-full rounded-full transition-all"
          style={{ width: Math.min(value, 100) + "%" }}
        />
      </div>
    </div>
  );
}

export function Ring({ value, caption }: { value: number; caption: string }) {
  const angle = Math.min(value, 100) * 3.6;
  return (
    <div className="flex flex-col items-center gap-2">
      <div
        className="grid size-32 place-items-center rounded-full"
        style={{
          background: `conic-gradient(var(--primary) ${angle}deg, var(--muted) ${angle}deg)`,
        }}
      >
        <div className="grid size-24 place-items-center rounded-full bg-card">
          <span className="text-xl font-extrabold">{value}%</span>
        </div>
      </div>
      <p className="text-xs font-semibold text-muted-foreground">{caption}</p>
    </div>
  );
}

export function Badge({
  children,
  tone = "brand",
}: {
  children: ReactNode;
  tone?: "brand" | "success" | "warning" | "danger" | "muted";
}) {
  const tones = {
    brand: "bg-accent text-accent-foreground",
    success: "bg-success/15 text-success",
    warning: "bg-warning/20 text-warning",
    danger: "bg-destructive/12 text-destructive",
    muted: "bg-muted text-muted-foreground",
  } as const;
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-bold whitespace-nowrap",
        tones[tone],
      )}
    >
      {children}
    </span>
  );
}

export function Button({
  children,
  variant = "primary",
  className,
  ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "outline" | "ghost";
}) {
  const variants = {
    primary: "brand-gradient text-primary-foreground shadow-[var(--shadow-card)]",
    outline: "border border-primary/40 text-primary-deep bg-card hover:bg-accent/50",
    ghost: "text-muted-foreground hover:bg-muted",
  } as const;
  return (
    <button
      {...rest}
      className={cn(
        "inline-flex shrink-0 items-center justify-center gap-2 rounded-xl px-4 py-2 text-xs font-bold transition-all active:scale-[0.98] sm:text-sm",
        variants[variant],
        className,
      )}
    >
      {children}
    </button>
  );
}

export function DataTable({
  head,
  rows,
}: {
  head: string[];
  rows: ReactNode[][];
}) {
  return (
    <div className="no-scrollbar w-full overflow-x-auto">
      <table className="w-full min-w-[640px] border-collapse text-sm">
        <thead>
          <tr className="text-start">
            {head.map((h, i) => (
              <th
                key={h + i}
                className="border-b border-border pb-2 text-start text-[11px] font-bold whitespace-nowrap text-muted-foreground"
              >
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className="border-b border-border/60 last:border-0 hover:bg-muted/40">
              {r.map((c, j) => (
                <td key={j} className="py-3 text-start align-middle whitespace-nowrap">
                  {c}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function BarChart({
  data,
}: {
  data: { label: string; a: number; b: number }[];
}) {
  const max = Math.max(...data.flatMap((d) => [d.a, d.b])) || 1;
  return (
    <div>
      <div className="flex items-end justify-between gap-3 sm:gap-6">
        {data.map((d) => (
          <div key={d.label} className="flex min-w-0 flex-1 flex-col items-center gap-2">
            <div className="flex h-40 w-full items-end justify-center gap-1.5">
              <div
                className="w-1/3 rounded-t-lg bg-muted"
                style={{ height: (d.a / max) * 100 + "%" }}
                title="Target"
              />
              <div
                className="brand-gradient w-1/3 rounded-t-lg"
                style={{ height: (d.b / max) * 100 + "%" }}
                title="Sales"
              />
            </div>
            <span className="text-[11px] font-bold text-muted-foreground">{d.label}</span>
          </div>
        ))}
      </div>
      <div className="mt-4 flex items-center justify-center gap-4 text-[11px] font-semibold text-muted-foreground">
        <span className="flex items-center gap-1.5">
          <i className="size-2.5 rounded-full bg-muted" /> التارجت
        </span>
        <span className="flex items-center gap-1.5">
          <i className="brand-gradient size-2.5 rounded-full" /> المبيعات
        </span>
      </div>
    </div>
  );
}

export function QuarterTabs({
  value,
  onChange,
  options,
}: {
  value: string;
  onChange: (v: string) => void;
  options: readonly string[];
}) {
  return (
    <div className="no-scrollbar flex gap-1.5 overflow-x-auto rounded-xl bg-muted p-1">
      {options.map((o) => (
        <button
          key={o}
          onClick={() => onChange(o)}
          className={cn(
            "shrink-0 rounded-lg px-3 py-1.5 text-[11px] font-bold transition-all sm:text-xs",
            value === o
              ? "brand-gradient text-primary-foreground"
              : "text-muted-foreground hover:text-foreground",
          )}
        >
          {o}
        </button>
      ))}
    </div>
  );
}
