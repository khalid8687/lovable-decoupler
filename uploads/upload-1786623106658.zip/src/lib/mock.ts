export type Role = "employee" | "manager" | "support" | "admin";

export const EGP = (n: number) =>
  "EGP " + n.toLocaleString("en-US", { maximumFractionDigits: 0 });

export const compact = (n: number) =>
  n >= 1_000_000
    ? (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M"
    : n >= 1000
      ? Math.round(n / 1000) + "K"
      : String(n);

export const pct = (a: number, b: number) => (b === 0 ? 0 : Math.round((a / b) * 100));

export const quarters = ["Q1", "Q2", "Q3", "Q4", "Full Year"] as const;

export type SalesPerson = {
  id: string;
  name: string;
  title: string;
  manager: string;
  target: number;
  sales: number;
  collections: number;
  projectsValue: number;
  commissionRate: number;
  commissionEarned: number;
  commissionPaid: number;
};

export const team: SalesPerson[] = [
  {
    id: "u1",
    name: "أحمد سالم",
    title: "Senior Sales",
    manager: "خالد منصور",
    target: 3_000_000,
    sales: 2_400_000,
    collections: 1_120_000,
    projectsValue: 1_700_000,
    commissionRate: 1,
    commissionEarned: 11_200,
    commissionPaid: 8_000,
  },
  {
    id: "u2",
    name: "عمر فؤاد",
    title: "Sales Executive",
    manager: "خالد منصور",
    target: 2_000_000,
    sales: 2_100_000,
    collections: 500_000,
    projectsValue: 1_400_000,
    commissionRate: 1,
    commissionEarned: 5_000,
    commissionPaid: 3_000,
  },
  {
    id: "u3",
    name: "منة عادل",
    title: "Sales Executive",
    manager: "خالد منصور",
    target: 1_800_000,
    sales: 1_260_000,
    collections: 260_000,
    projectsValue: 520_000,
    commissionRate: 1.2,
    commissionEarned: 3_120,
    commissionPaid: 1_000,
  },
  {
    id: "u4",
    name: "يوسف طارق",
    title: "Sales Executive",
    manager: "هالة رمزي",
    target: 2_500_000,
    sales: 1_150_000,
    collections: 860_000,
    projectsValue: 860_000,
    commissionRate: 1,
    commissionEarned: 8_600,
    commissionPaid: 5_000,
  },
];

export const me = team[0]!;

export type Deal = {
  id: string;
  client: string;
  project: string;
  value: number;
  date: string;
  seller: string;
  manager: string;
  partner?: { name: string; share: number };
  share: number;
  status: "موقّع" | "قيد التوقيع" | "مكتمل التحصيل";
};

export const deals: Deal[] = [
  {
    id: "C-1041",
    client: "مجموعة النيل العقارية",
    project: "هوية بصرية + حملة إطلاق",
    value: 1_000_000,
    date: "2026-01-12",
    seller: "أحمد سالم",
    manager: "خالد منصور",
    share: 100,
    status: "موقّع",
  },
  {
    id: "C-1046",
    client: "شركة دلتا للأغذية",
    project: "إدارة سوشيال ميديا سنوية",
    value: 700_000,
    date: "2026-02-03",
    seller: "أحمد سالم",
    manager: "خالد منصور",
    partner: { name: "عمر فؤاد", share: 30 },
    share: 70,
    status: "موقّع",
  },
  {
    id: "C-1052",
    client: "بنك القاهرة الحديث",
    project: "تطوير منصة رقمية",
    value: 1_400_000,
    date: "2026-02-21",
    seller: "عمر فؤاد",
    manager: "خالد منصور",
    share: 100,
    status: "قيد التوقيع",
  },
  {
    id: "C-1058",
    client: "مستشفى الشفاء",
    project: "حملة توعية + إنتاج فيديو",
    value: 520_000,
    date: "2026-03-05",
    seller: "منة عادل",
    manager: "خالد منصور",
    partner: { name: "يوسف طارق", share: 40 },
    share: 60,
    status: "موقّع",
  },
  {
    id: "C-1063",
    client: "أوركيد للمقاولات",
    project: "خطة تسويق عقاري",
    value: 860_000,
    date: "2026-03-18",
    seller: "يوسف طارق",
    manager: "هالة رمزي",
    share: 100,
    status: "مكتمل التحصيل",
  },
];

export type Project = {
  id: string;
  name: string;
  client: string;
  value: number;
  collected: number;
  owner: string;
  signedAt: string;
};

export const projects: Project[] = [
  {
    id: "P-201",
    name: "هوية بصرية + حملة إطلاق",
    client: "مجموعة النيل العقارية",
    value: 1_000_000,
    collected: 700_000,
    owner: "أحمد سالم",
    signedAt: "2026-01-12",
  },
  {
    id: "P-204",
    name: "إدارة سوشيال ميديا سنوية",
    client: "شركة دلتا للأغذية",
    value: 700_000,
    collected: 420_000,
    owner: "أحمد سالم",
    signedAt: "2026-02-03",
  },
  {
    id: "P-209",
    name: "تطوير منصة رقمية",
    client: "بنك القاهرة الحديث",
    value: 1_400_000,
    collected: 500_000,
    owner: "عمر فؤاد",
    signedAt: "2026-02-21",
  },
  {
    id: "P-215",
    name: "حملة توعية + إنتاج فيديو",
    client: "مستشفى الشفاء",
    value: 520_000,
    collected: 260_000,
    owner: "منة عادل",
    signedAt: "2026-03-05",
  },
  {
    id: "P-221",
    name: "خطة تسويق عقاري",
    client: "أوركيد للمقاولات",
    value: 860_000,
    collected: 860_000,
    owner: "يوسف طارق",
    signedAt: "2026-03-18",
  },
];

export type Payment = {
  id: string;
  projectId: string;
  project: string;
  amount: number;
  date: string;
  method: "تحويل بنكي" | "شيك" | "نقدي";
};

export const payments: Payment[] = [
  { id: "R-9001", projectId: "P-201", project: "هوية بصرية + حملة إطلاق", amount: 400_000, date: "2026-01-20", method: "تحويل بنكي" },
  { id: "R-9008", projectId: "P-201", project: "هوية بصرية + حملة إطلاق", amount: 300_000, date: "2026-02-18", method: "شيك" },
  { id: "R-9012", projectId: "P-204", project: "إدارة سوشيال ميديا سنوية", amount: 420_000, date: "2026-02-25", method: "تحويل بنكي" },
  { id: "R-9020", projectId: "P-209", project: "تطوير منصة رقمية", amount: 500_000, date: "2026-03-02", method: "تحويل بنكي" },
  { id: "R-9026", projectId: "P-215", project: "حملة توعية + إنتاج فيديو", amount: 260_000, date: "2026-03-12", method: "نقدي" },
  { id: "R-9031", projectId: "P-221", project: "خطة تسويق عقاري", amount: 860_000, date: "2026-03-25", method: "تحويل بنكي" },
];

export type Commission = {
  id: string;
  person: string;
  quarter: string;
  base: number;
  rate: number;
  earned: number;
  paid: number;
};

export const commissions: Commission[] = team.map((p, i) => ({
  id: "CM-" + (100 + i),
  person: p.name,
  quarter: "Q1 2026",
  base: p.collections,
  rate: p.commissionRate,
  earned: p.commissionEarned,
  paid: p.commissionPaid,
}));

export const managers = [
  { name: "خالد منصور", members: 3, target: 6_800_000, sales: 5_760_000, collections: 1_880_000 },
  { name: "هالة رمزي", members: 1, target: 2_500_000, sales: 1_150_000, collections: 860_000 },
];

export const totals = {
  target: team.reduce((s, p) => s + p.target, 0),
  sales: team.reduce((s, p) => s + p.sales, 0),
  collections: team.reduce((s, p) => s + p.collections, 0),
  projectsValue: projects.reduce((s, p) => s + p.value, 0),
  outstanding: projects.reduce((s, p) => s + (p.value - p.collected), 0),
  commissionEarned: team.reduce((s, p) => s + p.commissionEarned, 0),
  commissionPaid: team.reduce((s, p) => s + p.commissionPaid, 0),
};

export const quarterTrend = [
  { q: "Q1", target: 9_300_000, sales: 6_910_000 },
  { q: "Q2", target: 9_800_000, sales: 8_240_000 },
  { q: "Q3", target: 10_200_000, sales: 7_650_000 },
  { q: "Q4", target: 11_000_000, sales: 3_100_000 },
];

export type Ticket = {
  id: string;
  title: string;
  requester: string;
  type: "تعديل تعاقد" | "خطأ في تحصيل" | "صلاحيات" | "استفسار عمولة";
  priority: "عالية" | "متوسطة" | "منخفضة";
  status: "مفتوحة" | "قيد المعالجة" | "مغلقة";
  createdAt: string;
};

export const tickets: Ticket[] = [
  { id: "T-501", title: "تعديل نسبة المشاركة في التعاقد C-1046", requester: "عمر فؤاد", type: "تعديل تعاقد", priority: "عالية", status: "مفتوحة", createdAt: "2026-03-20" },
  { id: "T-502", title: "دفعة مسجلة مرتين للمشروع P-201", requester: "أحمد سالم", type: "خطأ في تحصيل", priority: "عالية", status: "قيد المعالجة", createdAt: "2026-03-21" },
  { id: "T-503", title: "طلب صلاحية عرض تقارير الفريق", requester: "منة عادل", type: "صلاحيات", priority: "متوسطة", status: "مفتوحة", createdAt: "2026-03-22" },
  { id: "T-504", title: "استفسار عن حساب العمولة المتبقية", requester: "يوسف طارق", type: "استفسار عمولة", priority: "منخفضة", status: "مغلقة", createdAt: "2026-03-18" },
];

export const auditLog = [
  { id: "L-1", at: "2026-03-22 10:14", user: "خالد منصور", action: "اعتمد تعاقد C-1058" },
  { id: "L-2", at: "2026-03-22 09:02", user: "الدعم", action: "عدّل دفعة R-9008" },
  { id: "L-3", at: "2026-03-21 16:40", user: "Super Admin", action: "حدّث تارجت Q2 لفريق خالد" },
  { id: "L-4", at: "2026-03-21 12:11", user: "أحمد سالم", action: "سجّل تحصيل 300,000" },
];
