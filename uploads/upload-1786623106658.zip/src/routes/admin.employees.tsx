import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, X } from "lucide-react";
import { Badge, Button, Card, DataTable, PageHeader } from "@/components/kit";
import { EGP, managers, team } from "@/lib/mock";

export const Route = createFileRoute("/admin/employees")({
  head: () => ({
    meta: [
      { title: "إدارة الموظفين | SalesTrack" },
      { name: "description", content: "إضافة موظفي المبيعات وربطهم بالمدير المباشر وتحديد نسبة العمولة." },
      { property: "og:title", content: "إدارة الموظفين | SalesTrack" },
      { property: "og:description", content: "الهيكل الإداري ونسب العمولات والصلاحيات." },
    ],
  }),
  component: EmployeesPage,
});

const field = "w-full rounded-xl border border-input bg-card px-3 py-2.5 text-sm outline-none focus:border-primary";
const label = "mb-1.5 block text-xs font-bold text-muted-foreground";

function EmployeesPage() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <PageHeader
        title="الموظفون"
        subtitle="الهيكل الإداري ونسب العمولة"
        action={
          <Button onClick={() => setOpen((v) => !v)}>
            {open ? <X className="size-4" /> : <Plus className="size-4" />}
            {open ? "إغلاق" : "موظف جديد"}
          </Button>
        }
      />

      {open ? (
        <Card title="إضافة موظف">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <div>
              <span className={label}>الاسم</span>
              <input className={field} placeholder="اسم الموظف" />
            </div>
            <div>
              <span className={label}>المسمى الوظيفي</span>
              <input className={field} placeholder="Sales Executive" />
            </div>
            <div>
              <span className={label}>المدير المباشر</span>
              <select className={field}>
                {managers.map((m) => (
                  <option key={m.name}>{m.name}</option>
                ))}
              </select>
            </div>
            <div>
              <span className={label}>الدور</span>
              <select className={field}>
                <option>الموظف</option>
                <option>مدير مجموعة</option>
                <option>الدعم</option>
                <option>Super Admin</option>
              </select>
            </div>
            <div>
              <span className={label}>نسبة العمولة %</span>
              <input className={field} type="number" step="0.1" placeholder="1" />
            </div>
            <div>
              <span className={label}>تارجت الربع الحالي</span>
              <input className={field} type="number" placeholder="3000000" />
            </div>
          </div>
          <div className="mt-5 flex flex-wrap gap-2">
            <Button>حفظ</Button>
            <Button variant="outline" onClick={() => setOpen(false)}>
              إلغاء
            </Button>
          </div>
        </Card>
      ) : null}

      <Card title="قائمة الموظفين">
        <DataTable
          head={["الاسم", "المسمى", "المدير المباشر", "نسبة العمولة", "التارجت", "الدور"]}
          rows={team.map((p) => [
            <span className="font-bold">{p.name}</span>,
            <span className="text-muted-foreground">{p.title}</span>,
            p.manager,
            <span className="font-bold">{p.commissionRate}%</span>,
            EGP(p.target),
            <Badge tone="brand">Sales Person</Badge>,
          ])}
        />
      </Card>

      <Card title="المديرون">
        <DataTable
          head={["الاسم", "عدد الفريق", "تارجت الفريق", "الدور"]}
          rows={managers.map((m) => [
            <span className="font-bold">{m.name}</span>,
            String(m.members),
            EGP(m.target),
            <Badge tone="success">Sales Manager</Badge>,
          ])}
        />
      </Card>
    </>
  );
}
