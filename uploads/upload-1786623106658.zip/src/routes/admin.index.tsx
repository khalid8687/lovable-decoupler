import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Target, TrendingUp, Wallet, Percent, Clock, FolderKanban } from "lucide-react";
import { BarChart, Card, DataTable, PageHeader, QuarterTabs, Ring, Stat } from "@/components/kit";
import { EGP, compact, managers, pct, quarterTrend, quarters, team, totals } from "@/lib/mock";

export const Route = createFileRoute("/admin/")({
  head: () => ({
    meta: [
      { title: "لوحة الإدارة | SalesTrack" },
      { name: "description", content: "الصورة الكاملة للقسم: التارجت، المبيعات، التحصيلات والعمولات لكل موظف ومدير." },
      { property: "og:title", content: "لوحة الإدارة | SalesTrack" },
      { property: "og:description", content: "اختيار Q1 / Q2 / Q3 / Q4 / Full Year ومتابعة الأداء الكامل." },
    ],
  }),
  component: AdminDashboard,
});

function AdminDashboard() {
  const [q, setQ] = useState("Q1");
  const pending = totals.commissionEarned - totals.commissionPaid;

  return (
    <>
      <PageHeader
        title="لوحة الإدارة"
        subtitle="صورة كاملة لقسم المبيعات"
        action={<QuarterTabs value={q} onChange={setQ} options={quarters} />}
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="إجمالي Target" value={EGP(totals.target)} tone="brand" icon={<Target className="size-4" />} />
        <Stat label="إجمالي المبيعات" value={EGP(totals.sales)} hint={`${pct(totals.sales, totals.target)}% تحقيق`} icon={<TrendingUp className="size-4" />} />
        <Stat label="إجمالي التحصيلات" value={EGP(totals.collections)} tone="success" icon={<Wallet className="size-4" />} />
        <Stat label="المتبقي في التحصيل" value={EGP(totals.outstanding)} tone="warning" icon={<Clock className="size-4" />} />
        <Stat label="إجمالي قيمة المشاريع" value={EGP(totals.projectsValue)} icon={<FolderKanban className="size-4" />} />
        <Stat label="عمولات مستحقة" value={EGP(totals.commissionEarned)} icon={<Percent className="size-4" />} />
        <Stat label="عمولات مصروفة" value={EGP(totals.commissionPaid)} tone="success" icon={<Wallet className="size-4" />} />
        <Stat label="عمولات متبقية" value={EGP(pending)} tone="warning" icon={<Clock className="size-4" />} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="تحقيق التارجت للقسم">
          <div className="grid place-items-center py-3">
            <Ring value={pct(totals.sales, totals.target)} caption={`${compact(totals.sales)} من ${compact(totals.target)}`} />
          </div>
        </Card>
        <Card title="مقارنة الأرباع السنوية" className="lg:col-span-2">
          <BarChart data={quarterTrend.map((x) => ({ label: x.q, a: x.target, b: x.sales }))} />
        </Card>
      </div>

      <Card title="أداء كل Sales Person">
        <DataTable
          head={["Sales Person", "المدير", "Target", "Sales", "Achievement", "Collections", "Commission"]}
          rows={team.map((p) => [
            <span className="font-bold">{p.name}</span>,
            <span className="text-muted-foreground">{p.manager}</span>,
            compact(p.target),
            compact(p.sales),
            <span className={pct(p.sales, p.target) >= 100 ? "font-bold text-success" : "font-bold text-warning"}>
              {pct(p.sales, p.target)}%
            </span>,
            compact(p.collections),
            compact(p.commissionEarned),
          ])}
        />
      </Card>

      <Card title="أداء كل Sales Manager">
        <DataTable
          head={["Sales Manager", "عدد الفريق", "Target", "Sales", "Achievement", "Collections"]}
          rows={managers.map((m) => [
            <span className="font-bold">{m.name}</span>,
            String(m.members),
            compact(m.target),
            compact(m.sales),
            <span className="font-bold">{pct(m.sales, m.target)}%</span>,
            compact(m.collections),
          ])}
        />
      </Card>
    </>
  );
}
