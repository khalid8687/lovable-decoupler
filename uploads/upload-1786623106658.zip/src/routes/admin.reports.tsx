import { createFileRoute } from "@tanstack/react-router";
import { FileSpreadsheet, FileText } from "lucide-react";
import { BarChart, Button, Card, DataTable, PageHeader } from "@/components/kit";
import { EGP, commissions, compact, deals, managers, pct, projects, quarterTrend, team } from "@/lib/mock";

export const Route = createFileRoute("/admin/reports")({
  head: () => ({
    meta: [
      { title: "تقارير الإدارة | SalesTrack" },
      { name: "description", content: "تقارير شاملة: التارجت، المبيعات، المشاريع، التحصيلات، العمولات والبيعات المشتركة." },
      { property: "og:title", content: "تقارير الإدارة | SalesTrack" },
      { property: "og:description", content: "تصدير كل التقارير إلى Excel أو PDF." },
    ],
  }),
  component: AdminReports,
});

function AdminReports() {
  return (
    <>
      <PageHeader
        title="التقارير"
        subtitle="كل تقارير القسم مع إمكانية التصدير"
        action={
          <div className="flex gap-2">
            <Button variant="outline">
              <FileSpreadsheet className="size-4" /> Excel
            </Button>
            <Button>
              <FileText className="size-4" /> PDF
            </Button>
          </div>
        }
      />

      <Card title="مقارنة الأرباع السنوية">
        <BarChart data={quarterTrend.map((x) => ({ label: x.q, a: x.target, b: x.sales }))} />
      </Card>

      <Card title="مبيعات كل مدير وفريقه">
        <DataTable
          head={["المدير", "عدد الفريق", "Target", "Sales", "Achievement", "Collections"]}
          rows={managers.map((m) => [
            <span className="font-bold">{m.name}</span>,
            String(m.members),
            compact(m.target),
            compact(m.sales),
            <span className="font-bold">{pct(m.sales, m.target)}%</span>,
            compact(m.collections),
          ])}
        />
      </Card>

      <Card title="العمولات">
        <DataTable
          head={["كود", "الموظف", "الربع", "الأساس (المحصل)", "النسبة", "المستحق", "المصروف", "المتبقي"]}
          rows={commissions.map((c) => [
            <span className="font-bold text-primary-deep">{c.id}</span>,
            c.person,
            c.quarter,
            EGP(c.base),
            c.rate + "%",
            EGP(c.earned),
            EGP(c.paid),
            <span className="font-bold text-warning">{EGP(c.earned - c.paid)}</span>,
          ])}
        />
      </Card>

      <Card title="البيعات المشتركة">
        <DataTable
          head={["كود", "الطرف الأول", "نسبته", "الطرف الثاني", "نسبته", "القيمة"]}
          rows={deals
            .filter((d) => d.partner)
            .map((d) => [
              <span className="font-bold text-primary-deep">{d.id}</span>,
              d.seller,
              d.share + "%",
              d.partner!.name,
              d.partner!.share + "%",
              EGP(d.value),
            ])}
        />
      </Card>

      <Card title="المشاريع والمبالغ المتبقية">
        <DataTable
          head={["المشروع", "العميل", "المسؤول", "القيمة", "المحصل", "المتبقي"]}
          rows={projects.map((p) => [
            p.name,
            <span className="text-muted-foreground">{p.client}</span>,
            p.owner,
            EGP(p.value),
            EGP(p.collected),
            <span className="font-bold text-warning">{EGP(p.value - p.collected)}</span>,
          ])}
        />
      </Card>

      <Card title="مبيعات كل موظف">
        <DataTable
          head={["الموظف", "Target", "Sales", "Achievement"]}
          rows={team.map((p) => [
            <span className="font-bold">{p.name}</span>,
            compact(p.target),
            compact(p.sales),
            pct(p.sales, p.target) + "%",
          ])}
        />
      </Card>
    </>
  );
}
