import { createFileRoute } from "@tanstack/react-router";
import { Badge, Button, Card, DataTable, PageHeader } from "@/components/kit";
import { auditLog } from "@/lib/mock";

export const Route = createFileRoute("/admin/settings")({
  head: () => ({
    meta: [
      { title: "إعدادات النظام | SalesTrack" },
      { name: "description", content: "سياسة العمولات، الأرباع السنوية، الصلاحيات وسجل العمليات." },
      { property: "og:title", content: "إعدادات النظام | SalesTrack" },
      { property: "og:description", content: "ضبط سياسة العمولة والصلاحيات لكل دور." },
    ],
  }),
  component: SettingsPage,
});

const field = "w-full rounded-xl border border-input bg-card px-3 py-2.5 text-sm outline-none focus:border-primary";
const label = "mb-1.5 block text-xs font-bold text-muted-foreground";

const roles = [
  { role: "الموظف", perms: "لوحته، بيعاته، مشاريعه، تحصيلاته، عمولته" },
  { role: "مدير مجموعة", perms: "أداء فريقه، اعتماد التعاقدات، تقارير الفريق" },
  { role: "الدعم", perms: "تصحيح السجلات، الطلبات، الصلاحيات" },
  { role: "Super Admin", perms: "كل الصلاحيات، التارجت، الإعدادات، التقارير" },
];

function SettingsPage() {
  return (
    <>
      <PageHeader title="الإعدادات" subtitle="سياسة العمولات والصلاحيات وسجل العمليات" />

      <Card title="سياسة العمولة" action={<Button className="px-3 py-1.5">حفظ</Button>}>
        <div className="grid gap-4 sm:grid-cols-3">
          <div>
            <span className={label}>أساس حساب العمولة</span>
            <select className={field}>
              <option>المبالغ المحصلة</option>
              <option>قيمة التعاقد</option>
            </select>
          </div>
          <div>
            <span className={label}>النسبة الافتراضية %</span>
            <input className={field} type="number" step="0.1" defaultValue={1} />
          </div>
          <div>
            <span className={label}>حد أدنى للتحقيق قبل الصرف %</span>
            <input className={field} type="number" defaultValue={70} />
          </div>
        </div>
      </Card>

      <Card title="السنة المالية والأرباع">
        <div className="grid gap-4 sm:grid-cols-3">
          <div>
            <span className={label}>بداية السنة المالية</span>
            <input className={field} type="date" defaultValue="2026-01-01" />
          </div>
          <div>
            <span className={label}>عملة النظام</span>
            <select className={field}>
              <option>EGP</option>
              <option>USD</option>
            </select>
          </div>
          <div>
            <span className={label}>الربع الحالي</span>
            <select className={field}>
              <option>Q1</option>
              <option>Q2</option>
              <option>Q3</option>
              <option>Q4</option>
            </select>
          </div>
        </div>
      </Card>

      <Card title="الأدوار والصلاحيات">
        <DataTable
          head={["الدور", "الصلاحيات", "الحالة"]}
          rows={roles.map((r) => [
            <span className="font-bold">{r.role}</span>,
            <span className="text-muted-foreground">{r.perms}</span>,
            <Badge tone="success">مفعّل</Badge>,
          ])}
        />
      </Card>

      <Card title="سجل العمليات">
        <DataTable
          head={["الوقت", "المستخدم", "الإجراء"]}
          rows={auditLog.map((l) => [l.at, <span className="font-bold">{l.user}</span>, l.action])}
        />
      </Card>
    </>
  );
}
