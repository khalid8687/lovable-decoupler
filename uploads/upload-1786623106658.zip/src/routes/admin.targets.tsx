import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Button, Card, DataTable, PageHeader, Progress, QuarterTabs, Stat } from "@/components/kit";
import { EGP, pct, quarters, team, totals } from "@/lib/mock";
import { Target, TrendingUp } from "lucide-react";

export const Route = createFileRoute("/admin/targets")({
  head: () => ({
    meta: [
      { title: "إدارة التارجت الربع سنوي | SalesTrack" },
      { name: "description", content: "تحديد التارجت الربع سنوي لكل موظف مبيعات ومتابعة نسبة التحقيق." },
      { property: "og:title", content: "إدارة التارجت الربع سنوي | SalesTrack" },
      { property: "og:description", content: "Q1 / Q2 / Q3 / Q4 لكل موظف." },
    ],
  }),
  component: TargetsPage,
});

function TargetsPage() {
  const [q, setQ] = useState("Q1");

  return (
    <>
      <PageHeader
        title="التارجت الربع سنوي"
        subtitle="تحديد التارجت لكل موظف في بداية كل Quarter"
        action={<QuarterTabs value={q} onChange={setQ} options={quarters} />}
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <Stat label={`إجمالي تارجت ${q}`} value={EGP(totals.target)} tone="brand" icon={<Target className="size-4" />} />
        <Stat label="المحقق" value={EGP(totals.sales)} icon={<TrendingUp className="size-4" />} />
        <Stat label="المتبقي" value={EGP(Math.max(totals.target - totals.sales, 0))} tone="warning" />
      </div>

      <Card title={`تارجت الموظفين — ${q}`} action={<Button className="px-3 py-1.5">حفظ التعديلات</Button>}>
        <DataTable
          head={["الموظف", "التارجت", "المحقق", "المتبقي", "نسبة التحقيق", "تعديل التارجت"]}
          rows={team.map((p) => [
            <span className="font-bold">{p.name}</span>,
            EGP(p.target),
            EGP(p.sales),
            EGP(Math.max(p.target - p.sales, 0)),
            <div className="w-32">
              <Progress value={pct(p.sales, p.target)} />
            </div>,
            <input
              type="number"
              defaultValue={p.target}
              className="w-36 rounded-xl border border-input bg-card px-3 py-1.5 text-xs outline-none focus:border-primary"
            />,
          ])}
        />
      </Card>
    </>
  );
}
