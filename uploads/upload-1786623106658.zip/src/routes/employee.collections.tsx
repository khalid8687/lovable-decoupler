import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, X } from "lucide-react";
import { Badge, Button, Card, DataTable, PageHeader, Progress, Stat } from "@/components/kit";
import { EGP, me, payments, pct, projects } from "@/lib/mock";
import { Wallet, Clock, Percent } from "lucide-react";

export const Route = createFileRoute("/employee/collections")({
  head: () => ({
    meta: [
      { title: "التحصيلات | SalesTrack" },
      { name: "description", content: "تسجيل دفعات التحصيل لكل مشروع ومتابعة المتبقي ونسبة التحصيل." },
      { property: "og:title", content: "التحصيلات | SalesTrack" },
      { property: "og:description", content: "أكثر من دفعة لنفس المشروع حتى اكتمال التحصيل." },
    ],
  }),
  component: CollectionsPage,
});

const field = "w-full rounded-xl border border-input bg-card px-3 py-2.5 text-sm outline-none focus:border-primary";
const label = "mb-1.5 block text-xs font-bold text-muted-foreground";

function CollectionsPage() {
  const [open, setOpen] = useState(false);
  const mine = projects.filter((p) => p.owner === me.name);
  const value = mine.reduce((s, p) => s + p.value, 0);
  const collected = mine.reduce((s, p) => s + p.collected, 0);
  const mineIds = mine.map((p) => p.id);

  return (
    <>
      <PageHeader
        title="التحصيلات"
        subtitle="متابعة الدفعات المحصلة والمتبقية لكل مشروع"
        action={
          <Button onClick={() => setOpen((v) => !v)}>
            {open ? <X className="size-4" /> : <Plus className="size-4" />}
            {open ? "إغلاق" : "تسجيل دفعة"}
          </Button>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="إجمالي قيمة المشاريع" value={EGP(value)} tone="brand" icon={<Wallet className="size-4" />} />
        <Stat label="إجمالي المحصل" value={EGP(collected)} tone="success" icon={<Wallet className="size-4" />} />
        <Stat label="المبلغ المتبقي" value={EGP(value - collected)} tone="warning" icon={<Clock className="size-4" />} />
        <Stat label="نسبة التحصيل" value={pct(collected, value) + "%"} icon={<Percent className="size-4" />} />
      </div>

      {open ? (
        <Card title="تسجيل دفعة تحصيل">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <span className={label}>المشروع</span>
              <select className={field}>
                {mine.map((p) => (
                  <option key={p.id}>{p.name}</option>
                ))}
              </select>
            </div>
            <div>
              <span className={label}>المبلغ (EGP)</span>
              <input className={field} type="number" placeholder="300000" />
            </div>
            <div>
              <span className={label}>تاريخ التحصيل</span>
              <input className={field} type="date" />
            </div>
            <div>
              <span className={label}>طريقة التحصيل</span>
              <select className={field}>
                <option>تحويل بنكي</option>
                <option>شيك</option>
                <option>نقدي</option>
              </select>
            </div>
          </div>
          <div className="mt-5 flex flex-wrap gap-2">
            <Button>حفظ الدفعة</Button>
            <Button variant="outline" onClick={() => setOpen(false)}>
              إلغاء
            </Button>
          </div>
        </Card>
      ) : null}

      <div className="grid gap-4 lg:grid-cols-2">
        {mine.map((p) => (
          <Card key={p.id} title={p.name}>
            <Progress value={pct(p.collected, p.value)} label={`${EGP(p.collected)} من ${EGP(p.value)}`} />
            <p className="mt-3 text-xs font-bold text-warning">
              متبقي: {EGP(p.value - p.collected)}
            </p>
          </Card>
        ))}
      </div>

      <Card title="سجل الدفعات">
        <DataTable
          head={["إيصال", "المشروع", "المبلغ", "التاريخ", "الطريقة"]}
          rows={payments
            .filter((r) => mineIds.includes(r.projectId))
            .map((r) => [
              <span className="font-bold text-primary-deep">{r.id}</span>,
              r.project,
              <span className="font-bold">{EGP(r.amount)}</span>,
              r.date,
              <Badge tone="muted">{r.method}</Badge>,
            ])}
        />
      </Card>
    </>
  );
}
