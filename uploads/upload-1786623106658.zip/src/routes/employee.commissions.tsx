import { createFileRoute } from "@tanstack/react-router";
import { Card, DataTable, PageHeader, Progress, Stat } from "@/components/kit";
import { EGP, deals, me, pct } from "@/lib/mock";
import { Percent, Wallet, Clock } from "lucide-react";

export const Route = createFileRoute("/employee/commissions")({
  head: () => ({
    meta: [
      { title: "عمولاتي | SalesTrack" },
      { name: "description", content: "نسبة العمولة، العمولة المستحقة، المصروفة والمتبقية مع البيعات المشتركة." },
      { property: "og:title", content: "عمولاتي | SalesTrack" },
      { property: "og:description", content: "حساب العمولة على المبالغ المحصلة وفق سياسة الشركة." },
    ],
  }),
  component: CommissionsPage,
});

function CommissionsPage() {
  const pending = me.commissionEarned - me.commissionPaid;

  return (
    <>
      <PageHeader title="العمولات" subtitle={`نسبة العمولة المسجلة: ${me.commissionRate}% من المبالغ المحصلة`} />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="نسبة العمولة" value={me.commissionRate + "%"} tone="brand" icon={<Percent className="size-4" />} />
        <Stat label="Commission Earned" value={EGP(me.commissionEarned)} icon={<Wallet className="size-4" />} />
        <Stat label="Commission Paid" value={EGP(me.commissionPaid)} tone="success" icon={<Wallet className="size-4" />} />
        <Stat label="Pending Commission" value={EGP(pending)} tone="warning" icon={<Clock className="size-4" />} />
      </div>

      <Card title="حالة الصرف">
        <Progress value={pct(me.commissionPaid, me.commissionEarned)} label="نسبة العمولة المصروفة" />
        <p className="mt-3 text-xs text-muted-foreground">
          يتم حساب العمولة على أساس المبالغ المحصلة ({EGP(me.collections)}) وفق سياسة الشركة.
        </p>
      </Card>

      <Card title="تفصيل العمولة على البيعات">
        <DataTable
          head={["كود", "العميل", "قيمة البيعة", "نصيبي %", "الأساس", "العمولة"]}
          rows={deals
            .filter((d) => d.seller === me.name || d.partner?.name === me.name)
            .map((d) => {
              const share = d.seller === me.name ? d.share : (d.partner?.share ?? 0);
              const base = (d.value * share) / 100;
              return [
                <span className="font-bold text-primary-deep">{d.id}</span>,
                d.client,
                EGP(d.value),
                <span className="font-bold">{share}%</span>,
                EGP(base),
                <span className="font-bold text-success">{EGP((base * me.commissionRate) / 100)}</span>,
              ];
            })}
        />
      </Card>
    </>
  );
}
