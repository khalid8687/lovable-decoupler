import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Target, TrendingUp, Wallet, Percent, FolderKanban, Clock } from "lucide-react";
import {
  Badge,
  BarChart,
  Card,
  DataTable,
  PageHeader,
  Progress,
  QuarterTabs,
  Ring,
  Stat,
} from "@/components/kit";
import { EGP, compact, deals, me, pct, projects, quarterTrend, quarters } from "@/lib/mock";

export const Route = createFileRoute("/employee/")({
  head: () => ({
    meta: [
      { title: "لوحة الموظف | SalesTrack" },
      { name: "description", content: "تارجتك الربع سنوي، مبيعاتك، تحصيلاتك وعمولاتك في شاشة واحدة." },
      { property: "og:title", content: "لوحة الموظف | SalesTrack" },
      { property: "og:description", content: "متابعة التارجت والمبيعات والتحصيلات والعمولات." },
    ],
  }),
  component: EmployeeDashboard,
});

function EmployeeDashboard() {
  const [q, setQ] = useState("Q1");
  const remaining = Math.max(me.target - me.sales, 0);
  const myProjects = projects.filter((p) => p.owner === me.name);
  const outstanding = myProjects.reduce((s, p) => s + (p.value - p.collected), 0);

  return (
    <>
      <PageHeader
        title={`أهلاً، ${me.name}`}
        subtitle={`${me.title} — المدير المباشر: ${me.manager}`}
        action={<QuarterTabs value={q} onChange={setQ} options={quarters} />}
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Quarterly Target" value={EGP(me.target)} tone="brand" icon={<Target className="size-4" />} />
        <Stat label="Total Sales" value={EGP(me.sales)} hint={`${pct(me.sales, me.target)}% من التارجت`} icon={<TrendingUp className="size-4" />} />
        <Stat label="Remaining to Target" value={EGP(remaining)} tone="warning" hint="المتبقي لتحقيق التارجت" icon={<Clock className="size-4" />} />
        <Stat label="Total Projects" value={String(myProjects.length)} hint={EGP(me.projectsValue)} icon={<FolderKanban className="size-4" />} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="نسبة تحقيق التارجت" className="lg:col-span-1">
          <div className="flex flex-col items-center gap-5 py-2">
            <Ring value={pct(me.sales, me.target)} caption={`${compact(me.sales)} من ${compact(me.target)}`} />
            <div className="w-full space-y-3">
              <Progress value={pct(me.collections, me.projectsValue)} label="نسبة التحصيل" />
              <Progress value={pct(me.commissionPaid, me.commissionEarned)} label="العمولة المصروفة" />
            </div>
          </div>
        </Card>

        <Card title="Target vs Achievement (بالأرباع)" className="lg:col-span-2">
          <BarChart data={quarterTrend.map((t) => ({ label: t.q, a: t.target, b: t.sales }))} />
        </Card>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <Stat label="Total Collections" value={EGP(me.collections)} tone="success" icon={<Wallet className="size-4" />} />
        <Stat label="Outstanding Collections" value={EGP(outstanding)} tone="warning" icon={<Clock className="size-4" />} />
        <Stat label="Commission Earned" value={EGP(me.commissionEarned)} hint={`نسبة العمولة ${me.commissionRate}%`} icon={<Percent className="size-4" />} />
      </div>

      <Card title="أحدث البيعات">
        <DataTable
          head={["كود", "العميل", "المشروع", "القيمة", "نصيبي", "الحالة"]}
          rows={deals
            .filter((d) => d.seller === me.name || d.partner?.name === me.name)
            .map((d) => [
              <span className="font-bold text-primary-deep">{d.id}</span>,
              d.client,
              <span className="text-muted-foreground">{d.project}</span>,
              EGP(d.value),
              <span className="font-bold">{d.seller === me.name ? d.share : d.partner?.share}%</span>,
              <Badge tone={d.status === "مكتمل التحصيل" ? "success" : d.status === "موقّع" ? "brand" : "warning"}>
                {d.status}
              </Badge>,
            ])}
        />
      </Card>
    </>
  );
}
