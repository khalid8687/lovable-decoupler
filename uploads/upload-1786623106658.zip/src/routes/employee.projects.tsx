import { createFileRoute } from "@tanstack/react-router";
import { Card, DataTable, PageHeader, Progress, Stat } from "@/components/kit";
import { EGP, me, pct, projects } from "@/lib/mock";
import { FolderKanban, Wallet, Clock } from "lucide-react";

export const Route = createFileRoute("/employee/projects")({
  head: () => ({
    meta: [
      { title: "مشاريعي | SalesTrack" },
      { name: "description", content: "كل المشاريع المرتبطة ببيعاتك مع قيمتها ونسبة تحصيلها." },
      { property: "og:title", content: "مشاريعي | SalesTrack" },
      { property: "og:description", content: "قيمة المشروع، المحصل، المتبقي ونسبة التحصيل." },
    ],
  }),
  component: ProjectsPage,
});

function ProjectsPage() {
  const mine = projects.filter((p) => p.owner === me.name);
  const value = mine.reduce((s, p) => s + p.value, 0);
  const collected = mine.reduce((s, p) => s + p.collected, 0);

  return (
    <>
      <PageHeader title="المشاريع" subtitle="كل بيعة مرتبطة بمشروعها الخاص" />

      <div className="grid gap-4 sm:grid-cols-3">
        <Stat label="عدد المشاريع" value={String(mine.length)} tone="brand" icon={<FolderKanban className="size-4" />} />
        <Stat label="إجمالي قيمة المشاريع" value={EGP(value)} icon={<Wallet className="size-4" />} />
        <Stat label="المتبقي في التحصيل" value={EGP(value - collected)} tone="warning" icon={<Clock className="size-4" />} />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {mine.map((p) => (
          <Card key={p.id} title={p.name}>
            <p className="text-xs font-semibold text-muted-foreground">
              {p.client} — تاريخ التعاقد {p.signedAt}
            </p>
            <div className="mt-4 grid grid-cols-3 gap-3 text-center">
              {[
                ["قيمة المشروع", EGP(p.value)],
                ["المحصل", EGP(p.collected)],
                ["المتبقي", EGP(p.value - p.collected)],
              ].map(([k, v]) => (
                <div key={k} className="rounded-xl bg-muted/60 p-2.5">
                  <p className="text-[10px] font-bold text-muted-foreground">{k}</p>
                  <p className="mt-1 text-xs font-extrabold">{v}</p>
                </div>
              ))}
            </div>
            <div className="mt-4">
              <Progress value={pct(p.collected, p.value)} label="نسبة التحصيل" />
            </div>
          </Card>
        ))}
      </div>

      <Card title="كل مشاريع القسم">
        <DataTable
          head={["كود", "المشروع", "العميل", "المسؤول", "القيمة", "المحصل", "نسبة التحصيل"]}
          rows={projects.map((p) => [
            <span className="font-bold text-primary-deep">{p.id}</span>,
            p.name,
            <span className="text-muted-foreground">{p.client}</span>,
            p.owner,
            EGP(p.value),
            EGP(p.collected),
            <span className="font-bold">{pct(p.collected, p.value)}%</span>,
          ])}
        />
      </Card>
    </>
  );
}
