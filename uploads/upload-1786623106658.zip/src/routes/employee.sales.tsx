import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, Users, X } from "lucide-react";
import { Badge, Button, Card, DataTable, PageHeader } from "@/components/kit";
import { EGP, deals, me } from "@/lib/mock";

export const Route = createFileRoute("/employee/sales")({
  head: () => ({
    meta: [
      { title: "تسجيل ومتابعة البيعات | SalesTrack" },
      { name: "description", content: "سجّل بيعة جديدة: العميل، المشروع، قيمته، المشارك ونسبة المشاركة." },
      { property: "og:title", content: "تسجيل ومتابعة البيعات | SalesTrack" },
      { property: "og:description", content: "تسجيل التعاقدات والبيعات المشتركة ونسب التوزيع." },
    ],
  }),
  component: SalesPage,
});

const field = "w-full rounded-xl border border-input bg-card px-3 py-2.5 text-sm outline-none focus:border-primary";
const label = "mb-1.5 block text-xs font-bold text-muted-foreground";

function SalesPage() {
  const [shared, setShared] = useState(false);
  const [share, setShare] = useState(70);
  const [open, setOpen] = useState(false);

  return (
    <>
      <PageHeader
        title="البيعات والتعاقدات"
        subtitle="كل بيعة مرتبطة بمشروع وقيمة وتاريخ تعاقد"
        action={
          <Button onClick={() => setOpen((v) => !v)}>
            {open ? <X className="size-4" /> : <Plus className="size-4" />}
            {open ? "إغلاق" : "بيعة جديدة"}
          </Button>
        }
      />

      {open ? (
        <Card title="تسجيل بيعة جديدة">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <span className={label}>اسم العميل</span>
              <input className={field} placeholder="مثال: مجموعة النيل العقارية" />
            </div>
            <div>
              <span className={label}>اسم المشروع / الخدمة</span>
              <input className={field} placeholder="مثال: هوية بصرية + حملة إطلاق" />
            </div>
            <div>
              <span className={label}>قيمة المشروع (EGP)</span>
              <input className={field} type="number" placeholder="1000000" />
            </div>
            <div>
              <span className={label}>تاريخ التعاقد</span>
              <input className={field} type="date" />
            </div>
            <div>
              <span className={label}>الشخص الذي قام بالبيع</span>
              <input className={field} defaultValue={me.name} readOnly />
            </div>
            <div>
              <span className={label}>المدير المباشر (تلقائي)</span>
              <input className={field + " bg-muted"} defaultValue={me.manager} readOnly />
            </div>
          </div>

          <div className="mt-5 rounded-xl border border-border bg-muted/40 p-4">
            <label className="flex cursor-pointer items-center gap-3 text-sm font-bold">
              <input
                type="checkbox"
                checked={shared}
                onChange={(e) => setShared(e.target.checked)}
                className="size-4 accent-[var(--primary)]"
              />
              <Users className="size-4 text-primary" />
              هل يوجد شخص آخر مشارك في البيعة؟
            </label>

            {shared ? (
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <div>
                  <span className={label}>اسم المشارك</span>
                  <select className={field}>
                    <option>عمر فؤاد</option>
                    <option>منة عادل</option>
                    <option>يوسف طارق</option>
                  </select>
                </div>
                <div>
                  <span className={label}>
                    نسبتي {share}% / المشارك {100 - share}%
                  </span>
                  <input
                    type="range"
                    min={10}
                    max={90}
                    step={5}
                    value={share}
                    onChange={(e) => setShare(Number(e.target.value))}
                    className="w-full accent-[var(--primary)]"
                  />
                </div>
              </div>
            ) : null}
          </div>

          <div className="mt-5 flex flex-wrap gap-2">
            <Button>حفظ البيعة</Button>
            <Button variant="outline" onClick={() => setOpen(false)}>
              إلغاء
            </Button>
          </div>
        </Card>
      ) : null}

      <Card title="سجل البيعات">
        <DataTable
          head={["كود", "العميل", "المشروع", "القيمة", "التاريخ", "المشارك", "النسبة", "الحالة"]}
          rows={deals.map((d) => [
            <span className="font-bold text-primary-deep">{d.id}</span>,
            d.client,
            <span className="text-muted-foreground">{d.project}</span>,
            EGP(d.value),
            d.date,
            d.partner ? `${d.partner.name} (${d.partner.share}%)` : <span className="text-muted-foreground">—</span>,
            <span className="font-bold">{d.share}%</span>,
            <Badge tone={d.status === "مكتمل التحصيل" ? "success" : d.status === "موقّع" ? "brand" : "warning"}>
              {d.status}
            </Badge>,
          ])}
        />
      </Card>
    </>
  );
}
