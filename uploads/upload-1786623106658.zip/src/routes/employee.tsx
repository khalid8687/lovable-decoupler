import { createFileRoute, Outlet } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";

export const Route = createFileRoute("/employee")({
  component: () => (
    <AppShell role="employee">
      <Outlet />
    </AppShell>
  ),
});
