import { createFileRoute, Link } from "@tanstack/react-router";
import { User, Users, LifeBuoy, ShieldCheck, ArrowLeft, Target, Wallet, Percent } from "lucide-react";
import logo from "@/assets/logo.png";
import hero from "@/assets/hero-sales.png";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SalesTrack — اختيار الدور | نظام إدارة ومتابعة المبيعات" },
      {
        name: "description",
        content:
          "ابدأ من بوابتك: الموظف، مدير المجموعة، الدعم، أو Super Admin — لمتابعة التارجت والمبيعات والتحصيلات والعمولات.",
      },
      { property: "og:title", content: "SalesTrack — نظام إدارة ومتابعة المبيعات" },
      {
        property: "og:description",
        content: "التارجت الربع سنوي ← التعاقدات ← المشاريع ← التحصيلات ← العمولات.",
      },
    ],
  }),
  component: RoleSelect,
});

const roles = [
  {
    to: "/employee",
    icon: User,
    title: "الموظف",
    en: "Sales Person",
    desc: "التارجت الخاص بك، بيعاتك، مشاريعك، تحصيلاتك وعمولتك.",
  },
  {
    to: "/manager",
    icon: Users,
    title: "مدير مجموعة",
    en: "Sales Manager",
    desc: "أداء فريقك ومقارنة التارجت والتحصيلات لكل موظف.",
  },
  {
    to: "/support",
    icon: LifeBuoy,
    title: "الدعم",
    en: "Support",
    desc: "طلبات التعديل، تصحيح التحصيلات، ومتابعة السجلات.",
  },
  {
    to: "/admin",
    icon: ShieldCheck,
    title: "Super Admin",
    en: "Administration",
    desc: "الصورة الكاملة للقسم، التارجت، الصلاحيات والتقارير.",
  },
] as const;

function RoleSelect() {
  return (
    <div className="min-h-screen bg-background">
      <div className="brand-gradient px-4 pt-10 pb-24 text-primary-foreground sm:px-6 sm:pt-14">
        <div className="mx-auto grid max-w-6xl items-center gap-8 lg:grid-cols-[minmax(0,1fr)_auto]">
          <div className="min-w-0">
            <div className="flex items-center gap-3">
              <img
                src={logo}
                alt="شعار SalesTrack"
                width={52}
                height={52}
                className="size-13 shrink-0 rounded-2xl bg-white/90 p-1"
              />
              <div className="min-w-0">
                <p className="text-lg font-extrabold sm:text-xl">SalesTrack</p>
                <p className="text-[11px] font-semibold opacity-85">إدارة ومتابعة المبيعات</p>
              </div>
            </div>
            <h1 className="mt-6 text-2xl leading-snug font-extrabold sm:text-4xl">
              متابعة كاملة من التارجت حتى العمولة
            </h1>
            <p className="mt-3 max-w-xl text-sm opacity-90 sm:text-base">
              التارجت الربع سنوي ← التعاقدات ← المشاريع ← التحصيلات ← العمولات. اختر بوابتك للبدء.
            </p>
            <div className="mt-6 flex flex-wrap gap-2 text-[11px] font-bold">
              {[
                { icon: Target, t: "Quarterly Target" },
                { icon: Wallet, t: "Collections" },
                { icon: Percent, t: "Commissions" },
              ].map((c) => (
                <span
                  key={c.t}
                  className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-3 py-1.5"
                >
                  <c.icon className="size-3.5" />
                  {c.t}
                </span>
              ))}
            </div>
          </div>
          <img
            src={hero}
            alt="فريق مبيعات يتابع لوحة الأداء"
            width={420}
            height={420}
            className="mx-auto hidden w-[340px] max-w-full lg:block"
          />
        </div>
      </div>

      <div className="mx-auto -mt-16 max-w-6xl px-4 pb-14 sm:px-6">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {roles.map((r) => (
            <Link
              key={r.to}
              to={r.to}
              className="card-surface group flex flex-col gap-3 p-5 transition-all hover:-translate-y-1 hover:shadow-[var(--shadow-float)]"
            >
              <span className="brand-gradient-soft grid size-12 place-items-center rounded-2xl text-primary-deep">
                <r.icon className="size-6" />
              </span>
              <div>
                <h2 className="text-base font-extrabold">{r.title}</h2>
                <p className="text-[11px] font-bold text-primary">{r.en}</p>
              </div>
              <p className="text-xs leading-relaxed text-muted-foreground">{r.desc}</p>
              <span className="mt-auto inline-flex items-center gap-1.5 pt-2 text-xs font-bold text-primary-deep">
                دخول
                <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-1" />
              </span>
            </Link>
          ))}
        </div>
        <p className="mt-8 text-center text-[11px] text-muted-foreground">
          عرض تجريبي ببيانات نموذجية — Targets + Sales + Projects + Collections + Commissions
        </p>
      </div>
    </div>
  );
}
