import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Target, TrendingUp, Wallet, Percent } from "lucide-react";
import { BarChart, Card, DataTable, PageHeader, Progress, QuarterTabs, Stat } from "@/components/kit";
import { EGP, compact, pct, quarterTrend, quarters, team } from "@/lib/mock";

export const Route = createFileRoute("/manager/")({
  head: () => ({
    meta: [
      { title: "لوحة مدير المجموعة | SalesTrack" },
      { name: "description", content: "أداء الأشخاص التابعين لك: التارجت، المبيعات، التحصيلات والعمولات." },
      { property: "og:title", content: "لوحة مدير المجموعة | SalesTrack" },
      { property: "og:description", content: "مقارنة أداء الفريق خلال الربع السنوي." },
    ],
  }),
  component: ManagerDashboard,
});

function ManagerDashboard() {
  const [q, setQ] = useState("Q1");
  const mine = team.filter((p) => p.manager === "خالد منصور");
  const t = mine.reduce((s, p) => s + p.target, 0);
  const s = mine.reduce((a, p) => a + p.sales, 0);
  const c = mine.reduce((a, p) => a + p.collections, 0);
  const cm = mine.reduce((a, p) => a + p.commissionEarned, 0);

  return (
    <>
      <PageHeader
        title="أداء الفريق"
        subtitle={`${mine.length} موظفين تابعين لك`}
        action={<QuarterTabs value={q} onChange={setQ} options={quarters} />}
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="إجمالي التارجت" value={EGP(t)} tone="brand" icon={<Target className="size-4" />} />
        <Stat label="إجمالي المبيعات" value={EGP(s)} hint={`${pct(s, t)}% تحقيق`} icon={<TrendingUp className="size-4" />} />
        <Stat label="إجمالي التحصيلات" value={EGP(c)} tone="success" icon={<Wallet className="size-4" />} />
        <Stat label="عمولات الفريق" value={EGP(cm)} icon={<Percent className="size-4" />} />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Target vs Achievement">
          <BarChart data={quarterTrend.map((x) => ({ label: x.q, a: x.target, b: x.sales }))} />
        </Card>
        <Card title="تحقيق التارجت لكل موظف">
          <div className="space-y-4">
            {mine.map((p) => (
              <div key={p.id}>
                <div className="mb-1 flex items-center justify-between text-xs font-bold">
                  <span className="truncate">{p.name}</span>
                  <span className="text-muted-foreground">
                    {compact(p.sales)} / {compact(p.target)}
                  </span>
                </div>
                <Progress value={pct(p.sales, p.target)} />
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card title="مقارنة أداء الفريق">
        <DataTable
          head={["Sales Person", "Target", "Sales", "Achievement", "Collections", "Commission"]}
          rows={mine.map((p) => [
            <span className="font-bold">{p.name}</span>,
            compact(p.target),
            compact(p.sales),
            <span className={pct(p.sales, p.target) >= 100 ? "font-bold text-success" : "font-bold text-warning"}>
              {pct(p.sales, p.target)}%
            </span>,
            compact(p.collections),
            compact(p.commissionEarned),
          ])}
        />
      </Card>
    </>
  );
}
