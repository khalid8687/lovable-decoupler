import { createFileRoute } from "@tanstack/react-router";
import { FileSpreadsheet, FileText } from "lucide-react";
import { BarChart, Button, Card, DataTable, PageHeader } from "@/components/kit";
import { EGP, compact, pct, projects, quarterTrend, team } from "@/lib/mock";

export const Route = createFileRoute("/manager/reports")({
  head: () => ({
    meta: [
      { title: "تقارير الفريق | SalesTrack" },
      { name: "description", content: "تقارير Target vs Achievement والمشاريع والتحصيلات والعمولات مع تصدير Excel و PDF." },
      { property: "og:title", content: "تقارير الفريق | SalesTrack" },
      { property: "og:description", content: "مقارنة الأرباع السنوية وتقارير الأداء." },
    ],
  }),
  component: ManagerReports,
});

const reportList = [
  "Target vs Achievement",
  "مبيعات كل موظف",
  "المشاريع",
  "التحصيلات",
  "المبالغ المتبقية",
  "العمولات",
  "البيعات المشتركة",
  "مقارنة الأرباع السنوية",
];

function ManagerReports() {
  const mine = team.filter((p) => p.manager === "خالد منصور");

  return (
    <>
      <PageHeader
        title="التقارير"
        subtitle="استخراج التقارير وتصديرها"
        action={
          <div className="flex gap-2">
            <Button variant="outline">
              <FileSpreadsheet className="size-4" /> Excel
            </Button>
            <Button>
              <FileText className="size-4" /> PDF
            </Button>
          </div>
        }
      />

      <Card title="التقارير المتاحة">
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {reportList.map((r) => (
            <button
              key={r}
              className="rounded-xl border border-border bg-card p-3 text-start text-xs font-bold transition-all hover:border-primary hover:bg-accent/40"
            >
              {r}
            </button>
          ))}
        </div>
      </Card>

      <Card title="مقارنة الأرباع السنوية">
        <BarChart data={quarterTrend.map((x) => ({ label: x.q, a: x.target, b: x.sales }))} />
      </Card>

      <Card title="Target vs Achievement — لكل موظف">
        <DataTable
          head={["الموظف", "Target", "Sales", "الفرق", "Achievement"]}
          rows={mine.map((p) => [
            <span className="font-bold">{p.name}</span>,
            compact(p.target),
            compact(p.sales),
            <span className={p.sales >= p.target ? "font-bold text-success" : "font-bold text-destructive"}>
              {compact(p.sales - p.target)}
            </span>,
            pct(p.sales, p.target) + "%",
          ])}
        />
      </Card>

      <Card title="تقرير المشاريع والتحصيلات">
        <DataTable
          head={["المشروع", "المسؤول", "القيمة", "المحصل", "المتبقي"]}
          rows={projects.map((p) => [
            p.name,
            p.owner,
            EGP(p.value),
            EGP(p.collected),
            <span className="font-bold text-warning">{EGP(p.value - p.collected)}</span>,
          ])}
        />
      </Card>
    </>
  );
}
