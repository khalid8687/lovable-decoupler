import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Badge, Button, Card, DataTable, PageHeader, QuarterTabs } from "@/components/kit";
import { EGP, deals, quarters } from "@/lib/mock";

export const Route = createFileRoute("/manager/sales")({
  head: () => ({
    meta: [
      { title: "تعاقدات الفريق | SalesTrack" },
      { name: "description", content: "مراجعة واعتماد تعاقدات الفريق مع نسب البيعات المشتركة." },
      { property: "og:title", content: "تعاقدات الفريق | SalesTrack" },
      { property: "og:description", content: "كل التعاقدات مع المشاركين ونسب التوزيع." },
    ],
  }),
  component: ManagerSales,
});

function ManagerSales() {
  const [q, setQ] = useState("Q1");
  const mine = deals.filter((d) => d.manager === "خالد منصور");

  return (
    <>
      <PageHeader
        title="تعاقدات الفريق"
        subtitle="مراجعة واعتماد البيعات المسجلة"
        action={<QuarterTabs value={q} onChange={setQ} options={quarters} />}
      />

      <Card title="بانتظار الاعتماد">
        <DataTable
          head={["كود", "الموظف", "العميل", "القيمة", "المشارك", "الحالة", "إجراء"]}
          rows={mine.map((d) => [
            <span className="font-bold text-primary-deep">{d.id}</span>,
            d.seller,
            d.client,
            EGP(d.value),
            d.partner ? `${d.partner.name} (${d.partner.share}%)` : <span className="text-muted-foreground">—</span>,
            <Badge tone={d.status === "قيد التوقيع" ? "warning" : "success"}>{d.status}</Badge>,
            <div className="flex gap-2">
              <Button className="px-3 py-1.5">اعتماد</Button>
              <Button variant="ghost" className="px-3 py-1.5">
                رفض
              </Button>
            </div>,
          ])}
        />
      </Card>

      <Card title="البيعات المشتركة">
        <DataTable
          head={["كود", "الطرف الأول", "نسبته", "الطرف الثاني", "نسبته", "قيمة البيعة"]}
          rows={mine
            .filter((d) => d.partner)
            .map((d) => [
              <span className="font-bold text-primary-deep">{d.id}</span>,
              d.seller,
              <span className="font-bold">{d.share}%</span>,
              d.partner!.name,
              <span className="font-bold">{d.partner!.share}%</span>,
              EGP(d.value),
            ])}
        />
      </Card>
    </>
  );
}
