import { createFileRoute } from "@tanstack/react-router";
import { Badge, Card, PageHeader, Progress, Button } from "@/components/kit";
import { EGP, pct, team } from "@/lib/mock";

export const Route = createFileRoute("/manager/team")({
  head: () => ({
    meta: [
      { title: "فريقي | SalesTrack" },
      { name: "description", content: "ملف كل موظف في فريقك: التارجت، المبيعات، التحصيلات والعمولة." },
      { property: "og:title", content: "فريقي | SalesTrack" },
      { property: "og:description", content: "متابعة تفصيلية لأداء كل موظف مبيعات." },
    ],
  }),
  component: TeamPage,
});

function TeamPage() {
  const mine = team.filter((p) => p.manager === "خالد منصور");

  return (
    <>
      <PageHeader title="الفريق" subtitle="الهيكل الإداري المسجل في النظام" />

      <div className="grid gap-4 lg:grid-cols-2">
        {mine.map((p) => {
          const a = pct(p.sales, p.target);
          return (
            <Card key={p.id}>
              <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
                <div className="flex min-w-0 items-center gap-3">
                  <span className="brand-gradient grid size-11 shrink-0 place-items-center rounded-2xl text-sm font-extrabold text-primary-foreground">
                    {p.name.slice(0, 1)}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-extrabold">{p.name}</p>
                    <p className="truncate text-[11px] text-muted-foreground">{p.title}</p>
                  </div>
                </div>
                <Badge tone={a >= 100 ? "success" : a >= 70 ? "brand" : "warning"}>{a}% تحقيق</Badge>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-3">
                {[
                  ["Target", EGP(p.target)],
                  ["Sales", EGP(p.sales)],
                  ["Collections", EGP(p.collections)],
                  ["Commission", EGP(p.commissionEarned)],
                ].map(([k, v]) => (
                  <div key={k} className="rounded-xl bg-muted/60 p-2.5">
                    <p className="text-[10px] font-bold text-muted-foreground">{k}</p>
                    <p className="mt-0.5 text-xs font-extrabold">{v}</p>
                  </div>
                ))}
              </div>

              <div className="mt-4">
                <Progress value={a} label="نسبة تحقيق التارجت" />
              </div>
              <div className="mt-4 flex gap-2">
                <Button variant="outline" className="flex-1">
                  تفاصيل الأداء
                </Button>
                <Button variant="ghost">تعديل التارجت</Button>
              </div>
            </Card>
          );
        })}
      </div>
    </>
  );
}
