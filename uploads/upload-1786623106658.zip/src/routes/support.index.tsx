import { createFileRoute, Link } from "@tanstack/react-router";
import { Ticket as TicketIcon, AlertTriangle, CheckCircle2, Clock } from "lucide-react";
import { Badge, Card, DataTable, PageHeader, Stat } from "@/components/kit";
import { auditLog, tickets } from "@/lib/mock";

export const Route = createFileRoute("/support/")({
  head: () => ({
    meta: [
      { title: "لوحة الدعم | SalesTrack" },
      { name: "description", content: "متابعة طلبات التعديل وتصحيح التحصيلات وصلاحيات المستخدمين." },
      { property: "og:title", content: "لوحة الدعم | SalesTrack" },
      { property: "og:description", content: "طلبات الدعم وسجل العمليات داخل النظام." },
    ],
  }),
  component: SupportDashboard,
});

function SupportDashboard() {
  const open = tickets.filter((t) => t.status === "مفتوحة").length;
  const progress = tickets.filter((t) => t.status === "قيد المعالجة").length;
  const closed = tickets.filter((t) => t.status === "مغلقة").length;
  const high = tickets.filter((t) => t.priority === "عالية").length;

  return (
    <>
      <PageHeader title="لوحة الدعم" subtitle="طلبات الموظفين والمديرين المتعلقة بالبيانات والصلاحيات" />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="طلبات مفتوحة" value={String(open)} tone="brand" icon={<TicketIcon className="size-4" />} />
        <Stat label="قيد المعالجة" value={String(progress)} tone="warning" icon={<Clock className="size-4" />} />
        <Stat label="مغلقة" value={String(closed)} tone="success" icon={<CheckCircle2 className="size-4" />} />
        <Stat label="أولوية عالية" value={String(high)} icon={<AlertTriangle className="size-4" />} />
      </div>

      <Card
        title="أحدث الطلبات"
        action={
          <Link to="/support/tickets" className="text-xs font-bold text-primary-deep">
            عرض الكل
          </Link>
        }
      >
        <DataTable
          head={["كود", "الطلب", "مقدم الطلب", "النوع", "الأولوية", "الحالة"]}
          rows={tickets.slice(0, 4).map((t) => [
            <span className="font-bold text-primary-deep">{t.id}</span>,
            t.title,
            t.requester,
            <Badge tone="muted">{t.type}</Badge>,
            <Badge tone={t.priority === "عالية" ? "danger" : t.priority === "متوسطة" ? "warning" : "muted"}>
              {t.priority}
            </Badge>,
            <Badge tone={t.status === "مغلقة" ? "success" : t.status === "مفتوحة" ? "brand" : "warning"}>
              {t.status}
            </Badge>,
          ])}
        />
      </Card>

      <Card title="سجل العمليات">
        <ul className="space-y-3">
          {auditLog.map((l) => (
            <li key={l.id} className="flex items-start gap-3 text-xs">
              <span className="brand-gradient mt-1.5 size-2 shrink-0 rounded-full" />
              <div className="min-w-0">
                <p className="font-bold">{l.action}</p>
                <p className="text-muted-foreground">
                  {l.user} — {l.at}
                </p>
              </div>
            </li>
          ))}
        </ul>
      </Card>
    </>
  );
}
