import { createFileRoute } from "@tanstack/react-router";
import { Badge, Button, Card, DataTable, PageHeader } from "@/components/kit";
import { EGP, deals, payments } from "@/lib/mock";

export const Route = createFileRoute("/support/records")({
  head: () => ({
    meta: [
      { title: "سجلات النظام | SalesTrack" },
      { name: "description", content: "مراجعة وتصحيح التعاقدات ودفعات التحصيل المسجلة في النظام." },
      { property: "og:title", content: "سجلات النظام | SalesTrack" },
      { property: "og:description", content: "تصحيح البيانات ومنع التسجيل المزدوج." },
    ],
  }),
  component: RecordsPage,
});

function RecordsPage() {
  return (
    <>
      <PageHeader title="السجلات" subtitle="تصحيح بيانات التعاقدات والتحصيلات" />

      <Card title="دفعات التحصيل">
        <DataTable
          head={["إيصال", "المشروع", "المبلغ", "التاريخ", "الطريقة", "إجراء"]}
          rows={payments.map((r) => [
            <span className="font-bold text-primary-deep">{r.id}</span>,
            r.project,
            <span className="font-bold">{EGP(r.amount)}</span>,
            r.date,
            <Badge tone="muted">{r.method}</Badge>,
            <div className="flex gap-2">
              <Button variant="outline" className="px-3 py-1.5">
                تعديل
              </Button>
              <Button variant="ghost" className="px-3 py-1.5">
                حذف
              </Button>
            </div>,
          ])}
        />
      </Card>

      <Card title="التعاقدات">
        <DataTable
          head={["كود", "العميل", "الموظف", "المدير", "القيمة", "الحالة", "إجراء"]}
          rows={deals.map((d) => [
            <span className="font-bold text-primary-deep">{d.id}</span>,
            d.client,
            d.seller,
            d.manager,
            EGP(d.value),
            <Badge tone={d.status === "مكتمل التحصيل" ? "success" : d.status === "موقّع" ? "brand" : "warning"}>
              {d.status}
            </Badge>,
            <Button variant="outline" className="px-3 py-1.5">
              مراجعة
            </Button>,
          ])}
        />
      </Card>
    </>
  );
}
