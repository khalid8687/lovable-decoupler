import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Badge, Button, Card, DataTable, PageHeader, QuarterTabs } from "@/components/kit";
import { tickets } from "@/lib/mock";

export const Route = createFileRoute("/support/tickets")({
  head: () => ({
    meta: [
      { title: "طلبات الدعم | SalesTrack" },
      { name: "description", content: "إدارة طلبات تعديل التعاقدات وتصحيح التحصيلات وطلبات الصلاحيات." },
      { property: "og:title", content: "طلبات الدعم | SalesTrack" },
      { property: "og:description", content: "فرز الطلبات حسب الحالة والأولوية." },
    ],
  }),
  component: TicketsPage,
});

const filters = ["الكل", "مفتوحة", "قيد المعالجة", "مغلقة"] as const;

function TicketsPage() {
  const [f, setF] = useState<string>("الكل");
  const rows = tickets.filter((t) => f === "الكل" || t.status === f);

  return (
    <>
      <PageHeader
        title="الطلبات"
        subtitle="كل الطلبات الواردة من الموظفين والمديرين"
        action={<QuarterTabs value={f} onChange={setF} options={filters} />}
      />

      <Card title={`الطلبات (${rows.length})`}>
        <DataTable
          head={["كود", "الطلب", "مقدم الطلب", "النوع", "الأولوية", "التاريخ", "الحالة", "إجراء"]}
          rows={rows.map((t) => [
            <span className="font-bold text-primary-deep">{t.id}</span>,
            t.title,
            t.requester,
            <Badge tone="muted">{t.type}</Badge>,
            <Badge tone={t.priority === "عالية" ? "danger" : t.priority === "متوسطة" ? "warning" : "muted"}>
              {t.priority}
            </Badge>,
            t.createdAt,
            <Badge tone={t.status === "مغلقة" ? "success" : t.status === "مفتوحة" ? "brand" : "warning"}>
              {t.status}
            </Badge>,
            <div className="flex gap-2">
              <Button className="px-3 py-1.5">معالجة</Button>
              <Button variant="ghost" className="px-3 py-1.5">
                إغلاق
              </Button>
            </div>,
          ])}
        />
      </Card>
    </>
  );
}
