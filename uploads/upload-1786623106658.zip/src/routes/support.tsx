import { createFileRoute, Outlet } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";

export const Route = createFileRoute("/support")({
  component: () => (
    <AppShell role="support">
      <Outlet />
    </AppShell>
  ),
});
