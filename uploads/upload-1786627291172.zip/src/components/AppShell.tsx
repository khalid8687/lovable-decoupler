import { Link, useRouterState } from "@tanstack/react-router";
import type { ReactNode } from "react";
import {
  LayoutDashboard,
  FileSignature,
  FolderKanban,
  Wallet,
  Percent,
  Users,
  BarChart3,
  LifeBuoy,
  Ticket,
  ShieldCheck,
  Target,
  Settings,
  LogOut,
  Bell,
  Coins,
  History,
} from "lucide-react";
import logo from "@/assets/logo.png";
import { ACTORS, queues, useStore, type Role } from "@/lib/store";

type NavItem = { to: string; label: string; icon: typeof LayoutDashboard };

const NAV: Record<Role, NavItem[]> = {
  employee: [
    { to: "/employee", label: "لوحتي", icon: LayoutDashboard },
    { to: "/employee/sales", label: "البيعات", icon: FileSignature },
    { to: "/employee/projects", label: "المشاريع", icon: FolderKanban },
    { to: "/employee/collections", label: "التحصيلات", icon: Wallet },
    { to: "/employee/commissions", label: "العمولات", icon: Percent },
  ],
  manager: [
    { to: "/manager", label: "لوحة الفريق", icon: LayoutDashboard },
    { to: "/manager/team", label: "الفريق", icon: Users },
    { to: "/manager/sales", label: "اعتماد البيعات", icon: FileSignature },
    { to: "/manager/collections", label: "التحصيلات", icon: Wallet },
    { to: "/manager/reports", label: "التقارير", icon: BarChart3 },
  ],
  admin: [
    { to: "/admin", label: "لوحة الإدارة", icon: LayoutDashboard },
    { to: "/admin/targets", label: "التارجت", icon: Target },
    { to: "/admin/employees", label: "الموظفون", icon: Users },
    { to: "/admin/reports", label: "التقارير", icon: BarChart3 },
    { to: "/admin/settings", label: "الإعدادات", icon: Settings },
  ],
  finance: [
    { to: "/finance", label: "لوحة المالية", icon: LayoutDashboard },
    { to: "/finance/sales", label: "صافي البيعات", icon: FileSignature },
    { to: "/finance/collections", label: "التحصيلات", icon: Wallet },
    { to: "/finance/commissions", label: "العمولات", icon: Coins },
    { to: "/finance/targets", label: "التارجت", icon: Target },
  ],
  support: [
    { to: "/support", label: "لوحة الدعم", icon: LifeBuoy },
    { to: "/support/tickets", label: "الطلبات", icon: Ticket },
    { to: "/support/records", label: "السجلات", icon: History },
  ],
};

const META: Record<Role, { title: string; badge: string }> = {
  employee: { title: "بوابة السيلز", badge: "Sales Person" },
  manager: { title: "بوابة مدير الفريق", badge: "Sales Manager" },
  admin: { title: "بوابة مدير الإدارة", badge: "Sales Director" },
  finance: { title: "بوابة الإدارة المالية", badge: "Finance" },
  support: { title: "بوابة الدعم الفني", badge: "Support" },
};

function inboxCount(role: Role, q: ReturnType<typeof queues>) {
  if (role === "manager") return q.managerDeals.length + q.managerCollections.length;
  if (role === "finance")
    return q.financeDeals.length + q.financeCollections.length + q.financeTargets.length;
  if (role === "support") return q.openTickets.length;
  if (role === "admin") return q.financeTargets.length;
  return 0;
}

export function AppShell({ role, children }: { role: Role; children: ReactNode }) {
  const items = NAV[role];
  const meta = META[role];
  const actor = ACTORS[role];
  const { s } = useStore();
  const count = inboxCount(role, queues(s));
  const pathname = useRouterState({ select: (st) => st.location.pathname });

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 start-0 z-30 hidden w-64 flex-col border-e border-border bg-card lg:flex">
        <div className="flex items-center gap-3 px-5 py-5">
          <img src={logo} alt="شعار النظام" width={40} height={40} className="size-10" />
          <div className="min-w-0">
            <p className="truncate text-sm font-extrabold">SalesTrack</p>
            <p className="truncate text-[11px] text-muted-foreground">إدارة ومتابعة المبيعات</p>
          </div>
        </div>
        <nav className="flex-1 space-y-1 px-3">
          {items.map((it) => {
            const active = pathname === it.to;
            return (
              <Link
                key={it.to}
                to={it.to}
                className={
                  "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-bold transition-all " +
                  (active
                    ? "brand-gradient text-primary-foreground shadow-[var(--shadow-card)]"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground")
                }
              >
                <it.icon className="size-[18px] shrink-0" />
                <span className="truncate">{it.label}</span>
              </Link>
            );
          })}
        </nav>
        <div className="p-3">
          <Link
            to="/"
            className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-bold text-muted-foreground transition-colors hover:bg-muted"
          >
            <LogOut className="size-[18px]" />
            تغيير الدور
          </Link>
        </div>
      </aside>

      <div className="lg:ps-64">
        {/* Top bar */}
        <header className="brand-gradient sticky top-0 z-20 px-4 pt-4 pb-5 text-primary-foreground sm:px-6">
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
            <div className="flex min-w-0 items-center gap-3">
              <img
                src={logo}
                alt="شعار النظام"
                width={36}
                height={36}
                className="size-9 shrink-0 rounded-lg bg-white/90 p-0.5 lg:hidden"
              />
              <div className="min-w-0">
                <p className="truncate text-[11px] font-semibold opacity-85">{meta.badge}</p>
                <h2 className="truncate text-base font-extrabold sm:text-lg">{meta.title}</h2>
              </div>
            </div>
            <div className="flex shrink-0 items-center gap-2">
              <span
                aria-label="طلبات بانتظارك"
                className="relative grid size-9 place-items-center rounded-xl bg-white/15"
              >
                <Bell className="size-4" />
                {count > 0 ? (
                  <span className="absolute -end-1 -top-1 grid min-w-4 place-items-center rounded-full bg-warning px-1 text-[10px] font-extrabold text-white">
                    {count}
                  </span>
                ) : null}
              </span>
              <div className="hidden items-center gap-2 rounded-xl bg-white/15 py-1.5 pe-3 ps-1.5 sm:flex">
                <span className="grid size-7 place-items-center rounded-lg bg-white/25 text-[11px] font-bold">
                  {actor.person.slice(0, 1)}
                </span>
                <span className="text-xs font-bold whitespace-nowrap">{actor.person}</span>
              </div>
            </div>
          </div>
        </header>

        <main className="mx-auto max-w-6xl space-y-5 px-4 pt-5 pb-28 sm:px-6 lg:pb-10">{children}</main>
      </div>

      {/* Mobile bottom nav */}
      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-card/95 backdrop-blur lg:hidden">
        <div className="no-scrollbar flex items-stretch justify-between gap-1 overflow-x-auto px-2 py-2">
          {items.map((it) => {
            const active = pathname === it.to;
            return (
              <Link
                key={it.to}
                to={it.to}
                className={
                  "flex min-w-[68px] flex-1 flex-col items-center gap-1 rounded-xl px-2 py-1.5 text-[10px] font-bold transition-colors " +
                  (active ? "text-primary-deep" : "text-muted-foreground")
                }
              >
                <span
                  className={
                    "grid size-8 place-items-center rounded-xl " +
                    (active ? "brand-gradient text-primary-foreground" : "bg-muted")
                  }
                >
                  <it.icon className="size-4" />
                </span>
                <span className="truncate">{it.label}</span>
              </Link>
            );
          })}
          <Link
            to="/"
            className="flex min-w-[68px] flex-col items-center gap-1 rounded-xl px-2 py-1.5 text-[10px] font-bold text-muted-foreground"
          >
            <span className="grid size-8 place-items-center rounded-xl bg-muted">
              <ShieldCheck className="size-4" />
            </span>
            الأدوار
          </Link>
        </div>
      </nav>
    </div>
  );
}
