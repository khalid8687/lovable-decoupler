import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { team, managers, quarterTrend } from "@/lib/mock";

/* ------------------------------------------------------------------ types */

export type Role = "employee" | "manager" | "admin" | "finance" | "support";

export type Currency = "EGP" | "USD" | "SAR";

export const RATES: Record<Currency, number> = { EGP: 1, USD: 48.6, SAR: 12.95 };
export const TAX_RATE = 14;

export const CURRENCIES: { code: Currency; label: string; sym: string }[] = [
  { code: "EGP", label: "جنيه مصري", sym: "EGP" },
  { code: "USD", label: "دولار أمريكي", sym: "USD" },
  { code: "SAR", label: "ريال سعودي", sym: "SAR" },
];

export const money = (n: number, c: Currency = "EGP") =>
  `${c} ${Math.round(n).toLocaleString("en-US")}`;

export const toEGP = (n: number, c: Currency) => n * RATES[c];

export const netOf = (gross: number, taxIncluded: boolean) =>
  taxIncluded ? gross / (1 + TAX_RATE / 100) : gross;

export type Stage =
  | "pending_manager"
  | "rejected_manager"
  | "pending_finance"
  | "approved"
  | "rejected_finance";

export const STAGE_LABEL: Record<Stage, string> = {
  pending_manager: "بانتظار مدير الفريق",
  rejected_manager: "مرفوض من مدير الفريق",
  pending_finance: "بانتظار الإدارة المالية",
  approved: "معتمد نهائياً",
  rejected_finance: "مرفوض من المالية",
};

export const STAGE_TONE: Record<Stage, "brand" | "success" | "warning" | "danger"> = {
  pending_manager: "warning",
  rejected_manager: "danger",
  pending_finance: "brand",
  approved: "success",
  rejected_finance: "danger",
};

export type Step = { at: string; by: string; action: string; note?: string };

export type Deal = {
  id: string;
  client: string;
  project: string;
  seller: string;
  manager: string;
  currency: Currency;
  gross: number;
  taxIncluded: boolean;
  net: number;
  financeNet?: number;
  partner?: { name: string; share: number } | undefined;
  share: number;
  date: string;
  stage: Stage;
  note?: string;
  history: Step[];
};

export type Collection = {
  id: string;
  dealId: string;
  client: string;
  seller: string;
  manager: string;
  currency: Currency;
  amount: number;
  financeAmount?: number;
  method: "تحويل بنكي" | "شيك" | "نقدي";
  ref: string;
  date: string;
  stage: Stage;
  note?: string;
  history: Step[];
};

export type TargetRow = {
  id: string;
  person: string;
  quarter: string;
  value: number;
  stage: Stage;
  setBy: string;
  history: Step[];
};

export type Ticket = {
  id: string;
  title: string;
  requester: string;
  role: string;
  type: "تعديل تعاقد" | "خطأ في تحصيل" | "صلاحيات" | "استفسار عمولة";
  priority: "عالية" | "متوسطة" | "منخفضة";
  status: "مفتوحة" | "قيد المعالجة" | "مغلقة";
  createdAt: string;
};

export type Rate = { person: string; rate: number; paid: number };

export type Log = { id: string; at: string; by: string; action: string };

/* ------------------------------------------------------------------ seed */

const now = () => new Date().toISOString().slice(0, 16).replace("T", " ");
const today = () => new Date().toISOString().slice(0, 10);

const step = (by: string, action: string, note?: string): Step => ({
  at: now(),
  by,
  action,
  ...(note ? { note } : {}),
});

const seedDeals: Deal[] = [
  {
    id: "C-1041",
    client: "مجموعة النيل العقارية",
    project: "هوية بصرية + حملة إطلاق",
    seller: "أحمد سالم",
    manager: "خالد منصور",
    currency: "EGP",
    gross: 1_140_000,
    taxIncluded: true,
    net: 1_000_000,
    financeNet: 1_000_000,
    share: 100,
    date: "2026-01-12",
    stage: "approved",
    history: [
      { at: "2026-01-12 10:20", by: "أحمد سالم (سيلز)", action: "تسجيل البيعة" },
      { at: "2026-01-12 14:02", by: "خالد منصور (مدير الفريق)", action: "اعتماد البيعة" },
      {
        at: "2026-01-13 09:40",
        by: "منال حسن (الإدارة المالية)",
        action: "اعتماد نهائي + تعديل الصافي",
        note: "المبلغ كان بالضريبة، تم حسم 14% ليصبح صافي البيعة 1,000,000",
      },
    ],
  },
  {
    id: "C-1046",
    client: "شركة دلتا للأغذية",
    project: "إدارة سوشيال ميديا سنوية",
    seller: "أحمد سالم",
    manager: "خالد منصور",
    currency: "EGP",
    gross: 700_000,
    taxIncluded: false,
    net: 700_000,
    financeNet: 700_000,
    partner: { name: "عمر فؤاد", share: 30 },
    share: 70,
    date: "2026-02-03",
    stage: "approved",
    history: [
      { at: "2026-02-03 11:10", by: "أحمد سالم (سيلز)", action: "تسجيل البيعة" },
      {
        at: "2026-02-03 16:30",
        by: "خالد منصور (مدير الفريق)",
        action: "اعتماد + إضافة مشارك",
        note: "عمر فؤاد 30%",
      },
      { at: "2026-02-04 10:00", by: "منال حسن (الإدارة المالية)", action: "اعتماد نهائي" },
    ],
  },
  {
    id: "C-1052",
    client: "بنك القاهرة الحديث",
    project: "تطوير منصة رقمية",
    seller: "عمر فؤاد",
    manager: "خالد منصور",
    currency: "USD",
    gross: 30_000,
    taxIncluded: false,
    net: 30_000,
    share: 100,
    date: "2026-02-21",
    stage: "pending_manager",
    history: [{ at: "2026-02-21 09:15", by: "عمر فؤاد (سيلز)", action: "تسجيل البيعة" }],
  },
  {
    id: "C-1058",
    client: "مستشفى الشفاء",
    project: "حملة توعية + إنتاج فيديو",
    seller: "منة عادل",
    manager: "خالد منصور",
    currency: "EGP",
    gross: 592_800,
    taxIncluded: true,
    net: 520_000,
    partner: { name: "يوسف طارق", share: 40 },
    share: 60,
    date: "2026-03-05",
    stage: "pending_finance",
    history: [
      { at: "2026-03-05 12:00", by: "منة عادل (سيلز)", action: "تسجيل البيعة" },
      {
        at: "2026-03-05 17:20",
        by: "خالد منصور (مدير الفريق)",
        action: "اعتماد + إضافة مشارك",
        note: "يوسف طارق 40%",
      },
    ],
  },
  {
    id: "C-1063",
    client: "أوركيد للمقاولات",
    project: "خطة تسويق عقاري",
    seller: "يوسف طارق",
    manager: "هالة رمزي",
    currency: "SAR",
    gross: 250_000,
    taxIncluded: false,
    net: 250_000,
    financeNet: 250_000,
    share: 100,
    date: "2026-03-18",
    stage: "approved",
    history: [
      { at: "2026-03-18 10:00", by: "يوسف طارق (سيلز)", action: "تسجيل البيعة" },
      { at: "2026-03-18 13:00", by: "هالة رمزي (مدير الفريق)", action: "اعتماد البيعة" },
      { at: "2026-03-19 09:00", by: "منال حسن (الإدارة المالية)", action: "اعتماد نهائي" },
    ],
  },
];

const seedCollections: Collection[] = [
  {
    id: "R-9001",
    dealId: "C-1041",
    client: "مجموعة النيل العقارية",
    seller: "أحمد سالم",
    manager: "خالد منصور",
    currency: "EGP",
    amount: 400_000,
    financeAmount: 400_000,
    method: "تحويل بنكي",
    ref: "TRX-88213",
    date: "2026-01-20",
    stage: "approved",
    history: [
      { at: "2026-01-20 10:00", by: "أحمد سالم (سيلز)", action: "تسجيل دفعة" },
      { at: "2026-01-20 15:00", by: "خالد منصور (مدير الفريق)", action: "مراجعة واعتماد" },
      { at: "2026-01-21 11:00", by: "منال حسن (الإدارة المالية)", action: "اعتماد نهائي للتحصيل" },
    ],
  },
  {
    id: "R-9008",
    dealId: "C-1041",
    client: "مجموعة النيل العقارية",
    seller: "أحمد سالم",
    manager: "خالد منصور",
    currency: "EGP",
    amount: 342_000,
    financeAmount: 300_000,
    method: "شيك",
    ref: "CHQ-4412",
    date: "2026-02-18",
    stage: "approved",
    note: "الموظف سجّل المبلغ بالضريبة — تم تعديله للصافي 300,000",
    history: [
      { at: "2026-02-18 09:00", by: "أحمد سالم (سيلز)", action: "تسجيل دفعة" },
      { at: "2026-02-18 12:00", by: "خالد منصور (مدير الفريق)", action: "مراجعة واعتماد" },
      {
        at: "2026-02-19 10:30",
        by: "منال حسن (الإدارة المالية)",
        action: "تعديل المبلغ + اعتماد نهائي",
        note: "حسم الضريبة 14%",
      },
    ],
  },
  {
    id: "R-9012",
    dealId: "C-1046",
    client: "شركة دلتا للأغذية",
    seller: "أحمد سالم",
    manager: "خالد منصور",
    currency: "EGP",
    amount: 420_000,
    method: "تحويل بنكي",
    ref: "TRX-90112",
    date: "2026-02-25",
    stage: "pending_finance",
    history: [
      { at: "2026-02-25 09:30", by: "أحمد سالم (سيلز)", action: "تسجيل دفعة" },
      { at: "2026-02-25 14:10", by: "خالد منصور (مدير الفريق)", action: "مراجعة واعتماد" },
    ],
  },
  {
    id: "R-9031",
    dealId: "C-1063",
    client: "أوركيد للمقاولات",
    seller: "يوسف طارق",
    manager: "هالة رمزي",
    currency: "SAR",
    amount: 250_000,
    financeAmount: 250_000,
    method: "تحويل بنكي",
    ref: "TRX-77410",
    date: "2026-03-25",
    stage: "approved",
    history: [
      { at: "2026-03-25 10:00", by: "يوسف طارق (سيلز)", action: "تسجيل دفعة" },
      { at: "2026-03-25 12:00", by: "هالة رمزي (مدير الفريق)", action: "مراجعة واعتماد" },
      { at: "2026-03-26 09:00", by: "منال حسن (الإدارة المالية)", action: "اعتماد نهائي للتحصيل" },
    ],
  },
  {
    id: "R-9036",
    dealId: "C-1046",
    client: "شركة دلتا للأغذية",
    seller: "أحمد سالم",
    manager: "خالد منصور",
    currency: "EGP",
    amount: 120_000,
    method: "نقدي",
    ref: "CASH-1120",
    date: "2026-03-28",
    stage: "pending_manager",
    history: [{ at: "2026-03-28 09:00", by: "أحمد سالم (سيلز)", action: "تسجيل دفعة" }],
  },
];

const seedTargets: TargetRow[] = team.map((p, i) => ({
  id: "TG-" + (300 + i),
  person: p.name,
  quarter: "Q1",
  value: p.target,
  stage: i === 2 ? "pending_finance" : "approved",
  setBy: "طارق الجندي (مدير الإدارة)",
  history: [
    { at: "2026-01-02 09:00", by: "طارق الجندي (مدير الإدارة)", action: "تحديد التارجت" },
    ...(i === 2
      ? []
      : [{ at: "2026-01-02 13:00", by: "منال حسن (الإدارة المالية)", action: "اعتماد نهائي" }]),
  ],
}));

const seedTickets: Ticket[] = [
  {
    id: "T-501",
    title: "تعديل نسبة المشاركة في التعاقد C-1046",
    requester: "عمر فؤاد",
    role: "سيلز",
    type: "تعديل تعاقد",
    priority: "عالية",
    status: "مفتوحة",
    createdAt: "2026-03-20",
  },
  {
    id: "T-502",
    title: "دفعة مسجلة مرتين للتعاقد C-1041",
    requester: "أحمد سالم",
    role: "سيلز",
    type: "خطأ في تحصيل",
    priority: "عالية",
    status: "قيد المعالجة",
    createdAt: "2026-03-21",
  },
  {
    id: "T-503",
    title: "طلب صلاحية عرض تقارير الفريق",
    requester: "منة عادل",
    role: "سيلز",
    type: "صلاحيات",
    priority: "متوسطة",
    status: "مفتوحة",
    createdAt: "2026-03-22",
  },
  {
    id: "T-504",
    title: "استفسار عن حساب العمولة المتبقية",
    requester: "يوسف طارق",
    role: "سيلز",
    type: "استفسار عمولة",
    priority: "منخفضة",
    status: "مغلقة",
    createdAt: "2026-03-18",
  },
];

const seedRates: Rate[] = team.map((p) => ({
  person: p.name,
  rate: p.commissionRate,
  paid: p.commissionPaid,
}));

const seedLogs: Log[] = [
  { id: "L-1", at: "2026-03-26 09:00", by: "منال حسن (الإدارة المالية)", action: "اعتماد نهائي للتحصيل R-9031" },
  { id: "L-2", at: "2026-03-25 12:00", by: "هالة رمزي (مدير الفريق)", action: "اعتماد التحصيل R-9031" },
  { id: "L-3", at: "2026-03-19 10:30", by: "منال حسن (الإدارة المالية)", action: "تعديل مبلغ التحصيل R-9008" },
  { id: "L-4", at: "2026-01-02 13:00", by: "منال حسن (الإدارة المالية)", action: "اعتماد تارجت Q1" },
];

type State = {
  deals: Deal[];
  collections: Collection[];
  targets: TargetRow[];
  tickets: Ticket[];
  rates: Rate[];
  logs: Log[];
  rateTable: Record<Currency, number>;
};

const seedState = (): State => ({
  deals: seedDeals,
  collections: seedCollections,
  targets: seedTargets,
  tickets: seedTickets,
  rates: seedRates,
  logs: seedLogs,
  rateTable: { ...RATES },
});

/* ------------------------------------------------------------- actors */

export const ACTORS: Record<Role, { person: string; label: string; sig: string }> = {
  employee: { person: "أحمد سالم", label: "سيلز", sig: "أحمد سالم (سيلز)" },
  manager: { person: "خالد منصور", label: "مدير الفريق", sig: "خالد منصور (مدير الفريق)" },
  admin: { person: "طارق الجندي", label: "مدير الإدارة", sig: "طارق الجندي (مدير الإدارة)" },
  finance: { person: "منال حسن", label: "الإدارة المالية", sig: "منال حسن (الإدارة المالية)" },
  support: { person: "سارة نبيل", label: "الدعم الفني", sig: "سارة نبيل (الدعم الفني)" },
};

/* ------------------------------------------------------------- context */

type Toast = { id: number; text: string; tone: "ok" | "warn" | "err" };

type Ctx = {
  s: State;
  toasts: Toast[];
  toast: (text: string, tone?: Toast["tone"]) => void;
  addDeal: (d: {
    client: string;
    project: string;
    currency: Currency;
    gross: number;
    taxIncluded: boolean;
    date: string;
    partner?: { name: string; share: number };
  }) => void;
  managerDeal: (id: string, ok: boolean, opts?: { partner?: { name: string; share: number } | null; note?: string }) => void;
  financeDeal: (id: string, ok: boolean, opts?: { net?: number; note?: string }) => void;
  addCollection: (c: {
    dealId: string;
    amount: number;
    method: Collection["method"];
    ref: string;
    date: string;
  }) => void;
  managerCollection: (id: string, ok: boolean, note?: string) => void;
  financeCollection: (id: string, ok: boolean, opts?: { amount?: number; note?: string }) => void;
  setTarget: (person: string, quarter: string, value: number) => void;
  financeTarget: (id: string, ok: boolean, note?: string) => void;
  setRate: (person: string, rate: number) => void;
  payCommission: (person: string, amount: number) => void;
  setFxRate: (c: Currency, v: number) => void;
  addTicket: (t: { title: string; type: Ticket["type"]; priority: Ticket["priority"]; requester: string }) => void;
  setTicket: (id: string, status: Ticket["status"]) => void;
  reset: () => void;
};

const StoreCtx = createContext<Ctx | null>(null);
const KEY = "salestrack-flow-v1";

export function StoreProvider({ children }: { children: ReactNode }) {
  const [s, setS] = useState<State>(seedState);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setS({ ...seedState(), ...(JSON.parse(raw) as State) });
    } catch {
      /* ignore */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(KEY, JSON.stringify(s));
    } catch {
      /* ignore */
    }
  }, [s, ready]);

  const toast = useCallback((text: string, tone: Toast["tone"] = "ok") => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, text, tone }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  }, []);

  const log = (st: State, by: string, action: string): State => ({
    ...st,
    logs: [{ id: "L-" + Date.now(), at: now(), by, action }, ...st.logs].slice(0, 60),
  });

  const api = useMemo<Ctx>(() => {
    const A = ACTORS;

    return {
      s,
      toasts,
      toast,

      addDeal: (d) => {
        const id = "C-" + (1100 + Math.floor(Math.random() * 800));
        const net = netOf(d.gross, d.taxIncluded);
        const deal: Deal = {
          id,
          client: d.client,
          project: d.project,
          seller: A.employee.person,
          manager: A.manager.person,
          currency: d.currency,
          gross: d.gross,
          taxIncluded: d.taxIncluded,
          net,
          share: d.partner ? 100 - d.partner.share : 100,
          date: d.date || today(),
          stage: "pending_manager",
          history: [step(A.employee.sig, "تسجيل البيعة")],
          ...(d.partner ? { partner: d.partner } : {}),
        };
        setS((st) => log({ ...st, deals: [deal, ...st.deals] }, A.employee.sig, `تسجيل بيعة ${id}`));
        toast(`تم إرسال البيعة ${id} لمدير الفريق للاعتماد`);
      },

      managerDeal: (id, ok, opts) => {
        setS((st) =>
          log(
            {
              ...st,
              deals: st.deals.map((d) =>
                d.id !== id
                  ? d
                  : {
                      ...d,
                      stage: ok ? "pending_finance" : "rejected_manager",
                      ...(opts?.partner !== undefined
                        ? opts.partner
                          ? { partner: opts.partner, share: 100 - opts.partner.share }
                          : { partner: undefined, share: 100 }
                        : {}),
                      ...(opts?.note ? { note: opts.note } : {}),
                      history: [
                        ...d.history,
                        step(
                          A.manager.sig,
                          ok ? "اعتماد البيعة وإرسالها للمالية" : "رفض البيعة",
                          opts?.partner ? `مشارك: ${opts.partner.name} ${opts.partner.share}%` : opts?.note,
                        ),
                      ],
                    },
              ),
            },
            A.manager.sig,
            `${ok ? "اعتماد" : "رفض"} البيعة ${id}`,
          ),
        );
        toast(ok ? `تم اعتماد ${id} — بانتظار الإدارة المالية` : `تم رفض ${id}`, ok ? "ok" : "warn");
      },

      financeDeal: (id, ok, opts) => {
        setS((st) =>
          log(
            {
              ...st,
              deals: st.deals.map((d) =>
                d.id !== id
                  ? d
                  : {
                      ...d,
                      stage: ok ? "approved" : "rejected_finance",
                      ...(ok ? { financeNet: opts?.net ?? d.net } : {}),
                      ...(opts?.note ? { note: opts.note } : {}),
                      history: [
                        ...d.history,
                        step(
                          A.finance.sig,
                          ok ? "اعتماد نهائي لصافي البيعة" : "رفض / إرجاع للتعديل",
                          opts?.note,
                        ),
                      ],
                    },
              ),
            },
            A.finance.sig,
            `${ok ? "اعتماد نهائي" : "رفض"} البيعة ${id}`,
          ),
        );
        toast(ok ? `اعتماد نهائي للبيعة ${id}` : `تم إرجاع ${id} للتعديل`, ok ? "ok" : "warn");
      },

      addCollection: (c) => {
        const deal = s.deals.find((d) => d.id === c.dealId);
        if (!deal) return;
        const id = "R-" + (9100 + Math.floor(Math.random() * 800));
        const row: Collection = {
          id,
          dealId: deal.id,
          client: deal.client,
          seller: A.employee.person,
          manager: deal.manager,
          currency: deal.currency,
          amount: c.amount,
          method: c.method,
          ref: c.ref,
          date: c.date || today(),
          stage: "pending_manager",
          history: [step(A.employee.sig, "تسجيل دفعة تحصيل")],
        };
        setS((st) =>
          log({ ...st, collections: [row, ...st.collections] }, A.employee.sig, `تسجيل تحصيل ${id}`),
        );
        toast(`تم إرسال التحصيل ${id} لمدير الفريق ثم المالية`);
      },

      managerCollection: (id, ok, note) => {
        setS((st) =>
          log(
            {
              ...st,
              collections: st.collections.map((c) =>
                c.id !== id
                  ? c
                  : {
                      ...c,
                      stage: ok ? "pending_finance" : "rejected_manager",
                      ...(note ? { note } : {}),
                      history: [
                        ...c.history,
                        step(A.manager.sig, ok ? "مراجعة واعتماد التحصيل" : "رفض التحصيل", note),
                      ],
                    },
              ),
            },
            A.manager.sig,
            `${ok ? "اعتماد" : "رفض"} التحصيل ${id}`,
          ),
        );
        toast(ok ? `تم تحويل ${id} للإدارة المالية` : `تم رفض ${id}`, ok ? "ok" : "warn");
      },

      financeCollection: (id, ok, opts) => {
        setS((st) =>
          log(
            {
              ...st,
              collections: st.collections.map((c) =>
                c.id !== id
                  ? c
                  : {
                      ...c,
                      stage: ok ? "approved" : "rejected_finance",
                      ...(ok ? { financeAmount: opts?.amount ?? c.amount } : {}),
                      ...(opts?.note ? { note: opts.note } : {}),
                      history: [
                        ...c.history,
                        step(
                          A.finance.sig,
                          ok
                            ? opts?.amount !== undefined && opts.amount !== c.amount
                              ? "تعديل المبلغ + اعتماد نهائي"
                              : "اعتماد نهائي للتحصيل"
                            : "رفض التحصيل",
                          opts?.note,
                        ),
                      ],
                    },
              ),
            },
            A.finance.sig,
            `${ok ? "اعتماد نهائي" : "رفض"} التحصيل ${id}`,
          ),
        );
        toast(ok ? `اعتماد نهائي للتحصيل ${id}` : `تم رفض التحصيل ${id}`, ok ? "ok" : "warn");
      },

      setTarget: (person, quarter, value) => {
        setS((st) => {
          const found = st.targets.find((t) => t.person === person && t.quarter === quarter);
          const targets = found
            ? st.targets.map((t) =>
                t === found
                  ? {
                      ...t,
                      value,
                      stage: "pending_finance" as Stage,
                      setBy: A.admin.sig,
                      history: [...t.history, step(A.admin.sig, "تعديل التارجت", money(value))],
                    }
                  : t,
              )
            : [
                {
                  id: "TG-" + Date.now(),
                  person,
                  quarter,
                  value,
                  stage: "pending_finance" as Stage,
                  setBy: A.admin.sig,
                  history: [step(A.admin.sig, "تحديد التارجت", money(value))],
                },
                ...st.targets,
              ];
          return log({ ...st, targets }, A.admin.sig, `تحديد تارجت ${person} — ${quarter}`);
        });
        toast(`تم إرسال تارجت ${person} للإدارة المالية للاعتماد النهائي`);
      },

      financeTarget: (id, ok, note) => {
        setS((st) =>
          log(
            {
              ...st,
              targets: st.targets.map((t) =>
                t.id !== id
                  ? t
                  : {
                      ...t,
                      stage: ok ? "approved" : "rejected_finance",
                      history: [
                        ...t.history,
                        step(A.finance.sig, ok ? "اعتماد نهائي للتارجت" : "رفض التارجت", note),
                      ],
                    },
              ),
            },
            A.finance.sig,
            `${ok ? "اعتماد" : "رفض"} تارجت`,
          ),
        );
        toast(ok ? "تم اعتماد التارجت نهائياً" : "تم رفض التارجت", ok ? "ok" : "warn");
      },

      setRate: (person, rate) => {
        setS((st) =>
          log(
            { ...st, rates: st.rates.map((r) => (r.person === person ? { ...r, rate } : r)) },
            A.finance.sig,
            `تحديد نسبة عمولة ${person} = ${rate}%`,
          ),
        );
        toast(`تم تحديث نسبة عمولة ${person} إلى ${rate}%`);
      },

      payCommission: (person, amount) => {
        setS((st) =>
          log(
            {
              ...st,
              rates: st.rates.map((r) => (r.person === person ? { ...r, paid: r.paid + amount } : r)),
            },
            A.finance.sig,
            `صرف عمولة ${person} بمبلغ ${money(amount)}`,
          ),
        );
        toast(`تم صرف ${money(amount)} عمولة إلى ${person}`);
      },

      setFxRate: (c, v) => {
        setS((st) =>
          log({ ...st, rateTable: { ...st.rateTable, [c]: v } }, A.finance.sig, `تحديث سعر ${c} = ${v}`),
        );
        toast(`تم تحديث سعر ${c}`);
      },

      addTicket: (t) => {
        const id = "T-" + (520 + Math.floor(Math.random() * 200));
        setS((st) =>
          log(
            {
              ...st,
              tickets: [
                {
                  id,
                  title: t.title,
                  requester: t.requester,
                  role: "سيلز",
                  type: t.type,
                  priority: t.priority,
                  status: "مفتوحة",
                  createdAt: today(),
                },
                ...st.tickets,
              ],
            },
            t.requester,
            `فتح طلب دعم ${id}`,
          ),
        );
        toast(`تم فتح الطلب ${id} لدى الدعم الفني`);
      },

      setTicket: (id, status) => {
        setS((st) =>
          log(
            { ...st, tickets: st.tickets.map((t) => (t.id === id ? { ...t, status } : t)) },
            A.support.sig,
            `تحديث الطلب ${id} → ${status}`,
          ),
        );
        toast(`الطلب ${id}: ${status}`);
      },

      reset: () => {
        setS(seedState());
        toast("تم إرجاع بيانات الديمو للحالة الأصلية", "warn");
      },
    };
  }, [s, toasts, toast]);

  return (
    <StoreCtx.Provider value={api}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 bottom-24 z-[60] flex flex-col items-center gap-2 px-4 lg:bottom-6">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={
              "pointer-events-auto max-w-md rounded-2xl px-4 py-3 text-xs font-bold text-white shadow-[var(--shadow-float)] " +
              (t.tone === "ok" ? "bg-success" : t.tone === "warn" ? "bg-warning" : "bg-destructive")
            }
          >
            {t.text}
          </div>
        ))}
      </div>
    </StoreCtx.Provider>
  );
}

export function useStore() {
  const ctx = useContext(StoreCtx);
  if (!ctx) throw new Error("useStore must be used inside StoreProvider");
  return ctx;
}

/* --------------------------------------------------------- selectors */

export const dealNet = (d: Deal) => d.financeNet ?? d.net;
export const dealNetEGP = (d: Deal) => toEGP(dealNet(d), d.currency);
export const collectionAmount = (c: Collection) => c.financeAmount ?? c.amount;
export const collectionEGP = (c: Collection) => toEGP(collectionAmount(c), c.currency);

export function shareOf(d: Deal, person: string) {
  if (d.seller === person) return d.share / 100;
  if (d.partner?.name === person) return d.partner.share / 100;
  return 0;
}

export function metricsFor(s: State, person: string) {
  const approvedDeals = s.deals.filter((d) => d.stage === "approved");
  const sales = approvedDeals.reduce((sum, d) => sum + dealNetEGP(d) * shareOf(d, person), 0);
  const pipeline = s.deals
    .filter((d) => d.stage === "pending_manager" || d.stage === "pending_finance")
    .reduce((sum, d) => sum + dealNetEGP(d) * shareOf(d, person), 0);

  const collections = s.collections
    .filter((c) => c.stage === "approved")
    .reduce((sum, c) => {
      const d = s.deals.find((x) => x.id === c.dealId);
      return sum + collectionEGP(c) * (d ? shareOf(d, person) : 0);
    }, 0);

  const pendingCollections = s.collections
    .filter((c) => c.stage === "pending_manager" || c.stage === "pending_finance")
    .reduce((sum, c) => {
      const d = s.deals.find((x) => x.id === c.dealId);
      return sum + collectionEGP(c) * (d ? shareOf(d, person) : 0);
    }, 0);

  const target = s.targets.find((t) => t.person === person && t.stage === "approved")?.value ?? 0;
  const rate = s.rates.find((r) => r.person === person)?.rate ?? 0;
  const paid = s.rates.find((r) => r.person === person)?.paid ?? 0;
  const earned = (collections * rate) / 100;

  return {
    sales,
    pipeline,
    collections,
    pendingCollections,
    outstanding: Math.max(sales - collections, 0),
    target,
    rate,
    earned,
    paid,
    pendingCommission: Math.max(earned - paid, 0),
  };
}

export function totalsOf(s: State) {
  const people = team.map((p) => p.name);
  const m = people.map((p) => metricsFor(s, p));
  const sum = (k: keyof (typeof m)[number]) => m.reduce((a, x) => a + (x[k] as number), 0);
  return {
    target: sum("target"),
    sales: sum("sales"),
    pipeline: sum("pipeline"),
    collections: sum("collections"),
    outstanding: sum("outstanding"),
    earned: sum("earned"),
    paid: sum("paid"),
    pendingCommission: sum("pendingCommission"),
  };
}

export function queues(s: State) {
  return {
    managerDeals: s.deals.filter((d) => d.stage === "pending_manager"),
    financeDeals: s.deals.filter((d) => d.stage === "pending_finance"),
    managerCollections: s.collections.filter((c) => c.stage === "pending_manager"),
    financeCollections: s.collections.filter((c) => c.stage === "pending_finance"),
    financeTargets: s.targets.filter((t) => t.stage === "pending_finance"),
    openTickets: s.tickets.filter((t) => t.status !== "مغلقة"),
  };
}

export { team, managers, quarterTrend };
