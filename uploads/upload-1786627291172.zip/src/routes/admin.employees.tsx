import { createFileRoute } from "@tanstack/react-router";
import { Badge, Card, DataTable, PageHeader, Progress, Stat } from "@/components/kit";
import { EGP, managers, pct, team } from "@/lib/mock";
import { ACTORS, metricsFor, useStore } from "@/lib/store";

export const Route = createFileRoute("/admin/employees")({
  head: () => ({
    meta: [
      { title: "الموظفون والهيكل الإداري | SalesTrack" },
      { name: "description", content: "كل موظف مبيعات ومديره المباشر وأرقامه المعتمدة داخل النظام." },
      { property: "og:title", content: "الموظفون والهيكل الإداري | SalesTrack" },
      { property: "og:description", content: "الهيكل الإداري وصلاحيات كل فئة." },
    ],
  }),
  component: EmployeesPage,
});

const ROLES = [
  ["السيلز", "تسجيل البيعات والتحصيلات فقط"],
  ["مدير الفريق", "اعتماد البيعات + إضافة مشارك + مراجعة التحصيلات"],
  ["مدير الإدارة", "تحديد وتعديل التارجت ومتابعة الأداء العام"],
  ["الإدارة المالية", "الاعتماد النهائي للبيعات والتحصيلات والتارجت + العمولات"],
  ["الدعم الفني", "التذاكر وتصحيح البيانات وسجل العمليات"],
];

function EmployeesPage() {
  const { s } = useStore();

  return (
    <>
      <PageHeader title="الموظفون" subtitle="الهيكل الإداري والصلاحيات المسجلة" />

      <div className="grid gap-4 sm:grid-cols-3">
        <Stat label="عدد موظفي المبيعات" value={String(team.length)} tone="brand" />
        <Stat label="عدد مديري الفرق" value={String(managers.length)} />
        <Stat label="عدد الفئات" value="5" tone="success" />
      </div>

      <Card title="فئات المستخدمين والصلاحيات">
        <DataTable
          head={["الفئة", "المستخدم في الديمو", "الصلاحيات"]}
          rows={ROLES.map(([role, perm], i) => [
            <span className="font-extrabold">{role}</span>,
            Object.values(ACTORS)[i]?.person ?? "—",
            <span className="text-muted-foreground">{perm}</span>,
          ])}
        />
      </Card>

      <Card title="موظفو المبيعات">
        <DataTable
          head={["الموظف", "المسمى", "المدير", "التارجت", "المبيعات", "التحصيلات", "نسبة التحقيق"]}
          rows={team.map((p) => {
            const m = metricsFor(s, p.name);
            return [
              <span className="font-bold">{p.name}</span>,
              <span className="text-muted-foreground">{p.title}</span>,
              p.manager,
              EGP(m.target),
              EGP(m.sales),
              EGP(m.collections),
              <div className="w-28">
                <Progress value={pct(m.sales, m.target || 1)} />
              </div>,
            ];
          })}
        />
      </Card>

      <Card title="مديرو الفرق">
        <DataTable
          head={["المدير", "عدد الأعضاء", "تارجت الفريق", "مبيعات الفريق", "الحالة"]}
          rows={managers.map((mg) => {
            const members = team.filter((p) => p.manager === mg.name);
            const sum = (k: "target" | "sales") =>
              members.reduce((a, p) => a + metricsFor(s, p.name)[k], 0);
            const a = pct(sum("sales"), sum("target") || 1);
            return [
              <span className="font-bold">{mg.name}</span>,
              String(members.length),
              EGP(sum("target")),
              EGP(sum("sales")),
              <Badge tone={a >= 100 ? "success" : a >= 70 ? "brand" : "warning"}>{a}%</Badge>,
            ];
          })}
        />
      </Card>
    </>
  );
}
