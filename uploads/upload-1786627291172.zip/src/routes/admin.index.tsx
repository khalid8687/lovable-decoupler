import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Coins, Target, TrendingUp, Wallet } from "lucide-react";
import { Badge, BarChart, Button, Card, DataTable, PageHeader, Progress, Ring, Stat } from "@/components/kit";
import { EGP, pct, team } from "@/lib/mock";
import { STAGE_LABEL, STAGE_TONE, metricsFor, queues, totalsOf, useStore } from "@/lib/store";

export const Route = createFileRoute("/admin/")({
  head: () => ({
    meta: [
      { title: "لوحة مدير الإدارة | SalesTrack" },
      { name: "description", content: "نظرة تنفيذية شاملة على التارجت والمبيعات والتحصيلات وأداء المديرين." },
      { property: "og:title", content: "لوحة مدير الإدارة | SalesTrack" },
      { property: "og:description", content: "مؤشرات الأداء العامة للشركة." },
    ],
  }),
  component: AdminHome,
});

function AdminHome() {
  const { s } = useStore();
  const t = totalsOf(s);
  const q = queues(s);

  return (
    <>
      <PageHeader
        title="اللوحة التنفيذية"
        subtitle="أنت تحدد التارجت وتراقب الأداء — الاعتماد المالي النهائي عند الإدارة المالية"
        action={
          <Link to="/admin/targets">
            <Button>
              تحديد التارجت <ArrowLeft className="size-4" />
            </Button>
          </Link>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="إجمالي التارجت المعتمد" value={EGP(t.target)} tone="brand" icon={<Target className="size-4" />} />
        <Stat label="مبيعات معتمدة" value={EGP(t.sales)} tone="success" icon={<TrendingUp className="size-4" />} />
        <Stat label="تحصيلات معتمدة" value={EGP(t.collections)} icon={<Wallet className="size-4" />} />
        <Stat label="عمولات مستحقة" value={EGP(t.pendingCommission)} tone="warning" icon={<Coins className="size-4" />} />
      </div>

      <div className="grid gap-4 lg:grid-cols-[320px_minmax(0,1fr)]">
        <Card title="تحقيق التارجت العام">
          <div className="grid place-items-center py-2">
            <Ring value={pct(t.sales, t.target || 1)} caption="من التارجت" />
          </div>
          <div className="mt-4 space-y-3">
            <Progress value={pct(t.collections, t.sales || 1)} label="نسبة التحصيل" />
            <Progress value={pct(t.paid, t.earned || 1)} label="العمولات المصروفة" />
          </div>
        </Card>

        <Card title="التارجت مقابل المبيعات لكل موظف">
          <BarChart
            data={team.map((p) => {
              const m = metricsFor(s, p.name);
              return {
                label: p.name.split(" ")[0] ?? p.name,
                a: Math.round(m.target),
                b: Math.round(m.sales),
              };
            })}
          />
        </Card>
      </div>

      <Card title="حالة الاعتمادات في النظام">
        <DataTable
          head={["المرحلة", "بيعات", "تحصيلات", "تارجت"]}
          rows={[
            ["عند مدير الفريق", String(q.managerDeals.length), String(q.managerCollections.length), "—"],
            ["عند الإدارة المالية", String(q.financeDeals.length), String(q.financeCollections.length), String(q.financeTargets.length)],
          ]}
        />
      </Card>

      <Card title="آخر البيعات">
        <DataTable
          head={["كود", "الموظف", "العميل", "العملة", "الحالة"]}
          rows={s.deals.slice(-8).reverse().map((d) => [
            <span className="font-bold text-primary-deep">{d.id}</span>,
            d.seller,
            d.client,
            d.currency,
            <Badge tone={STAGE_TONE[d.stage]}>{STAGE_LABEL[d.stage]}</Badge>,
          ])}
        />
      </Card>
    </>
  );
}
