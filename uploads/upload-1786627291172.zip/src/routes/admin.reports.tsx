import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { BarChart, Card, DataTable, PageHeader, QuarterTabs, Ring, Stat } from "@/components/kit";
import { EGP, managers, pct, quarterTrend, quarters, team } from "@/lib/mock";
import { metricsFor, totalsOf, useStore } from "@/lib/store";

export const Route = createFileRoute("/admin/reports")({
  head: () => ({
    meta: [
      { title: "التقارير التنفيذية | SalesTrack" },
      { name: "description", content: "تقارير ربع سنوية للمبيعات والتحصيلات والعمولات على مستوى الشركة والفرق." },
      { property: "og:title", content: "التقارير التنفيذية | SalesTrack" },
      { property: "og:description", content: "مقارنة الأرباع وأداء الفرق." },
    ],
  }),
  component: AdminReports,
});

function AdminReports() {
  const { s } = useStore();
  const [q, setQ] = useState("Full Year");
  const t = totalsOf(s);

  return (
    <>
      <PageHeader
        title="التقارير التنفيذية"
        subtitle="كل الأرقام مبنية على المعتمد نهائياً من الإدارة المالية"
        action={<QuarterTabs value={q} onChange={setQ} options={quarters} />}
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="التارجت" value={EGP(t.target)} tone="brand" />
        <Stat label="المبيعات" value={EGP(t.sales)} tone="success" />
        <Stat label="التحصيلات" value={EGP(t.collections)} />
        <Stat label="قيد الاعتماد" value={EGP(t.pipeline)} tone="warning" />
      </div>

      <div className="grid gap-4 lg:grid-cols-[320px_minmax(0,1fr)]">
        <Card title="نسبة التحقيق العامة">
          <div className="grid place-items-center py-2">
            <Ring value={pct(t.sales, t.target || 1)} caption={q} />
          </div>
        </Card>
        <Card title="اتجاه الأرباع (تارجت مقابل مبيعات)">
          <BarChart data={quarterTrend.map((x) => ({ label: x.q, a: x.target, b: x.sales }))} />
        </Card>
      </div>

      <Card title="أداء الفرق">
        <DataTable
          head={["المدير", "الأعضاء", "التارجت", "المبيعات", "التحصيلات", "نسبة التحقيق"]}
          rows={managers.map((mg) => {
            const members = team.filter((p) => p.manager === mg.name);
            const sum = (k: "target" | "sales" | "collections") =>
              members.reduce((a, p) => a + metricsFor(s, p.name)[k], 0);
            return [
              <span className="font-bold">{mg.name}</span>,
              String(members.length),
              EGP(sum("target")),
              EGP(sum("sales")),
              EGP(sum("collections")),
              <span className="font-bold">{pct(sum("sales"), sum("target") || 1)}%</span>,
            ];
          })}
        />
      </Card>

      <Card title="ترتيب الموظفين">
        <DataTable
          head={["#", "الموظف", "المبيعات", "التحصيلات", "العمولة المستحقة", "نسبة التحقيق"]}
          rows={team
            .map((p) => ({ p, m: metricsFor(s, p.name) }))
            .sort((a, b) => b.m.sales - a.m.sales)
            .map(({ p, m }, i) => [
              <span className="font-extrabold text-primary">{i + 1}</span>,
              <span className="font-bold">{p.name}</span>,
              EGP(m.sales),
              EGP(m.collections),
              EGP(m.earned),
              <span className="font-bold">{pct(m.sales, m.target || 1)}%</span>,
            ])}
        />
      </Card>
    </>
  );
}
