import { createFileRoute } from "@tanstack/react-router";
import { Button, Card, DataTable, Field, Input, PageHeader, Timeline } from "@/components/kit";
import { CURRENCIES, TAX_RATE, useStore } from "@/lib/store";

export const Route = createFileRoute("/admin/settings")({
  head: () => ({
    meta: [
      { title: "إعدادات النظام | SalesTrack" },
      { name: "description", content: "إعدادات الضريبة والعملات ومسار الاعتماد وسجل العمليات." },
      { property: "og:title", content: "إعدادات النظام | SalesTrack" },
      { property: "og:description", content: "ضبط النظام ومسار الموافقات." },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const { s, reset } = useStore();

  return (
    <>
      <PageHeader title="الإعدادات" subtitle="القواعد العامة التي يعمل بها النظام" />

      <Card title="القواعد المالية">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="نسبة الضريبة (%)" hint="تُحسم لحساب صافي البيعة">
            <Input value={TAX_RATE} readOnly className="bg-muted" />
          </Field>
          <Field label="عملة التقارير" hint="كل العملات تُحوّل للجنيه في التقارير">
            <Input value="EGP" readOnly className="bg-muted" />
          </Field>
        </div>
      </Card>

      <Card title="أسعار التحويل الحالية" action={<span className="text-[11px] font-bold text-muted-foreground">تُعدّل من الإدارة المالية</span>}>
        <DataTable
          head={["العملة", "الكود", "1 وحدة = جنيه"]}
          rows={CURRENCIES.map((c) => [c.label, c.code, <span className="font-extrabold">{s.rateTable[c.code]}</span>])}
        />
      </Card>

      <Card title="مسار الاعتماد المعتمد">
        <DataTable
          head={["العملية", "الخطوة 1", "الخطوة 2", "الخطوة 3"]}
          rows={[
            ["البيعة", "تسجيل السيلز", "اعتماد مدير الفريق", "اعتماد الإدارة المالية"],
            ["التحصيل", "تسجيل السيلز", "مراجعة مدير الفريق", "اعتماد الإدارة المالية"],
            ["التارجت", "مدير الإدارة", "اعتماد الإدارة المالية", "ساري"],
            ["العمولة", "الإدارة المالية تحدد النسبة", "تُحسب على التحصيل المعتمد", "صرف من المالية"],
          ]}
        />
      </Card>

      <Card title="سجل العمليات">
        <Timeline steps={s.logs.slice(-12).reverse().map((l) => ({ at: l.at, by: l.by, action: l.action }))} />
      </Card>

      <Card title="بيانات الديمو">
        <p className="text-xs text-muted-foreground">
          كل التعديلات محفوظة على هذا الجهاز. يمكنك إرجاع الديمو لحالته الأصلية.
        </p>
        <div className="mt-4">
          <Button variant="outline" onClick={reset}>
            إعادة تعيين بيانات الديمو
          </Button>
        </div>
      </Card>
    </>
  );
}
