import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Target, TrendingUp } from "lucide-react";
import {
  Badge,
  Button,
  Card,
  DataTable,
  FlowStrip,
  Input,
  PageHeader,
  Progress,
  QuarterTabs,
  Stat,
  Timeline,
} from "@/components/kit";
import { EGP, pct, quarters, team } from "@/lib/mock";
import { STAGE_LABEL, STAGE_TONE, metricsFor, totalsOf, useStore } from "@/lib/store";

export const Route = createFileRoute("/admin/targets")({
  head: () => ({
    meta: [
      { title: "تحديد التارجت الربع سنوي | SalesTrack" },
      {
        name: "description",
        content: "مدير الإدارة يحدد ويعدّل تارجت كل موظف لكل ربع، والإدارة المالية تعتمده نهائياً.",
      },
      { property: "og:title", content: "تحديد التارجت الربع سنوي | SalesTrack" },
      { property: "og:description", content: "Q1 / Q2 / Q3 / Q4 لكل موظف مع مسار اعتماد." },
    ],
  }),
  component: TargetsPage,
});

function TargetsPage() {
  const { s, setTarget } = useStore();
  const [q, setQ] = useState("Q1");
  const [draft, setDraft] = useState<Record<string, string>>({});
  const t = totalsOf(s);

  const rowFor = (person: string) => s.targets.find((x) => x.person === person && x.quarter.startsWith(q));

  return (
    <>
      <PageHeader
        title="التارجت الربع سنوي"
        subtitle="أنت تحدد التارجت — لا يسري إلا بعد اعتماد الإدارة المالية"
        action={<QuarterTabs value={q} onChange={setQ} options={quarters} />}
      />

      <Card title="مسار التارجت">
        <FlowStrip steps={["مدير الإدارة يحدد", "اعتماد الإدارة المالية", "ساري على الفريق"]} active={0} />
      </Card>

      <div className="grid gap-4 sm:grid-cols-3">
        <Stat label={`إجمالي تارجت ${q} المعتمد`} value={EGP(t.target)} tone="brand" icon={<Target className="size-4" />} />
        <Stat label="المحقق" value={EGP(t.sales)} tone="success" icon={<TrendingUp className="size-4" />} />
        <Stat label="المتبقي" value={EGP(Math.max(t.target - t.sales, 0))} tone="warning" />
      </div>

      <Card title={`تارجت الموظفين — ${q}`}>
        <DataTable
          head={["الموظف", "التارجت الحالي", "الحالة", "المحقق", "نسبة التحقيق", "تارجت جديد", "إجراء"]}
          rows={team.map((p) => {
            const m = metricsFor(s, p.name);
            const row = rowFor(p.name);
            const key = p.name + q;
            return [
              <span className="font-bold">{p.name}</span>,
              EGP(row?.value ?? 0),
              row ? <Badge tone={STAGE_TONE[row.stage]}>{STAGE_LABEL[row.stage]}</Badge> : <Badge tone="warning">غير محدد</Badge>,
              EGP(m.sales),
              <div className="w-28">
                <Progress value={pct(m.sales, m.target || 1)} />
              </div>,
              <Input
                type="number"
                className="w-36"
                value={draft[key] ?? String(row?.value ?? "")}
                onChange={(e) => setDraft((d) => ({ ...d, [key]: e.target.value }))}
              />,
              <Button
                className="px-3 py-1.5"
                onClick={() => setTarget(p.name, `${q} 2026`, Number(draft[key] ?? row?.value ?? 0))}
              >
                إرسال للمالية
              </Button>,
            ];
          })}
        />
      </Card>

      <Card title="سجل تعديلات التارجت">
        <Timeline steps={s.targets.flatMap((x) => x.history).slice(-10).reverse()} />
      </Card>
    </>
  );
}
