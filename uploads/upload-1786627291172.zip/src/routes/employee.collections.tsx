import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, X } from "lucide-react";
import {
  Badge,
  Button,
  Card,
  DataTable,
  Empty,
  Field,
  FlowStrip,
  Input,
  Modal,
  PageHeader,
  Progress,
  Select,
  Stat,
  Timeline,
} from "@/components/kit";
import { EGP, pct } from "@/lib/mock";
import {
  ACTORS,
  STAGE_LABEL,
  STAGE_TONE,
  collectionAmount,
  collectionEGP,
  dealNet,
  metricsFor,
  money,
  useStore,
  type Collection,
} from "@/lib/store";

export const Route = createFileRoute("/employee/collections")({
  head: () => ({
    meta: [
      { title: "تسجيل التحصيلات | SalesTrack" },
      {
        name: "description",
        content: "سجّل دفعات التحصيل تفصيلياً بالمبلغ والطريقة والمرجع، وتابع اعتمادها من المالية.",
      },
      { property: "og:title", content: "تسجيل التحصيلات | SalesTrack" },
      { property: "og:description", content: "دفعات متعددة لكل تعاقد مع مسار اعتماد واضح." },
    ],
  }),
  component: CollectionsPage,
});

const me = ACTORS.employee.person;

function CollectionsPage() {
  const { s, addCollection } = useStore();
  const m = metricsFor(s, me);
  const [open, setOpen] = useState(false);
  const [detail, setDetail] = useState<Collection | null>(null);

  const myDeals = s.deals.filter((d) => d.stage === "approved" && (d.seller === me || d.partner?.name === me));
  const [dealId, setDealId] = useState(myDeals[0]?.id ?? "");
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState<Collection["method"]>("تحويل بنكي");
  const [ref, setRef] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));

  const deal = s.deals.find((d) => d.id === dealId);
  const mine = s.collections.filter((c) => c.seller === me);

  const save = () => {
    if (!dealId || Number(amount) <= 0) return;
    addCollection({ dealId, amount: Number(amount), method, ref: ref || "—", date });
    setAmount("");
    setRef("");
    setOpen(false);
  };

  return (
    <>
      <PageHeader
        title="التحصيلات"
        subtitle="كل دفعة تُراجع من مدير الفريق ثم تُعتمد نهائياً من الإدارة المالية"
        action={
          <Button onClick={() => setOpen((v) => !v)}>
            {open ? <X className="size-4" /> : <Plus className="size-4" />}
            {open ? "إغلاق" : "تسجيل دفعة"}
          </Button>
        }
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <Stat label="تحصيلات معتمدة" value={EGP(m.collections)} tone="success" />
        <Stat label="بانتظار الاعتماد" value={EGP(m.pendingCollections)} tone="warning" />
        <Stat label="متبقي في مشاريعي" value={EGP(m.outstanding)} tone="brand" />
      </div>

      <Card title="مسار التحصيل">
        <FlowStrip steps={["تسجيل الدفعة", "مراجعة مدير الفريق", "اعتماد المالية", "محصّل"]} active={0} />
      </Card>

      {open ? (
        <Card title="تسجيل دفعة تحصيل">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="التعاقد">
              <Select value={dealId} onChange={(e) => setDealId(e.target.value)}>
                {myDeals.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.id} — {d.client}
                  </option>
                ))}
              </Select>
            </Field>
            <Field
              label={`المبلغ (${deal?.currency ?? "EGP"})`}
              hint={
                deal
                  ? `صافي التعاقد: ${money(dealNet(deal), deal.currency)} — سجّل الصافي بدون الضريبة`
                  : undefined
              }
            >
              <Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="300000" />
            </Field>
            <Field label="طريقة الدفع">
              <Select value={method} onChange={(e) => setMethod(e.target.value as Collection["method"])}>
                <option>تحويل بنكي</option>
                <option>شيك</option>
                <option>نقدي</option>
              </Select>
            </Field>
            <Field label="رقم المرجع / الشيك">
              <Input value={ref} onChange={(e) => setRef(e.target.value)} placeholder="TRX-88213" />
            </Field>
            <Field label="تاريخ التحصيل">
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </Field>
          </div>
          <div className="mt-5 flex flex-wrap gap-2">
            <Button onClick={save}>إرسال للمراجعة</Button>
            <Button variant="outline" onClick={() => setOpen(false)}>
              إلغاء
            </Button>
          </div>
        </Card>
      ) : null}

      <Card title="تحصيل كل تعاقد">
        <div className="grid gap-4 sm:grid-cols-2">
          {myDeals.map((d) => {
            const done = s.collections
              .filter((c) => c.dealId === d.id && c.stage === "approved")
              .reduce((a, c) => a + collectionAmount(c), 0);
            return (
              <div key={d.id} className="rounded-2xl border border-border p-4">
                <p className="text-sm font-extrabold">{d.client}</p>
                <p className="text-[11px] text-muted-foreground">
                  {d.id} — {d.project}
                </p>
                <div className="mt-3">
                  <Progress
                    value={pct(done, dealNet(d))}
                    label={`${money(done, d.currency)} من ${money(dealNet(d), d.currency)}`}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      <Card title="سجل دفعاتي">
        {mine.length ? (
          <DataTable
            head={["كود", "التعاقد", "المبلغ المسجّل", "المعتمد", "بالجنيه", "الطريقة", "التاريخ", "الحالة", ""]}
            rows={mine.map((c) => [
              <span className="font-bold text-primary-deep">{c.id}</span>,
              c.dealId,
              money(c.amount, c.currency),
              c.financeAmount !== undefined && c.financeAmount !== c.amount ? (
                <span className="font-bold text-warning">{money(c.financeAmount, c.currency)}</span>
              ) : (
                money(collectionAmount(c), c.currency)
              ),
              EGP(collectionEGP(c)),
              c.method,
              c.date,
              <Badge tone={STAGE_TONE[c.stage]}>{STAGE_LABEL[c.stage]}</Badge>,
              <Button variant="ghost" className="px-3 py-1.5" onClick={() => setDetail(c)}>
                المسار
              </Button>,
            ])}
          />
        ) : (
          <Empty text="لا توجد دفعات مسجلة" />
        )}
      </Card>

      <Modal open={!!detail} onClose={() => setDetail(null)} title={`مسار التحصيل ${detail?.id ?? ""}`}>
        {detail ? (
          <div className="space-y-4">
            {detail.note ? (
              <p className="rounded-xl bg-warning/15 p-3 text-[11px] font-bold text-warning">
                ملاحظة المالية: {detail.note}
              </p>
            ) : null}
            <Timeline steps={detail.history} />
          </div>
        ) : null}
      </Modal>
    </>
  );
}
