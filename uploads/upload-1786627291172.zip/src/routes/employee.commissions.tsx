import { createFileRoute } from "@tanstack/react-router";
import { Badge, Card, DataTable, Empty, PageHeader, Progress, Stat } from "@/components/kit";
import { EGP, pct } from "@/lib/mock";
import { ACTORS, collectionEGP, metricsFor, useStore } from "@/lib/store";

export const Route = createFileRoute("/employee/commissions")({
  head: () => ({
    meta: [
      { title: "عمولاتي | SalesTrack" },
      { name: "description", content: "العمولة محسوبة على التحصيلات المعتمدة بنسبة تحددها الإدارة المالية." },
      { property: "og:title", content: "عمولاتي | SalesTrack" },
      { property: "og:description", content: "المستحق والمصروف والمتبقي من العمولة." },
    ],
  }),
  component: MyCommissions,
});

const me = ACTORS.employee.person;

function MyCommissions() {
  const { s } = useStore();
  const m = metricsFor(s, me);
  const approved = s.collections.filter((c) => c.seller === me && c.stage === "approved");

  return (
    <>
      <PageHeader
        title="عمولاتي"
        subtitle={`النسبة الحالية ${m.rate}% — تُصرف من الإدارة المالية على التحصيلات المعتمدة فقط`}
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <Stat label="أساس الحساب (تحصيلات معتمدة)" value={EGP(m.collections)} tone="brand" />
        <Stat label="المستحق" value={EGP(m.earned)} tone="success" />
        <Stat label="المتبقي" value={EGP(m.pendingCommission)} tone="warning" />
      </div>

      <Card title="حالة الصرف">
        <Progress value={pct(m.paid, m.earned || 1)} label={`مصروف ${EGP(m.paid)} من ${EGP(m.earned)}`} />
      </Card>

      <Card title="تفصيل العمولة على الدفعات المعتمدة">
        {approved.length ? (
          <DataTable
            head={["الدفعة", "التعاقد", "المبلغ بالجنيه", "النسبة", "عمولة الدفعة", "الحالة"]}
            rows={approved.map((c) => [
              <span className="font-bold text-primary-deep">{c.id}</span>,
              c.dealId,
              EGP(collectionEGP(c)),
              `${m.rate}%`,
              <span className="font-extrabold">{EGP((collectionEGP(c) * m.rate) / 100)}</span>,
              <Badge tone="success">معتمدة</Badge>,
            ])}
          />
        ) : (
          <Empty text="لا توجد تحصيلات معتمدة بعد" />
        )}
      </Card>
    </>
  );
}
