import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Coins, TrendingUp, Wallet } from "lucide-react";
import { Badge, Button, Card, DataTable, PageHeader, Progress, Ring, Stat } from "@/components/kit";
import { EGP, pct } from "@/lib/mock";
import { ACTORS, STAGE_LABEL, STAGE_TONE, dealNetEGP, metricsFor, useStore } from "@/lib/store";

export const Route = createFileRoute("/employee/")({
  head: () => ({
    meta: [
      { title: "لوحة السيلز | SalesTrack" },
      { name: "description", content: "تارجت الربع، مبيعاتك المعتمدة، تحصيلاتك وعمولتك في شاشة واحدة." },
      { property: "og:title", content: "لوحة السيلز | SalesTrack" },
      { property: "og:description", content: "متابعة يومية لأداء موظف المبيعات." },
    ],
  }),
  component: EmployeeHome,
});

const me = ACTORS.employee.person;

function EmployeeHome() {
  const { s } = useStore();
  const m = metricsFor(s, me);
  const mine = s.deals.filter((d) => d.seller === me || d.partner?.name === me);

  return (
    <>
      <PageHeader
        title={`أهلاً، ${me}`}
        subtitle="أنت مسؤول عن تسجيل البيعات والتحصيلات فقط — الاعتماد يتم من مدير الفريق والمالية"
        action={
          <Link to="/employee/sales">
            <Button>
              بيعة جديدة <ArrowLeft className="size-4" />
            </Button>
          </Link>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="التارجت المعتمد" value={EGP(m.target)} tone="brand" />
        <Stat label="مبيعات معتمدة" value={EGP(m.sales)} icon={<TrendingUp className="size-4" />} tone="success" />
        <Stat label="تحصيلات معتمدة" value={EGP(m.collections)} icon={<Wallet className="size-4" />} />
        <Stat label="عمولة مستحقة" value={EGP(m.pendingCommission)} icon={<Coins className="size-4" />} tone="warning" />
      </div>

      <div className="grid gap-4 lg:grid-cols-[320px_minmax(0,1fr)]">
        <Card title="نسبة تحقيق التارجت">
          <div className="grid place-items-center py-2">
            <Ring value={pct(m.sales, m.target || 1)} caption="من التارجت" />
          </div>
          <div className="mt-4 space-y-3">
            <Progress value={pct(m.collections, m.sales || 1)} label="نسبة التحصيل من المبيعات" />
            <Progress value={pct(m.paid, m.earned || 1)} label="نسبة العمولة المصروفة" />
          </div>
        </Card>

        <Card title="بيعاتي الأخيرة">
          <DataTable
            head={["كود", "العميل", "صافي بالجنيه", "نصيبي", "الحالة"]}
            rows={mine.slice(-6).reverse().map((d) => [
              <span className="font-bold text-primary-deep">{d.id}</span>,
              d.client,
              EGP(dealNetEGP(d)),
              <span className="font-bold">{d.seller === me ? d.share : (d.partner?.share ?? 0)}%</span>,
              <Badge tone={STAGE_TONE[d.stage]}>{STAGE_LABEL[d.stage]}</Badge>,
            ])}
          />
        </Card>
      </div>

      <Card title="قيد الاعتماد الآن">
        <DataTable
          head={["النوع", "المرجع", "القيمة", "المرحلة"]}
          rows={[
            ...s.deals
              .filter((d) => (d.seller === me || d.partner?.name === me) && d.stage !== "approved")
              .map((d) => ["بيعة", d.id, EGP(dealNetEGP(d)), <Badge tone={STAGE_TONE[d.stage]}>{STAGE_LABEL[d.stage]}</Badge>]),
            ...s.collections
              .filter((c) => c.seller === me && c.stage !== "approved")
              .map((c) => ["تحصيل", c.id, EGP(c.amount), <Badge tone={STAGE_TONE[c.stage]}>{STAGE_LABEL[c.stage]}</Badge>]),
          ]}
        />
      </Card>
    </>
  );
}
