import { createFileRoute } from "@tanstack/react-router";
import { Badge, Card, DataTable, Empty, PageHeader, Progress, Stat } from "@/components/kit";
import { EGP, pct } from "@/lib/mock";
import {
  ACTORS,
  STAGE_LABEL,
  STAGE_TONE,
  collectionAmount,
  dealNet,
  dealNetEGP,
  metricsFor,
  money,
  useStore,
} from "@/lib/store";

export const Route = createFileRoute("/employee/projects")({
  head: () => ({
    meta: [
      { title: "مشاريعي | SalesTrack" },
      { name: "description", content: "كل مشروع معتمد مع قيمته الصافية ونسبة التحصيل والمتبقي." },
      { property: "og:title", content: "مشاريعي | SalesTrack" },
      { property: "og:description", content: "متابعة تنفيذ وتحصيل المشاريع." },
    ],
  }),
  component: MyProjects,
});

const me = ACTORS.employee.person;

function MyProjects() {
  const { s } = useStore();
  const m = metricsFor(s, me);
  const mine = s.deals.filter((d) => d.seller === me || d.partner?.name === me);

  const collected = (dealId: string) =>
    s.collections
      .filter((c) => c.dealId === dealId && c.stage === "approved")
      .reduce((a, c) => a + collectionAmount(c), 0);

  return (
    <>
      <PageHeader title="مشاريعي" subtitle="القيمة المعروضة هي صافي البيعة بدون الضريبة" />

      <div className="grid gap-4 sm:grid-cols-3">
        <Stat label="إجمالي قيمة مشاريعي" value={EGP(m.sales)} tone="brand" />
        <Stat label="المحصل" value={EGP(m.collections)} tone="success" />
        <Stat label="المتبقي" value={EGP(m.outstanding)} tone="warning" />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {mine.map((d) => {
          const done = collected(d.id);
          return (
            <Card key={d.id}>
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="truncate text-sm font-extrabold">{d.project}</p>
                  <p className="truncate text-[11px] text-muted-foreground">
                    {d.client} — {d.id}
                  </p>
                </div>
                <Badge tone={STAGE_TONE[d.stage]}>{STAGE_LABEL[d.stage]}</Badge>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-3">
                {[
                  ["صافي البيعة", money(dealNet(d), d.currency)],
                  ["بالجنيه", EGP(dealNetEGP(d))],
                  ["المحصل", money(done, d.currency)],
                  ["المتبقي", money(Math.max(dealNet(d) - done, 0), d.currency)],
                ].map(([k, v]) => (
                  <div key={k} className="rounded-xl bg-muted/60 p-2.5">
                    <p className="text-[10px] font-bold text-muted-foreground">{k}</p>
                    <p className="mt-0.5 text-xs font-extrabold">{v}</p>
                  </div>
                ))}
              </div>
              <div className="mt-4">
                <Progress value={pct(done, dealNet(d))} label="نسبة التحصيل" />
              </div>
            </Card>
          );
        })}
      </div>

      <Card title="جدول المشاريع">
        {mine.length ? (
          <DataTable
            head={["كود", "المشروع", "العميل", "العملة", "صافي البيعة", "المحصل", "التاريخ", "الحالة"]}
            rows={mine.map((d) => [
              <span className="font-bold text-primary-deep">{d.id}</span>,
              d.project,
              d.client,
              d.currency,
              money(dealNet(d), d.currency),
              money(collected(d.id), d.currency),
              d.date,
              <Badge tone={STAGE_TONE[d.stage]}>{STAGE_LABEL[d.stage]}</Badge>,
            ])}
          />
        ) : (
          <Empty text="لا توجد مشاريع" />
        )}
      </Card>
    </>
  );
}
