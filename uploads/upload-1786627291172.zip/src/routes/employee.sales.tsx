import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, X } from "lucide-react";
import {
  Badge,
  Button,
  Card,
  DataTable,
  Empty,
  Field,
  FlowStrip,
  Input,
  Modal,
  PageHeader,
  Select,
  Timeline,
} from "@/components/kit";
import { EGP, team } from "@/lib/mock";
import {
  ACTORS,
  CURRENCIES,
  STAGE_LABEL,
  STAGE_TONE,
  TAX_RATE,
  dealNet,
  dealNetEGP,
  money,
  netOf,
  useStore,
  type Currency,
  type Deal,
} from "@/lib/store";

export const Route = createFileRoute("/employee/sales")({
  head: () => ({
    meta: [
      { title: "تسجيل البيعات | SalesTrack" },
      {
        name: "description",
        content:
          "سجّل بيعة جديدة بالعملة (جنيه/دولار/ريال) وصافي البيعة بدون الضريبة، وتابع مسار اعتمادها.",
      },
      { property: "og:title", content: "تسجيل البيعات | SalesTrack" },
      { property: "og:description", content: "بيعة ← مدير الفريق ← الإدارة المالية." },
    ],
  }),
  component: SalesPage,
});

const me = ACTORS.employee.person;

function stageIndex(d: Deal) {
  if (d.stage === "pending_manager" || d.stage === "rejected_manager") return 1;
  if (d.stage === "pending_finance" || d.stage === "rejected_finance") return 2;
  return 3;
}

function SalesPage() {
  const { s, addDeal } = useStore();
  const [open, setOpen] = useState(false);
  const [detail, setDetail] = useState<Deal | null>(null);

  const [client, setClient] = useState("");
  const [project, setProject] = useState("");
  const [currency, setCurrency] = useState<Currency>("EGP");
  const [gross, setGross] = useState("");
  const [taxIncluded, setTaxIncluded] = useState(false);
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));

  const amount = Number(gross) || 0;
  const net = netOf(amount, taxIncluded);
  const mine = s.deals.filter((d) => d.seller === me || d.partner?.name === me);

  const save = () => {
    if (!client || !project || amount <= 0) return;
    addDeal({ client, project, currency, gross: amount, taxIncluded, date });
    setClient("");
    setProject("");
    setGross("");
    setTaxIncluded(false);
    setOpen(false);
  };

  return (
    <>
      <PageHeader
        title="البيعات والتعاقدات"
        subtitle="أنت تسجّل البيعة فقط — الاعتماد لمدير الفريق ثم الإدارة المالية"
        action={
          <Button onClick={() => setOpen((v) => !v)}>
            {open ? <X className="size-4" /> : <Plus className="size-4" />}
            {open ? "إغلاق" : "بيعة جديدة"}
          </Button>
        }
      />

      <Card title="مسار البيعة">
        <FlowStrip
          steps={["تسجيل السيلز", "اعتماد مدير الفريق", "اعتماد الإدارة المالية", "معتمدة"]}
          active={0}
        />
      </Card>

      {open ? (
        <Card title="تسجيل بيعة جديدة">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="اسم العميل">
              <Input value={client} onChange={(e) => setClient(e.target.value)} placeholder="مثال: مجموعة النيل العقارية" />
            </Field>
            <Field label="اسم المشروع / الخدمة">
              <Input value={project} onChange={(e) => setProject(e.target.value)} placeholder="مثال: هوية بصرية + حملة إطلاق" />
            </Field>
            <Field label="عملة البيعة">
              <Select value={currency} onChange={(e) => setCurrency(e.target.value as Currency)}>
                {CURRENCIES.map((c) => (
                  <option key={c.code} value={c.code}>
                    {c.label} ({c.code}) — 1 {c.code} = {s.rateTable[c.code]} EGP
                  </option>
                ))}
              </Select>
            </Field>
            <Field
              label={`قيمة البيعة (${currency})`}
              hint={`صافي البيعة بدون الضريبة: ${money(net, currency)} — يعادل ${EGP(net * (s.rateTable[currency] ?? 1))}`}
            >
              <Input type="number" value={gross} onChange={(e) => setGross(e.target.value)} placeholder="1000000" />
            </Field>
            <Field label="تاريخ التعاقد">
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </Field>
            <Field label="المدير المباشر (تلقائي)">
              <Input value={ACTORS.manager.person} readOnly className="bg-muted" />
            </Field>
          </div>

          <label className="mt-4 flex cursor-pointer items-center gap-3 rounded-xl border border-border bg-muted/40 p-4 text-sm font-bold">
            <input
              type="checkbox"
              checked={taxIncluded}
              onChange={(e) => setTaxIncluded(e.target.checked)}
              className="size-4 accent-[var(--primary)]"
            />
            المبلغ المُدخل يشمل الضريبة ({TAX_RATE}%) — سيتم حسمها لحساب صافي البيعة
          </label>

          <p className="mt-3 rounded-xl bg-accent/60 p-3 text-[11px] font-bold text-primary-deep">
            إضافة مشارك من التيم يتم من مدير الفريق عند الاعتماد، وتعديل الصافي النهائي من الإدارة
            المالية.
          </p>

          <div className="mt-5 flex flex-wrap gap-2">
            <Button onClick={save}>إرسال للاعتماد</Button>
            <Button variant="outline" onClick={() => setOpen(false)}>
              إلغاء
            </Button>
          </div>
        </Card>
      ) : null}

      <Card title="بيعاتي">
        {mine.length ? (
          <DataTable
            head={["كود", "العميل", "العملة", "صافي البيعة", "بالجنيه", "نصيبي", "المشارك", "الحالة", ""]}
            rows={mine.map((d) => [
              <span className="font-bold text-primary-deep">{d.id}</span>,
              d.client,
              d.currency,
              money(dealNet(d), d.currency),
              EGP(dealNetEGP(d)),
              <span className="font-bold">{d.seller === me ? d.share : (d.partner?.share ?? 0)}%</span>,
              d.partner ? `${d.partner.name} (${d.partner.share}%)` : <span className="text-muted-foreground">—</span>,
              <Badge tone={STAGE_TONE[d.stage]}>{STAGE_LABEL[d.stage]}</Badge>,
              <Button variant="ghost" className="px-3 py-1.5" onClick={() => setDetail(d)}>
                المسار
              </Button>,
            ])}
          />
        ) : (
          <Empty text="لا توجد بيعات بعد — ابدأ بتسجيل بيعة جديدة" />
        )}
      </Card>

      <Card title="فريقي (المشاركة في البيعات)">
        <div className="flex flex-wrap gap-2 text-[11px] font-bold text-muted-foreground">
          {team.map((p) => (
            <span key={p.id} className="rounded-full bg-muted px-3 py-1.5">
              {p.name} — {p.title}
            </span>
          ))}
        </div>
      </Card>

      <Modal open={!!detail} onClose={() => setDetail(null)} title={`مسار البيعة ${detail?.id ?? ""}`}>
        {detail ? (
          <div className="space-y-4">
            <FlowStrip
              steps={["تسجيل السيلز", "مدير الفريق", "الإدارة المالية", "معتمدة"]}
              active={stageIndex(detail)}
            />
            <div className="grid grid-cols-2 gap-3 text-xs">
              {[
                ["المبلغ المسجّل", money(detail.gross, detail.currency)],
                ["صافي البيعة", money(dealNet(detail), detail.currency)],
                ["الحالة", STAGE_LABEL[detail.stage]],
                ["بالجنيه", EGP(dealNetEGP(detail))],
              ].map(([k, v]) => (
                <div key={k} className="rounded-xl bg-muted/60 p-2.5">
                  <p className="text-[10px] font-bold text-muted-foreground">{k}</p>
                  <p className="mt-0.5 font-extrabold">{v}</p>
                </div>
              ))}
            </div>
            {detail.note ? (
              <p className="rounded-xl bg-warning/15 p-3 text-[11px] font-bold text-warning">
                ملاحظة: {detail.note}
              </p>
            ) : null}
            <Timeline steps={detail.history} />
          </div>
        ) : null}
      </Modal>
    </>
  );
}
