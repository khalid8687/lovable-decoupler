import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  Badge,
  Button,
  Card,
  DataTable,
  Empty,
  Field,
  Input,
  Modal,
  PageHeader,
  Textarea,
  Timeline,
} from "@/components/kit";
import { EGP } from "@/lib/mock";
import {
  STAGE_LABEL,
  STAGE_TONE,
  TAX_RATE,
  collectionAmount,
  collectionEGP,
  money,
  useStore,
  type Collection,
} from "@/lib/store";

export const Route = createFileRoute("/finance/collections")({
  head: () => ({
    meta: [
      { title: "اعتماد التحصيلات | SalesTrack" },
      {
        name: "description",
        content: "مراجعة دفعات التحصيل التي سجّلها السيلز تفصيلياً، تعديل المبلغ، والاعتماد النهائي.",
      },
      { property: "og:title", content: "اعتماد التحصيلات | SalesTrack" },
      { property: "og:description", content: "الاعتماد النهائي للتحصيل عند الإدارة المالية." },
    ],
  }),
  component: FinanceCollections,
});

function FinanceCollections() {
  const { s, financeCollection } = useStore();
  const [open, setOpen] = useState<Collection | null>(null);
  const [amount, setAmount] = useState(0);
  const [note, setNote] = useState("");

  const start = (c: Collection) => {
    setOpen(c);
    setAmount(Math.round(collectionAmount(c)));
    setNote("");
  };

  const pending = s.collections.filter((c) => c.stage === "pending_finance");
  const deal = open ? s.deals.find((d) => d.id === open.dealId) : undefined;

  return (
    <>
      <PageHeader
        title="التحصيلات — الاعتماد النهائي"
        subtitle="مراجعة كل دفعة: المبلغ، طريقة الدفع، والمرجع البنكي"
      />

      <Card title={`بانتظار الاعتماد (${pending.length})`}>
        {pending.length ? (
          <DataTable
            head={["كود", "التعاقد", "العميل", "السيلز", "المبلغ", "بالجنيه", "الطريقة", "المرجع", "إجراء"]}
            rows={pending.map((c) => [
              <span className="font-bold text-primary-deep">{c.id}</span>,
              c.dealId,
              c.client,
              c.seller,
              money(collectionAmount(c), c.currency),
              EGP(collectionEGP(c)),
              c.method,
              <span className="text-muted-foreground">{c.ref}</span>,
              <Button className="px-3 py-1.5" onClick={() => start(c)}>
                مراجعة
              </Button>,
            ])}
          />
        ) : (
          <Empty text="لا توجد تحصيلات بانتظار المالية" />
        )}
      </Card>

      <Card title="كل الدفعات">
        <DataTable
          head={["كود", "التعاقد", "السيلز", "المبلغ", "بالجنيه", "التاريخ", "الحالة", "السجل"]}
          rows={s.collections.map((c) => [
            <span className="font-bold text-primary-deep">{c.id}</span>,
            c.dealId,
            c.seller,
            money(collectionAmount(c), c.currency),
            EGP(collectionEGP(c)),
            c.date,
            <Badge tone={STAGE_TONE[c.stage]}>{STAGE_LABEL[c.stage]}</Badge>,
            <Button variant="ghost" className="px-3 py-1.5" onClick={() => start(c)}>
              تفاصيل
            </Button>,
          ])}
        />
      </Card>

      <Modal open={!!open} onClose={() => setOpen(null)} title={`مراجعة تحصيل — ${open?.id ?? ""}`}>
        {open ? (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 text-xs">
              {[
                ["التعاقد", open.dealId],
                ["العميل", open.client],
                ["السيلز", open.seller],
                ["مدير الفريق", open.manager],
                ["طريقة الدفع", open.method],
                ["المرجع", open.ref],
                ["التاريخ", open.date],
                ["المبلغ المسجّل", money(open.amount, open.currency)],
              ].map(([k, v]) => (
                <div key={k} className="rounded-xl bg-muted/60 p-2.5">
                  <p className="text-[10px] font-bold text-muted-foreground">{k}</p>
                  <p className="mt-0.5 font-extrabold">{v}</p>
                </div>
              ))}
            </div>

            {deal ? (
              <p className="rounded-xl bg-accent/60 p-3 text-[11px] font-bold text-primary-deep">
                صافي التعاقد المعتمد: {money(deal.financeNet ?? deal.net, deal.currency)} — إجمالي
                المحصل المعتمد لهذا التعاقد:{" "}
                {money(
                  s.collections
                    .filter((x) => x.dealId === deal.id && x.stage === "approved")
                    .reduce((a, x) => a + collectionAmount(x), 0),
                  deal.currency,
                )}
              </p>
            ) : null}

            <Field label={`المبلغ النهائي المعتمد (${open.currency})`}>
              <Input type="number" value={amount} onChange={(e) => setAmount(Number(e.target.value) || 0)} />
            </Field>
            <Button
              variant="outline"
              className="px-3 py-1.5"
              onClick={() => setAmount(Math.round(open.amount / (1 + TAX_RATE / 100)))}
            >
              حسم الضريبة {TAX_RATE}%
            </Button>

            <Field label="ملاحظة (تظهر للسيلز ومدير الفريق)">
              <Textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="سبب التعديل أو الرفض" />
            </Field>

            {open.stage === "pending_finance" ? (
              <div className="flex flex-wrap gap-2">
                <Button
                  onClick={() => {
                    financeCollection(open.id, true, { amount, ...(note ? { note } : {}) });
                    setOpen(null);
                  }}
                >
                  اعتماد نهائي
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    financeCollection(open.id, false, { note: note || "مرفوض — مرجع غير مطابق" });
                    setOpen(null);
                  }}
                >
                  رفض
                </Button>
              </div>
            ) : (
              <p className="rounded-xl bg-muted/60 p-3 text-[11px] font-bold text-muted-foreground">
                الحالة الحالية: {STAGE_LABEL[open.stage]}
              </p>
            )}

            <div>
              <p className="mb-2 text-xs font-extrabold">مسار الاعتماد</p>
              <Timeline steps={open.history} />
            </div>
          </div>
        ) : null}
      </Modal>
    </>
  );
}
