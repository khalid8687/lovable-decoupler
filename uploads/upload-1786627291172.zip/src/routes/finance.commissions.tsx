import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Button, Card, DataTable, Field, Input, Modal, PageHeader, Stat } from "@/components/kit";
import { EGP, team } from "@/lib/mock";
import { metricsFor, totalsOf, useStore } from "@/lib/store";

export const Route = createFileRoute("/finance/commissions")({
  head: () => ({
    meta: [
      { title: "العمولات وصرفها | SalesTrack" },
      {
        name: "description",
        content: "الإدارة المالية تحدد نسبة العمولة لكل موظف وتصرفها على أساس التحصيلات المعتمدة.",
      },
      { property: "og:title", content: "العمولات وصرفها | SalesTrack" },
      { property: "og:description", content: "نسب العمولة + الصرف + المتبقي." },
    ],
  }),
  component: FinanceCommissions,
});

function FinanceCommissions() {
  const { s, setRate, payCommission } = useStore();
  const t = totalsOf(s);
  const [draft, setDraft] = useState<Record<string, number>>({});
  const [pay, setPay] = useState<{ person: string; max: number } | null>(null);
  const [amount, setAmount] = useState(0);

  return (
    <>
      <PageHeader
        title="العمولات"
        subtitle="العمولة تُحسب على التحصيلات المعتمدة فقط — النسبة تحددها الإدارة المالية"
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <Stat label="إجمالي العمولات المستحقة" value={EGP(t.earned)} tone="brand" />
        <Stat label="المصروف" value={EGP(t.paid)} tone="success" />
        <Stat label="المتبقي للصرف" value={EGP(t.pendingCommission)} tone="warning" />
      </div>

      <Card title="نسب وعمولات الموظفين">
        <DataTable
          head={[
            "الموظف",
            "تحصيلات معتمدة",
            "نسبة العمولة %",
            "المستحق",
            "المصروف",
            "المتبقي",
            "إجراء",
          ]}
          rows={team.map((p) => {
            const m = metricsFor(s, p.name);
            const value = draft[p.name] ?? m.rate;
            return [
              <span className="font-bold">{p.name}</span>,
              EGP(m.collections),
              <Input
                type="number"
                step="0.1"
                value={value}
                className="w-24"
                onChange={(e) => setDraft((d) => ({ ...d, [p.name]: Number(e.target.value) || 0 }))}
              />,
              EGP(m.earned),
              EGP(m.paid),
              <span className="font-bold text-warning">{EGP(m.pendingCommission)}</span>,
              <div className="flex gap-2">
                <Button
                  className="px-3 py-1.5"
                  onClick={() => setRate(p.name, draft[p.name] ?? m.rate)}
                >
                  حفظ النسبة
                </Button>
                <Button
                  variant="outline"
                  className="px-3 py-1.5"
                  onClick={() => {
                    setPay({ person: p.name, max: Math.round(m.pendingCommission) });
                    setAmount(Math.round(m.pendingCommission));
                  }}
                >
                  صرف
                </Button>
              </div>,
            ];
          })}
        />
      </Card>

      <Modal open={!!pay} onClose={() => setPay(null)} title={`صرف عمولة — ${pay?.person ?? ""}`}>
        {pay ? (
          <div className="space-y-4">
            <Field label="المبلغ المصروف (EGP)" hint={`المتبقي المستحق: ${EGP(pay.max)}`}>
              <Input type="number" value={amount} onChange={(e) => setAmount(Number(e.target.value) || 0)} />
            </Field>
            <div className="flex gap-2">
              <Button
                onClick={() => {
                  payCommission(pay.person, amount);
                  setPay(null);
                }}
              >
                تأكيد الصرف
              </Button>
              <Button variant="ghost" onClick={() => setPay(null)}>
                إلغاء
              </Button>
            </div>
          </div>
        ) : null}
      </Modal>
    </>
  );
}
