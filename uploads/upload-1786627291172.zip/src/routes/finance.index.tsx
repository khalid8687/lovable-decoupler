import { createFileRoute, Link } from "@tanstack/react-router";
import { Coins, FileSignature, Target, Wallet, Percent, Clock } from "lucide-react";
import { Badge, Button, Card, DataTable, Empty, Field, Input, PageHeader, Stat } from "@/components/kit";
import { EGP, compact, pct } from "@/lib/mock";
import {
  CURRENCIES,
  STAGE_LABEL,
  collectionAmount,
  dealNet,
  money,
  queues,
  totalsOf,
  useStore,
} from "@/lib/store";

export const Route = createFileRoute("/finance/")({
  head: () => ({
    meta: [
      { title: "لوحة الإدارة المالية | SalesTrack" },
      {
        name: "description",
        content: "الاعتماد النهائي لصافي البيعات والتحصيلات والعمولات والتارجت مع أسعار العملات.",
      },
      { property: "og:title", content: "لوحة الإدارة المالية | SalesTrack" },
      { property: "og:description", content: "كل خطوة تنتهي عند الإدارة المالية." },
    ],
  }),
  component: FinanceHome,
});

function FinanceHome() {
  const { s, setFxRate } = useStore();
  const q = queues(s);
  const t = totalsOf(s);

  return (
    <>
      <PageHeader
        title="لوحة الإدارة المالية"
        subtitle="القرار النهائي في البيعات والتحصيلات والتارجت والعمولات"
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat
          label="بيعات بانتظار الاعتماد النهائي"
          value={String(q.financeDeals.length)}
          tone="brand"
          icon={<FileSignature className="size-4" />}
        />
        <Stat
          label="تحصيلات بانتظار الاعتماد"
          value={String(q.financeCollections.length)}
          tone="warning"
          icon={<Wallet className="size-4" />}
        />
        <Stat
          label="تارجت بانتظار الاعتماد"
          value={String(q.financeTargets.length)}
          icon={<Target className="size-4" />}
        />
        <Stat
          label="عمولات مستحقة للصرف"
          value={EGP(t.pendingCommission)}
          icon={<Percent className="size-4" />}
        />
        <Stat label="صافي المبيعات المعتمدة" value={EGP(t.sales)} tone="success" />
        <Stat label="تحصيلات معتمدة" value={EGP(t.collections)} tone="success" />
        <Stat label="متبقي في التحصيل" value={EGP(t.outstanding)} tone="warning" icon={<Clock className="size-4" />} />
        <Stat
          label="نسبة تحقيق القسم"
          value={pct(t.sales, t.target) + "%"}
          hint={`${compact(t.sales)} من ${compact(t.target)}`}
        />
      </div>

      <Card
        title="طلبات بيعات بانتظارك"
        action={
          <Link to="/finance/sales">
            <Button variant="outline" className="px-3 py-1.5">
              فتح الكل
            </Button>
          </Link>
        }
      >
        {q.financeDeals.length ? (
          <DataTable
            head={["كود", "العميل", "السيلز", "العملة", "صافي البيعة", "الحالة"]}
            rows={q.financeDeals.map((d) => [
              <span className="font-bold text-primary-deep">{d.id}</span>,
              d.client,
              d.seller,
              d.currency,
              money(dealNet(d), d.currency),
              <Badge tone="brand">{STAGE_LABEL[d.stage]}</Badge>,
            ])}
          />
        ) : (
          <Empty text="لا توجد بيعات بانتظار الاعتماد النهائي" />
        )}
      </Card>

      <Card
        title="تحصيلات بانتظارك"
        action={
          <Link to="/finance/collections">
            <Button variant="outline" className="px-3 py-1.5">
              فتح الكل
            </Button>
          </Link>
        }
      >
        {q.financeCollections.length ? (
          <DataTable
            head={["كود", "التعاقد", "السيلز", "المبلغ", "الطريقة", "التاريخ"]}
            rows={q.financeCollections.map((c) => [
              <span className="font-bold text-primary-deep">{c.id}</span>,
              c.dealId,
              c.seller,
              money(collectionAmount(c), c.currency),
              c.method,
              c.date,
            ])}
          />
        ) : (
          <Empty text="لا توجد تحصيلات بانتظار الاعتماد" />
        )}
      </Card>

      <Card title="أسعار تحويل العملات (Rate)" action={<Coins className="size-4 text-primary" />}>
        <div className="grid gap-4 sm:grid-cols-3">
          {CURRENCIES.map((c) => (
            <Field key={c.code} label={`${c.label} (${c.code}) = ؟ EGP`}>
              <Input
                type="number"
                step="0.01"
                value={s.rateTable[c.code]}
                disabled={c.code === "EGP"}
                onChange={(e) => setFxRate(c.code, Number(e.target.value) || 0)}
              />
            </Field>
          ))}
        </div>
        <p className="mt-3 text-[11px] font-semibold text-muted-foreground">
          كل المبالغ بالدولار أو الريال تُحوّل تلقائياً للجنيه المصري بهذه الأسعار عند حساب التارجت
          والعمولة.
        </p>
      </Card>
    </>
  );
}
