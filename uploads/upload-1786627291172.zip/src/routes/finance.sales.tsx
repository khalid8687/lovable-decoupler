import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  Badge,
  Button,
  Card,
  DataTable,
  Empty,
  Field,
  Input,
  Modal,
  PageHeader,
  Textarea,
  Timeline,
} from "@/components/kit";
import { EGP } from "@/lib/mock";
import {
  STAGE_LABEL,
  STAGE_TONE,
  TAX_RATE,
  dealNet,
  dealNetEGP,
  money,
  netOf,
  useStore,
  type Deal,
} from "@/lib/store";

export const Route = createFileRoute("/finance/sales")({
  head: () => ({
    meta: [
      { title: "صافي البيعات والاعتماد النهائي | SalesTrack" },
      {
        name: "description",
        content: "مراجعة صافي البيعة بدون ضريبة، تعديل المبلغ إذا سجّله الموظف خطأ، واعتماده نهائياً.",
      },
      { property: "og:title", content: "صافي البيعات والاعتماد النهائي | SalesTrack" },
      { property: "og:description", content: "الاعتماد المالي النهائي لكل تعاقد." },
    ],
  }),
  component: FinanceSales,
});

function FinanceSales() {
  const { s, financeDeal } = useStore();
  const [open, setOpen] = useState<Deal | null>(null);
  const [net, setNet] = useState(0);
  const [note, setNote] = useState("");

  const start = (d: Deal) => {
    setOpen(d);
    setNet(Math.round(dealNet(d)));
    setNote("");
  };

  const pending = s.deals.filter((d) => d.stage === "pending_finance");

  return (
    <>
      <PageHeader
        title="صافي البيعات — الاعتماد النهائي"
        subtitle={`الصافي = القيمة بدون الضريبة (${TAX_RATE}%) — للمالية حق تعديل المبلغ الذي سجّله السيلز`}
      />

      <Card title={`بانتظار الاعتماد النهائي (${pending.length})`}>
        {pending.length ? (
          <DataTable
            head={[
              "كود",
              "العميل",
              "السيلز",
              "المشارك",
              "العملة",
              "المسجّل",
              "صافي البيعة",
              "بالجنيه",
              "إجراء",
            ]}
            rows={pending.map((d) => [
              <span className="font-bold text-primary-deep">{d.id}</span>,
              d.client,
              d.seller,
              d.partner ? `${d.partner.name} (${d.partner.share}%)` : <span className="text-muted-foreground">—</span>,
              d.currency,
              <span className={d.taxIncluded ? "font-bold text-warning" : ""}>
                {money(d.gross, d.currency)}
                {d.taxIncluded ? " (بالضريبة)" : ""}
              </span>,
              <span className="font-bold">{money(dealNet(d), d.currency)}</span>,
              EGP(dealNetEGP(d)),
              <Button className="px-3 py-1.5" onClick={() => start(d)}>
                مراجعة واعتماد
              </Button>,
            ])}
          />
        ) : (
          <Empty text="لا توجد بيعات بانتظار المالية" />
        )}
      </Card>

      <Card title="كل التعاقدات">
        <DataTable
          head={["كود", "العميل", "السيلز", "العملة", "صافي البيعة", "بالجنيه", "الحالة", "السجل"]}
          rows={s.deals.map((d) => [
            <span className="font-bold text-primary-deep">{d.id}</span>,
            d.client,
            d.seller,
            d.currency,
            money(dealNet(d), d.currency),
            EGP(dealNetEGP(d)),
            <Badge tone={STAGE_TONE[d.stage]}>{STAGE_LABEL[d.stage]}</Badge>,
            <Button variant="ghost" className="px-3 py-1.5" onClick={() => start(d)}>
              تفاصيل
            </Button>,
          ])}
        />
      </Card>

      <Modal open={!!open} onClose={() => setOpen(null)} title={`مراجعة مالية — ${open?.id ?? ""}`}>
        {open ? (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 text-xs">
              {[
                ["العميل", open.client],
                ["المشروع", open.project],
                ["السيلز", open.seller],
                ["مدير الفريق", open.manager],
                ["العملة", open.currency],
                ["المبلغ المسجّل", money(open.gross, open.currency)],
                ["مسجّل بالضريبة؟", open.taxIncluded ? "نعم — تم الحسم" : "لا — صافي"],
                ["صافي محسوب", money(netOf(open.gross, open.taxIncluded), open.currency)],
              ].map(([k, v]) => (
                <div key={k} className="rounded-xl bg-muted/60 p-2.5">
                  <p className="text-[10px] font-bold text-muted-foreground">{k}</p>
                  <p className="mt-0.5 font-extrabold">{v}</p>
                </div>
              ))}
            </div>

            <Field
              label={`صافي البيعة النهائي (${open.currency}) — بدون الضريبة`}
              hint={`يعادل ${EGP(net * (s.rateTable[open.currency] ?? 1))} بسعر ${s.rateTable[open.currency]}`}
            >
              <Input type="number" value={net} onChange={(e) => setNet(Number(e.target.value) || 0)} />
            </Field>

            <div className="flex flex-wrap gap-2">
              <Button variant="outline" className="px-3 py-1.5" onClick={() => setNet(Math.round(open.gross / (1 + TAX_RATE / 100)))}>
                حسم الضريبة {TAX_RATE}%
              </Button>
              <Button variant="ghost" className="px-3 py-1.5" onClick={() => setNet(Math.round(open.gross))}>
                إرجاع المبلغ كما هو
              </Button>
            </div>

            <Field label="ملاحظة للسيلز (تظهر له في سجل البيعة)">
              <Textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="مثال: المبلغ كان بالضريبة، تم حسم 14% ليصبح صافي البيعة."
              />
            </Field>

            {open.stage === "pending_finance" ? (
              <div className="flex flex-wrap gap-2">
                <Button
                  onClick={() => {
                    financeDeal(open.id, true, { net, ...(note ? { note } : {}) });
                    setOpen(null);
                  }}
                >
                  اعتماد نهائي
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    financeDeal(open.id, false, { note: note || "إرجاع للتعديل" });
                    setOpen(null);
                  }}
                >
                  إرجاع للتعديل
                </Button>
              </div>
            ) : (
              <p className="rounded-xl bg-muted/60 p-3 text-[11px] font-bold text-muted-foreground">
                الحالة الحالية: {STAGE_LABEL[open.stage]}
              </p>
            )}

            <div>
              <p className="mb-2 text-xs font-extrabold">مسار الاعتماد</p>
              <Timeline steps={open.history} />
            </div>
          </div>
        ) : null}
      </Modal>
    </>
  );
}
