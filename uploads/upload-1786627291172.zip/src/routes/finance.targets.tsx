import { createFileRoute } from "@tanstack/react-router";
import { Badge, Button, Card, DataTable, Empty, PageHeader, Timeline } from "@/components/kit";
import { EGP } from "@/lib/mock";
import { STAGE_LABEL, STAGE_TONE, useStore } from "@/lib/store";

export const Route = createFileRoute("/finance/targets")({
  head: () => ({
    meta: [
      { title: "اعتماد التارجت | SalesTrack" },
      {
        name: "description",
        content: "مدير الإدارة يحدد التارجت والإدارة المالية تعتمده نهائياً قبل أن يصبح ساري.",
      },
      { property: "og:title", content: "اعتماد التارجت | SalesTrack" },
      { property: "og:description", content: "التارجت لا يسري إلا بعد اعتماد المالية." },
    ],
  }),
  component: FinanceTargets,
});

function FinanceTargets() {
  const { s, financeTarget } = useStore();
  const pending = s.targets.filter((t) => t.stage === "pending_finance");

  return (
    <>
      <PageHeader
        title="التارجت — الاعتماد النهائي"
        subtitle="أي تارجت يحدده أو يعدّله مدير الإدارة يصل هنا أولاً"
      />

      <Card title={`بانتظار الاعتماد (${pending.length})`}>
        {pending.length ? (
          <DataTable
            head={["الموظف", "الربع", "التارجت", "حدده", "إجراء"]}
            rows={pending.map((t) => [
              <span className="font-bold">{t.person}</span>,
              t.quarter,
              <span className="font-extrabold">{EGP(t.value)}</span>,
              <span className="text-muted-foreground">{t.setBy}</span>,
              <div className="flex gap-2">
                <Button className="px-3 py-1.5" onClick={() => financeTarget(t.id, true)}>
                  اعتماد
                </Button>
                <Button variant="ghost" className="px-3 py-1.5" onClick={() => financeTarget(t.id, false)}>
                  رفض
                </Button>
              </div>,
            ])}
          />
        ) : (
          <Empty text="لا يوجد تارجت بانتظار الاعتماد" />
        )}
      </Card>

      <Card title="كل التارجت المسجّل">
        <DataTable
          head={["الموظف", "الربع", "القيمة", "الحالة"]}
          rows={s.targets.map((t) => [
            <span className="font-bold">{t.person}</span>,
            t.quarter,
            EGP(t.value),
            <Badge tone={STAGE_TONE[t.stage]}>{STAGE_LABEL[t.stage]}</Badge>,
          ])}
        />
      </Card>

      <Card title="آخر التعديلات على التارجت">
        <Timeline steps={s.targets.flatMap((t) => t.history).slice(-8).reverse()} />
      </Card>
    </>
  );
}
