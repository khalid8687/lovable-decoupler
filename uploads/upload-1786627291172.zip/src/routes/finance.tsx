import { createFileRoute, Outlet } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";

export const Route = createFileRoute("/finance")({
  component: () => (
    <AppShell role="finance">
      <Outlet />
    </AppShell>
  ),
});
