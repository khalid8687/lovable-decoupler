import { createFileRoute, Link } from "@tanstack/react-router";
import {
  User,
  Users,
  LifeBuoy,
  ShieldCheck,
  ArrowLeft,
  Coins,
  Target,
  Wallet,
  Percent,
} from "lucide-react";
import logo from "@/assets/logo.png";
import hero from "@/assets/hero-sales.png";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SalesTrack — اختيار الدور | نظام إدارة ومتابعة المبيعات" },
      {
        name: "description",
        content:
          "ابدأ من بوابتك: السيلز، مدير الفريق، مدير الإدارة، الإدارة المالية، أو الدعم الفني — دورة كاملة من البيعة حتى العمولة.",
      },
      { property: "og:title", content: "SalesTrack — نظام إدارة ومتابعة المبيعات" },
      {
        property: "og:description",
        content: "بيعة السيلز ← اعتماد مدير الفريق ← الاعتماد النهائي من الإدارة المالية.",
      },
    ],
  }),
  component: RoleSelect,
});

const roles = [
  {
    to: "/employee",
    icon: User,
    title: "السيلز",
    en: "Sales Person",
    desc: "تسجيل البيعة بالعملة الصحيحة وصافيها بدون ضريبة، وتسجيل دفعات التحصيل.",
  },
  {
    to: "/manager",
    icon: Users,
    title: "مدير الفريق",
    en: "Sales Manager",
    desc: "اعتماد بيعات الفريق، إضافة مشارك من التيم بنسبته، ومراجعة التحصيلات.",
  },
  {
    to: "/admin",
    icon: ShieldCheck,
    title: "مدير الإدارة",
    en: "Sales Director",
    desc: "تحديد وتعديل التارجت الربع سنوي لكل موظف ومتابعة القسم بالكامل.",
  },
  {
    to: "/finance",
    icon: Coins,
    title: "الإدارة المالية",
    en: "Finance",
    desc: "الاعتماد النهائي: صافي البيعة، حسم الضريبة، التحصيلات، العمولات والتارجت.",
  },
  {
    to: "/support",
    icon: LifeBuoy,
    title: "الدعم الفني",
    en: "Support",
    desc: "طلبات التعديل والصلاحيات وتتبع كل عملية في سجل النظام.",
  },
] as const;

const flow = [
  "السيلز يسجّل البيعة/التحصيل",
  "مدير الفريق يعتمد ويضيف المشارك",
  "مدير الإدارة يحدد التارجت",
  "الإدارة المالية = الاعتماد النهائي",
];

function RoleSelect() {
  return (
    <div className="min-h-screen bg-background">
      <div className="brand-gradient px-4 pt-10 pb-24 text-primary-foreground sm:px-6 sm:pt-14">
        <div className="mx-auto grid max-w-6xl items-center gap-8 lg:grid-cols-[minmax(0,1fr)_auto]">
          <div className="min-w-0">
            <div className="flex items-center gap-3">
              <img
                src={logo}
                alt="شعار SalesTrack"
                width={52}
                height={52}
                className="size-13 shrink-0 rounded-2xl bg-white/90 p-1"
              />
              <div className="min-w-0">
                <p className="text-lg font-extrabold sm:text-xl">SalesTrack</p>
                <p className="text-[11px] font-semibold opacity-85">إدارة ومتابعة المبيعات</p>
              </div>
            </div>
            <h1 className="mt-6 text-2xl leading-snug font-extrabold sm:text-4xl">
              دورة عمل دقيقة من البيعة حتى العمولة
            </h1>
            <p className="mt-3 max-w-xl text-sm opacity-90 sm:text-base">
              كل خطوة تمر بمسار اعتماد واضح، والقرار النهائي دائماً عند الإدارة المالية. اختر بوابتك
              للبدء.
            </p>
            <div className="mt-6 flex flex-wrap gap-2 text-[11px] font-bold">
              {[
                { icon: Target, t: "Quarterly Target" },
                { icon: Wallet, t: "Collections Approval" },
                { icon: Percent, t: "Commissions" },
                { icon: Coins, t: "EGP / USD / SAR" },
              ].map((c) => (
                <span
                  key={c.t}
                  className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-3 py-1.5"
                >
                  <c.icon className="size-3.5" />
                  {c.t}
                </span>
              ))}
            </div>
          </div>
          <img
            src={hero}
            alt="فريق مبيعات يتابع لوحة الأداء"
            width={420}
            height={420}
            className="mx-auto hidden w-[340px] max-w-full lg:block"
          />
        </div>
      </div>

      <div className="mx-auto -mt-16 max-w-6xl px-4 pb-14 sm:px-6">
        <div className="card-surface mb-5 p-5">
          <h2 className="mb-3 text-sm font-extrabold">مسار الاعتماد داخل النظام</h2>
          <div className="no-scrollbar flex flex-wrap items-center gap-2 overflow-x-auto">
            {flow.map((f, i) => (
              <span key={f} className="flex items-center gap-2">
                <span className="brand-gradient-soft rounded-full px-3 py-1.5 text-[11px] font-bold text-primary-deep">
                  {i + 1}. {f}
                </span>
                {i < flow.length - 1 ? <span className="text-muted-foreground">←</span> : null}
              </span>
            ))}
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {roles.map((r) => (
            <Link
              key={r.to}
              to={r.to}
              className="card-surface group flex flex-col gap-3 p-5 transition-all hover:-translate-y-1 hover:shadow-[var(--shadow-float)]"
            >
              <span className="brand-gradient-soft grid size-12 place-items-center rounded-2xl text-primary-deep">
                <r.icon className="size-6" />
              </span>
              <div>
                <h2 className="text-base font-extrabold">{r.title}</h2>
                <p className="text-[11px] font-bold text-primary">{r.en}</p>
              </div>
              <p className="text-xs leading-relaxed text-muted-foreground">{r.desc}</p>
              <span className="mt-auto inline-flex items-center gap-1.5 pt-2 text-xs font-bold text-primary-deep">
                دخول
                <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-1" />
              </span>
            </Link>
          ))}
        </div>
        <p className="mt-8 text-center text-[11px] text-muted-foreground">
          عرض تجريبي تفاعلي — كل الأزرار تعمل والبيانات تنتقل فعلياً بين البوابات الخمس.
        </p>
      </div>
    </div>
  );
}
