import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  Badge,
  Button,
  Card,
  DataTable,
  Empty,
  Field,
  FlowStrip,
  Modal,
  PageHeader,
  Textarea,
  Timeline,
} from "@/components/kit";
import { EGP } from "@/lib/mock";
import {
  ACTORS,
  STAGE_LABEL,
  STAGE_TONE,
  collectionAmount,
  collectionEGP,
  money,
  useStore,
  type Collection,
} from "@/lib/store";

export const Route = createFileRoute("/manager/collections")({
  head: () => ({
    meta: [
      { title: "مراجعة تحصيلات الفريق | SalesTrack" },
      { name: "description", content: "مدير الفريق يراجع دفعات التحصيل قبل إرسالها للاعتماد النهائي في المالية." },
      { property: "og:title", content: "مراجعة تحصيلات الفريق | SalesTrack" },
      { property: "og:description", content: "مراجعة الدفعات وطرق الدفع والمراجع البنكية." },
    ],
  }),
  component: ManagerCollections,
});

const meManager = ACTORS.manager.person;

function ManagerCollections() {
  const { s, managerCollection } = useStore();
  const [open, setOpen] = useState<Collection | null>(null);
  const [note, setNote] = useState("");

  const mine = s.collections.filter((c) => c.manager === meManager);
  const pending = mine.filter((c) => c.stage === "pending_manager");

  return (
    <>
      <PageHeader title="تحصيلات الفريق" subtitle="مراجعة الدفعات ثم تحويلها للإدارة المالية" />

      <Card title="مسار التحصيل">
        <FlowStrip steps={["تسجيل السيلز", "مراجعة مدير الفريق", "اعتماد المالية", "محصّل"]} active={1} />
      </Card>

      <Card title={`بانتظار مراجعتك (${pending.length})`}>
        {pending.length ? (
          <DataTable
            head={["كود", "التعاقد", "الموظف", "المبلغ", "بالجنيه", "الطريقة", "المرجع", "إجراء"]}
            rows={pending.map((c) => [
              <span className="font-bold text-primary-deep">{c.id}</span>,
              c.dealId,
              c.seller,
              money(collectionAmount(c), c.currency),
              EGP(collectionEGP(c)),
              c.method,
              <span className="text-muted-foreground">{c.ref}</span>,
              <div className="flex gap-2">
                <Button className="px-3 py-1.5" onClick={() => managerCollection(c.id, true)}>
                  تحويل للمالية
                </Button>
                <Button
                  variant="ghost"
                  className="px-3 py-1.5"
                  onClick={() => {
                    setOpen(c);
                    setNote("");
                  }}
                >
                  تفاصيل
                </Button>
              </div>,
            ])}
          />
        ) : (
          <Empty text="لا توجد دفعات بانتظار المراجعة" />
        )}
      </Card>

      <Card title="كل دفعات الفريق">
        <DataTable
          head={["كود", "التعاقد", "الموظف", "المبلغ", "بالجنيه", "التاريخ", "الحالة", ""]}
          rows={mine.map((c) => [
            <span className="font-bold text-primary-deep">{c.id}</span>,
            c.dealId,
            c.seller,
            money(collectionAmount(c), c.currency),
            EGP(collectionEGP(c)),
            c.date,
            <Badge tone={STAGE_TONE[c.stage]}>{STAGE_LABEL[c.stage]}</Badge>,
            <Button variant="ghost" className="px-3 py-1.5" onClick={() => setOpen(c)}>
              المسار
            </Button>,
          ])}
        />
      </Card>

      <Modal open={!!open} onClose={() => setOpen(null)} title={`دفعة ${open?.id ?? ""}`}>
        {open ? (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 text-xs">
              {[
                ["الموظف", open.seller],
                ["العميل", open.client],
                ["المبلغ", money(open.amount, open.currency)],
                ["الطريقة", open.method],
                ["المرجع", open.ref],
                ["التاريخ", open.date],
              ].map(([k, v]) => (
                <div key={k} className="rounded-xl bg-muted/60 p-2.5">
                  <p className="text-[10px] font-bold text-muted-foreground">{k}</p>
                  <p className="mt-0.5 font-extrabold">{v}</p>
                </div>
              ))}
            </div>

            {open.stage === "pending_manager" ? (
              <>
                <Field label="ملاحظة">
                  <Textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="سبب الرفض مثلاً" />
                </Field>
                <div className="flex flex-wrap gap-2">
                  <Button
                    onClick={() => {
                      managerCollection(open.id, true, note || undefined);
                      setOpen(null);
                    }}
                  >
                    تحويل للمالية
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      managerCollection(open.id, false, note || "مرفوض من مدير الفريق");
                      setOpen(null);
                    }}
                  >
                    رفض
                  </Button>
                </div>
              </>
            ) : null}

            <Timeline steps={open.history} />
          </div>
        ) : null}
      </Modal>
    </>
  );
}
