import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, CheckCircle2, Users, Wallet } from "lucide-react";
import { Badge, Button, Card, DataTable, Empty, PageHeader, Progress, Ring, Stat } from "@/components/kit";
import { EGP, pct, team } from "@/lib/mock";
import { ACTORS, dealNetEGP, metricsFor, money, queues, useStore } from "@/lib/store";

export const Route = createFileRoute("/manager/")({
  head: () => ({
    meta: [
      { title: "لوحة مدير الفريق | SalesTrack" },
      { name: "description", content: "طلبات الاعتماد، أداء الفريق، ونسب تحقيق التارجت في لوحة واحدة." },
      { property: "og:title", content: "لوحة مدير الفريق | SalesTrack" },
      { property: "og:description", content: "اعتماد البيعات والتحصيلات ومتابعة الفريق." },
    ],
  }),
  component: ManagerHome,
});

const meManager = ACTORS.manager.person;

function ManagerHome() {
  const { s } = useStore();
  const q = queues(s);
  const myTeam = team.filter((p) => p.manager === meManager);
  const rows = myTeam.map((p) => ({ p, m: metricsFor(s, p.name) }));
  const sum = (k: "target" | "sales" | "collections") => rows.reduce((a, r) => a + r.m[k], 0);
  const pendingDeals = q.managerDeals.filter((d) => d.manager === meManager);
  const pendingColl = q.managerCollections.filter((c) => c.manager === meManager);

  return (
    <>
      <PageHeader
        title="لوحة مدير الفريق"
        subtitle={`${myTeam.length} موظفين — كل بيعة أو تحصيل يبدأ من عندك`}
        action={
          <Link to="/manager/sales">
            <Button>
              طلبات الاعتماد <ArrowLeft className="size-4" />
            </Button>
          </Link>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="تارجت الفريق" value={EGP(sum("target"))} tone="brand" />
        <Stat label="مبيعات معتمدة" value={EGP(sum("sales"))} tone="success" icon={<Users className="size-4" />} />
        <Stat label="تحصيلات معتمدة" value={EGP(sum("collections"))} icon={<Wallet className="size-4" />} />
        <Stat
          label="بانتظار اعتمادك"
          value={String(pendingDeals.length + pendingColl.length)}
          tone="warning"
          icon={<CheckCircle2 className="size-4" />}
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-[320px_minmax(0,1fr)]">
        <Card title="تحقيق تارجت الفريق">
          <div className="grid place-items-center py-2">
            <Ring value={pct(sum("sales"), sum("target") || 1)} caption="من التارجت" />
          </div>
          <div className="mt-4">
            <Progress value={pct(sum("collections"), sum("sales") || 1)} label="نسبة التحصيل" />
          </div>
        </Card>

        <Card title="بيعات بانتظار الاعتماد" action={<Link to="/manager/sales"><Button variant="ghost" className="px-3 py-1.5">الكل</Button></Link>}>
          {pendingDeals.length ? (
            <DataTable
              head={["كود", "الموظف", "العميل", "صافي بالجنيه"]}
              rows={pendingDeals.map((d) => [
                <span className="font-bold text-primary-deep">{d.id}</span>,
                d.seller,
                d.client,
                EGP(dealNetEGP(d)),
              ])}
            />
          ) : (
            <Empty text="لا توجد بيعات معلقة" />
          )}
        </Card>
      </div>

      <Card title="تحصيلات بانتظار المراجعة" action={<Link to="/manager/collections"><Button variant="ghost" className="px-3 py-1.5">الكل</Button></Link>}>
        {pendingColl.length ? (
          <DataTable
            head={["كود", "التعاقد", "الموظف", "المبلغ", "الطريقة"]}
            rows={pendingColl.map((c) => [
              <span className="font-bold text-primary-deep">{c.id}</span>,
              c.dealId,
              c.seller,
              money(c.amount, c.currency),
              c.method,
            ])}
          />
        ) : (
          <Empty text="لا توجد دفعات معلقة" />
        )}
      </Card>

      <Card title="أداء أعضاء الفريق">
        <DataTable
          head={["الموظف", "التارجت", "المبيعات", "التحصيلات", "نسبة التحقيق"]}
          rows={rows.map(({ p, m }) => [
            <span className="font-bold">{p.name}</span>,
            EGP(m.target),
            EGP(m.sales),
            EGP(m.collections),
            <Badge tone={pct(m.sales, m.target || 1) >= 100 ? "success" : pct(m.sales, m.target || 1) >= 70 ? "brand" : "warning"}>
              {pct(m.sales, m.target || 1)}%
            </Badge>,
          ])}
        />
      </Card>
    </>
  );
}
