import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { BarChart, Card, DataTable, PageHeader, QuarterTabs, Stat } from "@/components/kit";
import { EGP, pct, quarters, team } from "@/lib/mock";
import { ACTORS, metricsFor, useStore } from "@/lib/store";

export const Route = createFileRoute("/manager/reports")({
  head: () => ({
    meta: [
      { title: "تقارير الفريق | SalesTrack" },
      { name: "description", content: "تقارير ربع سنوية لمبيعات وتحصيلات الفريق ومقارنتها بالتارجت." },
      { property: "og:title", content: "تقارير الفريق | SalesTrack" },
      { property: "og:description", content: "أرقام الفريق ربع بربع." },
    ],
  }),
  component: ManagerReports,
});

const meManager = ACTORS.manager.person;

function ManagerReports() {
  const { s } = useStore();
  const [q, setQ] = useState("Q1");
  const mine = team.filter((p) => p.manager === meManager);
  const rows = mine.map((p) => ({ p, m: metricsFor(s, p.name) }));
  const sum = (k: "target" | "sales" | "collections" | "earned") => rows.reduce((a, r) => a + r.m[k], 0);

  return (
    <>
      <PageHeader
        title="تقارير الفريق"
        subtitle="مبيعات معتمدة مقابل التارجت المعتمد"
        action={<QuarterTabs value={q} onChange={setQ} options={quarters} />}
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label={`تارجت ${q}`} value={EGP(sum("target"))} tone="brand" />
        <Stat label="المبيعات" value={EGP(sum("sales"))} tone="success" />
        <Stat label="التحصيلات" value={EGP(sum("collections"))} />
        <Stat label="العمولات المستحقة" value={EGP(sum("earned"))} tone="warning" />
      </div>

      <Card title="التارجت مقابل المبيعات لكل موظف">
        <BarChart
          data={rows.map(({ p, m }) => ({
            label: p.name.split(" ")[0] ?? p.name,
            a: Math.round(m.target),
            b: Math.round(m.sales),
          }))}
        />
      </Card>

      <Card title={`تفصيل ${q}`}>
        <DataTable
          head={["الموظف", "التارجت", "المبيعات", "نسبة التحقيق", "التحصيلات", "نسبة التحصيل"]}
          rows={rows.map(({ p, m }) => [
            <span className="font-bold">{p.name}</span>,
            EGP(m.target),
            EGP(m.sales),
            <span className="font-bold">{pct(m.sales, m.target || 1)}%</span>,
            EGP(m.collections),
            <span className="font-bold">{pct(m.collections, m.sales || 1)}%</span>,
          ])}
        />
      </Card>
    </>
  );
}
