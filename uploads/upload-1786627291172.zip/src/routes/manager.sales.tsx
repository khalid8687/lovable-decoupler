import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  Badge,
  Button,
  Card,
  DataTable,
  Empty,
  Field,
  FlowStrip,
  Input,
  Modal,
  PageHeader,
  Select,
  Textarea,
  Timeline,
} from "@/components/kit";
import { EGP, team } from "@/lib/mock";
import {
  ACTORS,
  STAGE_LABEL,
  STAGE_TONE,
  dealNet,
  dealNetEGP,
  money,
  useStore,
  type Deal,
} from "@/lib/store";

export const Route = createFileRoute("/manager/sales")({
  head: () => ({
    meta: [
      { title: "اعتماد بيعات الفريق | SalesTrack" },
      {
        name: "description",
        content: "مدير الفريق يعتمد البيعة ويمكنه إضافة مشارك من التيم وتحديد نسبة المشاركة.",
      },
      { property: "og:title", content: "اعتماد بيعات الفريق | SalesTrack" },
      { property: "og:description", content: "اعتماد + إضافة مشارك + تحويل للمالية." },
    ],
  }),
  component: ManagerSales,
});

const meManager = ACTORS.manager.person;

function ManagerSales() {
  const { s, managerDeal } = useStore();
  const [open, setOpen] = useState<Deal | null>(null);
  const [withPartner, setWithPartner] = useState(false);
  const [partner, setPartner] = useState("");
  const [share, setShare] = useState(30);
  const [note, setNote] = useState("");

  const mine = s.deals.filter((d) => d.manager === meManager);
  const pending = mine.filter((d) => d.stage === "pending_manager");
  const teamNames = team.map((p) => p.name);

  const start = (d: Deal) => {
    setOpen(d);
    setWithPartner(!!d.partner);
    setPartner(d.partner?.name ?? teamNames.find((n) => n !== d.seller) ?? "");
    setShare(d.partner?.share ?? 30);
    setNote("");
  };

  const approve = () => {
    if (!open) return;
    managerDeal(open.id, true, {
      partner: withPartner && partner ? { name: partner, share } : null,
      ...(note ? { note } : {}),
    });
    setOpen(null);
  };

  return (
    <>
      <PageHeader title="بيعات الفريق" subtitle="اعتماد البيعة وتحديد المشاركين قبل إرسالها للإدارة المالية" />

      <Card title="مسار الاعتماد">
        <FlowStrip steps={["تسجيل السيلز", "اعتماد مدير الفريق", "اعتماد المالية", "معتمدة"]} active={1} />
      </Card>

      <Card title={`بانتظار اعتمادك (${pending.length})`}>
        {pending.length ? (
          <DataTable
            head={["كود", "الموظف", "العميل", "العملة", "صافي البيعة", "بالجنيه", "التاريخ", "إجراء"]}
            rows={pending.map((d) => [
              <span className="font-bold text-primary-deep">{d.id}</span>,
              d.seller,
              d.client,
              d.currency,
              money(dealNet(d), d.currency),
              EGP(dealNetEGP(d)),
              d.date,
              <Button className="px-3 py-1.5" onClick={() => start(d)}>
                مراجعة
              </Button>,
            ])}
          />
        ) : (
          <Empty text="لا توجد بيعات بانتظار الاعتماد" />
        )}
      </Card>

      <Card title="كل بيعات الفريق">
        <DataTable
          head={["كود", "الموظف", "العميل", "صافي بالجنيه", "المشارك", "الحالة", ""]}
          rows={mine.map((d) => [
            <span className="font-bold text-primary-deep">{d.id}</span>,
            d.seller,
            d.client,
            EGP(dealNetEGP(d)),
            d.partner ? `${d.partner.name} (${d.partner.share}%)` : <span className="text-muted-foreground">—</span>,
            <Badge tone={STAGE_TONE[d.stage]}>{STAGE_LABEL[d.stage]}</Badge>,
            <Button variant="ghost" className="px-3 py-1.5" onClick={() => start(d)}>
              تفاصيل
            </Button>,
          ])}
        />
      </Card>

      <Modal open={!!open} onClose={() => setOpen(null)} title={`مراجعة البيعة ${open?.id ?? ""}`}>
        {open ? (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 text-xs">
              {[
                ["الموظف", open.seller],
                ["العميل", open.client],
                ["المشروع", open.project],
                ["المبلغ المسجّل", money(open.gross, open.currency)],
                ["صافي بدون ضريبة", money(dealNet(open), open.currency)],
                ["بالجنيه", EGP(dealNetEGP(open))],
              ].map(([k, v]) => (
                <div key={k} className="rounded-xl bg-muted/60 p-2.5">
                  <p className="text-[10px] font-bold text-muted-foreground">{k}</p>
                  <p className="mt-0.5 font-extrabold">{v}</p>
                </div>
              ))}
            </div>

            <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-border bg-muted/40 p-4 text-sm font-bold">
              <input
                type="checkbox"
                checked={withPartner}
                onChange={(e) => setWithPartner(e.target.checked)}
                className="size-4 accent-[var(--primary)]"
              />
              إضافة مشارك من التيم في هذه البيعة
            </label>

            {withPartner ? (
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="المشارك">
                  <Select value={partner} onChange={(e) => setPartner(e.target.value)}>
                    {teamNames
                      .filter((n) => n !== open.seller)
                      .map((n) => (
                        <option key={n} value={n}>
                          {n}
                        </option>
                      ))}
                  </Select>
                </Field>
                <Field
                  label={`نسبة المشارك ${share}% / صاحب البيعة ${100 - share}%`}
                  hint={`نصيب المشارك: ${EGP((dealNetEGP(open) * share) / 100)}`}
                >
                  <Input
                    type="range"
                    min={5}
                    max={90}
                    step={5}
                    value={share}
                    onChange={(e) => setShare(Number(e.target.value))}
                    className="w-full accent-[var(--primary)]"
                  />
                </Field>
              </div>
            ) : null}

            <Field label="ملاحظة">
              <Textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="ملاحظة تظهر للسيلز" />
            </Field>

            {open.stage === "pending_manager" ? (
              <div className="flex flex-wrap gap-2">
                <Button onClick={approve}>اعتماد وإرسال للمالية</Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    managerDeal(open.id, false, { note: note || "مرفوض من مدير الفريق" });
                    setOpen(null);
                  }}
                >
                  رفض
                </Button>
              </div>
            ) : (
              <p className="rounded-xl bg-muted/60 p-3 text-[11px] font-bold text-muted-foreground">
                الحالة الحالية: {STAGE_LABEL[open.stage]}
              </p>
            )}

            <Timeline steps={open.history} />
          </div>
        ) : null}
      </Modal>
    </>
  );
}
