import { createFileRoute } from "@tanstack/react-router";
import { Badge, Card, DataTable, PageHeader, Progress } from "@/components/kit";
import { EGP, pct, team } from "@/lib/mock";
import { ACTORS, metricsFor, useStore } from "@/lib/store";

export const Route = createFileRoute("/manager/team")({
  head: () => ({
    meta: [
      { title: "فريقي | SalesTrack" },
      { name: "description", content: "ملف كل موظف: التارجت المعتمد، المبيعات، التحصيلات والعمولة." },
      { property: "og:title", content: "فريقي | SalesTrack" },
      { property: "og:description", content: "متابعة تفصيلية لأداء كل موظف مبيعات." },
    ],
  }),
  component: TeamPage,
});

const meManager = ACTORS.manager.person;

function TeamPage() {
  const { s } = useStore();
  const mine = team.filter((p) => p.manager === meManager);

  return (
    <>
      <PageHeader title="الفريق" subtitle="الأرقام محسوبة من البيعات والتحصيلات المعتمدة فقط" />

      <div className="grid gap-4 lg:grid-cols-2">
        {mine.map((p) => {
          const m = metricsFor(s, p.name);
          const a = pct(m.sales, m.target || 1);
          return (
            <Card key={p.id}>
              <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
                <div className="flex min-w-0 items-center gap-3">
                  <span className="brand-gradient grid size-11 shrink-0 place-items-center rounded-2xl text-sm font-extrabold text-primary-foreground">
                    {p.name.slice(0, 1)}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-extrabold">{p.name}</p>
                    <p className="truncate text-[11px] text-muted-foreground">{p.title}</p>
                  </div>
                </div>
                <Badge tone={a >= 100 ? "success" : a >= 70 ? "brand" : "warning"}>{a}% تحقيق</Badge>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-3">
                {[
                  ["التارجت", EGP(m.target)],
                  ["المبيعات", EGP(m.sales)],
                  ["التحصيلات", EGP(m.collections)],
                  ["العمولة المستحقة", EGP(m.earned)],
                ].map(([k, v]) => (
                  <div key={k} className="rounded-xl bg-muted/60 p-2.5">
                    <p className="text-[10px] font-bold text-muted-foreground">{k}</p>
                    <p className="mt-0.5 text-xs font-extrabold">{v}</p>
                  </div>
                ))}
              </div>

              <div className="mt-4 space-y-3">
                <Progress value={a} label="نسبة تحقيق التارجت" />
                <Progress value={pct(m.collections, m.sales || 1)} label="نسبة التحصيل" />
              </div>
            </Card>
          );
        })}
      </div>

      <Card title="مقارنة الفريق">
        <DataTable
          head={["الموظف", "التارجت", "المبيعات", "قيد الاعتماد", "التحصيلات", "المتبقي", "نسبة التحقيق"]}
          rows={mine.map((p) => {
            const m = metricsFor(s, p.name);
            return [
              <span className="font-bold">{p.name}</span>,
              EGP(m.target),
              EGP(m.sales),
              <span className="text-warning">{EGP(m.pipeline)}</span>,
              EGP(m.collections),
              EGP(m.outstanding),
              <div className="w-28">
                <Progress value={pct(m.sales, m.target || 1)} />
              </div>,
            ];
          })}
        />
      </Card>
    </>
  );
}
