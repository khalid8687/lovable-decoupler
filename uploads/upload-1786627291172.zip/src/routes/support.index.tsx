import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, LifeBuoy } from "lucide-react";
import { Badge, Button, Card, DataTable, Empty, PageHeader, Stat, Timeline } from "@/components/kit";
import { queues, useStore } from "@/lib/store";

export const Route = createFileRoute("/support/")({
  head: () => ({
    meta: [
      { title: "لوحة الدعم الفني | SalesTrack" },
      { name: "description", content: "التذاكر المفتوحة، حالات البيانات المرفوضة، وسجل كل العمليات في النظام." },
      { property: "og:title", content: "لوحة الدعم الفني | SalesTrack" },
      { property: "og:description", content: "متابعة التذاكر وسلامة البيانات." },
    ],
  }),
  component: SupportHome,
});

function SupportHome() {
  const { s } = useStore();
  const q = queues(s);
  const rejected = [
    ...s.deals.filter((d) => d.stage.startsWith("rejected")).map((d) => ["بيعة", d.id, d.seller, d.note ?? "—"]),
    ...s.collections.filter((c) => c.stage.startsWith("rejected")).map((c) => ["تحصيل", c.id, c.seller, c.note ?? "—"]),
  ];

  return (
    <>
      <PageHeader
        title="لوحة الدعم الفني"
        subtitle="حل مشاكل المستخدمين ومتابعة سلامة البيانات"
        action={
          <Link to="/support/tickets">
            <Button>
              التذاكر <ArrowLeft className="size-4" />
            </Button>
          </Link>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="تذاكر مفتوحة" value={String(q.openTickets.length)} tone="warning" icon={<LifeBuoy className="size-4" />} />
        <Stat label="عناصر مرفوضة" value={String(rejected.length)} tone="warning" />
        <Stat label="معلق عند مدير الفريق" value={String(q.managerDeals.length + q.managerCollections.length)} tone="brand" />
        <Stat label="معلق عند المالية" value={String(q.financeDeals.length + q.financeCollections.length + q.financeTargets.length)} />
      </div>

      <Card title="عناصر مرفوضة تحتاج تصحيح">
        {rejected.length ? (
          <DataTable head={["النوع", "الكود", "الموظف", "السبب"]} rows={rejected} />
        ) : (
          <Empty text="لا توجد عناصر مرفوضة" />
        )}
      </Card>

      <Card title="أحدث التذاكر">
        {q.openTickets.length ? (
          <DataTable
            head={["كود", "الموضوع", "مقدم الطلب", "الأهمية", "الحالة"]}
            rows={q.openTickets.slice(0, 6).map((t) => [
              <span className="font-bold text-primary-deep">{t.id}</span>,
              t.title,
              t.requester,
              <Badge tone={t.priority === "عالية" ? "danger" : t.priority === "متوسطة" ? "warning" : "brand"}>
                {t.priority}
              </Badge>,
              <Badge tone={t.status === "مفتوحة" ? "warning" : "brand"}>{t.status}</Badge>,
            ])}
          />
        ) : (
          <Empty text="لا توجد تذاكر مفتوحة" />
        )}
      </Card>

      <Card title="سجل العمليات">
        <Timeline steps={s.logs.slice(-12).reverse().map((l) => ({ at: l.at, by: l.by, action: l.action }))} />
      </Card>
    </>
  );
}
