import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Badge, Button, Card, DataTable, Empty, Input, Modal, PageHeader, Timeline } from "@/components/kit";
import { EGP } from "@/lib/mock";
import {
  STAGE_LABEL,
  STAGE_TONE,
  collectionAmount,
  collectionEGP,
  dealNet,
  dealNetEGP,
  money,
  useStore,
} from "@/lib/store";

export const Route = createFileRoute("/support/records")({
  head: () => ({
    meta: [
      { title: "سجلات البيانات | SalesTrack" },
      { name: "description", content: "استعراض كل البيعات والتحصيلات والتارجت مع مسار الاعتماد لكل عنصر." },
      { property: "og:title", content: "سجلات البيانات | SalesTrack" },
      { property: "og:description", content: "مرجع كامل لكل عمليات النظام." },
    ],
  }),
  component: RecordsPage,
});

type Tab = "deals" | "collections" | "targets" | "logs";

const TABS: { id: Tab; label: string }[] = [
  { id: "deals", label: "البيعات" },
  { id: "collections", label: "التحصيلات" },
  { id: "targets", label: "التارجت" },
  { id: "logs", label: "سجل العمليات" },
];

function RecordsPage() {
  const { s } = useStore();
  const [tab, setTab] = useState<Tab>("deals");
  const [term, setTerm] = useState("");
  const [history, setHistory] = useState<{ title: string; steps: { at: string; by: string; action: string; note?: string }[] } | null>(null);

  const has = (...v: string[]) => v.join(" ").toLowerCase().includes(term.toLowerCase());

  return (
    <>
      <PageHeader
        title="سجلات البيانات"
        subtitle="الدعم الفني يرى كل شيء للقراءة والمراجعة"
        action={<Input value={term} onChange={(e) => setTerm(e.target.value)} placeholder="بحث بالكود أو الاسم" className="sm:w-64" />}
      />

      <Card
        title={TABS.find((t) => t.id === tab)?.label ?? ""}
        action={
          <div className="flex flex-wrap gap-1.5">
            {TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`rounded-full px-3 py-1.5 text-[11px] font-bold transition ${
                  tab === t.id ? "brand-gradient text-primary-foreground" : "bg-muted text-muted-foreground"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        }
      >
        {tab === "deals" ? (
          <DataTable
            head={["كود", "العميل", "الموظف", "العملة", "صافي البيعة", "بالجنيه", "الحالة", ""]}
            rows={s.deals
              .filter((d) => has(d.id, d.client, d.seller, d.project))
              .map((d) => [
                <span className="font-bold text-primary-deep">{d.id}</span>,
                d.client,
                d.seller,
                d.currency,
                money(dealNet(d), d.currency),
                EGP(dealNetEGP(d)),
                <Badge tone={STAGE_TONE[d.stage]}>{STAGE_LABEL[d.stage]}</Badge>,
                <Button variant="ghost" className="px-3 py-1.5" onClick={() => setHistory({ title: d.id, steps: d.history })}>
                  المسار
                </Button>,
              ])}
          />
        ) : null}

        {tab === "collections" ? (
          <DataTable
            head={["كود", "التعاقد", "الموظف", "المبلغ", "بالجنيه", "الطريقة", "الحالة", ""]}
            rows={s.collections
              .filter((c) => has(c.id, c.dealId, c.seller, c.ref))
              .map((c) => [
                <span className="font-bold text-primary-deep">{c.id}</span>,
                c.dealId,
                c.seller,
                money(collectionAmount(c), c.currency),
                EGP(collectionEGP(c)),
                c.method,
                <Badge tone={STAGE_TONE[c.stage]}>{STAGE_LABEL[c.stage]}</Badge>,
                <Button variant="ghost" className="px-3 py-1.5" onClick={() => setHistory({ title: c.id, steps: c.history })}>
                  المسار
                </Button>,
              ])}
          />
        ) : null}

        {tab === "targets" ? (
          <DataTable
            head={["الموظف", "الربع", "القيمة", "حدده", "الحالة", ""]}
            rows={s.targets
              .filter((t) => has(t.person, t.quarter))
              .map((t) => [
                <span className="font-bold">{t.person}</span>,
                t.quarter,
                EGP(t.value),
                <span className="text-muted-foreground">{t.setBy}</span>,
                <Badge tone={STAGE_TONE[t.stage]}>{STAGE_LABEL[t.stage]}</Badge>,
                <Button variant="ghost" className="px-3 py-1.5" onClick={() => setHistory({ title: t.person, steps: t.history })}>
                  المسار
                </Button>,
              ])}
          />
        ) : null}

        {tab === "logs" ? (
          s.logs.length ? (
            <Timeline steps={s.logs.slice().reverse().map((l) => ({ at: l.at, by: l.by, action: l.action }))} />
          ) : (
            <Empty text="لا يوجد سجل بعد" />
          )
        ) : null}
      </Card>

      <Modal open={!!history} onClose={() => setHistory(null)} title={`مسار ${history?.title ?? ""}`}>
        {history ? <Timeline steps={history.steps} /> : null}
      </Modal>
    </>
  );
}
