import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, X } from "lucide-react";
import { Badge, Button, Card, DataTable, Empty, Field, Input, PageHeader, Select, Stat } from "@/components/kit";
import { useStore, type Ticket } from "@/lib/store";
import { team } from "@/lib/mock";

export const Route = createFileRoute("/support/tickets")({
  head: () => ({
    meta: [
      { title: "التذاكر | SalesTrack" },
      { name: "description", content: "استلام ومعالجة تذاكر المستخدمين: تعديل تعاقد، خطأ تحصيل، صلاحيات، عمولات." },
      { property: "og:title", content: "التذاكر | SalesTrack" },
      { property: "og:description", content: "إدارة تذاكر الدعم الفني." },
    ],
  }),
  component: TicketsPage,
});

const TYPES: Ticket["type"][] = ["تعديل تعاقد", "خطأ في تحصيل", "صلاحيات", "استفسار عمولة"];
const PRIORITIES: Ticket["priority"][] = ["عالية", "متوسطة", "منخفضة"];
const STATUSES: Ticket["status"][] = ["مفتوحة", "قيد المعالجة", "مغلقة"];

function TicketsPage() {
  const { s, addTicket, setTicket } = useStore();
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [type, setType] = useState<Ticket["type"]>("تعديل تعاقد");
  const [priority, setPriority] = useState<Ticket["priority"]>("متوسطة");
  const [requester, setRequester] = useState(team[0]?.name ?? "");
  const [filter, setFilter] = useState<"all" | Ticket["status"]>("all");

  const list = s.tickets.filter((t) => filter === "all" || t.status === filter);

  return (
    <>
      <PageHeader
        title="التذاكر"
        subtitle="كل طلب أو مشكلة من المستخدمين تُسجّل وتُتابع هنا"
        action={
          <Button onClick={() => setOpen((v) => !v)}>
            {open ? <X className="size-4" /> : <Plus className="size-4" />}
            {open ? "إغلاق" : "تذكرة جديدة"}
          </Button>
        }
      />

      <div className="grid gap-4 sm:grid-cols-3">
        {STATUSES.map((st) => (
          <Stat
            key={st}
            label={st}
            value={String(s.tickets.filter((t) => t.status === st).length)}
            tone={st === "مفتوحة" ? "warning" : st === "قيد المعالجة" ? "brand" : "success"}
          />
        ))}
      </div>

      {open ? (
        <Card title="تسجيل تذكرة">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="الموضوع">
              <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="مثال: دفعة مسجلة مرتين" />
            </Field>
            <Field label="مقدم الطلب">
              <Select value={requester} onChange={(e) => setRequester(e.target.value)}>
                {team.map((p) => (
                  <option key={p.id} value={p.name}>
                    {p.name}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="النوع">
              <Select value={type} onChange={(e) => setType(e.target.value as Ticket["type"])}>
                {TYPES.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="الأهمية">
              <Select value={priority} onChange={(e) => setPriority(e.target.value as Ticket["priority"])}>
                {PRIORITIES.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </Select>
            </Field>
          </div>
          <div className="mt-5 flex gap-2">
            <Button
              onClick={() => {
                if (!title) return;
                addTicket({ title, type, priority, requester });
                setTitle("");
                setOpen(false);
              }}
            >
              حفظ التذكرة
            </Button>
            <Button variant="outline" onClick={() => setOpen(false)}>
              إلغاء
            </Button>
          </div>
        </Card>
      ) : null}

      <Card
        title="قائمة التذاكر"
        action={
          <div className="flex flex-wrap gap-1.5">
            {(["all", ...STATUSES] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`rounded-full px-3 py-1.5 text-[11px] font-bold transition ${
                  filter === f ? "brand-gradient text-primary-foreground" : "bg-muted text-muted-foreground"
                }`}
              >
                {f === "all" ? "الكل" : f}
              </button>
            ))}
          </div>
        }
      >
        {list.length ? (
          <DataTable
            head={["كود", "الموضوع", "مقدم الطلب", "النوع", "الأهمية", "الحالة", "إجراء"]}
            rows={list.map((t) => [
              <span className="font-bold text-primary-deep">{t.id}</span>,
              t.title,
              t.requester,
              <span className="text-muted-foreground">{t.type}</span>,
              <Badge tone={t.priority === "عالية" ? "danger" : t.priority === "متوسطة" ? "warning" : "brand"}>
                {t.priority}
              </Badge>,
              <Badge tone={t.status === "مغلقة" ? "success" : t.status === "مفتوحة" ? "warning" : "brand"}>
                {t.status}
              </Badge>,
              <div className="flex gap-2">
                {t.status !== "قيد المعالجة" && t.status !== "مغلقة" ? (
                  <Button className="px-3 py-1.5" onClick={() => setTicket(t.id, "قيد المعالجة")}>
                    بدء المعالجة
                  </Button>
                ) : null}
                {t.status !== "مغلقة" ? (
                  <Button variant="outline" className="px-3 py-1.5" onClick={() => setTicket(t.id, "مغلقة")}>
                    إغلاق
                  </Button>
                ) : (
                  <Button variant="ghost" className="px-3 py-1.5" onClick={() => setTicket(t.id, "مفتوحة")}>
                    إعادة فتح
                  </Button>
                )}
              </div>,
            ])}
          />
        ) : (
          <Empty text="لا توجد تذاكر في هذا التصنيف" />
        )}
      </Card>
    </>
  );
}
