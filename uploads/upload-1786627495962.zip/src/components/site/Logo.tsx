import { cn } from "@/lib/utils";
import logoUrl from "@/assets/mrk-logo.png";

const RATIO = 647 / 436; // logo artwork aspect ratio

/**
 * MRK wordmark — the official company logo artwork, rendered as a mask so it
 * always takes the current text color of its container.
 * Scale it with a font-size utility on `className`.
 */
export function MrkLogo({
  className,
  withSub = true,
}: {
  className?: string;
  withSub?: boolean;
}) {
  // Without the sub-line we crop to the "MRK" band only.
  const height = withSub ? 2.4 : 1.85;
  const mask = {
    WebkitMaskImage: `url(${logoUrl})`,
    maskImage: `url(${logoUrl})`,
    WebkitMaskRepeat: "no-repeat",
    maskRepeat: "no-repeat",
    WebkitMaskSize: "100% auto",
    maskSize: "100% auto",
    WebkitMaskPosition: "top left",
    maskPosition: "top left",
    backgroundColor: "currentColor",
    width: `${RATIO * 2.4}em`,
    height: `${height}em`,
  } as const;

  return (
    <span
      className={cn("inline-block select-none align-middle", className)}
      role="img"
      aria-label="MRK development"
      dir="ltr"
      style={mask}
    />
  );
}
