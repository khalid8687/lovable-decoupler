import { Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { cn } from "@/lib/utils";
import { designs } from "@/data/mrk";

export type Lang = "ar" | "en";

export function useLang() {
  return useState<Lang>("ar");
}

export function SiteShell({
  theme,
  lang,
  setLang,
  designNameAr,
  designNameEn,
  children,
  className,
}: {
  theme: string;
  lang: Lang;
  setLang: (l: Lang) => void;
  designNameAr: string;
  designNameEn: string;
  children: ReactNode;
  className?: string;
}) {
  const ar = lang === "ar";
  return (
    <div
      dir={ar ? "rtl" : "ltr"}
      lang={ar ? "ar" : "en"}
      className={cn("site min-h-screen", theme, className)}
    >
      <div className="sticky top-0 z-50 flex flex-wrap items-center justify-between gap-x-3 gap-y-2 border-b border-border bg-surface/95 px-3 py-2 text-xs backdrop-blur supports-[backdrop-filter]:bg-surface/80 sm:px-4">
        <Link to="/" className="font-medium text-muted-foreground hover:text-foreground">
          {ar ? "→ رجوع لمعرض التصميمات" : "← Back to design gallery"}
        </Link>
        <div className="flex w-full flex-wrap items-center gap-2 sm:w-auto">
          <span className="hidden text-muted-foreground sm:inline">
            {ar ? `تصميم: ${designNameAr}` : `Design: ${designNameEn}`}
          </span>
          <div className="no-scrollbar -mx-1 flex flex-1 gap-1 overflow-x-auto px-1 sm:flex-none sm:overflow-visible">
            {designs.map((d, i) => (
              <Link
                key={d.slug}
                to="/design/$slug"
                params={{ slug: d.slug }}
                title={ar ? d.nameAr : d.nameEn}
                activeProps={{ className: "bg-primary text-primary-foreground border-primary" }}
                className="shrink-0 rounded-md border border-border px-2 py-1 text-[11px] font-medium text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
              >
                {i + 1}
              </Link>
            ))}
          </div>
          <button
            onClick={() => setLang(ar ? "en" : "ar")}
            className="shrink-0 rounded-md border border-border px-2.5 py-1 font-medium text-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
          >
            {ar ? "English" : "العربية"}
          </button>
        </div>
      </div>

      {children}
    </div>
  );
}

export function T({ ar, en, lang }: { ar: string; en: string; lang: Lang }) {
  return <>{lang === "ar" ? ar : en}</>;
}
