import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

/**
 * Shared graphic primitives for the ten MRK site designs.
 * They are theme-agnostic: every color comes from the active .site-* palette.
 */

/** Image that never breaks its box: fixed aspect ratio + object-cover. */
export function Frame({
  src,
  alt = "",
  ratio = "4/3",
  className,
  imgClassName,
  overlay,
  children,
}: {
  src: string;
  alt?: string;
  ratio?: string;
  className?: string;
  imgClassName?: string;
  overlay?: boolean;
  children?: ReactNode;
}) {
  return (
    <div className={cn("relative isolate overflow-hidden bg-muted", className)} style={{ aspectRatio: ratio }}>
      <img
        src={src}
        alt={alt}
        loading="lazy"
        decoding="async"
        className={cn("absolute inset-0 h-full w-full object-cover", imgClassName)}
      />
      {overlay ? (
        <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/25 to-transparent" />
      ) : null}
      {children ? <div className="relative h-full w-full">{children}</div> : null}
    </div>
  );
}

export function Eyebrow({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.22em] text-primary",
        className,
      )}
    >
      <span className="inline-block h-px w-6 bg-primary/60" aria-hidden />
      {children}
    </span>
  );
}

export function Pill({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-border bg-card/70 px-3 py-1 text-xs font-medium text-muted-foreground backdrop-blur",
        className,
      )}
    >
      {children}
    </span>
  );
}

export function SectionHead({
  eyebrow,
  title,
  desc,
  align = "start",
  className,
}: {
  eyebrow?: ReactNode;
  title: ReactNode;
  desc?: ReactNode;
  align?: "start" | "center";
  className?: string;
}) {
  return (
    <div className={cn("max-w-2xl", align === "center" && "mx-auto text-center", className)}>
      {eyebrow ? <Eyebrow>{eyebrow}</Eyebrow> : null}
      <h2 className="mt-3 text-balance text-2xl leading-tight sm:text-3xl lg:text-4xl">{title}</h2>
      {desc ? <p className="mt-3 text-pretty text-sm leading-relaxed text-muted-foreground sm:text-base">{desc}</p> : null}
    </div>
  );
}

export function StatBlock({ value, label, className }: { value: ReactNode; label: ReactNode; className?: string }) {
  return (
    <div className={cn("min-w-0", className)}>
      <div className="display text-2xl font-bold text-primary sm:text-3xl">{value}</div>
      <div className="mt-1 text-xs text-muted-foreground sm:text-sm">{label}</div>
    </div>
  );
}

export function Marquee({ items, className }: { items: string[]; className?: string }) {
  const row = [...items, ...items];
  return (
    <div className={cn("no-scrollbar w-full overflow-hidden", className)}>
      <div className="marquee-track flex w-max gap-8 whitespace-nowrap">
        {row.map((t, i) => (
          <span key={i} className="text-sm font-semibold uppercase tracking-[0.18em]">
            {t}
          </span>
        ))}
      </div>
    </div>
  );
}

export function GlowBg({ className }: { className?: string }) {
  return <div aria-hidden className={cn("mesh pointer-events-none absolute inset-0 -z-10 opacity-70 blur-2xl", className)} />;
}
