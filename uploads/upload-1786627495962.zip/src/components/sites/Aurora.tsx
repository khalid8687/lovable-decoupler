import { SiteShell, useLang } from "@/components/site/kit";
import { MrkLogo } from "@/components/site/Logo";
import { Frame, Eyebrow, Pill, SectionHead, StatBlock, GlowBg } from "@/components/site/ui";
import { company, projects, services, stats, testimonials } from "@/data/mrk";
import { Phone, MessageCircle, MapPin, Clock, Mail, Sparkles, ArrowUpRight } from "lucide-react";

export default function Aurora() {
  const [lang, setLang] = useLang();
  const ar = lang === "ar";

  return (
    <SiteShell theme="site-aurora" lang={lang} setLang={setLang} designNameAr="أورورا" designNameEn="Aurora">
      <div className="grain relative">
        {/* Hero */}
        <header className="relative overflow-hidden border-b border-border">
          <GlowBg className="mesh" />
          <div className="pointer-events-none absolute inset-0 grid-lines opacity-40" />
          <div className="pointer-events-none absolute -top-24 start-1/2 h-96 w-96 -translate-x-1/2 rounded-full border border-primary/20" />
          <div className="pointer-events-none absolute -top-10 start-1/2 h-64 w-64 -translate-x-1/2 rounded-full border border-accent/20" />

          <div className="relative mx-auto max-w-6xl px-4 pb-14 pt-6 sm:px-6 sm:pb-20 sm:pt-8">
            <nav className="flex flex-wrap items-center justify-between gap-3">
              <MrkLogo className="text-2xl text-foreground" />
              <Pill className="bg-card/60">
                <MapPin className="size-3.5 shrink-0" />
                <span className="truncate">{ar ? company.addressAr : company.addressEn}</span>
              </Pill>
            </nav>

            <div className="mt-12 flex flex-col items-center text-center sm:mt-16">
              <Eyebrow className="justify-center">{ar ? "منصة تسويق عقاري ذكية" : "Smart real-estate platform"}</Eyebrow>
              <h1 className="display mt-5 max-w-4xl text-balance text-3xl font-bold leading-[1.1] sm:text-5xl lg:text-6xl">
                {ar ? "عقارك القادم في " : "Your next property in "}
                <span className="text-gradient">{ar ? "6 أكتوبر" : "6th of October"}</span>
                {ar ? " يبدأ من هنا" : " starts here"}
              </h1>
              <p className="mt-5 max-w-2xl text-pretty text-sm leading-7 text-muted-foreground sm:text-base">
                {ar ? company.descAr : company.descEn}
              </p>
              <div className="mt-9 flex flex-wrap justify-center gap-3">
                <a href={`tel:${company.phone}`} className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-soft transition-transform hover:-translate-y-0.5">
                  <Phone className="size-4 shrink-0" /> {ar ? "احجز معاينة" : "Book a viewing"}
                </a>
                <a href="#projects" className="inline-flex items-center gap-2 rounded-full border border-border bg-card/50 px-6 py-3 text-sm font-semibold backdrop-blur transition-transform hover:-translate-y-0.5">
                  {ar ? "شوف المشاريع" : "See projects"} <ArrowUpRight className="size-4 shrink-0" />
                </a>
              </div>
            </div>

            {/* floating bento hero */}
            <div className="relative mt-12 sm:mt-16">
              <Frame src={projects[0]!.image} alt={ar ? projects[0]!.nameAr : projects[0]!.nameEn} ratio="16/9" className="rounded-3xl border border-border shadow-lift sm:rounded-[2rem]" overlay />
              <div className="absolute bottom-3 start-3 flex max-w-[85%] flex-wrap items-center gap-3 rounded-2xl border border-border bg-card/80 p-3 backdrop-blur sm:bottom-6 sm:start-6 sm:p-4">
                <Sparkles className="size-5 shrink-0 text-primary" />
                <div className="min-w-0">
                  <div className="truncate text-sm font-semibold">{ar ? projects[0]!.nameAr : projects[0]!.nameEn}</div>
                  <div className="truncate text-xs text-muted-foreground">{ar ? projects[0]!.priceAr : projects[0]!.priceEn}</div>
                </div>
              </div>
            </div>
          </div>
        </header>

        <main className="mx-auto max-w-6xl px-4 pb-16 sm:px-6 sm:pb-20">
          {/* Stats bento */}
          <section className="mt-8 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
            {stats.map((s) => (
              <div key={s.labelEn} className="rounded-3xl border border-border bg-card/70 p-5 backdrop-blur transition-transform hover:-translate-y-1 sm:p-6">
                <StatBlock value={ar ? s.valueAr : s.valueEn} label={ar ? s.labelAr : s.labelEn} />
              </div>
            ))}
          </section>

          {/* Projects */}
          <section id="projects" className="mt-10 sm:mt-14">
            <SectionHead eyebrow={ar ? "المشاريع" : "Projects"} title={ar ? "وحدات مضيئة داخل أفضل المواقع" : "Glowing units in the best locations"} />
            <div className="mt-6 grid gap-4 lg:grid-cols-3">
              {projects.map((p, i) => (
                <article key={p.id} className={`group overflow-hidden rounded-3xl border border-border bg-card/70 backdrop-blur transition-transform hover:-translate-y-1 ${i === 0 ? "lg:col-span-2 lg:row-span-2" : ""}`}>
                  <Frame src={p.image} alt={ar ? p.nameAr : p.nameEn} ratio={i === 0 ? "16/9" : "4/3"} className="transition-transform duration-500 group-hover:scale-[1.03]" />
                  <div className="p-5 sm:p-6">
                    <span className="text-xs font-semibold uppercase tracking-wide text-primary">{ar ? p.typeAr : p.typeEn}</span>
                    <h3 className="display mt-1 truncate text-lg font-semibold sm:text-xl">{ar ? p.nameAr : p.nameEn}</h3>
                    <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-sm">
                      <span className="text-muted-foreground">{ar ? p.areaAr : p.areaEn}</span>
                      <span className="rounded-full bg-primary/15 px-3 py-1 font-semibold text-primary">{ar ? p.priceAr : p.priceEn}</span>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </section>

          {/* Services */}
          <section className="mt-10 sm:mt-14">
            <SectionHead eyebrow={ar ? "خدماتنا" : "Services"} title={ar ? "كل ما تحتاجه لقرار استثماري صح" : "Everything for the right investment"} />
            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              {services.map((s) => (
                <div key={s.titleEn} className="rounded-3xl border border-border bg-surface/70 p-6 backdrop-blur">
                  <h3 className="display text-lg font-semibold">{ar ? s.titleAr : s.titleEn}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{ar ? s.descAr : s.descEn}</p>
                </div>
              ))}
            </div>
          </section>

          {/* Testimonials */}
          <section className="mt-10 sm:mt-14">
            <SectionHead eyebrow={ar ? "آراء العملاء" : "Testimonials"} title={ar ? "ثقة عملائنا هي رأس مالنا" : "Client trust is our capital"} />
            <div className="mt-6 grid gap-4 sm:grid-cols-3">
              {testimonials.map((t) => (
                <blockquote key={t.nameEn} className="rounded-3xl border border-border bg-card/70 p-6 text-sm backdrop-blur">
                  <p className="text-muted-foreground">"{ar ? t.textAr : t.textEn}"</p>
                  <footer className="mt-4 font-semibold text-primary">{ar ? t.nameAr : t.nameEn}</footer>
                </blockquote>
              ))}
            </div>
          </section>

          {/* Contact/footer */}
          <section id="contact" className="relative mt-10 overflow-hidden rounded-3xl border border-border bg-surface/80 p-6 backdrop-blur sm:mt-14 sm:rounded-[2rem] sm:p-10">
            <GlowBg className="opacity-40" />
            <div className="relative grid gap-8 lg:grid-cols-[auto_1fr]">
              <MrkLogo className="text-3xl text-primary" />
              <div className="grid gap-3 text-sm sm:grid-cols-2">
                <div className="flex items-center gap-2 min-w-0"><MapPin className="size-4 shrink-0 text-primary" /><span className="truncate">{ar ? company.addressAr : company.addressEn}</span></div>
                <div className="flex items-center gap-2 min-w-0"><Clock className="size-4 shrink-0 text-primary" /><span className="truncate">{ar ? company.hoursAr : company.hoursEn}</span></div>
                <div className="flex items-center gap-2 min-w-0"><Mail className="size-4 shrink-0 text-primary" /><span className="truncate">{company.email}</span></div>
                <div className="flex items-center gap-2 min-w-0"><Phone className="size-4 shrink-0 text-primary" /><span className="truncate">{company.phone}</span></div>
              </div>
            </div>
            <div className="relative mt-6 flex flex-wrap gap-3">
              <a href={`https://wa.me/${company.whatsapp.replace(/\D/g, "")}`} className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground">
                <MessageCircle className="size-4 shrink-0" /> {ar ? "واتساب" : "WhatsApp"}
              </a>
              <a href={`tel:${company.phone}`} className="inline-flex items-center gap-2 rounded-full border border-border px-5 py-2.5 text-sm font-semibold">
                <Phone className="size-4 shrink-0" /> {ar ? "اتصل الآن" : "Call now"}
              </a>
            </div>
          </section>
        </main>
      </div>
    </SiteShell>
  );
}
