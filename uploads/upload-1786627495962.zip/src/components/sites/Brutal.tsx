import { SiteShell, useLang } from "@/components/site/kit";
import { MrkLogo } from "@/components/site/Logo";
import { Frame, Marquee } from "@/components/site/ui";
import { company, projects, services, stats, testimonials } from "@/data/mrk";
import { Phone, MessageCircle, MapPin, Clock, Mail, ArrowRight } from "lucide-react";

export default function Brutal() {
  const [lang, setLang] = useLang();
  const ar = lang === "ar";
  const ticker = ar
    ? ["شقق", "فيلات", "محلات", "مكاتب", "تقسيط ١٠ سنوات", "مول العرب", "6 أكتوبر"]
    : ["APARTMENTS", "VILLAS", "RETAIL", "OFFICES", "10Y PLANS", "MALL OF ARABIA", "6 OCTOBER"];

  return (
    <SiteShell theme="site-brutal" lang={lang} setLang={setLang} designNameAr="بروتال" designNameEn="Brutal">
      <div className="border-b-[3px] border-foreground">
        <div className="flex flex-wrap items-center justify-between gap-3 p-4 sm:p-5">
          <MrkLogo className="text-2xl text-foreground sm:text-3xl" />
          <a href={`tel:${company.phone}`} className="border-[3px] border-foreground bg-foreground px-4 py-2 text-sm font-black text-primary-foreground shadow-[4px_4px_0_0_var(--color-accent)] transition-transform hover:-translate-y-0.5">
            {company.phone}
          </a>
        </div>
      </div>

      <div className="border-b-[3px] border-foreground bg-foreground py-2 text-primary-foreground">
        <Marquee items={ticker} />
      </div>

      <header className="grid border-b-[3px] border-foreground lg:grid-cols-2">
        <div className="dots border-b-[3px] border-foreground p-6 sm:p-8 lg:border-b-0 lg:border-e-[3px]">
          <span className="inline-block border-2 border-foreground bg-accent px-3 py-1 text-[11px] font-black uppercase tracking-widest text-accent-foreground">
            {ar ? "عقارات 6 أكتوبر" : "6th of October Real Estate"}
          </span>
          <h1 className="display mt-5 text-[2.4rem] font-black uppercase leading-[0.95] sm:text-6xl lg:text-7xl">
            {ar ? "نبيع عقار." : "WE SELL"}<br />
            {ar ? "مش وعود." : "PROPERTY."}
          </h1>
          <p className="mt-6 max-w-md text-sm font-semibold leading-6">{ar ? company.descAr : company.descEn}</p>
          <div className="mt-7 flex flex-wrap gap-3">
            <a href={`tel:${company.phone}`} className="inline-flex items-center gap-2 border-[3px] border-foreground bg-primary px-5 py-2.5 text-sm font-black uppercase text-primary-foreground shadow-[4px_4px_0_0_var(--color-foreground)] transition-transform hover:-translate-y-0.5"><Phone className="size-4 shrink-0" />{ar ? "اتصل الآن" : "Call now"}</a>
            <a href={`https://wa.me/${company.whatsapp.replace(/\D/g, "")}`} className="inline-flex items-center gap-2 border-[3px] border-foreground bg-card px-5 py-2.5 text-sm font-black uppercase shadow-[4px_4px_0_0_var(--color-foreground)] transition-transform hover:-translate-y-0.5"><MessageCircle className="size-4 shrink-0 text-accent" />{ar ? "واتساب" : "WhatsApp"}</a>
          </div>
          <div className="mt-8 grid grid-cols-2 gap-0 border-[3px] border-foreground">
            {stats.map((s, i) => (
              <div key={s.labelEn} className={`p-3 sm:p-4 ${i % 2 === 0 ? "border-e-[3px]" : ""} ${i < 2 ? "border-b-[3px]" : ""} border-foreground`}>
                <div className="display text-3xl font-black">{ar ? s.valueAr : s.valueEn}</div>
                <div className="text-[11px] font-bold uppercase">{ar ? s.labelAr : s.labelEn}</div>
              </div>
            ))}
          </div>
        </div>
        <Frame src={projects[2]!.image} alt={ar ? "مول تجاري" : "Mall"} ratio="4/3" className="border-b-0" />
      </header>

      <main>
        <section className="grid border-b-[3px] border-foreground sm:grid-cols-2 lg:grid-cols-4">
          {projects.map((p, i) => (
            <article key={p.id} className={`relative border-b-[3px] border-foreground p-4 last:border-b-0 sm:p-5 lg:border-b-0 lg:last:border-e-0 ${i < 3 ? "lg:border-e-[3px]" : ""}`}>
              <span className="display absolute end-3 top-3 z-10 text-4xl font-black text-background/70 sm:text-5xl" aria-hidden>
                {String(i + 1).padStart(2, "0")}
              </span>
              <Frame src={p.image} alt={ar ? p.nameAr : p.nameEn} ratio="4/3" className="border-[3px] border-foreground" />
              <h3 className="display mt-4 truncate text-xl font-black uppercase">{ar ? p.nameAr : p.nameEn}</h3>
              <p className="text-xs font-bold uppercase text-muted-foreground">{ar ? p.typeAr : p.typeEn}</p>
              <p className="mt-2 inline-block bg-foreground px-2 py-1 text-xs font-black text-primary-foreground">{ar ? p.priceAr : p.priceEn}</p>
            </article>
          ))}
        </section>

        <section className="grid border-b-[3px] border-foreground sm:grid-cols-2">
          {services.map((s, i) => (
            <div key={s.titleEn} className={`p-6 sm:p-8 ${i % 2 === 0 ? "sm:border-e-[3px]" : ""} ${i < 2 ? "border-b-[3px]" : ""} border-foreground`}>
              <span className="inline-flex size-8 items-center justify-center border-2 border-foreground bg-accent text-xs font-black text-accent-foreground">{i + 1}</span>
              <h3 className="display mt-3 text-2xl font-black uppercase">{ar ? s.titleAr : s.titleEn}</h3>
              <p className="mt-2 text-sm font-semibold text-muted-foreground">{ar ? s.descAr : s.descEn}</p>
            </div>
          ))}
        </section>

        <section className="grid border-b-[3px] border-foreground divide-y-[3px] divide-foreground sm:grid-cols-3 sm:divide-y-0">
          {testimonials.map((t, i) => (
            <blockquote key={t.nameEn} className={`p-6 text-sm font-semibold ${i < 2 ? "sm:border-e-[3px]" : ""} border-foreground`}>
              "{ar ? t.textAr : t.textEn}"
              <footer className="mt-3 flex items-center gap-2 text-xs font-black uppercase"><ArrowRight className="size-3.5 shrink-0 rtl:rotate-180" />{ar ? t.nameAr : t.nameEn}</footer>
            </blockquote>
          ))}
        </section>

        <footer id="contact" className="bg-foreground p-6 text-primary-foreground sm:p-8">
          <div className="flex flex-wrap items-start justify-between gap-6">
            <div>
              <MrkLogo className="text-3xl sm:text-4xl" />
              <p className="mt-4 flex items-center gap-2 text-sm font-black uppercase"><MapPin className="size-4 shrink-0" /><span>{ar ? company.addressAr : company.addressEn}</span></p>
              <p className="mt-2 flex items-center gap-2 text-sm font-bold"><Clock className="size-4 shrink-0" /><span>{ar ? company.hoursAr : company.hoursEn}</span></p>
              <p className="mt-2 flex items-center gap-2 text-sm font-bold"><Mail className="size-4 shrink-0" /><span className="truncate">{company.email}</span></p>
            </div>
            <div className="flex flex-wrap gap-3">
              <a href={`tel:${company.phone}`} className="inline-flex items-center gap-2 border-[3px] border-primary-foreground px-5 py-2.5 text-sm font-black uppercase"><Phone className="size-4 shrink-0" />{company.phone}</a>
              <a href={`https://wa.me/${company.whatsapp.replace(/\D/g, "")}`} className="inline-flex items-center gap-2 border-[3px] border-primary-foreground bg-accent px-5 py-2.5 text-sm font-black uppercase text-accent-foreground"><MessageCircle className="size-4 shrink-0" />{ar ? "واتساب" : "WhatsApp"}</a>
            </div>
          </div>
        </footer>
      </main>
    </SiteShell>
  );
}
