import { SiteShell, useLang } from "@/components/site/kit";
import { MrkLogo } from "@/components/site/Logo";
import { Frame, Eyebrow, Pill, SectionHead } from "@/components/site/ui";
import { company, projects, services, stats, testimonials } from "@/data/mrk";
import compound from "@/assets/compound.jpg";
import mall from "@/assets/mall.jpg";
import { Phone, MessageCircle, MapPin, Clock, Mail } from "lucide-react";

export default function Clay() {
  const [lang, setLang] = useLang();
  const ar = lang === "ar";

  return (
    <SiteShell theme="site-clay" lang={lang} setLang={setLang} designNameAr="كلاي" designNameEn="Clay">
      <div className="relative mx-auto max-w-6xl px-4 sm:px-6">
        {/* decorative blobs */}
        <div aria-hidden className="pointer-events-none absolute -end-16 top-10 -z-10 size-64 rounded-full bg-primary/15 blur-3xl" />
        <div aria-hidden className="pointer-events-none absolute -start-20 top-72 -z-10 size-72 rounded-full bg-accent/20 blur-3xl" />

        <nav className="flex flex-wrap items-center justify-between gap-3 py-6">
          <MrkLogo className="text-xl text-primary" />
          <div className="flex flex-wrap items-center gap-2">
            <Pill className="border-border bg-card"><Clock className="size-3.5 text-primary" /> {ar ? company.hoursAr : company.hoursEn}</Pill>
            <a href={`tel:${company.phone}`} className="rounded-full bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground shadow-soft">
              {ar ? "اتصل بنا" : "Call us"}
            </a>
          </div>
        </nav>

        {/* Hero */}
        <header className="grid gap-8 rounded-[1.75rem] bg-card p-6 shadow-soft sm:rounded-[2.5rem] sm:p-10 lg:grid-cols-2 lg:items-center">
          <div className="min-w-0">
            <Eyebrow>{ar ? "MRK العقارية" : "MRK Real Estate"}</Eyebrow>
            <h1 className="display mt-4 text-balance text-3xl font-semibold leading-tight sm:text-4xl lg:text-5xl">
              {ar ? "نساعدك تلاقي مكانك المريح" : "We help you find your comfortable place"}
            </h1>
            <p className="mt-4 text-pretty text-muted-foreground">{ar ? company.descAr : company.descEn}</p>
            <div className="mt-7 flex flex-wrap gap-3">
              <a href={`tel:${company.phone}`} className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground shadow-lift">
                <Phone className="size-4" /> {ar ? "احجز مكالمة" : "Book a call"}
              </a>
              <a href={`https://wa.me/${company.whatsapp.replace(/\D/g, "")}`} className="inline-flex items-center gap-2 rounded-full border border-border bg-background px-6 py-3.5 text-sm font-semibold text-foreground">
                <MessageCircle className="size-4" /> WhatsApp
              </a>
            </div>
          </div>
          <div className="relative min-w-0">
            <Frame src={compound} alt="" ratio="4/3" className="rounded-[1.5rem] shadow-soft sm:rounded-[2rem]" />
            <div className="absolute -bottom-6 -start-4 w-32 rounded-2xl border-4 border-background bg-accent p-2 shadow-lift sm:w-40">
              <Frame src={mall} alt="" ratio="1/1" className="rounded-xl" />
            </div>
          </div>
        </header>

        <main className="space-y-8 py-10 sm:space-y-12 sm:py-14">
          {/* Stats bento */}
          <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {stats.map((s, i) => (
              <div key={s.labelEn} className={`rounded-[1.75rem] p-5 text-center shadow-soft ${i % 2 === 0 ? "bg-secondary text-secondary-foreground" : "bg-card"}`}>
                <div className="display text-xl font-semibold sm:text-2xl">{ar ? s.valueAr : s.valueEn}</div>
                <div className="mt-1 text-xs opacity-80">{ar ? s.labelAr : s.labelEn}</div>
              </div>
            ))}
          </section>

          {/* Projects staggered bento */}
          <section>
            <SectionHead eyebrow={ar ? "مشاريعنا" : "Our projects"} title={ar ? "اختار المكان اللي يشبهك" : "Pick the place that suits you"} />
            <div className="mt-8 grid gap-5 sm:grid-cols-2">
              {projects.map((p, i) => (
                <article key={p.id} className={`rounded-[1.75rem] bg-card p-4 shadow-soft sm:rounded-[2rem] sm:p-5 ${i === 0 ? "sm:col-span-2" : ""}`}>
                  <div className="grid gap-4 sm:grid-cols-[1.3fr_1fr] sm:items-center" style={i === 0 ? {} : { gridTemplateColumns: "1fr" }}>
                    <Frame src={p.image} alt={ar ? p.nameAr : p.nameEn} ratio={i === 0 ? "16/9" : "4/3"} className="rounded-[1.5rem] sm:rounded-[1.75rem]" />
                    <div className="min-w-0 px-1 pt-4 sm:pt-0">
                      <h3 className="display truncate text-xl font-semibold">{ar ? p.nameAr : p.nameEn}</h3>
                      <p className="mt-1 text-sm text-muted-foreground">{ar ? p.typeAr : p.typeEn} — {ar ? p.areaAr : p.areaEn}</p>
                      <p className="mt-3 inline-block rounded-full bg-accent px-4 py-2 text-sm font-semibold text-accent-foreground">
                        {ar ? p.priceAr : p.priceEn}
                      </p>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </section>

          {/* Services */}
          <section className="rounded-[1.75rem] bg-card p-6 shadow-soft sm:rounded-[2.5rem] sm:p-10">
            <SectionHead align="center" eyebrow={ar ? "خدماتنا" : "Our services"} title={ar ? "كل خدمة بتساعدك تقرر بثقة" : "Every service helps you decide confidently"} />
            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              {services.map((s, i) => (
                <div key={s.titleEn} className="flex items-start gap-4 rounded-[1.75rem] bg-secondary p-5 text-secondary-foreground">
                  <span className="display flex size-11 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
                    {i + 1}
                  </span>
                  <div className="min-w-0">
                    <h3 className="font-semibold">{ar ? s.titleAr : s.titleEn}</h3>
                    <p className="mt-1 text-sm opacity-80">{ar ? s.descAr : s.descEn}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Testimonials */}
          <section>
            <SectionHead align="center" eyebrow={ar ? "قالوا عننا" : "Testimonials"} title={ar ? "تجارب دافئة من عملائنا" : "Warm stories from our clients"} />
            <div className="mt-8 grid gap-5 sm:grid-cols-3">
              {testimonials.map((t) => (
                <blockquote key={t.nameEn} className="rounded-[1.75rem] bg-card p-6 text-sm shadow-soft">
                  <p className="text-muted-foreground">"{ar ? t.textAr : t.textEn}"</p>
                  <footer className="mt-4 flex items-center gap-3">
                    <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-accent text-xs font-bold text-accent-foreground">
                      {(ar ? t.nameAr : t.nameEn).slice(0, 1)}
                    </span>
                    <span className="truncate font-semibold text-foreground">{ar ? t.nameAr : t.nameEn}</span>
                  </footer>
                </blockquote>
              ))}
            </div>
          </section>

          {/* Footer/contact */}
          <footer className="rounded-[1.75rem] bg-primary p-6 text-primary-foreground shadow-lift sm:rounded-[2.5rem] sm:p-10">
            <div className="flex flex-col gap-8 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <MrkLogo className="text-2xl" />
                <p className="mt-3 max-w-xs text-sm opacity-90">{ar ? company.taglineAr : company.taglineEn}</p>
              </div>
              <div className="grid gap-3 text-sm sm:grid-cols-1">
                <p className="flex items-center gap-2 min-w-0"><MapPin className="size-4 shrink-0" /> <span className="break-words">{ar ? company.addressAr : company.addressEn}</span></p>
                <p className="flex items-center gap-2"><Mail className="size-4 shrink-0" /> <span className="break-words">{company.email}</span></p>
                <p className="flex items-center gap-2"><Clock className="size-4 shrink-0" /> {ar ? company.hoursAr : company.hoursEn}</p>
              </div>
              <div className="flex shrink-0 flex-col gap-3">
                <a href={`tel:${company.phone}`} className="inline-flex items-center gap-2 rounded-full bg-background px-5 py-3 text-sm font-semibold text-foreground">
                  <Phone className="size-4" /> {company.phone}
                </a>
                <a href={`https://wa.me/${company.whatsapp.replace(/\D/g, "")}`} className="inline-flex items-center gap-2 rounded-full border border-primary-foreground/40 px-5 py-3 text-sm font-semibold">
                  <MessageCircle className="size-4" /> WhatsApp
                </a>
              </div>
            </div>
          </footer>
        </main>
      </div>
    </SiteShell>
  );
}
