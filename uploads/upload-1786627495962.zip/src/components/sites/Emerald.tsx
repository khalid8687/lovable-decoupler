import { useState } from "react";
import { SiteShell, useLang } from "@/components/site/kit";
import { MrkLogo } from "@/components/site/Logo";
import { Frame, Eyebrow, SectionHead, Pill } from "@/components/site/ui";
import { company, projects, services, stats, testimonials } from "@/data/mrk";
import compound from "@/assets/compound.jpg";
import { Phone, MessageCircle, MapPin, Clock, Mail } from "lucide-react";

export default function Emerald() {
  const [lang, setLang] = useLang();
  const ar = lang === "ar";
  const [hover, setHover] = useState<string | null>(null);
  const active = projects.find((p) => p.id === hover) ?? projects[0]!;

  return (
    <SiteShell theme="site-emerald" lang={lang} setLang={setLang} designNameAr="إمرالد" designNameEn="Emerald">
      <div className="relative">
        <header className="relative overflow-hidden">
          <div className="mesh pointer-events-none absolute inset-0 opacity-40" aria-hidden />
          <div className="relative mx-auto max-w-4xl px-4 pt-10 text-center sm:px-6 sm:pt-16">
            <div className="mx-auto flex w-fit items-center gap-3 border border-gold/50 px-6 py-2">
              <MrkLogo className="text-2xl text-primary" />
            </div>
            <Eyebrow className="mx-auto mt-8 justify-center">{ar ? "منذ ٢٠١٢ — مول العرب" : "Since 2012 — Mall of Arabia"}</Eyebrow>
            <h1 className="display mt-5 text-balance text-4xl leading-tight sm:text-5xl lg:text-6xl">
              {ar ? "تسويق عقاري" : "Real estate,"} <br />
              <span className="text-primary">{ar ? "بمعايير مختلفة" : "refined to perfection"}</span>
            </h1>
            <p className="mx-auto mt-6 max-w-xl text-pretty text-sm leading-7 text-muted-foreground sm:text-base">
              {ar ? company.descAr : company.descEn}
            </p>
          </div>

          <div className="relative mx-auto mt-10 max-w-3xl px-4 sm:px-6">
            <div className="border border-gold/60 p-2 shadow-soft sm:p-3">
              <Frame src={compound} ratio="16/10" className="sm:!aspect-[21/9]" overlay>
                <div className="flex h-full flex-col items-center justify-end p-6 text-center sm:p-10">
                  <p className="display text-lg text-primary-foreground sm:text-2xl">
                    {ar ? company.taglineAr : company.taglineEn}
                  </p>
                </div>
              </Frame>
            </div>
          </div>
        </header>

        <div className="mx-auto mt-12 max-w-5xl border-y border-gold/40 sm:mt-16">
          <div className="grid divide-y divide-gold/30 sm:grid-cols-4 sm:divide-x sm:divide-y-0">
            {stats.map((s) => (
              <div key={s.labelEn} className="p-6 text-center">
                <div className="display text-3xl text-primary">{ar ? s.valueAr : s.valueEn}</div>
                <div className="mt-1 text-xs uppercase tracking-wider text-muted-foreground">{ar ? s.labelAr : s.labelEn}</div>
              </div>
            ))}
          </div>
        </div>

        <main className="mx-auto max-w-5xl px-4 py-16 sm:px-6 sm:py-24">
          <SectionHead align="center" eyebrow={ar ? "ماذا نقدم" : "What we offer"} title={<span className="display">{ar ? "خدماتنا" : "Our services"}</span>} className="mx-auto" />
          <ol className="mx-auto mt-10 max-w-3xl">
            {services.map((s, i) => (
              <li key={s.titleEn} className="flex gap-4 border-b border-border py-5 sm:gap-6 sm:py-6">
                <span className="display shrink-0 text-2xl text-gold">{String(i + 1).padStart(2, "0")}</span>
                <div className="min-w-0">
                  <h3 className="display text-xl">{ar ? s.titleAr : s.titleEn}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{ar ? s.descAr : s.descEn}</p>
                </div>
              </li>
            ))}
          </ol>

          <div className="mt-20 sm:mt-28">
            <SectionHead align="center" eyebrow={ar ? "المحفظة" : "Portfolio"} title={<span className="display">{ar ? "مشاريع مختارة" : "Selected projects"}</span>} className="mx-auto" />
            <div className="mt-10 grid gap-8 lg:grid-cols-[1.1fr_1fr]">
              <div className="order-2 lg:order-1">
                <Frame src={active.image} alt={ar ? active.nameAr : active.nameEn} ratio="4/5" className="rounded-lg shadow-lift transition-all duration-500" />
              </div>
              <ol className="order-1 divide-y divide-border lg:order-2">
                {projects.map((p, i) => (
                  <li
                    key={p.id}
                    onMouseEnter={() => setHover(p.id)}
                    className="group flex items-baseline gap-4 py-5 transition-colors hover:text-primary"
                  >
                    <span className="display text-sm text-gold">{String(i + 1).padStart(2, "0")}</span>
                    <div className="min-w-0 flex-1">
                      <h3 className="display text-2xl transition-colors group-hover:text-primary sm:text-3xl">{ar ? p.nameAr : p.nameEn}</h3>
                      <p className="mt-1 text-xs uppercase tracking-widest text-muted-foreground">{ar ? p.typeAr : p.typeEn} · {ar ? p.areaAr : p.areaEn}</p>
                    </div>
                    <span className="hidden shrink-0 text-sm text-primary sm:inline">{ar ? p.priceAr : p.priceEn}</span>
                  </li>
                ))}
              </ol>
            </div>
          </div>

          <section className="mt-20 border-t border-gold/40 pt-14 text-center sm:mt-28">
            <p className="display mx-auto max-w-3xl text-balance text-2xl leading-snug italic sm:text-3xl">
              “{ar ? testimonials[0]!.textAr : testimonials[0]!.textEn}”
            </p>
            <footer className="mt-4 text-xs uppercase tracking-widest text-muted-foreground">
              {ar ? testimonials[0]!.nameAr : testimonials[0]!.nameEn}
            </footer>
            <div className="mx-auto mt-10 grid max-w-3xl gap-6 sm:grid-cols-2">
              {testimonials.slice(1).map((t) => (
                <blockquote key={t.nameEn} className="border-t border-border pt-5 text-start">
                  <p className="text-sm leading-6 text-muted-foreground">“{ar ? t.textAr : t.textEn}”</p>
                  <footer className="mt-2 text-xs uppercase tracking-widest text-primary">{ar ? t.nameAr : t.nameEn}</footer>
                </blockquote>
              ))}
            </div>
          </section>
        </main>

        <footer className="border-t border-gold/40 bg-secondary px-4 py-12 text-secondary-foreground sm:py-16">
          <div className="mx-auto max-w-4xl text-center">
            <MrkLogo className="mx-auto text-2xl text-primary" />
            <p className="mt-6 flex flex-wrap items-center justify-center gap-2 text-sm"><MapPin className="size-4 text-gold" />{ar ? company.addressAr : company.addressEn}</p>
            <p className="mt-2 flex flex-wrap items-center justify-center gap-2 text-sm"><Clock className="size-4 text-gold" />{ar ? company.hoursAr : company.hoursEn}</p>
            <p className="mt-2 flex flex-wrap items-center justify-center gap-2 text-sm"><Mail className="size-4 text-gold" />{company.email}</p>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
              <a href={`tel:${company.phone}`} className="inline-flex items-center gap-2 border border-gold px-6 py-3 text-sm font-medium transition-colors hover:bg-gold hover:text-background">
                <Phone className="size-4" />{ar ? "اتصل بنا" : "Call us"}
              </a>
              <a href={`https://wa.me/${company.whatsapp.replace(/\D/g, "")}`} className="inline-flex items-center gap-2 bg-primary px-6 py-3 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90">
                <MessageCircle className="size-4" />{ar ? "واتساب" : "WhatsApp"}
              </a>
            </div>
          </div>
        </footer>
      </div>
    </SiteShell>
  );
}
