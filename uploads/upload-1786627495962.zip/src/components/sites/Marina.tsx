import { SiteShell, useLang } from "@/components/site/kit";
import { MrkLogo } from "@/components/site/Logo";
import { Frame, SectionHead, Pill } from "@/components/site/ui";
import { company, projects, services, stats, testimonials } from "@/data/mrk";
import { Phone, MessageCircle, MapPin, Clock, Mail, Building2, HandCoins, Compass, KeyRound, Star } from "lucide-react";

const icons = [Building2, HandCoins, Compass, KeyRound];

export default function Marina() {
  const [lang, setLang] = useLang();
  const ar = lang === "ar";

  const nav = [
    { ar: "الرئيسية", en: "Home", href: "#top" },
    { ar: "المشاريع", en: "Projects", href: "#projects" },
    { ar: "الخدمات", en: "Services", href: "#services" },
    { ar: "تواصل", en: "Contact", href: "#contact" },
  ];

  return (
    <SiteShell theme="site-marina" lang={lang} setLang={setLang} designNameAr="مارينا" designNameEn="Marina">
      <div id="top" className="mx-auto max-w-7xl px-4 sm:px-6">
        <nav className="flex flex-wrap items-center justify-between gap-3 py-5">
          <MrkLogo className="text-2xl text-primary" />
          <div className="no-scrollbar hidden gap-6 overflow-x-auto text-sm font-medium text-muted-foreground md:flex">
            {nav.map((n) => (
              <a key={n.en} href={n.href} className="shrink-0 transition-colors hover:text-foreground">{ar ? n.ar : n.en}</a>
            ))}
          </div>
          <a href={`tel:${company.phone}`} className="inline-flex shrink-0 items-center gap-2 rounded-full bg-primary px-4 py-2.5 text-xs font-semibold text-primary-foreground shadow-soft transition-transform hover:-translate-y-0.5">
            <Phone className="size-3.5 shrink-0" /> {ar ? "اتصل بنا" : "Call us"}
          </a>
        </nav>

        {/* Hero */}
        <section className="grid items-center gap-8 py-6 lg:grid-cols-2">
          <div>
            <Pill><Star className="size-3.5 shrink-0 text-accent" />{ar ? company.addressAr : company.addressEn}</Pill>
            <h1 className="display mt-5 text-balance text-3xl font-semibold leading-tight sm:text-4xl lg:text-5xl">
              {ar ? "وحدات مختارة بعناية داخل أفضل كمبوندات أكتوبر" : "Hand-picked units in October's best compounds"}
            </h1>
            <p className="mt-5 max-w-lg text-sm leading-7 text-muted-foreground sm:text-base">{ar ? company.descAr : company.descEn}</p>
            <div className="mt-7 flex flex-wrap gap-3">
              <a href={`tel:${company.phone}`} className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-soft transition-transform hover:-translate-y-0.5"><Phone className="size-4 shrink-0" />{ar ? "احجز استشارة" : "Book consult"}</a>
              <a href={`https://wa.me/${company.whatsapp.replace(/\D/g, "")}`} className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-6 py-3 text-sm font-semibold transition-transform hover:-translate-y-0.5"><MessageCircle className="size-4 shrink-0 text-accent" />{ar ? "واتساب" : "WhatsApp"}</a>
            </div>
          </div>
          <div className="relative">
            <Frame src={projects[1]!.image} alt={ar ? "تشطيب داخلي" : "Interior"} ratio="4/3" className="rounded-[2rem] shadow-lift" />
            <div className="absolute -bottom-4 start-4 flex items-center gap-3 rounded-2xl border border-border bg-card px-4 py-3 shadow-lift sm:start-6">
              <div className="rounded-xl bg-primary/10 p-2"><Building2 className="size-5 shrink-0 text-primary" /></div>
              <div className="min-w-0">
                <div className="text-sm font-semibold">{ar ? stats[1]!.valueAr : stats[1]!.valueEn}</div>
                <div className="truncate text-xs text-muted-foreground">{ar ? stats[1]!.labelAr : stats[1]!.labelEn}</div>
              </div>
            </div>
            <div className="absolute -top-4 end-4 hidden items-center gap-3 rounded-2xl border border-border bg-card px-4 py-3 shadow-lift sm:flex sm:end-6">
              <div className="rounded-xl bg-accent/10 p-2"><Star className="size-5 shrink-0 text-accent" /></div>
              <div className="min-w-0">
                <div className="text-sm font-semibold">{ar ? stats[3]!.valueAr : stats[3]!.valueEn}</div>
                <div className="truncate text-xs text-muted-foreground">{ar ? stats[3]!.labelAr : stats[3]!.labelEn}</div>
              </div>
            </div>
          </div>
        </section>

        {/* Stats strip */}
        <section className="grid grid-cols-2 gap-3 py-6 sm:gap-4 lg:grid-cols-4">
          {stats.map((s) => (
            <div key={s.labelEn} className="rounded-2xl border border-border bg-card p-5 shadow-soft transition-transform hover:-translate-y-1">
              <div className="display text-2xl font-semibold text-foreground">{ar ? s.valueAr : s.valueEn}</div>
              <div className="mt-1 text-xs text-muted-foreground">{ar ? s.labelAr : s.labelEn}</div>
            </div>
          ))}
        </section>

        {/* Projects carousel */}
        <section id="projects" className="py-8">
          <SectionHead eyebrow={ar ? "المشاريع" : "Projects"} title={ar ? "استكشف مشاريعنا المتاحة" : "Explore available projects"} />
          <div className="no-scrollbar mt-6 flex snap-x snap-mandatory gap-5 overflow-x-auto pb-4">
            {projects.map((p) => (
              <article key={p.id} className="w-72 shrink-0 snap-start overflow-hidden rounded-2xl border border-border bg-card shadow-soft transition-transform hover:-translate-y-1 sm:w-80">
                <Frame src={p.image} alt={ar ? p.nameAr : p.nameEn} ratio="4/3" />
                <div className="p-5">
                  <span className="text-xs font-semibold uppercase tracking-wide text-primary">{ar ? p.typeAr : p.typeEn}</span>
                  <h3 className="mt-1 truncate font-semibold">{ar ? p.nameAr : p.nameEn}</h3>
                  <p className="mt-1 text-xs text-muted-foreground">{ar ? p.areaAr : p.areaEn}</p>
                  <p className="mt-3 rounded-full bg-primary/10 px-3 py-1 text-center text-sm font-semibold text-primary">{ar ? p.priceAr : p.priceEn}</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        {/* Services icon grid */}
        <section id="services" className="py-8">
          <SectionHead eyebrow={ar ? "الخدمات" : "Services"} title={ar ? "خدمات متكاملة تحت سقف واحد" : "Full-service, under one roof"} />
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {services.map((s, i) => {
              const Icon = icons[i % icons.length]!;
              return (
                <div key={s.titleEn} className="rounded-2xl border border-border bg-card p-6 shadow-soft transition-transform hover:-translate-y-1">
                  <div className="inline-flex rounded-xl bg-primary/10 p-3"><Icon className="size-5 shrink-0 text-primary" /></div>
                  <h3 className="mt-4 font-semibold">{ar ? s.titleAr : s.titleEn}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{ar ? s.descAr : s.descEn}</p>
                </div>
              );
            })}
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-8">
          <div className="grid gap-4 sm:grid-cols-3">
            {testimonials.map((t) => (
              <blockquote key={t.nameEn} className="rounded-2xl bg-secondary p-6 text-sm text-secondary-foreground shadow-soft">
                <div className="mb-2 flex gap-0.5 text-accent">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className="size-3.5 shrink-0 fill-current" />)}</div>
                "{ar ? t.textAr : t.textEn}"
                <footer className="mt-3 text-xs font-semibold opacity-70">{ar ? t.nameAr : t.nameEn}</footer>
              </blockquote>
            ))}
          </div>
        </section>

        {/* Footer */}
        <footer id="contact" className="mb-8 grid gap-6 rounded-3xl border border-border bg-card p-6 shadow-soft sm:p-8 lg:grid-cols-[auto_1fr_auto] lg:items-center">
          <MrkLogo className="text-2xl text-primary" />
          <div className="grid gap-2 text-sm text-muted-foreground sm:grid-cols-2">
            <div className="flex items-center gap-2 min-w-0"><MapPin className="size-4 shrink-0 text-primary" /><span className="truncate">{ar ? company.addressAr : company.addressEn}</span></div>
            <div className="flex items-center gap-2 min-w-0"><Clock className="size-4 shrink-0 text-primary" /><span className="truncate">{ar ? company.hoursAr : company.hoursEn}</span></div>
            <div className="flex items-center gap-2 min-w-0"><Mail className="size-4 shrink-0 text-primary" /><span className="truncate">{company.email}</span></div>
            <div className="flex items-center gap-2 min-w-0"><Phone className="size-4 shrink-0 text-primary" /><span className="truncate">{company.phone}</span></div>
          </div>
          <div className="flex flex-wrap gap-3">
            <a href={`https://wa.me/${company.whatsapp.replace(/\D/g, "")}`} className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground"><MessageCircle className="size-4 shrink-0" />{ar ? "واتساب" : "WhatsApp"}</a>
            <a href={`tel:${company.phone}`} className="inline-flex items-center gap-2 rounded-full border border-border px-5 py-2.5 text-sm font-semibold"><Phone className="size-4 shrink-0" />{ar ? "اتصل" : "Call"}</a>
          </div>
        </footer>
      </div>
    </SiteShell>
  );
}
