import { SiteShell, useLang } from "@/components/site/kit";
import { MrkLogo } from "@/components/site/Logo";
import { Frame, Eyebrow, Pill, SectionHead, StatBlock, GlowBg } from "@/components/site/ui";
import { company, projects, services, stats, testimonials } from "@/data/mrk";
import tower from "@/assets/tower.jpg";
import compound from "@/assets/compound.jpg";
import { Phone, MessageCircle, MapPin, Clock, Mail, CheckCircle2, Building2, ShieldCheck, TrendingUp, Wallet, type LucideIcon } from "lucide-react";

const icons: LucideIcon[] = [Building2, ShieldCheck, TrendingUp, Wallet];

export default function Mint() {
  const [lang, setLang] = useLang();
  const ar = lang === "ar";

  return (
    <SiteShell theme="site-mint" lang={lang} setLang={setLang} designNameAr="مِنت" designNameEn="Mint">
      {/* Sticky pill nav */}
      <div className="sticky top-[41px] z-40 border-b border-border bg-background/90 backdrop-blur supports-[backdrop-filter]:bg-background/70">
        <nav className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <MrkLogo className="text-xl text-foreground" />
          <div className="hidden items-center gap-1 rounded-full border border-border bg-card p-1 text-sm shadow-sm sm:flex">
            <a href="#projects" className="rounded-full px-4 py-1.5 text-muted-foreground hover:bg-secondary hover:text-secondary-foreground">{ar ? "المشاريع" : "Projects"}</a>
            <a href="#services" className="rounded-full px-4 py-1.5 text-muted-foreground hover:bg-secondary hover:text-secondary-foreground">{ar ? "الخدمات" : "Services"}</a>
            <a href="#contact" className="rounded-full px-4 py-1.5 text-muted-foreground hover:bg-secondary hover:text-secondary-foreground">{ar ? "تواصل" : "Contact"}</a>
          </div>
          <a href={`tel:${company.phone}`} className="shrink-0 rounded-full bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground shadow-sm sm:text-sm">
            {ar ? "استشارة مجانية" : "Free consult"}
          </a>
        </nav>
      </div>

      <main className="relative mx-auto max-w-6xl px-4 sm:px-6">
        <GlowBg className="opacity-40" />

        {/* Split hero */}
        <header className="grid items-center gap-10 py-10 sm:py-16 lg:grid-cols-2">
          <div className="min-w-0">
            <Pill><span className="size-1.5 rounded-full bg-primary" /> {ar ? "مول العرب — 6 أكتوبر" : "Mall of Arabia — 6th of October"}</Pill>
            <h1 className="display mt-5 text-balance text-3xl font-bold leading-tight sm:text-4xl lg:text-5xl">
              {ar ? "ابحث، قارن، واحجز وحدتك بثقة" : "Search, compare and reserve with confidence"}
            </h1>
            <p className="mt-4 text-pretty text-muted-foreground">{ar ? company.descAr : company.descEn}</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a href={`tel:${company.phone}`} className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground shadow-lift">
                <Phone className="size-4" /> {ar ? "اتصل الآن" : "Call now"}
              </a>
              <a href={`https://wa.me/${company.whatsapp.replace(/\D/g, "")}`} className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-5 py-3 text-sm font-semibold text-foreground">
                <MessageCircle className="size-4" /> WhatsApp
              </a>
            </div>
            <div className="mt-9 grid grid-cols-2 gap-4 border-t border-border pt-6 sm:grid-cols-4">
              {stats.map((s) => (
                <StatBlock key={s.labelEn} value={ar ? s.valueAr : s.valueEn} label={ar ? s.labelAr : s.labelEn} />
              ))}
            </div>
          </div>
          <div className="relative min-w-0">
            <div className="absolute -inset-4 -z-10 rounded-[2rem] bg-gradient-to-br from-primary/20 to-accent/10 blur-2xl" />
            <Frame src={tower} alt="" ratio="4/3" className="rounded-3xl border border-border shadow-soft" />
            <div className="absolute -bottom-8 -start-6 w-40 rounded-2xl border border-border bg-card p-3 shadow-lift sm:w-52">
              <Frame src={compound} alt="" ratio="4/3" className="rounded-xl" />
              <p className="mt-2 truncate text-xs font-semibold">{ar ? projects[1]!.nameAr : projects[1]!.nameEn}</p>
              <p className="truncate text-[11px] text-primary">{ar ? projects[1]!.priceAr : projects[1]!.priceEn}</p>
            </div>
          </div>
        </header>

        {/* Feature grid */}
        <section id="services" className="py-12 sm:py-16">
          <SectionHead align="center" eyebrow={ar ? "لماذا نحن" : "Why us"} title={ar ? "كل ما تحتاجه في مكان واحد" : "Everything you need, in one place"} />
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {services.map((s, i) => {
              const Icon = icons[i % icons.length] ?? Building2;
              return (
                <div key={s.titleEn} className="group rounded-2xl border border-border bg-card p-5 shadow-sm transition-all hover:-translate-y-1 hover:shadow-lift">
                  <div className="flex size-11 items-center justify-center rounded-xl bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                    <Icon className="size-5" />
                  </div>
                  <h3 className="display mt-4 font-semibold">{ar ? s.titleAr : s.titleEn}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{ar ? s.descAr : s.descEn}</p>
                </div>
              );
            })}
          </div>
        </section>

        {/* Projects list */}
        <section id="projects" className="py-4 sm:py-6">
          <SectionHead eyebrow={ar ? "الوحدات" : "Units"} title={ar ? "الوحدات المتاحة الآن" : "Available units now"} />
          <div className="mt-8 grid gap-5 sm:grid-cols-2">
            {projects.map((p) => (
              <article key={p.id} className="flex gap-4 rounded-2xl border border-border bg-card p-4 shadow-sm transition-shadow hover:shadow-lift">
                <Frame src={p.image} alt={ar ? p.nameAr : p.nameEn} ratio="1/1" className="w-28 shrink-0 rounded-xl sm:w-32" />
                <div className="min-w-0 flex-1">
                  <h3 className="truncate font-semibold">{ar ? p.nameAr : p.nameEn}</h3>
                  <p className="text-xs text-muted-foreground">{ar ? p.typeAr : p.typeEn} · {ar ? p.areaAr : p.areaEn}</p>
                  <p className="mt-2 text-sm font-bold text-primary">{ar ? p.priceAr : p.priceEn}</p>
                  <div className="mt-2 flex items-center gap-1 text-xs text-muted-foreground">
                    <CheckCircle2 className="size-3.5 text-primary" /> {ar ? "معاينة متاحة" : "Viewing available"}
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-12 sm:py-16">
          <SectionHead align="center" eyebrow={ar ? "آراء العملاء" : "Testimonials"} title={ar ? "عملاء سعداء بتجربتهم" : "Clients happy with their experience"} />
          <div className="mt-8 grid gap-5 sm:grid-cols-3">
            {testimonials.map((t) => (
              <blockquote key={t.nameEn} className="rounded-2xl border border-border bg-card p-6 text-sm shadow-sm">
                <p className="text-muted-foreground">"{ar ? t.textAr : t.textEn}"</p>
                <footer className="mt-4 flex items-center gap-3">
                  <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                    {(ar ? t.nameAr : t.nameEn).slice(0, 1)}
                  </span>
                  <span className="truncate font-semibold text-foreground">{ar ? t.nameAr : t.nameEn}</span>
                </footer>
              </blockquote>
            ))}
          </div>
        </section>

        {/* CTA band */}
        <section id="contact" className="py-8 sm:py-10">
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary to-accent p-6 text-primary-foreground shadow-lift sm:p-10">
            <div className="dots pointer-events-none absolute inset-0 opacity-20" />
            <div className="relative flex flex-col justify-between gap-6 sm:flex-row sm:items-center">
              <div className="min-w-0">
                <h3 className="display text-2xl font-bold sm:text-3xl">{ar ? "جاهز تبدأ استثمارك؟" : "Ready to start investing?"}</h3>
                <p className="mt-2 max-w-md text-sm opacity-90">{ar ? company.taglineAr : company.taglineEn}</p>
              </div>
              <div className="flex shrink-0 flex-wrap gap-3">
                <a href={`tel:${company.phone}`} className="inline-flex items-center gap-2 rounded-full bg-background px-5 py-3 text-sm font-semibold text-foreground">
                  <Phone className="size-4" /> {company.phone}
                </a>
                <a href={`https://wa.me/${company.whatsapp.replace(/\D/g, "")}`} className="inline-flex items-center gap-2 rounded-full border border-primary-foreground/40 px-5 py-3 text-sm font-semibold">
                  <MessageCircle className="size-4" /> WhatsApp
                </a>
              </div>
            </div>
          </div>
        </section>

        <footer className="flex flex-col gap-4 border-t border-border py-8 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <MrkLogo className="text-xl text-foreground" />
          <div className="flex flex-wrap gap-x-6 gap-y-2 min-w-0">
            <span className="flex items-center gap-1.5 min-w-0"><MapPin className="size-4 shrink-0 text-primary" /> <span className="break-words">{ar ? company.addressAr : company.addressEn}</span></span>
            <span className="flex items-center gap-1.5"><Clock className="size-4 shrink-0 text-primary" /> {ar ? company.hoursAr : company.hoursEn}</span>
            <span className="flex items-center gap-1.5 min-w-0"><Mail className="size-4 shrink-0 text-primary" /> <span className="break-words">{company.email}</span></span>
          </div>
        </footer>
      </main>
    </SiteShell>
  );
}
