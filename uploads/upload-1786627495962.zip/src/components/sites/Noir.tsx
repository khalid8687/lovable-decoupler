import { SiteShell, useLang } from "@/components/site/kit";
import { MrkLogo } from "@/components/site/Logo";
import { Frame, Eyebrow, Pill, SectionHead, StatBlock, GlowBg } from "@/components/site/ui";
import { company, projects, services, stats, testimonials } from "@/data/mrk";
import interior from "@/assets/interior.jpg";
import { Phone, MessageCircle, MapPin, Clock, Mail, ArrowUpRight } from "lucide-react";

export default function Noir() {
  const [lang, setLang] = useLang();
  const ar = lang === "ar";

  return (
    <SiteShell theme="site-noir" lang={lang} setLang={setLang} designNameAr="نوار" designNameEn="Noir">
      {/* Cinematic magazine cover hero */}
      <header className="relative min-h-[90svh] overflow-hidden border-b border-border">
        <Frame src={interior} alt="" ratio="16/9" className="absolute inset-0 h-full w-full" imgClassName="opacity-95" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/55 to-background/5" />
        <div className="absolute inset-0 bg-gradient-to-b from-background/30 via-transparent to-transparent" />

        <div className="grain pointer-events-none absolute inset-0 opacity-30" />

        <div className="relative mx-auto flex min-h-[90svh] max-w-6xl flex-col justify-between px-4 py-6 sm:px-8 sm:py-10">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <MrkLogo className="text-2xl text-foreground sm:text-3xl" />
            <div className="flex flex-col items-end gap-2 text-end">
              <span className="text-[11px] uppercase tracking-[0.35em] text-gold">
                {ar ? "عدد 6 أكتوبر" : "The October Issue"}
              </span>
              <span className="text-[11px] uppercase tracking-[0.3em] text-muted-foreground">N°01 — 2024</span>
            </div>
          </div>

          <div className="max-w-3xl">
            <Eyebrow className="text-gold">{ar ? "عقارات فاخرة" : "Luxury Real Estate"}</Eyebrow>
            <h1 className="display mt-4 text-balance text-4xl leading-[0.98] sm:text-6xl lg:text-7xl">
              {ar ? "العقار الفاخر له عنوان واحد" : "Luxury property has one address"}
            </h1>
            <p className="mt-5 max-w-xl text-pretty text-sm leading-relaxed text-muted-foreground sm:text-base">
              {ar ? company.taglineAr : company.taglineEn}
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <a href={`tel:${company.phone}`} className="inline-flex items-center gap-2 rounded-full border border-gold/60 bg-gold px-6 py-3 text-xs font-semibold uppercase tracking-[0.2em] text-gold-foreground shadow-lift transition-transform hover:scale-[1.03]">
                <Phone className="size-4" /> {ar ? "اتصل الآن" : "Call now"}
              </a>
              <a href={`https://wa.me/${company.whatsapp.replace(/\D/g, "")}`} className="inline-flex items-center gap-2 rounded-full border border-border px-6 py-3 text-xs font-semibold uppercase tracking-[0.2em] text-foreground transition-colors hover:border-gold hover:text-gold">
                <MessageCircle className="size-4" /> WhatsApp
              </a>
            </div>
          </div>
        </div>
      </header>

      <main className="relative">
        <GlowBg className="opacity-30" />

        {/* Stat strip */}
        <section className="relative border-b border-border px-4 py-8 sm:px-8">
          <div className="mx-auto grid max-w-6xl grid-cols-2 gap-6 sm:flex sm:flex-wrap sm:justify-between">
            {stats.map((s) => (
              <div key={s.labelEn} className="min-w-0 border-t border-gold/30 pt-3">
                <StatBlock value={<span className="text-gold">{ar ? s.valueAr : s.valueEn}</span>} label={<span className="uppercase tracking-widest">{ar ? s.labelAr : s.labelEn}</span>} />
              </div>
            ))}
          </div>
        </section>

        {/* Film-strip projects */}
        <section className="mx-auto max-w-6xl px-4 py-12 sm:px-8 sm:py-16">
          <SectionHead eyebrow={ar ? "الملف" : "The File"} title={ar ? "ملف المشاريع الحصرية" : "Exclusive project file"} />
          <div className="no-scrollbar mt-8 flex gap-5 overflow-x-auto pb-4 sm:gap-7">
            {projects.map((p, i) => (
              <article key={p.id} className="group w-64 shrink-0 sm:w-80">
                <Frame src={p.image} alt={ar ? p.nameAr : p.nameEn} ratio="3/4" className="rounded-sm shadow-soft" imgClassName="grayscale-[15%] transition-all duration-500 group-hover:grayscale-0 group-hover:scale-105" overlay>
                  <span className="display absolute -top-2 start-3 text-7xl text-gold/70 sm:text-8xl">{String(i + 1).padStart(2, "0")}</span>
                  <div className="absolute bottom-0 start-0 end-0 p-4">
                    <Pill className="border-gold/40 bg-background/60 text-gold">{ar ? p.typeAr : p.typeEn}</Pill>
                  </div>
                </Frame>
                <div className="mt-4 flex items-start justify-between gap-2 border-t border-border pt-3">
                  <div className="min-w-0">
                    <h3 className="display truncate text-xl sm:text-2xl">{ar ? p.nameAr : p.nameEn}</h3>
                    <p className="mt-1 text-xs uppercase tracking-widest text-muted-foreground">{ar ? p.areaAr : p.areaEn}</p>
                  </div>
                  <ArrowUpRight className="mt-1 size-4 shrink-0 text-gold" />
                </div>
                <p className="mt-1 text-sm font-medium text-gold">{ar ? p.priceAr : p.priceEn}</p>
              </article>
            ))}
          </div>
        </section>

        {/* About + services */}
        <section className="border-t border-border px-4 py-12 sm:px-8 sm:py-16">
          <div className="mx-auto grid max-w-6xl gap-10 lg:grid-cols-[1fr_1.4fr]">
            <div>
              <Eyebrow className="text-gold">{ar ? "عن الشركة" : "About us"}</Eyebrow>
              <h2 className="display mt-4 text-3xl leading-tight sm:text-4xl">{ar ? "من نحن" : "Who we are"}</h2>
              <p className="mt-4 text-pretty text-sm leading-7 text-muted-foreground">{ar ? company.descAr : company.descEn}</p>
            </div>
            <div className="grid gap-6 sm:grid-cols-2">
              {services.map((s, i) => (
                <div key={s.titleEn} className="border-t border-gold/30 pt-4">
                  <span className="display text-3xl text-gold/60">{String(i + 1).padStart(2, "0")}</span>
                  <h3 className="display mt-2 text-xl">{ar ? s.titleAr : s.titleEn}</h3>
                  <p className="mt-2 text-sm leading-6 text-muted-foreground">{ar ? s.descAr : s.descEn}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="border-t border-border px-4 py-12 sm:px-8 sm:py-16">
          <div className="mx-auto max-w-6xl">
            <SectionHead eyebrow={ar ? "آراء العملاء" : "Testimonials"} title={ar ? "كلام يستحق القراءة" : "Words worth reading"} />
            <div className="mt-8 grid gap-8 sm:grid-cols-3">
              {testimonials.map((t) => (
                <blockquote key={t.nameEn} className="rounded-sm border border-border bg-card/40 p-6 shadow-soft">
                  <p className="display text-lg leading-snug sm:text-xl">"{ar ? t.textAr : t.textEn}"</p>
                  <footer className="mt-4 text-xs uppercase tracking-widest text-gold">{ar ? t.nameAr : t.nameEn}</footer>
                </blockquote>
              ))}
            </div>
          </div>
        </section>

        {/* Contact / footer */}
        <footer className="border-t border-border bg-card/30 px-4 py-10 sm:px-8 sm:py-14">
          <div className="mx-auto grid max-w-6xl gap-8 sm:grid-cols-[auto_1fr] sm:items-start">
            <MrkLogo className="text-3xl text-gold" />
            <div className="grid gap-3 text-sm text-muted-foreground sm:grid-cols-3">
              <p className="flex items-start gap-2 min-w-0"><MapPin className="mt-0.5 size-4 shrink-0 text-gold" /> <span className="break-words">{ar ? company.addressAr : company.addressEn}</span></p>
              <p className="flex items-start gap-2 min-w-0"><Clock className="mt-0.5 size-4 shrink-0 text-gold" /> <span>{ar ? company.hoursAr : company.hoursEn}</span></p>
              <p className="flex items-start gap-2 min-w-0"><Mail className="mt-0.5 size-4 shrink-0 text-gold" /> <span className="break-words">{company.email}</span></p>
            </div>
          </div>
          <div className="mx-auto mt-8 flex max-w-6xl flex-wrap gap-4 border-t border-border pt-6">
            <a href={`tel:${company.phone}`} className="inline-flex items-center gap-2 rounded-full bg-gold px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.2em] text-gold-foreground">
              <Phone className="size-4" /> {company.phone}
            </a>
            <a href={`https://wa.me/${company.whatsapp.replace(/\D/g, "")}`} className="inline-flex items-center gap-2 rounded-full border border-border px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.2em] text-foreground">
              <MessageCircle className="size-4" /> WhatsApp
            </a>
          </div>
        </footer>
      </main>
    </SiteShell>
  );
}
