import { SiteShell, useLang } from "@/components/site/kit";
import { MrkLogo } from "@/components/site/Logo";
import { Frame, Eyebrow } from "@/components/site/ui";
import { company, projects, services, stats, testimonials } from "@/data/mrk";
import tower from "@/assets/tower.jpg";
import { Phone, MessageCircle } from "lucide-react";

export default function Paper() {
  const [lang, setLang] = useLang();
  const ar = lang === "ar";
  const today = ar ? "الإصدار ٠٧ — أكتوبر" : "Issue No. 07 — October";

  return (
    <SiteShell theme="site-paper" lang={lang} setLang={setLang} designNameAr="بيبر" designNameEn="Paper">
      <header className="border-b-4 border-foreground">
        <div className="mx-auto flex max-w-6xl flex-wrap items-end justify-between gap-3 px-4 py-4 text-[10px] uppercase tracking-widest text-muted-foreground sm:px-6">
          <span>{today}</span>
          <span>{ar ? "مدينة ٦ أكتوبر، الجيزة" : "6th of October City, Giza"}</span>
        </div>
        <div className="mx-auto flex max-w-6xl items-center justify-center border-t border-border px-4 py-5 sm:px-6 sm:py-6">
          <MrkLogo className="text-4xl text-foreground" />
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 sm:px-6">
        <section className="grid gap-8 border-b-2 border-foreground py-8 sm:py-10 lg:grid-cols-3">
          <div className="min-w-0 lg:col-span-2">
            <span className="inline-block bg-primary px-2 py-1 text-xs font-bold uppercase text-primary-foreground">
              {ar ? "الملف الرئيسي" : "Lead story"}
            </span>
            <h1 className="display mt-4 text-balance text-3xl font-bold leading-tight sm:text-4xl lg:text-5xl">
              {ar ? "كيف تختار وحدتك الصح في أكتوبر؟" : "How to choose the right unit in October"}
            </h1>
            <Frame src={tower} ratio="16/9" className="mt-6" imgClassName="grayscale" />
            <p className="mt-5 columns-1 gap-8 text-pretty text-sm leading-7 text-muted-foreground sm:columns-2">
              {ar ? company.descAr : company.descEn} {ar ? company.taglineAr : company.taglineEn}
            </p>
          </div>
          <aside className="min-w-0 border-t border-border pt-6 lg:border-s-2 lg:border-t-0 lg:border-foreground lg:ps-6 lg:pt-0">
            <h2 className="display border-b-2 border-foreground pb-2 text-sm font-bold uppercase tracking-widest">
              {ar ? "بالأرقام" : "By the numbers"}
            </h2>
            <dl className="mt-4 space-y-4">
              {stats.map((s) => (
                <div key={s.labelEn} className="flex items-baseline justify-between gap-2 border-b border-dotted border-border pb-2">
                  <dt className="text-xs text-muted-foreground">{ar ? s.labelAr : s.labelEn}</dt>
                  <dd className="display shrink-0 text-xl font-bold text-primary">{ar ? s.valueAr : s.valueEn}</dd>
                </div>
              ))}
            </dl>
            <h2 className="display mt-8 border-b-2 border-foreground pb-2 text-sm font-bold uppercase tracking-widest">
              {ar ? "اتصل بنا" : "Contact"}
            </h2>
            <p className="mt-3 text-xs leading-6 text-muted-foreground">
              {ar ? company.addressAr : company.addressEn}<br />{company.phone}<br />{company.email}<br />{ar ? company.hoursAr : company.hoursEn}
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              <a href={`tel:${company.phone}`} className="inline-flex items-center gap-1.5 border border-foreground px-3 py-1.5 text-[11px] font-bold uppercase tracking-wide">
                <Phone className="size-3" />{ar ? "اتصال" : "Call"}
              </a>
              <a href={`https://wa.me/${company.whatsapp.replace(/\D/g, "")}`} className="inline-flex items-center gap-1.5 bg-primary px-3 py-1.5 text-[11px] font-bold uppercase tracking-wide text-primary-foreground">
                <MessageCircle className="size-3" />{ar ? "واتساب" : "WhatsApp"}
              </a>
            </div>
          </aside>
        </section>

        <section className="border-b-2 border-foreground py-10">
          <div className="flex items-baseline justify-between gap-3 border-b-2 border-foreground pb-2">
            <h2 className="display text-sm font-bold uppercase tracking-widest">{ar ? "المعروض حالياً" : "Now listed"}</h2>
            <Eyebrow className="text-primary">{ar ? "٠١ / السوق" : "01 / Market"}</Eyebrow>
          </div>
          <div className="no-scrollbar mt-4 overflow-x-auto">
            <table className="w-full min-w-[38rem] text-start text-sm">
              <thead className="text-xs uppercase text-muted-foreground">
                <tr className="border-b border-foreground">
                  <th className="py-2 text-start font-bold">{ar ? "المشروع" : "Project"}</th>
                  <th className="py-2 text-start font-bold">{ar ? "النوع" : "Type"}</th>
                  <th className="py-2 text-start font-bold">{ar ? "المساحة" : "Area"}</th>
                  <th className="py-2 text-start font-bold">{ar ? "السعر" : "Price"}</th>
                </tr>
              </thead>
              <tbody>
                {projects.map((p, i) => (
                  <tr key={p.id} className="border-b border-dotted border-border">
                    <td className="py-3 font-semibold">
                      <span className="me-2 text-muted-foreground">{String(i + 1).padStart(2, "0")}</span>
                      {ar ? p.nameAr : p.nameEn}
                    </td>
                    <td className="py-3 text-muted-foreground">{ar ? p.typeAr : p.typeEn}</td>
                    <td className="py-3 text-muted-foreground">{ar ? p.areaAr : p.areaEn}</td>
                    <td className="py-3 font-semibold text-primary">{ar ? p.priceAr : p.priceEn}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-3 text-[10px] uppercase tracking-widest text-muted-foreground">
            * {ar ? "الأسعار قابلة للتغيير حسب خطة السداد المختارة." : "Prices subject to change based on selected payment plan."}
          </p>
        </section>

        <section className="grid grid-cols-2 gap-x-6 gap-y-8 border-b-2 border-foreground py-10 sm:gap-x-8 lg:grid-cols-4">
          {services.map((s, i) => (
            <div key={s.titleEn} className="min-w-0">
              <span className="text-[10px] font-bold uppercase tracking-widest text-primary">{String(i + 1).padStart(2, "0")}</span>
              <h3 className="display mt-1 border-b border-foreground pb-1 text-sm font-bold uppercase">{ar ? s.titleAr : s.titleEn}</h3>
              <p className="mt-2 text-xs leading-6 text-muted-foreground">{ar ? s.descAr : s.descEn}</p>
            </div>
          ))}
        </section>

        <section className="grid gap-6 border-b border-border py-10 sm:grid-cols-3 sm:gap-8">
          {testimonials.map((t) => (
            <blockquote key={t.nameEn} className="border-s-2 border-primary ps-4 text-sm italic">
              “{ar ? t.textAr : t.textEn}”
              <footer className="mt-2 text-xs not-italic uppercase tracking-widest text-primary">— {ar ? t.nameAr : t.nameEn}</footer>
            </blockquote>
          ))}
        </section>
      </main>

      <footer className="border-t-4 border-foreground px-4 py-6 text-center text-[10px] uppercase tracking-widest text-muted-foreground sm:px-6 sm:text-xs">
        {ar ? company.nameAr : company.nameEn} — {ar ? company.hoursAr : company.hoursEn}
      </footer>
    </SiteShell>
  );
}
