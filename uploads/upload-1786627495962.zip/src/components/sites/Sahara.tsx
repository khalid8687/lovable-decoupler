import { SiteShell, useLang } from "@/components/site/kit";
import { MrkLogo } from "@/components/site/Logo";
import { Frame, Eyebrow } from "@/components/site/ui";
import { company, projects, services, stats, testimonials } from "@/data/mrk";
import { Phone, MessageCircle, MapPin, Clock, Mail } from "lucide-react";

export default function Sahara() {
  const [lang, setLang] = useLang();
  const ar = lang === "ar";

  const index = [
    { ar: "المقدمة", en: "Intro", href: "#intro" },
    { ar: "المشاريع", en: "Projects", href: "#projects" },
    { ar: "الخدمات", en: "Services", href: "#services" },
    { ar: "آراء", en: "Voices", href: "#voices" },
    { ar: "تواصل", en: "Contact", href: "#contact" },
  ];

  return (
    <SiteShell theme="site-sahara" lang={lang} setLang={setLang} designNameAr="صحارى" designNameEn="Sahara">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="lg:grid lg:grid-cols-[auto_1fr] lg:gap-10">
          {/* sticky side index */}
          <aside className="hidden border-e border-border py-10 lg:sticky lg:top-14 lg:block lg:h-[calc(100vh-3.5rem)] lg:w-40 lg:self-start">
            <MrkLogo className="text-xl text-primary" />
            <nav className="mt-10 flex flex-col gap-4 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              {index.map((n) => (
                <a key={n.en} href={n.href} className="transition-colors hover:text-primary">{ar ? n.ar : n.en}</a>
              ))}
            </nav>
          </aside>

          <main className="min-w-0 py-6 sm:py-10">
            {/* header for mobile */}
            <div className="mb-8 flex items-center justify-between lg:hidden">
              <MrkLogo className="text-xl text-primary" />
              <a href={`tel:${company.phone}`} className="rounded-sm border border-primary px-3 py-1.5 text-xs font-semibold text-primary">{ar ? "اتصل" : "Call"}</a>
            </div>

            {/* Hero: editorial collage */}
            <section id="intro" className="grid gap-6 border-b border-foreground/20 pb-10 lg:grid-cols-2 lg:items-end">
              <div>
                <Eyebrow>{ar ? company.taglineAr : company.taglineEn}</Eyebrow>
                <h1 className="display mt-4 text-balance text-4xl uppercase leading-[0.92] sm:text-6xl lg:text-7xl">
                  {ar ? "معرض الضوء العقاري" : "The Gallery of Light"}
                </h1>
                <p className="mt-6 max-w-md text-sm leading-7 text-muted-foreground">{ar ? company.descAr : company.descEn}</p>
                <div className="mt-6 flex flex-wrap gap-3">
                  <a href={`tel:${company.phone}`} className="inline-flex items-center gap-2 bg-primary px-5 py-2.5 text-xs font-bold uppercase tracking-wider text-primary-foreground"><Phone className="size-3.5 shrink-0" />{ar ? "اتصل الآن" : "Call now"}</a>
                  <a href={`https://wa.me/${company.whatsapp.replace(/\D/g, "")}`} className="inline-flex items-center gap-2 border border-foreground px-5 py-2.5 text-xs font-bold uppercase tracking-wider"><MessageCircle className="size-3.5 shrink-0" />{ar ? "واتساب" : "WhatsApp"}</a>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <Frame src={projects[0]!.image} alt="" ratio="3/4" className="col-span-2 border border-border" />
                <div className="grid gap-3">
                  <Frame src={projects[1]!.image} alt="" ratio="1/1" className="border border-border" />
                  <Frame src={projects[2]!.image} alt="" ratio="1/1" className="border border-border" />
                </div>
              </div>
            </section>

            {/* Stats */}
            <section className="grid grid-cols-2 gap-px border-b border-foreground/20 bg-border sm:grid-cols-4">
              {stats.map((s) => (
                <div key={s.labelEn} className="bg-background p-5 sm:p-6">
                  <div className="display text-3xl uppercase text-primary">{ar ? s.valueAr : s.valueEn}</div>
                  <div className="mt-1 text-xs text-muted-foreground">{ar ? s.labelAr : s.labelEn}</div>
                </div>
              ))}
            </section>

            {/* Projects list */}
            <section id="projects" className="border-b border-foreground/20 py-10">
              <h2 className="display text-2xl uppercase tracking-wide sm:text-3xl">{ar ? "المشاريع" : "Selected Projects"}</h2>
              <ul className="mt-6 divide-y divide-border">
                {projects.map((p, i) => (
                  <li key={p.id} className="grid grid-cols-[auto_auto_1fr_auto] items-center gap-3 py-5 sm:gap-5">
                    <span className="display shrink-0 text-2xl text-primary/60">{String(i + 1).padStart(2, "0")}</span>
                    <Frame src={p.image} alt={ar ? p.nameAr : p.nameEn} ratio="4/3" className="w-20 shrink-0 border border-border sm:w-28" />
                    <div className="min-w-0">
                      <div className="truncate text-base font-semibold sm:text-lg">{ar ? p.nameAr : p.nameEn}</div>
                      <div className="truncate text-xs text-muted-foreground">{ar ? p.typeAr : p.typeEn} — {ar ? p.areaAr : p.areaEn}</div>
                    </div>
                    <div className="shrink-0 text-end text-xs font-bold uppercase text-accent sm:text-sm">{ar ? p.priceAr : p.priceEn}</div>
                  </li>
                ))}
              </ul>
            </section>

            {/* Services */}
            <section id="services" className="grid grid-cols-1 gap-px border-b border-foreground/20 bg-border sm:grid-cols-2">
              {services.map((s) => (
                <div key={s.titleEn} className="bg-background p-6 sm:p-8">
                  <h3 className="display text-xl uppercase tracking-wide text-primary">{ar ? s.titleAr : s.titleEn}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{ar ? s.descAr : s.descEn}</p>
                </div>
              ))}
            </section>

            {/* Testimonials */}
            <section id="voices" className="grid gap-6 border-b border-foreground/20 py-10 sm:grid-cols-3">
              {testimonials.map((t) => (
                <blockquote key={t.nameEn} className="border-s-2 border-primary ps-4 text-sm">
                  <p className="leading-6">"{ar ? t.textAr : t.textEn}"</p>
                  <footer className="mt-2 text-xs font-bold uppercase tracking-wide text-muted-foreground">{ar ? t.nameAr : t.nameEn}</footer>
                </blockquote>
              ))}
            </section>

            {/* Footer */}
            <footer id="contact" className="grid gap-6 py-10 text-sm sm:grid-cols-2">
              <div>
                <MrkLogo className="text-2xl text-primary" />
                <p className="mt-4 flex items-center gap-2 text-muted-foreground"><MapPin className="size-4 shrink-0" /><span className="min-w-0">{ar ? company.addressAr : company.addressEn}</span></p>
                <p className="mt-2 flex items-center gap-2 text-muted-foreground"><Clock className="size-4 shrink-0" /><span>{ar ? company.hoursAr : company.hoursEn}</span></p>
                <p className="mt-2 flex items-center gap-2 text-muted-foreground"><Mail className="size-4 shrink-0" /><span className="truncate">{company.email}</span></p>
              </div>
              <div className="flex flex-wrap items-start gap-3 sm:justify-end">
                <a href={`tel:${company.phone}`} className="inline-flex items-center gap-2 bg-primary px-5 py-2.5 text-xs font-bold uppercase tracking-wider text-primary-foreground"><Phone className="size-3.5 shrink-0" />{company.phone}</a>
                <a href={`https://wa.me/${company.whatsapp.replace(/\D/g, "")}`} className="inline-flex items-center gap-2 border border-foreground px-5 py-2.5 text-xs font-bold uppercase tracking-wider"><MessageCircle className="size-3.5 shrink-0" />{ar ? "واتساب" : "WhatsApp"}</a>
              </div>
            </footer>
          </main>
        </div>
      </div>
    </SiteShell>
  );
}
