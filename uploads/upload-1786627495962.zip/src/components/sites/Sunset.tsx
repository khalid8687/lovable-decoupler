import { SiteShell, useLang } from "@/components/site/kit";
import { MrkLogo } from "@/components/site/Logo";
import { Frame, Pill, SectionHead } from "@/components/site/ui";
import { company, projects, services, stats, testimonials } from "@/data/mrk";
import mall from "@/assets/mall.jpg";
import { Phone, MessageCircle, Sparkles, MapPin, Clock } from "lucide-react";

export default function Sunset() {
  const [lang, setLang] = useLang();
  const ar = lang === "ar";

  return (
    <SiteShell theme="site-sunset" lang={lang} setLang={setLang} designNameAr="صن ست" designNameEn="Sunset">
      <div className="relative overflow-hidden">
        <div className="pointer-events-none absolute -left-32 top-0 h-96 w-96 rounded-full bg-primary/30 blur-[110px]" aria-hidden />
        <div className="pointer-events-none absolute -right-24 top-96 h-96 w-96 rounded-full bg-accent/25 blur-[120px]" aria-hidden />
        <div className="pointer-events-none absolute left-1/3 top-[60rem] h-72 w-72 rounded-full bg-gold/20 blur-[100px]" aria-hidden />

        <div className="relative mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-8">
          <nav className="flex items-center justify-between gap-3 rounded-full border border-border bg-card/60 px-4 py-3 shadow-soft backdrop-blur sm:px-5">
            <MrkLogo className="text-xl text-foreground" />
            <div className="flex items-center gap-2">
              <a href={`https://wa.me/${company.whatsapp.replace(/\D/g, "")}`} className="hidden rounded-full border border-border px-4 py-2 text-xs font-semibold sm:inline-flex">
                {ar ? "واتساب" : "WhatsApp"}
              </a>
              <a href={`tel:${company.phone}`} className="rounded-full bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground">
                {ar ? "كلمنا" : "Call"}
              </a>
            </div>
          </nav>

          <header className="mt-10 grid items-center gap-10 sm:mt-14 lg:grid-cols-5">
            <div className="lg:col-span-3">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-card/70 px-3 py-1 text-[11px] font-semibold text-primary">
                <Sparkles className="size-3.5" />{ar ? "عقارات ٦ أكتوبر" : "6th of October real estate"}
              </span>
              <h1 className="display mt-5 text-balance text-4xl font-semibold leading-tight sm:text-5xl lg:text-6xl">
                {ar ? "بيت العمر" : "The home"}<br />
                <span className="text-gradient">{ar ? "على بعد مكالمة" : "one call away"}</span>
              </h1>
              <p className="mt-5 max-w-lg text-pretty text-muted-foreground">{ar ? company.descAr : company.descEn}</p>
              <div className="mt-8 flex flex-wrap gap-3">
                {stats.slice(0, 3).map((s) => (
                  <div key={s.labelEn} className="rounded-3xl border border-border bg-card/70 px-5 py-3 shadow-soft backdrop-blur">
                    <div className="display text-xl font-semibold text-primary">{ar ? s.valueAr : s.valueEn}</div>
                    <div className="text-[11px] text-muted-foreground">{ar ? s.labelAr : s.labelEn}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative lg:col-span-2">
              <Frame src={mall} ratio="4/5" className="rounded-[2.5rem] shadow-lift sm:rounded-[3rem]" />
              <div className="absolute -bottom-5 start-4 flex items-center gap-2 rounded-2xl border border-border bg-card/90 px-4 py-2.5 shadow-lift backdrop-blur">
                <div className="grid size-9 place-items-center rounded-full bg-gradient-to-br from-primary to-accent text-xs font-bold text-primary-foreground">98%</div>
                <div className="text-[11px] leading-tight text-muted-foreground">{ar ? "رضا العملاء" : "Client satisfaction"}</div>
              </div>
            </div>
          </header>

          <main className="mt-14 space-y-6 sm:mt-20">
            <section>
              <SectionHead align="start" eyebrow={ar ? "المحفظة" : "Portfolio"} title={ar ? "مشاريعنا المميزة" : "Featured projects"} />
              <div className="mt-6 grid gap-5 sm:grid-cols-2">
                {projects.map((p) => (
                  <article key={p.id} className="group flex items-center gap-4 rounded-[2rem] border border-border bg-card/70 p-4 shadow-soft backdrop-blur transition-transform duration-300 hover:-translate-y-1">
                    <Frame src={p.image} ratio="1/1" className="h-24 w-24 shrink-0 rounded-[1.5rem]" />
                    <div className="min-w-0">
                      <h3 className="display truncate text-lg font-semibold">{ar ? p.nameAr : p.nameEn}</h3>
                      <p className="truncate text-xs text-muted-foreground">{ar ? p.typeAr : p.typeEn} — {ar ? p.areaAr : p.areaEn}</p>
                      <p className="mt-1 text-sm font-semibold text-primary">{ar ? p.priceAr : p.priceEn}</p>
                    </div>
                  </article>
                ))}
              </div>
            </section>

            <section className="rounded-[2rem] border border-border bg-card/50 p-6 shadow-soft backdrop-blur sm:rounded-[2.5rem] sm:p-8">
              <h2 className="display text-2xl font-semibold">{ar ? "بنقدم إيه؟" : "What we do"}</h2>
              <div className="mt-6 grid gap-5 sm:grid-cols-2">
                {services.map((s) => (
                  <div key={s.titleEn} className="rounded-[1.75rem] bg-gradient-to-br from-card to-secondary/60 p-5">
                    <h3 className="font-semibold text-primary">{ar ? s.titleAr : s.titleEn}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{ar ? s.descAr : s.descEn}</p>
                  </div>
                ))}
              </div>
            </section>

            <section className="grid gap-5 sm:grid-cols-3">
              {testimonials.map((t) => (
                <blockquote key={t.nameEn} className="relative rounded-[2rem] border border-border bg-card/60 p-6 text-sm shadow-soft backdrop-blur">
                  <div className="mb-3 flex items-center gap-2">
                    <div className="grid size-9 shrink-0 place-items-center rounded-full bg-gradient-to-br from-primary to-accent text-xs font-bold text-primary-foreground">
                      {(ar ? t.nameAr : t.nameEn).slice(0, 1)}
                    </div>
                    <span className="text-xs font-semibold text-primary">{ar ? t.nameAr : t.nameEn}</span>
                  </div>
                  <p className="text-pretty text-muted-foreground">“{ar ? t.textAr : t.textEn}”</p>
                </blockquote>
              ))}
            </section>

            <footer className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-primary to-accent p-6 text-primary-foreground sm:rounded-[2.5rem] sm:p-8">
              <div className="flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <MrkLogo className="text-3xl" />
                  <p className="mt-4 flex items-center gap-2 text-sm font-medium"><MapPin className="size-4" />{ar ? company.addressAr : company.addressEn}</p>
                  <p className="mt-1 flex items-center gap-2 text-sm"><Clock className="size-4" />{ar ? company.hoursAr : company.hoursEn}</p>
                </div>
                <div className="flex flex-wrap gap-3">
                  <a href={`tel:${company.phone}`} className="inline-flex items-center gap-2 rounded-full bg-background/20 px-5 py-3 text-sm font-semibold backdrop-blur hover:bg-background/30">
                    <Phone className="size-4" />{ar ? "اتصل الآن" : "Call now"}
                  </a>
                  <a href={`https://wa.me/${company.whatsapp.replace(/\D/g, "")}`} className="inline-flex items-center gap-2 rounded-full bg-background/95 px-5 py-3 text-sm font-semibold text-foreground hover:opacity-90">
                    <MessageCircle className="size-4" />{ar ? "واتساب" : "WhatsApp"}
                  </a>
                </div>
              </div>
            </footer>
          </main>
        </div>
      </div>
    </SiteShell>
  );
}
