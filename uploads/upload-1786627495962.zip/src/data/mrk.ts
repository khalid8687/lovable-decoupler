export type Project = {
  id: string;
  nameAr: string;
  nameEn: string;
  areaAr: string;
  areaEn: string;
  priceAr: string;
  priceEn: string;
  typeAr: string;
  typeEn: string;
  image: string;
};

import tower from "@/assets/tower.jpg";
import compound from "@/assets/compound.jpg";
import mall from "@/assets/mall.jpg";
import interior from "@/assets/interior.jpg";

export const images = { tower, compound, mall, interior };

export const company = {
  nameAr: "إم آر كيه للتسويق العقاري",
  nameEn: "MRK Real Estate Marketing",
  short: "MRK",
  taglineAr: "شريكك الأول في التسويق العقاري بمدينة 6 أكتوبر",
  taglineEn: "Your first partner in real estate marketing in 6th of October City",
  descAr:
    "شركة MRK للتسويق العقاري متخصصة في بيع وتسويق الوحدات السكنية والتجارية والإدارية داخل أرقى كمبوندات ومولات مدينة 6 أكتوبر، مع استشارات استثمارية وخطط سداد مرنة.",
  descEn:
    "MRK specializes in selling and marketing residential, commercial and administrative units across the finest compounds and malls of 6th of October City, with investment advisory and flexible payment plans.",
  addressAr: "مول العرب – مدينة 6 أكتوبر – الجيزة",
  addressEn: "Mall of Arabia – 6th of October City – Giza",
  phone: "+20 100 000 0000",
  whatsapp: "+20 100 000 0000",
  email: "info@mrk-realestate.com",
  hoursAr: "يوميًا من 10 ص حتى 10 م",
  hoursEn: "Daily 10 AM – 10 PM",
};

export const stats = [
  { valueAr: "+١٢ سنة", valueEn: "12+ yrs", labelAr: "خبرة في السوق", labelEn: "Market experience" },
  { valueAr: "+٢٥٠٠", valueEn: "2,500+", labelAr: "وحدة تم بيعها", labelEn: "Units sold" },
  { valueAr: "+٤٠", valueEn: "40+", labelAr: "مشروع حصري", labelEn: "Exclusive projects" },
  { valueAr: "٩٨٪", valueEn: "98%", labelAr: "رضا العملاء", labelEn: "Client satisfaction" },
];

export const services = [
  {
    titleAr: "بيع الوحدات السكنية",
    titleEn: "Residential sales",
    descAr: "شقق ودوبلكس وفيلات داخل كمبوندات 6 أكتوبر وزايد.",
    descEn: "Apartments, duplexes and villas in October and Zayed compounds.",
  },
  {
    titleAr: "المحلات والمولات التجارية",
    titleEn: "Retail & malls",
    descAr: "محلات ومكاتب إدارية بعوائد إيجارية مضمونة.",
    descEn: "Shops and offices with guaranteed rental returns.",
  },
  {
    titleAr: "الاستشارات الاستثمارية",
    titleEn: "Investment advisory",
    descAr: "دراسة العائد واختيار أنسب فرصة حسب ميزانيتك.",
    descEn: "ROI studies and the right opportunity for your budget.",
  },
  {
    titleAr: "إعادة البيع والتقسيط",
    titleEn: "Resale & installments",
    descAr: "خطط سداد تصل إلى ١٠ سنوات ومقدم يبدأ من ٥٪.",
    descEn: "Payment plans up to 10 years, down payment from 5%.",
  },
];

export const projects: Project[] = [
  {
    id: "sky-tower",
    nameAr: "سكاي تاور",
    nameEn: "Sky Tower",
    areaAr: "من ٩٥ م²",
    areaEn: "From 95 m²",
    priceAr: "تبدأ من ٢.٩ مليون ج.م",
    priceEn: "From EGP 2.9M",
    typeAr: "شقق سكنية",
    typeEn: "Apartments",
    image: tower,
  },
  {
    id: "green-compound",
    nameAr: "جرين ريزيدنس",
    nameEn: "Green Residence",
    areaAr: "من ٢٤٠ م²",
    areaEn: "From 240 m²",
    priceAr: "تبدأ من ٨.٥ مليون ج.م",
    priceEn: "From EGP 8.5M",
    typeAr: "فيلات وتاون هاوس",
    typeEn: "Villas & townhouses",
    image: compound,
  },
  {
    id: "arabia-plaza",
    nameAr: "أرابيا بلازا",
    nameEn: "Arabia Plaza",
    areaAr: "من ٣٥ م²",
    areaEn: "From 35 m²",
    priceAr: "تبدأ من ٤.٢ مليون ج.م",
    priceEn: "From EGP 4.2M",
    typeAr: "محلات تجارية",
    typeEn: "Retail shops",
    image: mall,
  },
  {
    id: "urban-lofts",
    nameAr: "أوربان لوفتس",
    nameEn: "Urban Lofts",
    areaAr: "من ٧٠ م²",
    areaEn: "From 70 m²",
    priceAr: "تبدأ من ٢.١ مليون ج.م",
    priceEn: "From EGP 2.1M",
    typeAr: "استوديوهات مفروشة",
    typeEn: "Furnished studios",
    image: interior,
  },
];

export const testimonials = [
  {
    nameAr: "أحمد سيد",
    nameEn: "Ahmed Sayed",
    textAr: "اشتريت شقة عن طريق MRK وكل الإجراءات كانت واضحة وسريعة.",
    textEn: "I bought my apartment through MRK — clear and fast process.",
  },
  {
    nameAr: "منى فتحي",
    nameEn: "Mona Fathy",
    textAr: "فريق محترم ساعدني أختار محل تجاري بعائد ممتاز.",
    textEn: "A professional team helped me pick a shop with great returns.",
  },
  {
    nameAr: "كريم مصطفى",
    nameEn: "Karim Mostafa",
    textAr: "أفضل استشارة استثمارية حصلت عليها في 6 أكتوبر.",
    textEn: "The best investment advice I got in 6th of October.",
  },
];

export const designs = [
  { slug: "aurora", nameAr: "أورورا", nameEn: "Aurora", noteAr: "زجاج مضيء وشبكة بينتو ليلية", noteEn: "Glass bento, midnight glow" },
  { slug: "sahara", nameAr: "صحارى", nameEn: "Sahara", noteAr: "رملي دافئ وتايبوغرافي عريض", noteEn: "Warm sand editorial" },
  { slug: "marina", nameAr: "مارينا", nameEn: "Marina", noteAr: "أزرق محيطي أنيق ولمسة مرجانية", noteEn: "Ocean blue with coral" },
  { slug: "brutal", nameAr: "بروتال", nameEn: "Brutal", noteAr: "بوستر سويسري بحدود سميكة", noteEn: "Swiss neo-brutalist poster" },
  { slug: "emerald", nameAr: "إمرالد", nameEn: "Emerald", noteAr: "زمردي وذهبي فاخر", noteEn: "Emerald & gold luxury" },
  { slug: "paper", nameAr: "بيبر", nameEn: "Paper", noteAr: "جريدة أبيض وأسود وأحمر", noteEn: "Newsprint, red accents" },
  { slug: "sunset", nameAr: "صن ست", nameEn: "Sunset", noteAr: "غروب بنفسجي وأشكال ناعمة", noteEn: "Plum dusk, soft blobs" },
  { slug: "noir", nameAr: "نوار", nameEn: "Noir", noteAr: "أسود سينمائي وشامبين ذهبي", noteEn: "Cinematic black & champagne" },
  { slug: "mint", nameAr: "مِنت", nameEn: "Mint", noteAr: "واجهة منتج نظيفة بلون نعناعي", noteEn: "Clean minty product UI" },
  { slug: "clay", nameAr: "كلاي", nameEn: "Clay", noteAr: "طيني دافئ بأشكال عضوية", noteEn: "Warm organic clay" },
];

