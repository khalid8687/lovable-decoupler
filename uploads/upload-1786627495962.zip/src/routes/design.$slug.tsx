import { createFileRoute, notFound } from "@tanstack/react-router";
import type { ComponentType } from "react";
import { designs } from "@/data/mrk";
import Aurora from "@/components/sites/Aurora";
import Sahara from "@/components/sites/Sahara";
import Marina from "@/components/sites/Marina";
import Brutal from "@/components/sites/Brutal";
import Emerald from "@/components/sites/Emerald";
import Paper from "@/components/sites/Paper";
import Sunset from "@/components/sites/Sunset";
import Noir from "@/components/sites/Noir";
import Mint from "@/components/sites/Mint";
import Clay from "@/components/sites/Clay";

const registry: Record<string, ComponentType> = {
  aurora: Aurora,
  sahara: Sahara,
  marina: Marina,
  brutal: Brutal,
  emerald: Emerald,
  paper: Paper,
  sunset: Sunset,
  noir: Noir,
  mint: Mint,
  clay: Clay,
};

export const Route = createFileRoute("/design/$slug")({
  loader: ({ params }) => {
    const design = designs.find((d) => d.slug === params.slug);
    if (!design) throw notFound();
    return { design };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return { meta: [{ title: "تصميم غير متاح — MRK" }, { name: "robots", content: "noindex" }] };
    }
    const title = `تصميم ${loaderData.design.nameAr} — موقع MRK للتسويق العقاري`;
    const description = `${loaderData.design.noteAr} — نسخة كاملة من موقع شركة MRK للتسويق العقاري في 6 أكتوبر بالعربية والإنجليزية.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
      ],
    };
  },
  component: DesignPage,
});

function DesignPage() {
  const { design } = Route.useLoaderData();
  const Component = registry[design.slug];
  if (!Component) return null;
  return <Component />;
}
