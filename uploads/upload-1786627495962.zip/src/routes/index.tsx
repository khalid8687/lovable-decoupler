import { createFileRoute, Link } from "@tanstack/react-router";
import { designs, company, stats } from "@/data/mrk";
import tower from "@/assets/tower.jpg";
import { MrkLogo } from "@/components/site/Logo";
import { ArrowLeft, MapPin, Phone } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "معرض تصميمات موقع MRK للتسويق العقاري — 6 أكتوبر" },
      {
        name: "description",
        content:
          "اختر من بين عشرة تصميمات كاملة لموقع شركة MRK للتسويق العقاري في مول العرب، 6 أكتوبر — عربي وإنجليزي.",
      },
      { property: "og:title", content: "معرض تصميمات موقع MRK للتسويق العقاري" },
      {
        property: "og:description",
        content: "عشرة تصميمات جاهزة لموقع شركة MRK العقارية في مدينة 6 أكتوبر.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Gallery,
});

/** [background, primary, accent] preview of each theme (mirrors src/styles.css v3). */
const swatches: Record<string, [string, string, string]> = {
  aurora: ["#1a1c2e", "#67d9de", "#a389e8"],
  sahara: ["#f7f0e4", "#b8663a", "#c9954f"],
  marina: ["#f7f9fc", "#2e5aa8", "#e8734a"],
  brutal: ["#f6f4ea", "#1a1a1a", "#2f6bf0"],
  emerald: ["#fbfbf3", "#1e6b52", "#c8a35a"],
  paper: ["#fbfbfa", "#cf2b23", "#1c1c1c"],
  sunset: ["#2c1f2c", "#f0a172", "#e57fa3"],
  noir: ["#171612", "#d6b26a", "#bb9059"],
  mint: ["#fbfefd", "#1f8f8b", "#43bfa0"],
  clay: ["#f4ece0", "#b56a48", "#7d8b5e"],
};

function ThemePreview({ slug }: { slug: string }) {
  const [bg, primary, accent] = swatches[slug] ?? ["#eee", "#333", "#999"];
  return (
    <div
      className="relative aspect-16/10 w-full overflow-hidden rounded-xl border border-border"
      style={{ backgroundColor: bg }}
      aria-hidden
    >
      <div
        className="absolute inset-x-0 top-0 h-5 border-b"
        style={{ backgroundColor: accent, opacity: 0.18, borderColor: primary + "33" }}
      />
      <div className="absolute inset-x-3 top-8 h-2.5 rounded-full" style={{ backgroundColor: primary }} />
      <div
        className="absolute inset-x-3 top-[3.2rem] h-2 w-2/3 rounded-full"
        style={{ backgroundColor: primary, opacity: 0.45 }}
      />
      <div className="absolute inset-x-3 bottom-3 flex gap-2">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className="h-8 flex-1 rounded-md"
            style={{ backgroundColor: i === 1 ? accent : primary, opacity: i === 1 ? 0.85 : 0.22 }}
          />
        ))}
      </div>
      <div
        className="absolute -bottom-6 -end-6 h-20 w-20 rounded-full blur-xl"
        style={{ backgroundColor: accent, opacity: 0.5 }}
      />
    </div>
  );
}

function Gallery() {
  return (
    <div dir="rtl" className="min-h-screen bg-background text-foreground">
      <header className="relative isolate overflow-hidden border-b border-border">
        <img
          src={tower}
          alt="أبراج سكنية في مدينة 6 أكتوبر"
          className="absolute inset-0 -z-10 h-full w-full object-cover opacity-15"
        />
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-background/70 via-background/85 to-background" />
        <div className="relative mx-auto max-w-5xl px-4 py-12 text-center sm:px-6 sm:py-20">
          <div className="flex justify-center">
            <MrkLogo className="text-4xl text-primary sm:text-6xl lg:text-7xl" />
          </div>
          <h1 className="mt-8 text-balance text-2xl font-bold sm:text-3xl lg:text-4xl">
            عشرة تصميمات لموقع {company.nameAr}
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-pretty text-sm leading-7 text-muted-foreground sm:text-base">
            كل تصميم موقع كامل ومستقل بهويته الخاصة، بالعربية والإنجليزية، لشركة تسويق عقاري في{" "}
            {company.addressAr}. اضغط أي تصميم لتصفحه.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-2 text-xs sm:text-sm">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card/70 px-3 py-1.5 text-muted-foreground backdrop-blur">
              <MapPin className="h-3.5 w-3.5 shrink-0 text-primary" />
              <span className="min-w-0">{company.addressAr}</span>
            </span>
            <a
              href={`tel:${company.phone}`}
              className="inline-flex items-center gap-1.5 rounded-full bg-primary px-3 py-1.5 font-medium text-primary-foreground transition-transform hover:-translate-y-0.5"
            >
              <Phone className="h-3.5 w-3.5 shrink-0" />
              {company.phone}
            </a>
          </div>

          <div className="mx-auto mt-8 grid max-w-3xl grid-cols-2 gap-3 sm:grid-cols-4">
            {stats.map((s) => (
              <div key={s.labelAr} className="rounded-xl border border-border bg-card/60 p-3 backdrop-blur">
                <div className="text-lg font-bold text-primary sm:text-xl">{s.valueAr}</div>
                <div className="mt-0.5 text-[11px] text-muted-foreground sm:text-xs">{s.labelAr}</div>
              </div>
            ))}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-10 sm:px-6 sm:py-14">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {designs.map((d, i) => (
            <Link
              key={d.slug}
              to="/design/$slug"
              params={{ slug: d.slug }}
              className="group rounded-2xl border border-border bg-card p-4 transition-all duration-300 hover:-translate-y-1 hover:border-primary/40 hover:shadow-xl active:scale-[0.99] sm:p-5"
            >
              <ThemePreview slug={d.slug} />
              <div className="mt-4 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
                <h2 className="min-w-0 truncate text-lg font-semibold sm:text-xl">
                  {d.nameAr} <span className="text-muted-foreground">/ {d.nameEn}</span>
                </h2>
                <span className="shrink-0 rounded-full bg-secondary px-2 py-0.5 text-xs text-muted-foreground">
                  {String(i + 1).padStart(2, "0")}
                </span>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">{d.noteAr}</p>
              <p className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-primary opacity-75 transition-opacity group-hover:opacity-100">
                افتح الموقع
                <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-1" />
              </p>
            </Link>
          ))}
        </div>
      </main>

      <footer className="border-t border-border px-4 py-8 text-center text-xs text-muted-foreground sm:px-6 sm:text-sm">
        {company.nameAr} — {company.addressAr} — {company.phone}
      </footer>
    </div>
  );
}
