CREATE TYPE public.app_role AS ENUM ('admin','user');

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "users read own roles" ON public.user_roles FOR SELECT TO authenticated USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TABLE public.categories (
  id text PRIMARY KEY,
  label text NOT NULL,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.categories TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.categories TO authenticated;
GRANT ALL ON public.categories TO service_role;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "categories public read" ON public.categories FOR SELECT USING (true);
CREATE POLICY "categories admin write" ON public.categories FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER categories_updated_at BEFORE UPDATE ON public.categories FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name text NOT NULL,
  category_id text NOT NULL REFERENCES public.categories(id) ON UPDATE CASCADE,
  description text NOT NULL DEFAULT '',
  price numeric(10,2) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT 'ج.م',
  image_key text,
  image_url text,
  quantity int NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.products TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.products TO authenticated;
GRANT ALL ON public.products TO service_role;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "products public read" ON public.products FOR SELECT USING (is_active = true);
CREATE POLICY "products admin read" ON public.products FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE POLICY "products admin write" ON public.products FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER products_updated_at BEFORE UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.categories (id,label,sort_order) VALUES
 ('laundry','مساحيق الغسيل',1),
 ('dishwashing','منظفات الأطباق',2),
 ('disinfectants','مطهرات',3),
 ('paper','ورقيات',4),
 ('tools','أدوات النظافة',5);

INSERT INTO public.products (slug,name,category_id,description,price,unit,image_key,quantity,sort_order) VALUES
 ('persil-gel-lavender','برسيل جيل لافندر - ٣ لتر','laundry','تركيبة جيل مركزة برائحة اللافندر الفاخرة',145,'ج.م','persil-gel-lavender',24,1),
 ('downy-softener','داوني منعم ملابس - ١ لتر','laundry','نعومة فائقة ورائحة تدوم طويلاً',52,'ج.م','downy-softener',40,2),
 ('oxi-powder','أوكسي مسحوق غسيل - ٥ كيلو','laundry','إزالة البقع الصعبة بفاعلية الأكسجين',220,'ج.م','oxi-powder',5,3),
 ('fairy-lemon-1l','فيري ليمون - ١ لتر','dishwashing','قوة الليمون لإزالة الدهون فوراً',65,'ج.م','fairy-lemon-1l',30,4),
 ('fairy-750ml','فيري سائل أطباق - ٧٥٠ مل','dishwashing','رغوة غنية ولمعان فائق للأطباق',48,'ج.م','fairy-750ml',35,5),
 ('clorox-white','كلوركس أبيض - ٩٥٠ مل','disinfectants','تعقيم وتبييض قوي لكل الأسطح',25.5,'ج.م','clorox-white',50,6),
 ('floor-pine','مطهر أرضيات برائحة الصنوبر - ٣ لتر','disinfectants','تركيبة مركزة برائحة منعشة تدوم',65,'ج.م','floor-pine',18,7),
 ('dettol-surface','ديتول مطهر أسطح - ٧٥٠ مل','disinfectants','يقتل ٩٩.٩٪ من الجراثيم والبكتيريا',55,'ج.م','dettol-surface',4,8),
 ('kitchen-towels','مناديل مطبخ - ٦ رول','paper','امتصاص عالي وورق متين عالي الجودة',88,'ج.م','kitchen-towels',22,9),
 ('toilet-tissue','مناديل حمام - ١٢ رول','paper','نعومة فائقة وراحة للاستخدام اليومي',75,'ج.م','toilet-tissue',26,10),
 ('microfiber-cloths','فوط مايكروفايبر - ٣ قطع','tools','امتصاص عالي وتلميع فائق بدون خدوش',35,'ج.م','microfiber-cloths',15,11),
 ('bucket-mop','طقم جردل وشرشوبة','tools','طقم متكامل لتنظيف الأرضيات باحترافية',120,'ج.م','bucket-mop',8,12);