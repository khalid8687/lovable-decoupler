ALTER TABLE public.products ADD COLUMN IF NOT EXISTS image_path text;

CREATE TABLE public.product_logs (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  product_name text not null default '',
  field text not null,
  old_value text,
  new_value text,
  changed_by uuid,
  created_at timestamptz not null default now()
);

GRANT SELECT ON public.product_logs TO authenticated;
GRANT ALL ON public.product_logs TO service_role;

ALTER TABLE public.product_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "product_logs admin read" ON public.product_logs
FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'::app_role));

CREATE INDEX product_logs_product_created_idx ON public.product_logs (product_id, created_at DESC);

CREATE OR REPLACE FUNCTION public.log_product_changes()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.quantity IS DISTINCT FROM OLD.quantity THEN
    INSERT INTO public.product_logs (product_id, product_name, field, old_value, new_value, changed_by)
    VALUES (NEW.id, NEW.name, 'quantity', OLD.quantity::text, NEW.quantity::text, auth.uid());
  END IF;
  IF NEW.is_active IS DISTINCT FROM OLD.is_active THEN
    INSERT INTO public.product_logs (product_id, product_name, field, old_value, new_value, changed_by)
    VALUES (NEW.id, NEW.name, 'is_active', OLD.is_active::text, NEW.is_active::text, auth.uid());
  END IF;
  IF NEW.price IS DISTINCT FROM OLD.price THEN
    INSERT INTO public.product_logs (product_id, product_name, field, old_value, new_value, changed_by)
    VALUES (NEW.id, NEW.name, 'price', OLD.price::text, NEW.price::text, auth.uid());
  END IF;
  RETURN NEW;
END; $$;

CREATE TRIGGER products_change_log
AFTER UPDATE ON public.products
FOR EACH ROW EXECUTE FUNCTION public.log_product_changes();

CREATE POLICY "product images public read" ON storage.objects
FOR SELECT USING (bucket_id = 'product-images');

CREATE POLICY "product images admin insert" ON storage.objects
FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'product-images' AND public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "product images admin update" ON storage.objects
FOR UPDATE TO authenticated
USING (bucket_id = 'product-images' AND public.has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (bucket_id = 'product-images' AND public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "product images admin delete" ON storage.objects
FOR DELETE TO authenticated
USING (bucket_id = 'product-images' AND public.has_role(auth.uid(), 'admin'::app_role));