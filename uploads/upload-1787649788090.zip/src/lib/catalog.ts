import { supabase } from "@/integrations/supabase/client";

import persilGel from "@/assets/products/persil-gel-lavender.jpg";
import downySoftener from "@/assets/products/downy-softener.jpg";
import oxiPowder from "@/assets/products/oxi-powder.jpg";
import fairyLemon1l from "@/assets/products/fairy-lemon-1l.jpg";
import fairy750 from "@/assets/products/fairy-750ml.jpg";
import cloroxWhite from "@/assets/products/clorox-white.jpg";
import floorPine from "@/assets/products/floor-pine.jpg";
import dettolSurface from "@/assets/products/dettol-surface.jpg";
import kitchenTowels from "@/assets/products/kitchen-towels.jpg";
import toiletTissue from "@/assets/products/toilet-tissue.jpg";
import microfiberCloths from "@/assets/products/microfiber-cloths.jpg";
import bucketMop from "@/assets/products/bucket-mop.jpg";

export const PRODUCT_IMAGES: Record<string, string> = {
  "persil-gel-lavender": persilGel,
  "downy-softener": downySoftener,
  "oxi-powder": oxiPowder,
  "fairy-lemon-1l": fairyLemon1l,
  "fairy-750ml": fairy750,
  "clorox-white": cloroxWhite,
  "floor-pine": floorPine,
  "dettol-surface": dettolSurface,
  "kitchen-towels": kitchenTowels,
  "toilet-tissue": toiletTissue,
  "microfiber-cloths": microfiberCloths,
  "bucket-mop": bucketMop,
};

export const PLACEHOLDER_IMAGE = "/placeholder.svg";

export interface Category {
  id: string;
  label: string;
  sort_order: number;
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  category_id: string;
  description: string;
  price: number;
  unit: string;
  image_key: string | null;
  image_url: string | null;
  image_path?: string | null;
  quantity: number;
  is_active: boolean;
  sort_order: number;
}

export interface ProductLog {
  id: string;
  product_id: string;
  product_name: string;
  field: string;
  old_value: string | null;
  new_value: string | null;
  created_at: string;
}

export const PRODUCT_BUCKET = "product-images";
const TEN_YEARS = 60 * 60 * 24 * 365 * 10;

/** يرفع صورة المنتج للتخزين ويرجّع رابط دائم + المسار */
export async function uploadProductImage(file: File) {
  const ext = (file.name.split(".").pop() || "jpg").toLowerCase();
  const path = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const { error } = await supabase.storage
    .from(PRODUCT_BUCKET)
    .upload(path, file, { cacheControl: "31536000", upsert: false });
  if (error) throw error;
  const { data, error: signErr } = await supabase.storage
    .from(PRODUCT_BUCKET)
    .createSignedUrl(path, TEN_YEARS);
  if (signErr || !data) throw signErr ?? new Error("تعذر إنشاء رابط الصورة");
  return { url: data.signedUrl, path };
}

export async function deleteProductImage(path: string) {
  await supabase.storage.from(PRODUCT_BUCKET).remove([path]);
}


export function productImage(p: Pick<Product, "image_key" | "image_url">) {
  if (p.image_url) return p.image_url;
  if (p.image_key && PRODUCT_IMAGES[p.image_key]) return PRODUCT_IMAGES[p.image_key]!;
  return PLACEHOLDER_IMAGE;
}

export const LOW_STOCK_THRESHOLD = 6;

export type StockState = "out" | "limited" | "available";

export function stockState(quantity: number): StockState {
  if (quantity <= 0) return "out";
  if (quantity <= LOW_STOCK_THRESHOLD) return "limited";
  return "available";
}

export function stockLabel(quantity: number) {
  const s = stockState(quantity);
  if (s === "out") return "نفدت الكمية";
  if (s === "limited") return "كمية محدودة";
  return "متوفر";
}

export function stockClasses(quantity: number) {
  const s = stockState(quantity);
  if (s === "out") return "bg-neutral-200 text-neutral-600";
  if (s === "limited") return "bg-amber-100 text-amber-800";
  return "bg-green-100 text-green-700";
}

export function formatPrice(n: number) {
  return n.toLocaleString("ar-EG", {
    minimumFractionDigits: n % 1 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  });
}

export type SortMode = "default" | "price-asc" | "price-desc";

export const SORT_OPTIONS: { id: SortMode; label: string }[] = [
  { id: "default", label: "الترتيب الافتراضي" },
  { id: "price-asc", label: "السعر: من الأقل للأعلى" },
  { id: "price-desc", label: "السعر: من الأعلى للأقل" },
];

export function sortProducts(list: Product[], mode: SortMode) {
  const copy = [...list];
  if (mode === "price-asc") copy.sort((a, b) => a.price - b.price);
  else if (mode === "price-desc") copy.sort((a, b) => b.price - a.price);
  return copy;
}

/* ---------- queries ---------- */

export const categoriesQuery = {
  queryKey: ["categories"],
  queryFn: async (): Promise<Category[]> => {
    const { data, error } = await supabase
      .from("categories")
      .select("id,label,sort_order")
      .order("sort_order", { ascending: true });
    if (error) throw error;
    return (data ?? []) as Category[];
  },
};

const PRODUCT_FIELDS =
  "id,slug,name,category_id,description,price,unit,image_key,image_url,image_path,quantity,is_active,sort_order";

function normalize(rows: unknown[]): Product[] {
  return (rows as Product[]).map((r) => ({ ...r, price: Number(r.price) }));
}

export const publicProductsQuery = {
  queryKey: ["products", "public"],
  queryFn: async (): Promise<Product[]> => {
    const { data, error } = await supabase
      .from("products")
      .select(PRODUCT_FIELDS)
      .eq("is_active", true)
      .order("sort_order", { ascending: true });
    if (error) throw error;
    return normalize(data ?? []);
  },
};

export const adminProductsQuery = {
  queryKey: ["products", "admin"],
  queryFn: async (): Promise<Product[]> => {
    const { data, error } = await supabase
      .from("products")
      .select(PRODUCT_FIELDS)
      .order("sort_order", { ascending: true });
    if (error) throw error;
    return normalize(data ?? []);
  },
};

export const productLogsQuery = {
  queryKey: ["product_logs"],
  queryFn: async (): Promise<ProductLog[]> => {
    const { data, error } = await supabase
      .from("product_logs")
      .select("id,product_id,product_name,field,old_value,new_value,created_at")
      .order("created_at", { ascending: false })
      .limit(100);
    if (error) throw error;
    return (data ?? []) as ProductLog[];
  },
};

export function logFieldLabel(field: string) {
  if (field === "quantity") return "الكمية";
  if (field === "price") return "السعر";
  if (field === "is_active") return "الظهور في المتجر";
  return field;
}

export function logValueLabel(field: string, value: string | null) {
  if (value === null) return "-";
  if (field === "is_active") return value === "true" ? "معروض" : "مخفي";
  return value;
}
