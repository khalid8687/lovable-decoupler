import persilGel from "@/assets/products/persil-gel-lavender.jpg";
import downySoftener from "@/assets/products/downy-softener.jpg";
import oxiPowder from "@/assets/products/oxi-powder.jpg";
import fairyLemon1l from "@/assets/products/fairy-lemon-1l.jpg";
import fairy750 from "@/assets/products/fairy-750ml.jpg";
import cloroxWhite from "@/assets/products/clorox-white.jpg";
import floorPine from "@/assets/products/floor-pine.jpg";
import dettolSurface from "@/assets/products/dettol-surface.jpg";
import kitchenTowels from "@/assets/products/kitchen-towels.jpg";
import toiletTissue from "@/assets/products/toilet-tissue.jpg";
import microfiberCloths from "@/assets/products/microfiber-cloths.jpg";
import bucketMop from "@/assets/products/bucket-mop.jpg";

export type CategoryId =
  | "laundry"
  | "dishwashing"
  | "disinfectants"
  | "paper"
  | "tools";

export interface Category {
  id: CategoryId;
  label: string;
}

export const CATEGORIES: Category[] = [
  { id: "laundry", label: "مساحيق الغسيل" },
  { id: "dishwashing", label: "منظفات الأطباق" },
  { id: "disinfectants", label: "مطهرات" },
  { id: "paper", label: "ورقيات" },
  { id: "tools", label: "أدوات النظافة" },
];

export interface Product {
  id: string;
  name: string;
  category: CategoryId;
  categoryLabel: string;
  description: string;
  price: number;
  unit: string;
  image: string;
  stock: "available" | "limited";
}

export const PRODUCTS: Product[] = [
  {
    id: "persil-gel-lavender",
    name: "برسيل جيل لافندر - ٣ لتر",
    category: "laundry",
    categoryLabel: "مساحيق غسيل",
    description: "تركيبة جيل مركزة برائحة اللافندر الفاخرة",
    price: 145,
    unit: "ج.م",
    image: persilGel,
    stock: "available",
  },
  {
    id: "downy-softener",
    name: "داوني منعم ملابس - ١ لتر",
    category: "laundry",
    categoryLabel: "مساحيق غسيل",
    description: "نعومة فائقة ورائحة تدوم طويلاً",
    price: 52,
    unit: "ج.م",
    image: downySoftener,
    stock: "available",
  },
  {
    id: "oxi-powder",
    name: "أوكسي مسحوق غسيل - ٥ كيلو",
    category: "laundry",
    categoryLabel: "مساحيق غسيل",
    description: "إزالة البقع الصعبة بفاعلية الأكسجين",
    price: 220,
    unit: "ج.م",
    image: oxiPowder,
    stock: "limited",
  },
  {
    id: "fairy-lemon-1l",
    name: "فيري ليمون - ١ لتر",
    category: "dishwashing",
    categoryLabel: "منظفات أطباق",
    description: "قوة الليمون لإزالة الدهون فوراً",
    price: 65,
    unit: "ج.م",
    image: fairyLemon1l,
    stock: "available",
  },
  {
    id: "fairy-750ml",
    name: "فيري سائل أطباق - ٧٥٠ مل",
    category: "dishwashing",
    categoryLabel: "منظفات أطباق",
    description: "رغوة غنية ولمعان فائق للأطباق",
    price: 48,
    unit: "ج.م",
    image: fairy750,
    stock: "available",
  },
  {
    id: "clorox-white",
    name: "كلوركس أبيض - ٩٥٠ مل",
    category: "disinfectants",
    categoryLabel: "مطهرات",
    description: "تعقيم وتبييض قوي لكل الأسطح",
    price: 25.5,
    unit: "ج.م",
    image: cloroxWhite,
    stock: "available",
  },
  {
    id: "floor-pine",
    name: "مطهر أرضيات برائحة الصنوبر - ٣ لتر",
    category: "disinfectants",
    categoryLabel: "مطهرات",
    description: "تركيبة مركزة برائحة منعشة تدوم",
    price: 65,
    unit: "ج.م",
    image: floorPine,
    stock: "available",
  },
  {
    id: "dettol-surface",
    name: "ديتول مطهر أسطح - ٧٥٠ مل",
    category: "disinfectants",
    categoryLabel: "مطهرات",
    description: "يقتل ٩٩.٩٪ من الجراثيم والبكتيريا",
    price: 55,
    unit: "ج.م",
    image: dettolSurface,
    stock: "limited",
  },
  {
    id: "kitchen-towels",
    name: "مناديل مطبخ - ٦ رول",
    category: "paper",
    categoryLabel: "ورقيات",
    description: "امتصاص عالي وورق متين عالي الجودة",
    price: 88,
    unit: "ج.م",
    image: kitchenTowels,
    stock: "available",
  },
  {
    id: "toilet-tissue",
    name: "مناديل حمام - ١٢ رول",
    category: "paper",
    categoryLabel: "ورقيات",
    description: "نعومة فائقة وراحة للاستخدام اليومي",
    price: 75,
    unit: "ج.م",
    image: toiletTissue,
    stock: "available",
  },
  {
    id: "microfiber-cloths",
    name: "فوط مايكروفايبر - ٣ قطع",
    category: "tools",
    categoryLabel: "أدوات نظافة",
    description: "امتصاص عالي وتلميع فائق بدون خدوش",
    price: 35,
    unit: "ج.م",
    image: microfiberCloths,
    stock: "available",
  },
  {
    id: "bucket-mop",
    name: "طقم جردل وشرشوبة",
    category: "tools",
    categoryLabel: "أدوات نظافة",
    description: "طقم متكامل لتنظيف الأرضيات باحترافية",
    price: 120,
    unit: "ج.م",
    image: bucketMop,
    stock: "available",
  },
];

// رقم واتساب للمحل
export const WHATSAPP_NUMBER = "201145146164";
export const SHOP_NAME = "الياسين للمنظفات";
export const SHOP_ADDRESS = "زاوية أبو مسلم - الشون - أمام مسجد الرحمة";
export const SHOP_PHONE = "201145146164";

export function buildWhatsAppOrderLink(items: { name: string; qty: number; price: number }[]) {
  const lines = items.map(
    (i) => `• ${i.name} ×${i.qty} = ${i.qty * i.price} ج.م`,
  );
  const total = items.reduce((s, i) => s + i.qty * i.price, 0);
  const text = encodeURIComponent(
    `السلام عليكم، عاوز أطلب من ${SHOP_NAME}:\n\n${lines.join("\n")}\n\nالإجمالي: ${total} ج.م`,
  );
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${text}`;
}

export function buildWhatsAppSingleLink(name: string, price: number) {
  const text = encodeURIComponent(
    `السلام عليكم، عاوز أطلب: ${name} - السعر ${price} ج.م`,
  );
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${text}`;
}
