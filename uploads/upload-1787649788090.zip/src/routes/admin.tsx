import { useEffect, useMemo, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, useIsAdmin } from "@/hooks/useAuth";
import {
  adminProductsQuery,
  categoriesQuery,
  formatPrice,
  logFieldLabel,
  logValueLabel,
  productImage,
  productLogsQuery,
  stockClasses,
  stockLabel,
  uploadProductImage,
  type Category,
  type Product,
} from "@/lib/catalog";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "لوحة التحكم | الياسين للمنظفات" },
      {
        name: "description",
        content: "لوحة تحكم إدارة المنتجات والأسعار والتصنيفات والكميات.",
      },
      { property: "og:title", content: "لوحة التحكم | الياسين للمنظفات" },
      {
        property: "og:description",
        content: "إدارة المنتجات والأسعار والكميات والتصنيفات.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPage,
});

const emptyForm = {
  id: "",
  slug: "",
  name: "",
  category_id: "",
  description: "",
  price: "",
  unit: "ج.م",
  image_url: "",
  image_path: "",
  quantity: "0",
  is_active: true,
};
type FormState = typeof emptyForm;


function AdminPage() {
  const { session, loading } = useAuth();
  const navigate = useNavigate();
  const isAdmin = useIsAdmin(session?.user.id);

  useEffect(() => {
    if (!loading && !session) navigate({ to: "/auth" });
  }, [loading, session, navigate]);

  if (loading || !session) {
    return <Centered>جاري التحميل...</Centered>;
  }

  if (isAdmin === null) return <Centered>جاري التحقق من الصلاحيات...</Centered>;
  if (!isAdmin) return <ClaimAdmin />;

  return <Dashboard email={session.user.email ?? ""} />;
}

function Centered({ children }: { children: React.ReactNode }) {
  return (
    <div
      dir="rtl"
      className="grid min-h-screen place-items-center bg-brand-surface font-cairo text-brand-muted"
    >
      {children}
    </div>
  );
}

function ClaimAdmin() {
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function claim() {
    setBusy(true);
    const { data, error } = await supabase.rpc("claim_first_admin");
    setBusy(false);
    if (error) {
      setMsg("حصل خطأ: " + error.message);
      return;
    }
    if (data) window.location.reload();
    else setMsg("في مدير معيّن بالفعل للموقع. اطلب منه يضيفك.");
  }

  return (
    <div
      dir="rtl"
      className="grid min-h-screen place-items-center bg-brand-surface px-4 font-cairo"
    >
      <div className="w-full max-w-sm rounded-3xl bg-white p-8 text-center ring-1 ring-black/5">
        <h1 className="text-lg font-bold">حسابك مش مدير</h1>
        <p className="mt-2 text-sm text-brand-muted">
          لو ده أول حساب للمحل، اضغط الزر عشان تفعّل صلاحية الإدارة.
        </p>
        <button
          onClick={claim}
          disabled={busy}
          className="mt-5 w-full rounded-xl bg-brand-primary py-2.5 text-sm font-bold text-white disabled:opacity-60"
        >
          {busy ? "جاري..." : "تفعيل حسابي كمدير"}
        </button>
        {msg && <p className="mt-4 text-xs text-amber-700">{msg}</p>}
        <button
          onClick={() => supabase.auth.signOut().then(() => window.location.assign("/auth"))}
          className="mt-4 text-xs text-brand-muted underline"
        >
          تسجيل الخروج
        </button>
      </div>
    </div>
  );
}

function Dashboard({ email }: { email: string }) {
  const qc = useQueryClient();
  const { data: categories = [] } = useQuery(categoriesQuery);
  const { data: products = [] } = useQuery(adminProductsQuery);
  const [tab, setTab] = useState<"products" | "stock" | "categories" | "logs">("products");
  const [form, setForm] = useState<FormState>(emptyForm);
  const [editing, setEditing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);

  const catLabel = useMemo(
    () => Object.fromEntries(categories.map((c) => [c.id, c.label])),
    [categories],
  );

  function reset() {
    setForm({ ...emptyForm, category_id: categories[0]?.id ?? "" });
    setEditing(false);
    setError(null);
  }

  function edit(p: Product) {
    setForm({
      id: p.id,
      slug: p.slug,
      name: p.name,
      category_id: p.category_id,
      description: p.description,
      price: String(p.price),
      unit: p.unit,
      image_url: p.image_url ?? "",
      image_path: p.image_path ?? "",
      quantity: String(p.quantity),
      is_active: p.is_active,
    });
    setEditing(true);
    setError(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function onPickImage(file: File) {
    setUploading(true);
    setError(null);
    try {
      const { url, path } = await uploadProductImage(file);
      setForm((f) => ({ ...f, image_url: url, image_path: path }));
    } catch (err) {
      setError("فشل رفع الصورة: " + (err as Error).message);
    } finally {
      setUploading(false);
    }
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const payload = {
      slug:
        form.slug.trim() ||
        form.name.trim().replace(/\s+/g, "-").slice(0, 60) + "-" + Date.now().toString(36),
      name: form.name.trim(),
      category_id: form.category_id || categories[0]?.id || "",
      description: form.description.trim(),
      price: Number(form.price) || 0,
      unit: form.unit.trim() || "ج.م",
      image_url: form.image_url.trim() || null,
      image_path: form.image_path.trim() || null,
      quantity: Number(form.quantity) || 0,
      is_active: form.is_active,
    };
    const res = editing
      ? await supabase.from("products").update(payload).eq("id", form.id)
      : await supabase.from("products").insert(payload);
    if (res.error) {
      setError(res.error.message);
      return;
    }
    await qc.invalidateQueries({ queryKey: ["products"] });
    await qc.invalidateQueries({ queryKey: ["product_logs"] });
    reset();
  }


  async function remove(p: Product) {
    if (!confirm(`متأكد من حذف "${p.name}"؟`)) return;
    const { error } = await supabase.from("products").delete().eq("id", p.id);
    if (error) setError(error.message);
    else await qc.invalidateQueries({ queryKey: ["products"] });
  }

  async function toggleActive(p: Product) {
    await supabase.from("products").update({ is_active: !p.is_active }).eq("id", p.id);
    await qc.invalidateQueries({ queryKey: ["products"] });
  }

  async function quickQty(p: Product, delta: number) {
    const next = Math.max(0, p.quantity + delta);
    await supabase.from("products").update({ quantity: next }).eq("id", p.id);
    await qc.invalidateQueries({ queryKey: ["products"] });
    await qc.invalidateQueries({ queryKey: ["product_logs"] });
  }

  return (
    <div dir="rtl" className="min-h-screen bg-brand-surface font-cairo text-brand-text">
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md ring-1 ring-black/5">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
          <h1 className="text-lg font-bold">لوحة تحكم الياسين</h1>
          <div className="flex items-center gap-3 text-xs">
            <span className="hidden text-brand-muted sm:inline" dir="ltr">
              {email}
            </span>
            <Link to="/" className="rounded-full bg-brand-primary/10 px-3 py-1.5 font-medium text-brand-primary">
              المتجر
            </Link>
            <button
              onClick={() => supabase.auth.signOut().then(() => window.location.assign("/"))}
              className="rounded-full border border-black/10 px-3 py-1.5"
            >
              خروج
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-4 py-8">
        <div className="mb-6 flex flex-wrap gap-2">
          <TabBtn active={tab === "products"} onClick={() => setTab("products")}>
            المنتجات ({products.length})
          </TabBtn>
          <TabBtn active={tab === "stock"} onClick={() => setTab("stock")}>
            الكمية والتوافر
          </TabBtn>
          <TabBtn active={tab === "categories"} onClick={() => setTab("categories")}>
            التصنيفات ({categories.length})
          </TabBtn>
          <TabBtn active={tab === "logs"} onClick={() => setTab("logs")}>
            سجل التغييرات
          </TabBtn>
        </div>

        {error && (
          <p className="mb-4 rounded-xl bg-red-50 p-3 text-xs text-red-700">{error}</p>
        )}

        {tab === "products" ? (
          <>
            <form onSubmit={save} className="mb-8 rounded-3xl bg-white p-6 ring-1 ring-black/5">
              <h2 className="mb-4 font-bold">
                {editing ? "تعديل منتج" : "إضافة منتج جديد"}
              </h2>
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="اسم المنتج">
                  <input
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className={inputCls}
                  />
                </Field>
                <Field label="التصنيف">
                  <select
                    value={form.category_id || categories[0]?.id || ""}
                    onChange={(e) => setForm({ ...form, category_id: e.target.value })}
                    className={inputCls}
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.label}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="السعر">
                  <input
                    type="number"
                    step="0.5"
                    min="0"
                    required
                    value={form.price}
                    onChange={(e) => setForm({ ...form, price: e.target.value })}
                    className={inputCls}
                  />
                </Field>
                <Field label="الكمية المتاحة">
                  <input
                    type="number"
                    min="0"
                    value={form.quantity}
                    onChange={(e) => setForm({ ...form, quantity: e.target.value })}
                    className={inputCls}
                  />
                </Field>
                <Field label="الوحدة">
                  <input
                    value={form.unit}
                    onChange={(e) => setForm({ ...form, unit: e.target.value })}
                    className={inputCls}
                  />
                </Field>
                <Field label="صورة المنتج">
                  <div className="flex items-center gap-3">
                    <img
                      src={form.image_url || "/placeholder.svg"}
                      alt=""
                      className="size-12 shrink-0 rounded-lg object-cover ring-1 ring-black/5"
                    />
                    <input
                      type="file"
                      accept="image/*"
                      disabled={uploading}
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (f) void onPickImage(f);
                      }}
                      className="w-full text-xs file:ml-3 file:rounded-lg file:border-0 file:bg-brand-primary/10 file:px-3 file:py-2 file:text-xs file:font-bold file:text-brand-primary"
                    />
                  </div>
                  {uploading && (
                    <span className="mt-1 block text-[11px] text-brand-muted">جاري رفع الصورة...</span>
                  )}
                </Field>
                <Field label="أو رابط صورة (اختياري)">
                  <input
                    value={form.image_url}
                    onChange={(e) => setForm({ ...form, image_url: e.target.value })}
                    dir="ltr"
                    placeholder="https://..."
                    className={inputCls}
                  />
                </Field>
                <div className="sm:col-span-2">
                  <Field label="الوصف">
                    <textarea
                      rows={2}
                      value={form.description}
                      onChange={(e) => setForm({ ...form, description: e.target.value })}
                      className={inputCls}
                    />
                  </Field>
                </div>
              </div>

              <label className="mt-4 flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={form.is_active}
                  onChange={(e) => setForm({ ...form, is_active: e.target.checked })}
                />
                معروض في المتجر
              </label>

              <div className="mt-5 flex gap-2">
                <button
                  type="submit"
                  className="rounded-xl bg-brand-primary px-6 py-2.5 text-sm font-bold text-white"
                >
                  {editing ? "حفظ التعديلات" : "إضافة المنتج"}
                </button>
                {editing && (
                  <button
                    type="button"
                    onClick={reset}
                    className="rounded-xl border border-black/10 px-6 py-2.5 text-sm"
                  >
                    إلغاء
                  </button>
                )}
              </div>
            </form>

            <div className="space-y-3">
              {products.map((p) => (
                <div
                  key={p.id}
                  className="flex flex-wrap items-center gap-4 rounded-2xl bg-white p-4 ring-1 ring-black/5"
                >
                  <img
                    src={productImage(p)}
                    alt={p.name}
                    className="size-14 shrink-0 rounded-xl object-cover"
                  />
                  <div className="min-w-40 grow">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">{p.name}</span>
                      {!p.is_active && (
                        <span className="rounded bg-neutral-200 px-2 text-[10px] text-neutral-600">
                          مخفي
                        </span>
                      )}
                    </div>
                    <span className="text-xs text-brand-muted">
                      {catLabel[p.category_id] ?? p.category_id}
                    </span>
                  </div>
                  <div className="text-sm font-bold text-brand-primary">
                    {formatPrice(p.price)} {p.unit}
                  </div>
                  <div className="flex items-center gap-1 rounded-full bg-brand-surface p-1">
                    <button onClick={() => quickQty(p, -1)} className="size-6 rounded-full">−</button>
                    <span className="w-10 text-center text-sm font-bold">{p.quantity}</span>
                    <button onClick={() => quickQty(p, 1)} className="size-6 rounded-full">+</button>
                  </div>
                  <span className={`rounded px-2 py-0.5 text-[10px] font-bold ${stockClasses(p.quantity)}`}>
                    {stockLabel(p.quantity)}
                  </span>
                  <div className="flex gap-2 text-xs">
                    <button onClick={() => edit(p)} className="rounded-lg border border-black/10 px-3 py-1.5">
                      تعديل
                    </button>
                    <button onClick={() => toggleActive(p)} className="rounded-lg border border-black/10 px-3 py-1.5">
                      {p.is_active ? "إخفاء" : "إظهار"}
                    </button>
                    <button onClick={() => remove(p)} className="rounded-lg bg-red-50 px-3 py-1.5 text-red-700">
                      حذف
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        ) : tab === "stock" ? (
          <StockPanel products={products} catLabel={catLabel} />
        ) : tab === "logs" ? (
          <LogsPanel />
        ) : (
          <CategoriesPanel categories={categories} />
        )}
      </div>
    </div>
  );
}

function StockPanel({
  products,
  catLabel,
}: {
  products: Product[];
  catLabel: Record<string, string>;
}) {
  const qc = useQueryClient();
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const list = useMemo(() => {
    const t = q.trim();
    return t ? products.filter((p) => p.name.includes(t)) : products;
  }, [products, q]);

  async function apply(p: Product, patch: { quantity?: number; is_active?: boolean }) {
    setBusy(p.id);
    setErr(null);
    const { error } = await supabase.from("products").update(patch).eq("id", p.id);
    if (error) setErr(error.message);
    await qc.invalidateQueries({ queryKey: ["products"] });
    await qc.invalidateQueries({ queryKey: ["product_logs"] });
    setBusy(null);
  }

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="ابحث باسم المنتج..."
          className={`${inputCls} max-w-xs`}
        />
        <span className="text-xs text-brand-muted">
          تحديث سريع للكمية وحالة التوافر — أي تغيير بيتسجّل تلقائيًا في سجل التغييرات.
        </span>
      </div>
      {err && <p className="mb-4 rounded-xl bg-red-50 p-3 text-xs text-red-700">{err}</p>}
      <div className="space-y-3">
        {list.map((p) => (
          <div
            key={p.id}
            className={`flex flex-wrap items-center gap-3 rounded-2xl bg-white p-4 ring-1 ring-black/5 ${
              busy === p.id ? "opacity-60" : ""
            }`}
          >
            <img src={productImage(p)} alt="" className="size-12 rounded-xl object-cover" />
            <div className="min-w-40 grow">
              <div className="text-sm font-medium">{p.name}</div>
              <span className="text-xs text-brand-muted">
                {catLabel[p.category_id] ?? p.category_id}
              </span>
            </div>
            <div className="flex items-center gap-1 rounded-full bg-brand-surface p-1">
              <button
                onClick={() => apply(p, { quantity: Math.max(0, p.quantity - 1) })}
                className="size-7 rounded-full text-lg leading-none"
              >
                −
              </button>
              <input
                type="number"
                min="0"
                value={p.quantity}
                onChange={(e) => apply(p, { quantity: Math.max(0, Number(e.target.value) || 0) })}
                className="w-16 rounded-full bg-white px-2 py-1 text-center text-sm font-bold"
              />
              <button
                onClick={() => apply(p, { quantity: p.quantity + 1 })}
                className="size-7 rounded-full text-lg leading-none"
              >
                +
              </button>
            </div>
            <div className="flex flex-wrap gap-1 text-[11px]">
              {[0, 5, 10, 25, 50].map((n) => (
                <button
                  key={n}
                  onClick={() => apply(p, { quantity: n })}
                  className="rounded-lg border border-black/10 px-2 py-1"
                >
                  {n === 0 ? "نفدت" : n}
                </button>
              ))}
            </div>
            <span className={`rounded px-2 py-0.5 text-[10px] font-bold ${stockClasses(p.quantity)}`}>
              {stockLabel(p.quantity)}
            </span>
            <button
              onClick={() => apply(p, { is_active: !p.is_active })}
              className="rounded-lg border border-black/10 px-3 py-1.5 text-xs"
            >
              {p.is_active ? "إخفاء من المتجر" : "إظهار في المتجر"}
            </button>
          </div>
        ))}
        {list.length === 0 && (
          <p className="rounded-2xl bg-white p-6 text-center text-sm text-brand-muted ring-1 ring-black/5">
            مفيش نتائج.
          </p>
        )}
      </div>
    </div>
  );
}

function LogsPanel() {
  const { data: logs = [], isLoading } = useQuery(productLogsQuery);

  if (isLoading) {
    return <p className="text-sm text-brand-muted">جاري تحميل السجل...</p>;
  }
  if (logs.length === 0) {
    return (
      <p className="rounded-2xl bg-white p-6 text-center text-sm text-brand-muted ring-1 ring-black/5">
        لسه مفيش تغييرات مسجّلة.
      </p>
    );
  }

  return (
    <div className="overflow-hidden rounded-2xl bg-white ring-1 ring-black/5">
      <table className="w-full text-right text-sm">
        <thead className="bg-brand-surface text-xs text-brand-muted">
          <tr>
            <th className="px-4 py-3 font-medium">المنتج</th>
            <th className="px-4 py-3 font-medium">الحقل</th>
            <th className="px-4 py-3 font-medium">من</th>
            <th className="px-4 py-3 font-medium">إلى</th>
            <th className="px-4 py-3 font-medium">التاريخ</th>
          </tr>
        </thead>
        <tbody>
          {logs.map((l) => (
            <tr key={l.id} className="border-t border-black/5">
              <td className="px-4 py-2.5">{l.product_name}</td>
              <td className="px-4 py-2.5 text-brand-muted">{logFieldLabel(l.field)}</td>
              <td className="px-4 py-2.5">{logValueLabel(l.field, l.old_value)}</td>
              <td className="px-4 py-2.5 font-bold text-brand-primary">
                {logValueLabel(l.field, l.new_value)}
              </td>
              <td className="px-4 py-2.5 text-xs text-brand-muted">
                {new Date(l.created_at).toLocaleString("ar-EG")}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}


function CategoriesPanel({ categories }: { categories: Category[] }) {
  const qc = useQueryClient();
  const [id, setId] = useState("");
  const [label, setLabel] = useState("");
  const [error, setError] = useState<string | null>(null);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const { error } = await supabase.from("categories").insert({
      id: id.trim() || label.trim().replace(/\s+/g, "-"),
      label: label.trim(),
      sort_order: categories.length + 1,
    });
    if (error) return setError(error.message);
    setId("");
    setLabel("");
    await qc.invalidateQueries({ queryKey: ["categories"] });
  }

  async function rename(c: Category, next: string) {
    if (!next || next === c.label) return;
    await supabase.from("categories").update({ label: next }).eq("id", c.id);
    await qc.invalidateQueries({ queryKey: ["categories"] });
  }

  async function remove(c: Category) {
    if (!confirm(`حذف التصنيف "${c.label}"؟`)) return;
    const { error } = await supabase.from("categories").delete().eq("id", c.id);
    if (error) setError("مينفعش تحذف تصنيف فيه منتجات. انقل المنتجات الأول.");
    else await qc.invalidateQueries({ queryKey: ["categories"] });
  }

  return (
    <div>
      <form onSubmit={add} className="mb-6 rounded-3xl bg-white p-6 ring-1 ring-black/5">
        <h2 className="mb-4 font-bold">إضافة تصنيف</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="اسم التصنيف">
            <input required value={label} onChange={(e) => setLabel(e.target.value)} className={inputCls} />
          </Field>
          <Field label="المعرّف بالإنجليزي (اختياري)">
            <input value={id} onChange={(e) => setId(e.target.value)} dir="ltr" className={inputCls} />
          </Field>
        </div>
        <button className="mt-5 rounded-xl bg-brand-primary px-6 py-2.5 text-sm font-bold text-white">
          إضافة
        </button>
        {error && <p className="mt-3 text-xs text-red-700">{error}</p>}
      </form>

      <div className="space-y-3">
        {categories.map((c) => (
          <div key={c.id} className="flex items-center gap-3 rounded-2xl bg-white p-4 ring-1 ring-black/5">
            <input
              defaultValue={c.label}
              onBlur={(e) => rename(c, e.target.value.trim())}
              className="grow rounded-lg border border-black/10 px-3 py-1.5 text-sm"
            />
            <span className="text-xs text-brand-muted" dir="ltr">
              {c.id}
            </span>
            <button onClick={() => remove(c)} className="rounded-lg bg-red-50 px-3 py-1.5 text-xs text-red-700">
              حذف
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

const inputCls =
  "w-full rounded-xl border border-black/10 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-brand-primary/30";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs text-brand-muted">{label}</span>
      {children}
    </label>
  );
}

function TabBtn({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full px-5 py-1.5 text-sm font-medium ring-1 transition-colors ${
        active
          ? "bg-brand-primary text-white ring-brand-primary"
          : "bg-white text-brand-muted ring-black/5"
      }`}
    >
      {children}
    </button>
  );
}
