import { useEffect, useState } from "react";
import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "دخول الإدارة | الياسين للمنظفات" },
      {
        name: "description",
        content: "صفحة تسجيل دخول إدارة كتالوج أسعار الياسين للمنظفات.",
      },
      { property: "og:title", content: "دخول الإدارة | الياسين للمنظفات" },
      {
        property: "og:description",
        content: "تسجيل دخول لوحة تحكم المنتجات والأسعار.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/admin" });
    });
  }, [navigate]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: `${window.location.origin}/admin` },
        });
        if (error) throw error;
        setMsg("تم إنشاء الحساب. لو مطلوب تأكيد بريد، افتح الرسالة المرسلة لك.");
        const { data } = await supabase.auth.getSession();
        if (data.session) navigate({ to: "/admin" });
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate({ to: "/admin" });
      }
    } catch (err) {
      setMsg(err instanceof Error ? err.message : "حصل خطأ، حاول تاني.");
    } finally {
      setBusy(false);
    }
  }

  async function google() {
    setMsg(null);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      setMsg("تعذّر الدخول بجوجل، جرّب البريد وكلمة السر.");
      return;
    }
    if (result.redirected) return;
    navigate({ to: "/admin" });
  }

  return (
    <div
      dir="rtl"
      className="flex min-h-screen items-center justify-center bg-brand-surface px-4 font-cairo text-brand-text"
    >
      <div className="w-full max-w-sm rounded-3xl bg-white p-8 ring-1 ring-black/5">
        <div className="mb-6 flex items-center justify-center gap-2">
          <div className="grid size-8 place-items-center rounded-[8px] bg-brand-primary text-sm font-bold text-white">
            ي
          </div>
          <span className="font-semibold">الياسين للمنظفات</span>
        </div>
        <h1 className="text-center text-xl font-bold">
          {mode === "signin" ? "دخول لوحة التحكم" : "إنشاء حساب إدارة"}
        </h1>

        <form onSubmit={submit} className="mt-6 space-y-3">
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="البريد الإلكتروني"
            dir="ltr"
            className="w-full rounded-xl border border-black/10 px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-brand-primary/30"
          />
          <input
            type="password"
            required
            minLength={6}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="كلمة السر"
            dir="ltr"
            className="w-full rounded-xl border border-black/10 px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-brand-primary/30"
          />
          <button
            type="submit"
            disabled={busy}
            className="w-full rounded-xl bg-brand-primary py-2.5 text-sm font-bold text-white transition-opacity disabled:opacity-60"
          >
            {busy ? "جاري..." : mode === "signin" ? "دخول" : "إنشاء الحساب"}
          </button>
        </form>

        <button
          onClick={google}
          className="mt-3 w-full rounded-xl border border-black/10 py-2.5 text-sm font-medium transition-colors hover:bg-black/5"
        >
          الدخول بحساب جوجل
        </button>

        {msg && (
          <p className="mt-4 rounded-xl bg-amber-50 p-3 text-xs text-amber-800">{msg}</p>
        )}

        <button
          onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
          className="mt-4 w-full text-center text-xs text-brand-muted underline"
        >
          {mode === "signin" ? "معنديش حساب — إنشاء حساب" : "عندي حساب — تسجيل دخول"}
        </button>

        <Link
          to="/"
          className="mt-4 block text-center text-xs text-brand-primary"
        >
          الرجوع للمتجر
        </Link>
      </div>
    </div>
  );
}
