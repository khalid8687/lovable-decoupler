import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  SHOP_ADDRESS,
  SHOP_PHONE,
  WHATSAPP_NUMBER,
  buildWhatsAppOrderLink,
  buildWhatsAppSingleLink,
} from "@/lib/products";
import {
  SORT_OPTIONS,
  categoriesQuery,
  formatPrice,
  productImage,
  publicProductsQuery,
  sortProducts,
  stockClasses,
  stockLabel,
  stockState,
  type Product,
  type SortMode,
} from "@/lib/catalog";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "الياسين للمنظفات | كتالوج أسعار المنظفات ومستلزمات البيت" },
      {
        name: "description",
        content:
          "الياسين للمنظفات — كتالوج أسعار مساحيق الغسيل ومنظفات الأطباق والمطهرات والورقيات وأدوات النظافة مع حالة التوافر والكميات. اطلب مباشرة عبر واتساب.",
      },
      { property: "og:title", content: "الياسين للمنظفات | كتالوج الأسعار" },
      {
        property: "og:description",
        content:
          "أجود أنواع المنظفات ومستلزمات العناية بالمنزل بأسعار تنافسية مع بيان الكميات المتاحة. اطلب عبر واتساب.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

interface CartItem {
  product: Product;
  qty: number;
}

function Index() {
  const { data: categories = [] } = useQuery(categoriesQuery);
  const { data: products = [], isLoading } = useQuery(publicProductsQuery);

  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<SortMode>("default");
  const [cart, setCart] = useState<Record<string, number>>({});

  const catLabel = useMemo(
    () => Object.fromEntries(categories.map((c) => [c.id, c.label])),
    [categories],
  );

  const filtered = useMemo(() => {
    const q = query.trim();
    const list = products.filter((p) => {
      const inCat = activeCategory === "all" || p.category_id === activeCategory;
      const inQuery =
        q === "" ||
        p.name.includes(q) ||
        (catLabel[p.category_id] ?? "").includes(q) ||
        p.description.includes(q);
      return inCat && inQuery;
    });
    return sortProducts(list, sort);
  }, [products, activeCategory, query, sort, catLabel]);

  const cartItems: CartItem[] = useMemo(
    () =>
      Object.entries(cart)
        .map(([id, qty]) => {
          const product = products.find((p) => p.id === id);
          return product ? { product, qty } : null;
        })
        .filter((x): x is CartItem => x !== null),
    [cart, products],
  );

  const cartCount = cartItems.reduce((s, i) => s + i.qty, 0);
  const cartTotal = cartItems.reduce((s, i) => s + i.qty * i.product.price, 0);

  function setQty(id: string, delta: number, max: number) {
    setCart((prev) => {
      const next = Math.min(max, Math.max(0, (prev[id] ?? 0) + delta));
      const copy = { ...prev };
      if (next === 0) delete copy[id];
      else copy[id] = next;
      return copy;
    });
  }

  const orderItems = cartItems.map((i) => ({
    name: i.product.name,
    qty: i.qty,
    price: i.product.price,
  }));

  return (
    <div
      dir="rtl"
      className="min-h-screen bg-brand-surface font-cairo text-brand-text selection:bg-brand-primary/10"
    >
      {/* Header */}
      <header className="sticky top-0 z-50 w-full bg-brand-surface/95 backdrop-blur-md ring-1 ring-black/5">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2">
            <div className="size-8 rounded-[8px] bg-brand-primary grid place-items-center text-white">
              <span className="text-sm font-bold">ي</span>
            </div>
            <h1 className="text-lg font-semibold tracking-tight">الياسين للمنظفات</h1>
          </div>

          <a
            href={buildWhatsAppOrderLink(orderItems)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-full bg-brand-primary px-4 py-2 text-sm font-medium text-white transition-transform hover:scale-[1.02]"
          >
            <CartIcon />
            <span className="hidden sm:inline">
              {cartCount > 0 ? `إتمام الطلب (${cartCount})` : "اطلب الآن عبر واتساب"}
            </span>
            {cartCount > 0 && (
              <span className="sm:hidden rounded-full bg-white/25 px-2 text-xs">
                {cartCount}
              </span>
            )}
          </a>
        </div>
      </header>

      <main>
        {/* Hero */}
        <section className="bg-white py-12 sm:py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="max-w-[56ch]">
              <span className="inline-block rounded-full bg-brand-primary/10 px-3 py-1 text-xs font-bold text-brand-primary">
                ثقة • نظافة • توفير
              </span>
              <h2 className="mt-4 text-balance text-4xl font-bold leading-tight text-brand-text sm:text-5xl">
                نظافة أكيدة.. لكل بيت في مصر
              </h2>
              <p className="mt-4 text-pretty text-lg text-brand-muted">
                نقدّم لكم أجود أنواع المنظفات ومستلزمات العناية بالمنزل بأسعار
                تنافسية. تصفّح كتالوج الأسعار واطلب طلبيتك لتصلك حتى باب البيت.
              </p>
            </div>
          </div>
        </section>

        {/* Filter + Search + Sort */}
        <section className="sticky top-16 z-40 bg-brand-surface py-4 ring-1 ring-black/5">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
              <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
                <CategoryChip
                  active={activeCategory === "all"}
                  onClick={() => setActiveCategory("all")}
                >
                  الكل
                </CategoryChip>
                {categories.map((c) => (
                  <CategoryChip
                    key={c.id}
                    active={activeCategory === c.id}
                    onClick={() => setActiveCategory(c.id)}
                  >
                    {c.label}
                  </CategoryChip>
                ))}
              </div>

              <div className="flex shrink-0 gap-2">
                <select
                  value={sort}
                  onChange={(e) => setSort(e.target.value as SortMode)}
                  aria-label="ترتيب المنتجات"
                  className="rounded-full border border-black/5 bg-white px-4 py-2 text-sm text-brand-text outline-none ring-brand-primary/20 focus:ring-2"
                >
                  {SORT_OPTIONS.map((o) => (
                    <option key={o.id} value={o.id}>
                      {o.label}
                    </option>
                  ))}
                </select>

                <div className="relative grow">
                  <input
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="ابحث عن منتج..."
                    className="w-full rounded-full border border-black/5 bg-white py-2 pr-10 pl-4 text-sm text-brand-text outline-none ring-brand-primary/20 placeholder:text-brand-muted/70 focus:ring-2 sm:w-56"
                  />
                  <SearchIcon />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Product grid */}
        <section className="py-12">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            {isLoading ? (
              <div className="py-20 text-center text-brand-muted">جاري تحميل المنتجات...</div>
            ) : filtered.length === 0 ? (
              <div className="py-20 text-center text-brand-muted">
                لا توجد منتجات مطابقة لبحثك.
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
                {filtered.map((p, idx) => {
                  const qty = cart[p.id] ?? 0;
                  const out = stockState(p.quantity) === "out";
                  return (
                    <div
                      key={p.id}
                      className="group relative flex flex-col rounded-[16px] bg-white p-3 ring-1 ring-black/5 transition-transform hover:-translate-y-1 animate-fade-up"
                      style={{ animationDelay: `${idx * 40}ms` }}
                    >
                      <Link
                        to="/product/$slug"
                        params={{ slug: p.slug }}
                        className="mb-4 block aspect-square w-full overflow-hidden rounded-[12px] bg-neutral-100"
                      >
                        <img
                          src={productImage(p)}
                          alt={p.name}
                          loading="lazy"
                          className={`size-full object-cover transition-transform duration-500 group-hover:scale-[1.04] ${out ? "opacity-60" : ""}`}
                        />
                      </Link>

                      <div className="flex grow flex-col">
                        <span className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-brand-primary">
                          {catLabel[p.category_id] ?? p.category_id}
                        </span>
                        <Link
                          to="/product/$slug"
                          params={{ slug: p.slug }}
                          className="text-sm font-medium leading-snug text-brand-text hover:text-brand-primary"
                        >
                          {p.name}
                        </Link>
                        <p className="mt-1 text-xs text-brand-muted">{p.description}</p>

                        <div className="mt-3 flex flex-wrap items-center gap-2">
                          <span
                            className={`rounded px-2 py-0.5 text-[10px] font-bold ${stockClasses(p.quantity)}`}
                          >
                            {stockLabel(p.quantity)}
                          </span>
                          <span className="text-[10px] text-brand-muted">
                            الكمية: {p.quantity}
                          </span>
                        </div>

                        <div className="mt-4 flex items-end justify-between">
                          <div>
                            <span className="block text-xs text-brand-muted">السعر</span>
                            <span className="text-lg font-semibold text-brand-text">
                              {formatPrice(p.price)}{" "}
                              <span className="text-xs">{p.unit}</span>
                            </span>
                          </div>

                          {out ? null : qty === 0 ? (
                            <button
                              onClick={() => setQty(p.id, 1, p.quantity)}
                              aria-label={`أضف ${p.name} للطلب`}
                              className="flex size-8 items-center justify-center rounded-full bg-brand-primary/10 text-brand-primary transition-colors hover:bg-brand-primary hover:text-white"
                            >
                              <PlusIcon />
                            </button>
                          ) : (
                            <div className="flex items-center gap-1 rounded-full bg-brand-primary/10 p-1">
                              <button
                                onClick={() => setQty(p.id, -1, p.quantity)}
                                aria-label="إنقاص"
                                className="flex size-6 items-center justify-center rounded-full text-brand-primary hover:bg-white"
                              >
                                <MinusIcon />
                              </button>
                              <span className="w-5 text-center text-sm font-bold text-brand-primary">
                                {qty}
                              </span>
                              <button
                                onClick={() => setQty(p.id, 1, p.quantity)}
                                aria-label="زيادة"
                                className="flex size-6 items-center justify-center rounded-full text-brand-primary hover:bg-white"
                              >
                                <PlusIcon />
                              </button>
                            </div>
                          )}
                        </div>

                        {out ? (
                          <span className="mt-3 block w-full rounded-lg bg-neutral-100 py-1.5 text-center text-xs font-medium text-neutral-500">
                            غير متوفر حالياً
                          </span>
                        ) : (
                          <a
                            href={buildWhatsAppSingleLink(p.name, p.price)}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="mt-3 block w-full rounded-lg border border-brand-primary/20 py-1.5 text-center text-xs font-medium text-brand-primary transition-colors hover:bg-brand-primary hover:text-white"
                          >
                            اطلب عبر واتساب
                          </a>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </section>

        {/* Wholesale / contact band */}
        <section className="bg-white py-12">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="rounded-3xl bg-brand-primary p-8 text-white sm:p-12">
              <div className="grid gap-8 md:grid-cols-2 md:items-center">
                <div>
                  <h3 className="text-2xl font-bold sm:text-3xl">
                    صاحب محل منظفات؟ عندنا أسعار جملة خاصة بيك
                  </h3>
                  <p className="mt-3 text-white/85">
                    نوفر قوائم أسعار وتخفيضات حصرية لتجار التجزئة والكميات
                    الكبيرة. تواصل معنا واحصل على عرض سعر مخصص.
                  </p>
                </div>
                <div className="flex flex-col gap-3 sm:flex-row md:justify-end">
                  <a
                    href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent("عاوز أعرف عروض أسعار الجملة")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="rounded-full bg-white px-6 py-3 text-center text-sm font-bold text-brand-primary transition-transform hover:scale-[1.02]"
                  >
                    عروض الجملة
                  </a>
                  <a
                    href={`tel:+${SHOP_PHONE}`}
                    className="rounded-full border border-white/40 px-6 py-3 text-center text-sm font-bold text-white transition-colors hover:bg-white/10"
                  >
                    اتصل بنا
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-black/5 bg-white py-10">
        <div className="mx-auto max-w-7xl px-4 text-center sm:px-6 lg:px-8">
          <div className="mb-6 flex items-center justify-center gap-2">
            <div className="size-7 rounded-[6px] bg-brand-primary grid place-items-center text-white">
              <span className="text-xs font-bold">ي</span>
            </div>
            <span className="font-semibold">الياسين للمنظفات</span>
          </div>
          <p className="text-sm text-brand-muted">
            العنوان: {SHOP_ADDRESS} — متاحون يومياً من ٩ صباحاً حتى ١٠ مساءً
          </p>
          <p className="mt-1 text-sm text-brand-muted">
            للطلب والتوصيل:{" "}
            <a href={`tel:+${SHOP_PHONE}`} className="font-medium text-brand-primary" dir="ltr">
              01145146164
            </a>
          </p>
          <p className="mt-4 text-xs text-neutral-400">
            جميع الأسعار خاضعة للتغيير بناءً على أسعار السوق
          </p>
          <Link to="/admin" className="mt-3 inline-block text-xs text-neutral-400 hover:text-brand-primary">
            لوحة تحكم المحل
          </Link>
        </div>
      </footer>

      {/* Floating cart summary */}
      {cartCount > 0 && (
        <div className="fixed inset-x-0 bottom-0 z-50 border-t border-black/5 bg-white/95 backdrop-blur-md px-4 py-3 shadow-lg">
          <div className="mx-auto flex max-w-7xl items-center justify-between gap-4">
            <div className="text-sm">
              <span className="text-brand-muted">إجمالي الطلب: </span>
              <span className="text-lg font-bold text-brand-primary">
                {formatPrice(cartTotal)} ج.م
              </span>
              <span className="mr-2 text-brand-muted">({cartCount} منتج)</span>
            </div>
            <a
              href={buildWhatsAppOrderLink(orderItems)}
              target="_blank"
              rel="noopener noreferrer"
              className="shrink-0 rounded-full bg-brand-primary px-6 py-2.5 text-sm font-bold text-white"
            >
              إتمام الطلب عبر واتساب
            </a>
          </div>
        </div>
      )}
    </div>
  );
}

function CategoryChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`shrink-0 rounded-full px-5 py-1.5 text-sm font-medium ring-1 transition-colors ${
        active
          ? "bg-brand-primary text-white ring-brand-primary"
          : "bg-white text-brand-muted ring-black/5 hover:bg-brand-primary/5 hover:text-brand-primary"
      }`}
    >
      {children}
    </button>
  );
}

function CartIcon() {
  return (
    <svg
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <circle cx="9" cy="21" r="1" />
      <circle cx="20" cy="21" r="1" />
      <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
    </svg>
  );
}

function SearchIcon() {
  return (
    <svg
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-brand-muted"
    >
      <circle cx="11" cy="11" r="8" />
      <path d="m21 21-4.3-4.3" />
    </svg>
  );
}

function PlusIcon() {
  return (
    <svg
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M12 5v14M5 12h14" />
    </svg>
  );
}

function MinusIcon() {
  return (
    <svg
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M5 12h14" />
    </svg>
  );
}
