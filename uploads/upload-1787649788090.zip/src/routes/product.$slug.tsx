import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  categoriesQuery,
  formatPrice,
  productImage,
  publicProductsQuery,
  stockClasses,
  stockLabel,
  stockState,
} from "@/lib/catalog";
import { SHOP_ADDRESS, SHOP_PHONE, buildWhatsAppSingleLink } from "@/lib/products";

export const Route = createFileRoute("/product/$slug")({
  head: () => ({
    meta: [
      { title: "تفاصيل المنتج | الياسين للمنظفات" },
      {
        name: "description",
        content:
          "تفاصيل المنتج والسعر وحالة التوافر والكمية المتاحة في محل الياسين للمنظفات.",
      },
      { property: "og:title", content: "تفاصيل المنتج | الياسين للمنظفات" },
      {
        property: "og:description",
        content: "السعر وحالة التوافر والكمية المتاحة — واطلب مباشرة عبر واتساب.",
      },
      { property: "og:type", content: "product" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProductPage,
});

function ProductPage() {
  const { slug } = Route.useParams();
  const { data: products, isLoading } = useQuery(publicProductsQuery);
  const { data: categories = [] } = useQuery(categoriesQuery);
  const product = products?.find((p) => p.slug === slug);

  return (
    <div dir="rtl" className="min-h-screen bg-brand-surface font-cairo text-brand-text">
      <header className="sticky top-0 z-40 bg-brand-surface/95 backdrop-blur-md ring-1 ring-black/5">
        <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-4">
          <Link to="/" className="flex items-center gap-2">
            <div className="grid size-8 place-items-center rounded-[8px] bg-brand-primary text-sm font-bold text-white">
              ي
            </div>
            <span className="font-semibold">الياسين للمنظفات</span>
          </Link>
          <Link to="/" className="text-sm text-brand-primary">
            ← رجوع للكتالوج
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-10">
        {isLoading ? (
          <p className="py-20 text-center text-brand-muted">جاري التحميل...</p>
        ) : !product ? (
          <div className="py-20 text-center">
            <h1 className="text-xl font-bold">المنتج غير متاح</h1>
            <Link to="/" className="mt-4 inline-block text-brand-primary">
              العودة للكتالوج
            </Link>
          </div>
        ) : (
          <div className="grid gap-8 md:grid-cols-2">
            <div className="overflow-hidden rounded-3xl bg-white p-4 ring-1 ring-black/5">
              <img
                src={productImage(product)}
                alt={product.name}
                className="aspect-square w-full rounded-2xl object-cover"
              />
            </div>

            <div>
              <span className="text-xs font-bold text-brand-primary">
                {categories.find((c) => c.id === product.category_id)?.label ??
                  product.category_id}
              </span>
              <h1 className="mt-2 text-2xl font-bold sm:text-3xl">{product.name}</h1>
              <p className="mt-3 text-brand-muted">{product.description}</p>

              <div className="mt-6 rounded-2xl bg-white p-5 ring-1 ring-black/5">
                <span className="text-xs text-brand-muted">السعر</span>
                <div className="text-3xl font-bold text-brand-primary">
                  {formatPrice(product.price)}{" "}
                  <span className="text-base">{product.unit}</span>
                </div>

                <div className="mt-4 flex items-center gap-3">
                  <span
                    className={`rounded px-2.5 py-1 text-xs font-bold ${stockClasses(product.quantity)}`}
                  >
                    {stockLabel(product.quantity)}
                  </span>
                  <span className="text-sm text-brand-muted">
                    الكمية المتاحة: <b>{product.quantity}</b>
                  </span>
                </div>

                <a
                  href={buildWhatsAppSingleLink(product.name, product.price)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`mt-5 block rounded-xl py-3 text-center text-sm font-bold text-white ${
                    stockState(product.quantity) === "out"
                      ? "pointer-events-none bg-neutral-300"
                      : "bg-brand-primary"
                  }`}
                >
                  {stockState(product.quantity) === "out"
                    ? "غير متوفر حالياً"
                    : "اطلب عبر واتساب"}
                </a>
              </div>

              <p className="mt-5 text-xs text-brand-muted">
                العنوان: {SHOP_ADDRESS} — للطلب:{" "}
                <a href={`tel:+${SHOP_PHONE}`} dir="ltr" className="text-brand-primary">
                  01145146164
                </a>
              </p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
