import {
  IdCard,
  Timer,
  Gauge,
  Tags,
  BarChart3,
  Network,
  Wifi,
  CheckCircle2,
  MessageCircle,
  PackagePlus,
  Printer,
  ShoppingCart,
  MonitorSmartphone,
} from "lucide-react";
import { site, t, type Lang } from "@/lib/i18n";
import cafeCardsImg from "@/assets/cafe-cards.jpg";
import logo from "@/assets/smartpoint-logo.png.asset.json";

const featureIcons = [IdCard, Timer, Gauge, Tags, BarChart3, Network];
const stepIcons = [PackagePlus, Printer, ShoppingCart, MonitorSmartphone];

function SectionTitle({ kicker, title }: { kicker: string; title: string }) {
  return (
    <div className="mx-auto max-w-2xl text-center">
      <p className="text-xs font-bold uppercase tracking-[0.25em] text-primary">{kicker}</p>
      <h2 className="mt-3 text-2xl font-extrabold sm:text-3xl md:text-4xl">{title}</h2>
    </div>
  );
}

export function CafeCardPage({ lang }: { lang: Lang }) {
  const d = t(lang).cafeCard;

  return (
    <main>
      {/* HERO */}
      <section className="relative overflow-hidden hero-surface">
        <div className="absolute inset-0 surface-grid" aria-hidden="true" />
        <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-4 py-16 lg:grid-cols-2 lg:px-8 lg:py-24">
          <div>
            <p className="inline-flex items-center gap-2 rounded-full border border-border bg-secondary/60 px-4 py-1.5 text-xs text-muted-foreground">
              <Wifi className="h-3.5 w-3.5 text-primary" />
              {d.badge}
            </p>
            <h1 className="mt-5 text-3xl font-extrabold leading-[1.3] sm:text-4xl md:text-5xl">
              {d.h1}
            </h1>
            <p className="mt-3 text-lg font-bold text-gradient">{d.sub}</p>
            <p className="mt-5 max-w-xl text-sm leading-8 text-muted-foreground sm:text-base">
              {d.lead}
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a
                href={site.whatsapp}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-primary-foreground shadow-[var(--shadow-glow)] transition-opacity hover:opacity-90"
              >
                <MessageCircle className="h-4 w-4" />
                {d.ctaPrimary}
              </a>
              <a
                href={site.whatsapp}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-lg border border-border px-6 py-3 text-sm font-bold text-foreground transition-colors hover:bg-secondary"
              >
                {d.ctaSecondary} <span dir="ltr">{site.phoneDisplay}</span>
              </a>
            </div>
          </div>
          <div className="relative">
            <img
              src={cafeCardsImg}
              alt={d.visualAlt}
              width={1024}
              height={1024}
              className="w-full rounded-2xl border border-border object-cover shadow-[var(--shadow-glow)]"
            />
            <img
              src={logo.url}
              alt=""
              aria-hidden="true"
              className="absolute bottom-4 end-4 h-10 w-auto rounded-lg bg-background/70 p-1.5 opacity-80 backdrop-blur-sm"
            />
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section className="mx-auto max-w-7xl px-4 py-16 lg:px-8 lg:py-24">
        <SectionTitle kicker={d.featuresKicker} title={d.featuresTitle} />
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {d.features.map((f, i) => {
            const Icon = featureIcons[i] ?? Wifi;
            return (
              <article key={f.t} className="card-premium rounded-2xl p-6">
                <span className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-secondary text-primary">
                  <Icon className="h-6 w-6" />
                </span>
                <h3 className="mt-5 text-lg font-bold">{f.t}</h3>
                <p className="mt-3 text-sm leading-7 text-muted-foreground">{f.d}</p>
              </article>
            );
          })}
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="border-y border-border/60 bg-surface-deep">
        <div className="mx-auto max-w-7xl px-4 py-16 lg:px-8 lg:py-24">
          <SectionTitle kicker={d.stepsKicker} title={d.stepsTitle} />
          <ol className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {d.steps.map((s, i) => {
              const Icon = stepIcons[i] ?? Wifi;
              return (
                <li key={s} className="card-premium relative rounded-2xl p-6">
                  <span className="absolute end-5 top-5 text-4xl font-extrabold text-primary/15">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-secondary text-primary">
                    <Icon className="h-6 w-6" />
                  </span>
                  <p className="mt-5 text-base font-bold leading-7">{s}</p>
                </li>
              );
            })}
          </ol>
        </div>
      </section>

      {/* BENEFITS */}
      <section className="mx-auto max-w-7xl px-4 py-16 lg:px-8 lg:py-24">
        <SectionTitle kicker="Smart Point" title={d.benefitsTitle} />
        <ul className="mx-auto mt-12 grid max-w-4xl gap-4 sm:grid-cols-2">
          {d.benefits.map((b) => (
            <li
              key={b}
              className="flex items-center gap-3 rounded-xl border border-border bg-card px-5 py-4 text-sm font-bold"
            >
              <CheckCircle2 className="h-5 w-5 shrink-0 text-primary" />
              {b}
            </li>
          ))}
        </ul>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 pb-16 lg:px-8 lg:pb-24">
        <div className="relative overflow-hidden rounded-3xl border border-border p-8 text-center hero-surface sm:p-14">
          <div className="absolute inset-0 surface-grid" aria-hidden="true" />
          <div className="relative">
            <h2 className="text-2xl font-extrabold sm:text-3xl md:text-4xl">{d.ctaTitle}</h2>
            <p className="mx-auto mt-4 max-w-2xl text-sm leading-8 text-muted-foreground sm:text-base">
              {d.ctaText}
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <a
                href={site.whatsapp}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-lg bg-primary px-7 py-3.5 text-sm font-bold text-primary-foreground shadow-[var(--shadow-glow)] transition-opacity hover:opacity-90"
              >
                <MessageCircle className="h-4 w-4" />
                {d.ctaPrimary}
              </a>
              <a
                href={site.whatsapp}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-lg border border-border px-7 py-3.5 text-sm font-bold text-foreground transition-colors hover:bg-secondary"
              >
                {d.ctaSecondary} <span dir="ltr">{site.phoneDisplay}</span>
              </a>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
