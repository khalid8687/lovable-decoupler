import { Link } from "@tanstack/react-router";
import { MapPin, Globe, MessageCircle, Truck, Headset } from "lucide-react";
import logo from "@/assets/smartpoint-logo.png.asset.json";
import { site, t, type Lang } from "@/lib/i18n";

export function Footer({ lang }: { lang: Lang }) {
  const d = t(lang);

  return (
    <footer className="border-t border-border/60 bg-surface-deep">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 lg:grid-cols-3 lg:px-8">
        <div>
          <div className="flex items-center gap-3">
            <img
              src={logo.url}
              alt={d.footer.logoAlt}
              width={64}
              height={64}
              loading="lazy"
              className="h-14 w-14 rounded-lg object-cover"
            />
            <div>
              <p className="text-lg font-extrabold">
                SMART <span className="text-primary">POINT</span>
              </p>
              <p className="text-xs text-muted-foreground">{site.tagline}</p>
            </div>
          </div>
          <p className="mt-4 max-w-sm text-sm leading-7 text-muted-foreground">{d.footer.about}</p>
        </div>

        <nav aria-label={d.footer.linksNav}>
          <h2 className="text-sm font-bold text-foreground">{d.footer.quickLinks}</h2>
          <ul className="mt-4 grid grid-cols-2 gap-2 text-sm text-muted-foreground">
            {d.nav.map((item) => (
              <li key={item.slug || "home"}>
                {item.slug ? (
                  <Link
                    to="/$lang/$slug"
                    params={{ lang, slug: item.slug }}
                    className="transition-colors hover:text-primary"
                  >
                    {item.label}
                  </Link>
                ) : (
                  <Link
                    to="/$lang"
                    params={{ lang }}
                    className="transition-colors hover:text-primary"
                  >
                    {item.label}
                  </Link>
                )}
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <h2 className="text-sm font-bold text-foreground">{d.footer.contact}</h2>
          <ul className="mt-4 space-y-3 text-sm text-muted-foreground">
            <li className="flex items-center gap-2">
              <Globe className="h-4 w-4 shrink-0 text-primary" />
              <span dir="ltr">{site.domain}</span>
            </li>
            <li>
              <a
                href={site.whatsapp}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 transition-colors hover:text-primary"
              >
                <MessageCircle className="h-4 w-4 shrink-0 text-primary" />
                <span>
                  {d.footer.whatsappLabel}: <span dir="ltr">{site.phoneDisplay}</span>
                </span>
              </a>
            </li>
            <li className="flex items-center gap-2">
              <MapPin className="h-4 w-4 shrink-0 text-primary" />
              {d.city}
            </li>
            <li className="flex items-center gap-2">
              <Truck className="h-4 w-4 shrink-0 text-primary" />
              {d.footer.shipping}
            </li>
            <li className="flex items-center gap-2">
              <Headset className="h-4 w-4 shrink-0 text-primary" />
              {d.footer.support}
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-border/60 py-5 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Smart Point — Technology &amp; Business Solutions
      </div>
    </footer>
  );
}
