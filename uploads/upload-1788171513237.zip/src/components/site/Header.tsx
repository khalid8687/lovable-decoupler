import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { Menu, X, MessageCircle, User as UserIcon, LogOut, Inbox, LifeBuoy } from "lucide-react";
import logo from "@/assets/smartpoint-logo.png.asset.json";
import { supabase } from "@/integrations/supabase/client";
import { displayName, useAuth, useProfile } from "@/hooks/useAuth";
import { authT } from "@/lib/auth-i18n";
import { altLang, site, t, type Lang } from "@/lib/i18n";

function AccountArea({ lang, onNavigate }: { lang: Lang; onNavigate?: () => void }) {
  const d = authT(lang);
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const { profile } = useProfile(user?.id);
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);

  if (loading) return null;

  if (!user) {
    return (
      <Link
        to="/$lang/login"
        params={{ lang }}
        onClick={onNavigate}
        className="inline-flex items-center gap-2 rounded-lg border border-border px-3 py-2 text-sm font-bold text-foreground transition-colors hover:bg-secondary"
      >
        <UserIcon className="h-4 w-4" />
        <span className="hidden sm:inline">{d.signIn}</span>
      </Link>
    );
  }

  const name = displayName(profile, user);
  const avatar =
    profile?.avatar_url ??
    ((user.user_metadata as { avatar_url?: string } | undefined)?.avatar_url ?? null);

  const item =
    "flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground";

  async function signOut() {
    setOpen(false);
    onNavigate?.();
    await supabase.auth.signOut();
    navigate({ to: "/$lang", params: { lang }, replace: true });
  }

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-label={d.accountMenu}
        aria-expanded={open}
        className="inline-flex max-w-[180px] items-center gap-2 rounded-lg border border-border px-2 py-1.5 text-sm font-bold transition-colors hover:bg-secondary"
      >
        {avatar ? (
          <img
            src={avatar}
            alt=""
            width={28}
            height={28}
            referrerPolicy="no-referrer"
            className="h-7 w-7 rounded-full object-cover"
          />
        ) : (
          <span className="flex h-7 w-7 items-center justify-center rounded-full bg-secondary">
            <UserIcon className="h-4 w-4" />
          </span>
        )}
        <span className="hidden truncate sm:inline">{name}</span>
      </button>

      {open && (
        <div className="absolute end-0 z-50 mt-2 w-56 rounded-xl border border-border bg-card p-1.5 shadow-xl">
          <Link
            to="/$lang/account"
            params={{ lang }}
            onClick={() => {
              setOpen(false);
              onNavigate?.();
            }}
            className={item}
          >
            <UserIcon className="h-4 w-4" />
            {d.myAccount}
          </Link>
          <Link
            to="/$lang/account"
            params={{ lang }}
            hash="requests"
            onClick={() => {
              setOpen(false);
              onNavigate?.();
            }}
            className={item}
          >
            <Inbox className="h-4 w-4" />
            {d.myRequests}
          </Link>
          <a href={site.whatsapp} target="_blank" rel="noopener noreferrer" className={item}>
            <LifeBuoy className="h-4 w-4" />
            {d.support}
          </a>
          <button type="button" onClick={signOut} className={item}>
            <LogOut className="h-4 w-4" />
            {d.logout}
          </button>
        </div>
      )}
    </div>
  );
}

function LangSwitcher({ lang, className = "" }: { lang: Lang; className?: string }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const rest = pathname.replace(/^\/(ar|en)/, "");
  const other = altLang(lang);
  const copy = t(lang).cta.switchLang;

  return (
    <div
      aria-label={copy}
      className={`inline-flex items-center overflow-hidden rounded-lg border border-border text-xs font-bold ${className}`}
      dir="ltr"
    >
      <span className="bg-primary px-2.5 py-1.5 uppercase text-primary-foreground">{lang}</span>
      <a
        href={`/${other}${rest}`}
        hrefLang={other}
        className="px-2.5 py-1.5 uppercase text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
      >
        {other}
      </a>
    </div>
  );
}

export function Header({ lang }: { lang: Lang }) {
  const [open, setOpen] = useState(false);
  const d = t(lang);

  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-background/80 backdrop-blur-xl">
      <div className="mx-auto grid max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-4 py-3 lg:px-8">
        <Link to="/$lang" params={{ lang }} className="flex min-w-0 items-center gap-3">
          <img
            src={logo.url}
            alt={d.footer.logoAlt}
            width={56}
            height={56}
            className="h-12 w-12 shrink-0 rounded-lg object-cover sm:h-14 sm:w-14"
          />
          <span className="min-w-0">
            <span className="block truncate text-base font-extrabold tracking-tight sm:text-lg">
              SMART <span className="text-primary">POINT</span>
            </span>
            <span className="block truncate text-[11px] text-muted-foreground">{site.tagline}</span>
          </span>
        </Link>

        <div className="flex items-center gap-2">
          <nav aria-label={d.cta.mainNav} className="hidden xl:block">
            <ul className="flex items-center gap-1">
              {d.nav.map((item) =>
                item.slug ? (
                  <li key={item.slug}>
                    <Link
                      to="/$lang/$slug"
                      params={{ lang, slug: item.slug }}
                      className="rounded-md px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                      activeProps={{ className: "bg-secondary text-foreground" }}
                    >
                      {item.label}
                    </Link>
                  </li>
                ) : (
                  <li key="home">
                    <Link
                      to="/$lang"
                      params={{ lang }}
                      activeOptions={{ exact: true }}
                      className="rounded-md px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                      activeProps={{ className: "bg-secondary text-foreground" }}
                    >
                      {item.label}
                    </Link>
                  </li>
                ),
              )}
            </ul>
          </nav>

          <LangSwitcher lang={lang} />

          <AccountArea lang={lang} />


          <Link
            to="/$lang/$slug"
            params={{ lang, slug: "contact" }}
            className="hidden rounded-lg bg-primary px-4 py-2 text-sm font-bold text-primary-foreground shadow-[var(--shadow-glow)] transition-opacity hover:opacity-90 sm:inline-flex"
          >
            {d.cta.contact}
          </Link>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-label={open ? d.cta.menuClose : d.cta.menuOpen}
            aria-expanded={open}
            className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-border text-foreground xl:hidden"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {open && (
        <nav aria-label={d.cta.mobileNav} className="border-t border-border/60 xl:hidden">
          <ul className="mx-auto grid max-w-7xl gap-1 px-4 py-3">
            {d.nav.map((item) => (
              <li key={item.slug || "home"}>
                {item.slug ? (
                  <Link
                    to="/$lang/$slug"
                    params={{ lang, slug: item.slug }}
                    onClick={() => setOpen(false)}
                    className="block rounded-md px-3 py-2 text-sm text-muted-foreground hover:bg-secondary hover:text-foreground"
                  >
                    {item.label}
                  </Link>
                ) : (
                  <Link
                    to="/$lang"
                    params={{ lang }}
                    onClick={() => setOpen(false)}
                    className="block rounded-md px-3 py-2 text-sm text-muted-foreground hover:bg-secondary hover:text-foreground"
                  >
                    {item.label}
                  </Link>
                )}
              </li>
            ))}
            <li className="mt-2">
              <AccountArea lang={lang} onNavigate={() => setOpen(false)} />
            </li>
            <li className="mt-2">
              <a
                href={site.whatsapp}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground"
              >
                <MessageCircle className="h-4 w-4" />
                {d.footer.whatsappLabel} <span dir="ltr">{site.phoneDisplay}</span>
              </a>
            </li>
          </ul>
        </nav>
      )}
    </header>
  );
}
