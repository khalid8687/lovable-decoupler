import type { Lang } from "./i18n";

export type AuthDict = {
  signIn: string;
  signInMeta: { title: string; description: string };
  accountMeta: { title: string; description: string };
  welcome: string;
  welcomeSub: string;
  continueGoogle: string;
  signingIn: string;
  signInError: string;
  legal: string;
  account: string;
  myAccount: string;
  myRequests: string;
  support: string;
  logout: string;
  accountMenu: string;
  profile: string;
  email: string;
  phone: string;
  phonePlaceholder: string;
  noPhone: string;
  language: string;
  memberSince: string;
  editProfile: string;
  fullName: string;
  save: string;
  saving: string;
  cancel: string;
  saved: string;
  saveError: string;
  requestsTitle: string;
  noRequests: string;
  noRequestsHint: string;
  supportTitle: string;
  supportText: string;
  loading: string;
};

const ar: AuthDict = {
  signIn: "تسجيل الدخول",
  signInMeta: {
    title: "تسجيل الدخول | سمارت بوينت",
    description: "سجّل الدخول إلى حسابك في سمارت بوينت باستخدام حساب Google للوصول إلى خدماتك وطلباتك.",
  },
  accountMeta: {
    title: "حسابي | سمارت بوينت",
    description: "لوحة حساب العميل في سمارت بوينت: بياناتك، طلباتك والدعم الفني.",
  },
  welcome: "مرحباً بك في Smart Point",
  welcomeSub: "سجّل الدخول للوصول إلى حسابك وخدماتك",
  continueGoogle: "المتابعة باستخدام Google",
  signingIn: "جارٍ تسجيل الدخول…",
  signInError: "تعذّر تسجيل الدخول، برجاء المحاولة مرة أخرى.",
  legal: "لن نطلب منك إنشاء كلمة مرور عند استخدام حساب Google.",
  account: "الحساب",
  myAccount: "حسابي",
  myRequests: "طلباتي",
  support: "الدعم الفني",
  logout: "تسجيل الخروج",
  accountMenu: "قائمة الحساب",
  profile: "بيانات الحساب",
  email: "البريد الإلكتروني",
  phone: "رقم الهاتف",
  phonePlaceholder: "01xxxxxxxxx",
  noPhone: "لم تتم الإضافة بعد",
  language: "اللغة المفضلة",
  memberSince: "تاريخ إنشاء الحساب",
  editProfile: "تعديل البيانات",
  fullName: "الاسم بالكامل",
  save: "حفظ",
  saving: "جارٍ الحفظ…",
  cancel: "إلغاء",
  saved: "تم حفظ البيانات",
  saveError: "تعذّر حفظ البيانات",
  requestsTitle: "طلباتي",
  noRequests: "لا توجد طلبات حالياً",
  noRequestsHint: "كلمنا على واتساب لبدء أول طلب أو استفسار.",
  supportTitle: "الدعم الفني",
  supportText: "فريق سمارت بوينت متاح لدعمك عن بُعد في أي وقت.",
  loading: "جارٍ التحميل…",
};

const en: AuthDict = {
  signIn: "Sign In",
  signInMeta: {
    title: "Sign In | Smart Point",
    description: "Sign in to your Smart Point account with Google to access your services and requests.",
  },
  accountMeta: {
    title: "My Account | Smart Point",
    description: "Smart Point customer account: your details, requests and technical support.",
  },
  welcome: "Welcome to Smart Point",
  welcomeSub: "Sign in to access your account and services",
  continueGoogle: "Continue with Google",
  signingIn: "Signing in…",
  signInError: "Sign in failed. Please try again.",
  legal: "No separate password is required when using your Google account.",
  account: "Account",
  myAccount: "My Account",
  myRequests: "My Requests",
  support: "Support",
  logout: "Logout",
  accountMenu: "Account menu",
  profile: "Profile details",
  email: "Email",
  phone: "Phone number",
  phonePlaceholder: "01xxxxxxxxx",
  noPhone: "Not added yet",
  language: "Preferred language",
  memberSince: "Account created",
  editProfile: "Edit profile",
  fullName: "Full name",
  save: "Save",
  saving: "Saving…",
  cancel: "Cancel",
  saved: "Profile updated",
  saveError: "Could not save your profile",
  requestsTitle: "My Requests",
  noRequests: "No requests yet",
  noRequestsHint: "Message us on WhatsApp to start your first request.",
  supportTitle: "Support",
  supportText: "The Smart Point team is available for remote support at any time.",
  loading: "Loading…",
};

export const authT = (lang: Lang): AuthDict => (lang === "en" ? en : ar);
