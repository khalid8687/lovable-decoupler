export const LANGS = ["ar", "en"] as const;
export type Lang = (typeof LANGS)[number];

export const isLang = (v: unknown): v is Lang =>
  typeof v === "string" && (LANGS as readonly string[]).includes(v);

export const dirOf = (lang: Lang) => (lang === "ar" ? "rtl" : "ltr");

/** Page slugs shared by both languages (SEO-friendly, identical across locales). */
export const pageSlugs = [
  "pos-systems",
  "accounting-inventory",
  "restaurants-cafes",
  "cafe-card-systems",
  "computers-laptops",
  "cctv-security",
  "about",
  "contact",
] as const;
export type PageSlug = (typeof pageSlugs)[number];

export const site = {
  name: "Smart Point",
  nameAr: "سمارت بوينت",
  tagline: "Technology & Business Solutions",
  domain: "smartpoint-eg.com",
  phoneDisplay: "01005459464",
  whatsapp: "https://wa.me/201005459464",
} as const;

type Nav = { slug: PageSlug | ""; label: string }[];

type PageContent = {
  title: string;
  metaTitle: string;
  metaDescription: string;
  intro: string;
  points: { t: string; d: string }[];
};

type Dict = {
  htmlLang: string;
  langLabel: string;
  city: string;
  nav: Nav;
  cta: {
    whatsapp: string;
    contact: string;
    explore: string;
    learnMore: string;
    menuOpen: string;
    menuClose: string;
    mainNav: string;
    mobileNav: string;
    switchLang: string;
  };
  home: {
    metaTitle: string;
    metaDescription: string;
    badge: string;
    h1a: string;
    h1b: string;
    lead: string;
    heroAlt: string;
    servicesKicker: string;
    servicesTitle: string;
    servicesText: string;
    services: { t: string; d: string; slug: PageSlug }[];
    softwareKicker: string;
    softwareTitle: string;
    softwareText: string;
    dashboardAlt: string;
    restaurantsKicker: string;
    restaurantsTitle: string;
    restaurantsText: string;
    restaurants: { t: string; d: string }[];
    hardwareKicker: string;
    hardwareTitle: string;
    hardwareText: string;
    hardware: { t: string; d: string }[];
    cctvKicker: string;
    cctvTitle: string;
    cctvText: string;
    cctvAlt: string;
    cctvPoints: string[];
    whyKicker: string;
    whyTitle: string;
    why: { t: string; d: string }[];
    ctaTitle: string;
    ctaText: string;
  };
  footer: {
    about: string;
    quickLinks: string;
    contact: string;
    shipping: string;
    support: string;
    whatsappLabel: string;
    linksNav: string;
    logoAlt: string;
  };
  pages: Record<PageSlug, PageContent>;
  cafeCard: {
    metaTitle: string;
    metaDescription: string;
    badge: string;
    h1: string;
    sub: string;
    lead: string;
    visualAlt: string;
    featuresKicker: string;
    featuresTitle: string;
    features: { t: string; d: string }[];
    stepsKicker: string;
    stepsTitle: string;
    steps: string[];
    benefitsTitle: string;
    benefits: string[];
    ctaTitle: string;
    ctaText: string;
    ctaPrimary: string;
    ctaSecondary: string;
  };
};

const ar: Dict = {
  htmlLang: "ar",
  langLabel: "العربية",
  city: "الجيزة، مصر",
  nav: [
    { slug: "", label: "الرئيسية" },
    { slug: "pos-systems", label: "أنظمة POS" },
    { slug: "accounting-inventory", label: "الحسابات والمخازن" },
    { slug: "restaurants-cafes", label: "المطاعم والكافيهات" },
    { slug: "cafe-card-systems", label: "كروت الكافيهات" },
    { slug: "computers-laptops", label: "الكمبيوتر واللابتوب" },
    { slug: "cctv-security", label: "كاميرات المراقبة" },
    { slug: "about", label: "من نحن" },
    { slug: "contact", label: "تواصل معنا" },
  ],
  cta: {
    whatsapp: "تواصل معنا على واتساب",
    contact: "تواصل معنا",
    explore: "اكتشف حلولنا",
    learnMore: "اعرف المزيد",
    menuOpen: "فتح القائمة",
    menuClose: "إغلاق القائمة",
    mainNav: "التنقل الرئيسي",
    mobileNav: "التنقل للجوال",
    switchLang: "تغيير اللغة",
  },
  home: {
    metaTitle: "سمارت بوينت | برامج كاشير وأنظمة POS وحسابات ومخازن في مصر",
    metaDescription:
      "سمارت بوينت للحلول التقنية: برنامج كاشير للمحلات والمطاعم، برامج حسابات ومخازن، أنظمة POS، سيستم كروت الكافيهات، أجهزة كمبيوتر ولابتوب وكاميرات مراقبة. شحن لكل مصر ودعم فني عن بُعد.",
    badge: "Smart Solutions for Your Business",
    h1a: "كل حلول أعمالك في",
    h1b: "مكان واحد",
    lead: "سمارت بوينت تقدم حلولاً تقنية متكاملة للأنشطة التجارية في مصر: برامج كاشير وأنظمة POS، برامج حسابات ومخازن، أنظمة إدارة المطاعم والكافيهات وكروت الكافيهات، إلى جانب أجهزة الكمبيوتر واللابتوب وكاميرات المراقبة والحلول الأمنية.",
    heroAlt: "شبكة رقمية تعبر عن الحلول التقنية المتكاملة من سمارت بوينت",
    servicesKicker: "خدماتنا",
    servicesTitle: "حلول تقنية لكل نشاط تجاري",
    servicesText: "اختر الحل المناسب لنشاطك، وسنساعدك في التركيب والتشغيل والتدريب.",
    services: [
      {
        t: "برامج الكاشير وأنظمة POS",
        d: "برنامج كاشير للمحلات والسوبر ماركت مع فواتير سريعة، باركود، وتقارير مبيعات لحظية.",
        slug: "pos-systems",
      },
      {
        t: "برامج الحسابات والمخازن",
        d: "برنامج حسابات ومخازن متكامل: الموردين والعملاء، الأرصدة، الجرد وتقارير الأرباح.",
        slug: "accounting-inventory",
      },
      {
        t: "أنظمة إدارة المطاعم والكافيهات",
        d: "إدارة الطلبات، الصالة والتيك أواي والدليفري، شاشة المطبخ وتكلفة الأصناف.",
        slug: "restaurants-cafes",
      },
      {
        t: "سيستم كروت الكافيهات",
        d: "كروت الكافيهات لحساب وقت الجلسة والخدمات وربطها مباشرة بالكاشير.",
        slug: "cafe-card-systems",
      },
      {
        t: "أجهزة الكمبيوتر واللابتوب",
        d: "أجهزة وشاشات ولابتوبات ومستلزمات مناسبة للأعمال المكتبية ونقاط البيع.",
        slug: "computers-laptops",
      },
      {
        t: "كاميرات المراقبة والحلول الأمنية",
        d: "توريد وتركيب كاميرات مراقبة عالية الدقة مع متابعة عن بُعد من الموبايل.",
        slug: "cctv-security",
      },
    ],
    softwareKicker: "Business Software",
    softwareTitle: "برامج إدارة الأعمال: كاشير، حسابات، مخازن",
    softwareText:
      "نظام واحد يربط المبيعات بالمخزون والحسابات، ويعطيك تقارير واضحة عن الأرباح وحركة الأصناف، مع صلاحيات للمستخدمين وفروع متعددة.",
    dashboardAlt: "واجهة لوحة تحكم برنامج المبيعات والمخازن من سمارت بوينت",
    restaurantsKicker: "Restaurants & Cafes",
    restaurantsTitle: "أنظمة المطاعم والكافيهات وكروت الكافيهات",
    restaurantsText:
      "إدارة كاملة للطلبات والتوصيل والمطبخ، مع سيستم كروت لحساب وقت الجلسات في الكافيهات.",
    restaurants: [
      { t: "إدارة الطلبات", d: "صالة، تيك أواي ودليفري في شاشة واحدة." },
      { t: "شاشة المطبخ", d: "متابعة تحضير الأصناف وتقليل وقت الانتظار." },
      { t: "كروت الكافيهات", d: "احتساب الوقت والخدمات تلقائيًا على الفاتورة." },
    ],
    hardwareKicker: "Hardware",
    hardwareTitle: "أجهزة POS وكمبيوتر ولابتوب وشاشات",
    hardwareText: "أجهزة مختارة تناسب بيئة العمل اليومية، مع شحن لجميع محافظات مصر.",
    hardware: [
      { t: "أجهزة POS", d: "كاشير متكامل، طابعات فواتير، درج نقدية وقارئ باركود." },
      { t: "أجهزة كمبيوتر", d: "تجميعات مكتبية للأعمال والمحاسبة بأداء ثابت." },
      { t: "لابتوب", d: "لابتوبات للأعمال والمهام اليومية بمواصفات مختلفة." },
      { t: "شاشات كمبيوتر", d: "شاشات بمقاسات متعددة للمكاتب ونقاط البيع." },
      { t: "الإكسسوارات", d: "لوحات مفاتيح، ماوس، كابلات ومستلزمات التشغيل." },
    ],
    cctvKicker: "CCTV & Security",
    cctvTitle: "كاميرات مراقبة وحلول أمنية للمنشآت",
    cctvText:
      "نقوم بتوريد وتركيب أنظمة المراقبة للمحلات والمطاعم والمخازن والشركات، مع اختيار الكاميرات وأجهزة التسجيل المناسبة لمساحة المكان.",
    cctvAlt: "كاميرا مراقبة احترافية مثبتة داخل منشأة تجارية",
    cctvPoints: [
      "كاميرات داخلية وخارجية بدقة عالية",
      "أجهزة تسجيل وتخزين حسب مدة الأرشفة المطلوبة",
      "متابعة مباشرة من الموبايل عن بُعد",
    ],
    whyKicker: "لماذا سمارت بوينت",
    whyTitle: "شريك تقني تعتمد عليه في تشغيل نشاطك",
    why: [
      { t: "حلول متكاملة", d: "برامج وأجهزة وتركيب من مصدر واحد." },
      { t: "دعم فني عن بُعد", d: "حل المشكلات بسرعة دون انتظار زيارة." },
      { t: "شحن لكل المحافظات", d: "توصيل الأجهزة لجميع محافظات مصر." },
      { t: "دعم ما بعد البيع", d: "متابعة مستمرة وتدريب على استخدام النظام." },
      { t: "تناسب كل الأنشطة", d: "من المحل الصغير حتى الشركات والمخازن." },
      { t: "برامج وأجهزة معًا", d: "توافق كامل بين السوفتوير والهاردوير." },
    ],
    ctaTitle: "مش عارف أنهي سيستم مناسب لنشاطك؟",
    ctaText:
      "كلمنا وقولنا نوع نشاطك وحجمه، وهنرشحلك البرنامج والأجهزة المناسبة بأفضل تكلفة، مع التركيب والتدريب والدعم الفني.",
  },
  footer: {
    about:
      "برامج كاشير وحسابات ومخازن، أنظمة إدارة المطاعم والكافيهات، أجهزة كمبيوتر ولابتوب، وكاميرات مراقبة — من مكان واحد.",
    quickLinks: "روابط سريعة",
    contact: "تواصل معنا",
    shipping: "شحن لجميع محافظات مصر",
    support: "دعم فني عن بُعد",
    whatsappLabel: "واتساب",
    linksNav: "روابط الموقع",
    logoAlt: "شعار Smart Point",
  },
  pages: {
    "pos-systems": {
      title: "أنظمة POS وبرامج الكاشير",
      metaTitle: "أنظمة POS وبرامج الكاشير للمحلات والسوبر ماركت | سمارت بوينت",
      metaDescription:
        "برنامج كاشير وأنظمة POS للمحلات والسوبر ماركت في مصر: فواتير سريعة، باركود، عروض وخصومات، وتقارير مبيعات لحظية مع تركيب وتدريب ودعم فني.",
      intro:
        "نظام نقاط بيع سريع وسهل يناسب المحلات والسوبر ماركت والمتاجر متعددة الفروع، مربوط مباشرة بالمخزون والحسابات.",
      points: [
        { t: "فواتير سريعة", d: "شاشة بيع بسيطة تختصر وقت الطابور وتقلل الأخطاء." },
        { t: "باركود ووحدات", d: "دعم الباركود والوحدات المختلفة وأسعار الجملة والقطاعي." },
        { t: "الورديات والصلاحيات", d: "تقفيل وردية لكل كاشير مع صلاحيات محددة لكل مستخدم." },
        { t: "تقارير لحظية", d: "متابعة المبيعات والأرباح وأكثر الأصناف حركة أولًا بأول." },
        { t: "فروع متعددة", d: "إدارة أكثر من فرع ومخزن من نظام واحد." },
        { t: "أجهزة متوافقة", d: "طابعات فواتير، درج نقدية، قارئ باركود وشاشات لمس." },
      ],
    },
    "accounting-inventory": {
      title: "برامج الحسابات والمخازن",
      metaTitle: "برنامج حسابات ومخازن للشركات والمحلات في مصر | سمارت بوينت",
      metaDescription:
        "برنامج حسابات ومخازن متكامل: العملاء والموردين، الأرصدة، الجرد، أذون الصرف والإضافة وتقارير الأرباح والخسائر، مع دعم فني عن بُعد.",
      intro:
        "نظام محاسبي عملي يربط المخزون بالمبيعات والمشتريات ويعطيك صورة واضحة عن أرباحك وأرصدتك في أي وقت.",
      points: [
        { t: "العملاء والموردين", d: "كشوف حساب وأرصدة ومتابعة التحصيل والمديونيات." },
        { t: "إدارة المخازن", d: "أذون إضافة وصرف وتحويل بين المخازن مع حد الطلب." },
        { t: "الجرد", d: "جرد دوري ومفاجئ مع تسوية الفروق تلقائيًا." },
        { t: "المشتريات", d: "أوامر شراء وفواتير موردين ومرتجعات." },
        { t: "التقارير المالية", d: "أرباح وخسائر، مصروفات، وحركة الخزينة والبنوك." },
        { t: "صلاحيات آمنة", d: "تحديد ما يراه كل مستخدم وحماية بيانات الحسابات." },
      ],
    },
    "restaurants-cafes": {
      title: "أنظمة إدارة المطاعم والكافيهات",
      metaTitle: "نظام إدارة مطاعم وكافيهات: طلبات ودليفري وشاشة مطبخ | سمارت بوينت",
      metaDescription:
        "نظام مطاعم وكافيهات في مصر: إدارة طلبات الصالة والتيك أواي والدليفري، شاشة مطبخ، تسعير الأصناف وتكلفة المكونات وتقارير مبيعات دقيقة.",
      intro:
        "نظام تشغيل كامل للمطاعم والكافيهات يبدأ من استلام الطلب حتى تسليمه، مع تحكم دقيق في التكلفة.",
      points: [
        { t: "طلبات الصالة", d: "خريطة طاولات، تقسيم الفواتير ونقل الطلبات بين الطاولات." },
        { t: "تيك أواي ودليفري", d: "بيانات العملاء والعناوين ومتابعة الطيارين." },
        { t: "شاشة المطبخ", d: "إرسال الطلبات مباشرة للمطبخ وتقليل وقت الانتظار." },
        { t: "تكلفة الأصناف", d: "ربط المكونات بالمخزون لحساب تكلفة كل صنف بدقة." },
        { t: "العروض والخصومات", d: "وجبات وعروض ومكونات إضافية بأسعار مرنة." },
        { t: "تقارير التشغيل", d: "أكثر الأصناف مبيعًا، أوقات الذروة وأداء الفروع." },
      ],
    },
    "cafe-card-systems": {
      title: "سيستم كروت الكافيهات",
      metaTitle: "سيستم كروت الكافيهات: إنترنت بكارت مش باسورد | سمارت بوينت",
      metaDescription:
        "نظام Smart Point Cafe Card لإدارة إنترنت الكافيهات بكروت مدفوعة مسبقًا: تحكم في الوقت والسرعة والأسعار والمستخدمين وتقارير الاستخدام والمبيعات، وشحن لكل مصر.",
      intro:
        "حل مخصص للكافيهات التي تحاسب بالوقت: كارت لكل عميل أو طاولة، والحساب يتم تلقائيًا عند الخروج.",
      points: [
        { t: "حساب الوقت تلقائيًا", d: "بداية ونهاية الجلسة باحتساب دقيق للتعريفة." },
        { t: "خدمات على الكارت", d: "إضافة المشروبات والوجبات إلى نفس الكارت." },
        { t: "ربط بالكاشير", d: "الفاتورة النهائية تظهر في نظام الكاشير مباشرة." },
        { t: "تعريفات مرنة", d: "أسعار مختلفة حسب الوقت أو نوع الجلسة أو العروض." },
        { t: "منع التلاعب", d: "صلاحيات وتسجيل لكل عملية فتح أو إغلاق كارت." },
        { t: "تقارير الجلسات", d: "متوسط مدة الجلسة والإيراد لكل طاولة ولكل وردية." },
      ],
    },
    "computers-laptops": {
      title: "أجهزة الكمبيوتر واللابتوب",
      metaTitle: "بيع أجهزة كمبيوتر ولابتوب وشاشات وأجهزة POS في مصر | سمارت بوينت",
      metaDescription:
        "توريد أجهزة كمبيوتر ولابتوب وشاشات وأجهزة POS وطابعات فواتير وقارئ باركود ومستلزمات التشغيل، مع شحن لجميع محافظات مصر.",
      intro:
        "نوفر الأجهزة المناسبة لبيئة العمل اليومية ونضمن توافقها الكامل مع البرامج التي نركبها.",
      points: [
        { t: "أجهزة POS", d: "كاشير متكامل، طابعات فواتير، درج نقدية وقارئ باركود." },
        { t: "أجهزة كمبيوتر", d: "تجميعات مكتبية للأعمال والمحاسبة بأداء ثابت." },
        { t: "لابتوب", d: "لابتوبات للأعمال والمهام اليومية بمواصفات مختلفة." },
        { t: "شاشات", d: "شاشات بمقاسات متعددة للمكاتب ونقاط البيع." },
        { t: "الإكسسوارات", d: "لوحات مفاتيح، ماوس، كابلات ومستلزمات التشغيل." },
        { t: "شحن وتركيب", d: "توصيل لجميع المحافظات وتجهيز الأجهزة قبل التسليم." },
      ],
    },
    "cctv-security": {
      title: "كاميرات المراقبة والحلول الأمنية",
      metaTitle: "تركيب كاميرات مراقبة للمحلات والشركات في مصر | سمارت بوينت",
      metaDescription:
        "توريد وتركيب كاميرات مراقبة داخلية وخارجية عالية الدقة، أجهزة تسجيل وتخزين، ومتابعة مباشرة من الموبايل للمحلات والمطاعم والمخازن والشركات.",
      intro:
        "نصمم نظام المراقبة حسب مساحة المكان وعدد النقاط المطلوبة، وننفذه بالكامل مع الصيانة والمتابعة.",
      points: [
        { t: "كاميرات عالية الدقة", d: "كاميرات داخلية وخارجية بجودة صورة واضحة ليلًا ونهارًا." },
        { t: "أجهزة تسجيل", d: "اختيار سعة التخزين حسب مدة الأرشفة المطلوبة." },
        { t: "متابعة عن بُعد", d: "مشاهدة مباشرة من الموبايل في أي وقت." },
        { t: "تركيب احترافي", d: "توزيع النقاط وتمديد الكابلات بشكل منظم وآمن." },
        { t: "أنظمة للمنشآت", d: "حلول للمحلات والمطاعم والمخازن والشركات." },
        { t: "صيانة ودعم", d: "متابعة دورية وحل الأعطال بسرعة." },
      ],
    },
    about: {
      title: "من نحن",
      metaTitle: "من نحن | سمارت بوينت للحلول التقنية في مصر",
      metaDescription:
        "سمارت بوينت شركة حلول تقنية في الجيزة، مصر: برامج كاشير وحسابات ومخازن، أنظمة مطاعم وكافيهات، أجهزة وكاميرات مراقبة، مع شحن لكل مصر ودعم فني عن بُعد.",
      intro:
        "سمارت بوينت شركة مصرية متخصصة في الحلول التقنية للأنشطة التجارية: نوفر البرامج والأجهزة والتركيب والدعم من مصدر واحد.",
      points: [
        { t: "حلول متكاملة", d: "برامج وأجهزة وتركيب وتدريب من جهة واحدة." },
        { t: "خبرة بالسوق المصري", d: "أنظمة مضبوطة على طريقة تشغيل المحلات والمطاعم في مصر." },
        { t: "دعم فني عن بُعد", d: "حل المشكلات بسرعة دون انتظار زيارة ميدانية." },
        { t: "شحن لكل مصر", d: "توصيل الأجهزة لجميع المحافظات." },
        { t: "دعم ما بعد البيع", d: "متابعة مستمرة وتدريب على استخدام النظام." },
        { t: "مقرنا", d: "الجيزة، مصر — ونخدم عملاء في جميع أنحاء الجمهورية." },
      ],
    },
    contact: {
      title: "تواصل معنا",
      metaTitle: "تواصل مع سمارت بوينت | واتساب 01005459464",
      metaDescription:
        "تواصل مع سمارت بوينت للحلول التقنية عبر واتساب 01005459464 للاستفسار عن برامج الكاشير وأنظمة POS والحسابات والمخازن والأجهزة وكاميرات المراقبة.",
      intro: "كلمنا وقولنا نوع نشاطك وحجمه، وهنرشحلك البرنامج والأجهزة المناسبة بأفضل تكلفة.",
      points: [
        { t: "واتساب", d: "01005459464 — أسرع طريقة للرد على استفسارك." },
        { t: "الموقع", d: "smartpoint-eg.com" },
        { t: "المقر", d: "الجيزة، مصر" },
        { t: "التغطية", d: "شحن لجميع محافظات مصر." },
        { t: "الدعم", d: "دعم فني عن بُعد لعملائنا." },
        { t: "الاستشارة", d: "نساعدك في اختيار النظام قبل الشراء بدون التزام." },
      ],
    },
  },
  cafeCard: {
    metaTitle: "سيستم كروت الكافيهات: إنترنت بكارت مش باسورد | سمارت بوينت",
    metaDescription:
      "نظام Smart Point Cafe Card لإدارة إنترنت الكافيهات بكروت مدفوعة مسبقًا: تحكم في الوقت والسرعة والأسعار والمستخدمين وتقارير الاستخدام والمبيعات، وشحن لكل مصر.",
    badge: "الإنترنت بكارت... مش باسورد",
    h1: "حوّل إنترنت كافيهك إلى مصدر دخل إضافي",
    sub: "مع Smart Point Cafe Card System",
    lead: "نظام ذكي لإدارة الإنترنت داخل الكافيهات والمقاهي من خلال كروت مخصصة، يساعدك على التحكم في الاستخدام والسرعات والأسعار بدل مشاركة باسورد الواي فاي مع الجميع.",
    visualAlt: "كروت إنترنت مدفوعة مسبقًا من سمارت بوينت بجانب لوحة تحكم لإدارة الشبكة في كافيه",
    featuresKicker: "مميزات النظام",
    featuresTitle: "تحكم كامل في شبكة الكافيه",
    features: [
      { t: "كارت خاص لكل عميل", d: "تحكم أفضل في مدة الاستخدام والخدمة." },
      { t: "تحكم في الوقت", d: "حدد مدة الإنترنت لكل كارت بسهولة." },
      { t: "تحكم في السرعة", d: "حدد سرعة مختلفة حسب نوع الكارت." },
      { t: "إدارة الأسعار", d: "أنشئ باقات وأسعار مختلفة حسب احتياج نشاطك." },
      { t: "تقارير الاستخدام", d: "تابع الكروت والاستهلاك والمبيعات من مكان واحد." },
      { t: "شبكة أكثر تحكمًا", d: "بدل مشاركة باسورد واحد مع جميع العملاء." },
    ],
    stepsKicker: "إزاي بيشتغل؟",
    stepsTitle: "النظام سهل والإدارة أسهل",
    steps: [
      "أنشئ الباقة",
      "اطبع أو جهّز الكروت",
      "العميل يشتري الكارت",
      "يستخدم الإنترنت حسب الوقت والسرعة المحددة",
    ],
    benefitsTitle: "ليه تستخدم Cafe Card System؟",
    benefits: [
      "تحكم أفضل في الإنترنت",
      "مصدر دخل إضافي للكافيه",
      "باقات مختلفة تناسب العملاء",
      "تقليل الاستخدام العشوائي للشبكة",
      "متابعة الاستخدام والمبيعات",
      "تجربة أكثر احترافية للعملاء",
    ],
    ctaTitle: "عايز تطبق سيستم الكروت في الكافيه بتاعك؟",
    ctaText: "كلم Smart Point واعرف أنسب نظام وباقات لنشاطك.",
    ctaPrimary: "اطلب النظام الآن",
    ctaSecondary: "تواصل على واتساب",
  },
};

const en: Dict = {
  htmlLang: "en",
  langLabel: "English",
  city: "Giza, Egypt",
  nav: [
    { slug: "", label: "Home" },
    { slug: "pos-systems", label: "POS Systems" },
    { slug: "accounting-inventory", label: "Accounting & Inventory" },
    { slug: "restaurants-cafes", label: "Restaurants & Cafes" },
    { slug: "cafe-card-systems", label: "Cafe Card Systems" },
    { slug: "computers-laptops", label: "Computers & Laptops" },
    { slug: "cctv-security", label: "CCTV & Security" },
    { slug: "about", label: "About" },
    { slug: "contact", label: "Contact" },
  ],
  cta: {
    whatsapp: "Talk to us on WhatsApp",
    contact: "Contact us",
    explore: "Explore our solutions",
    learnMore: "Learn more",
    menuOpen: "Open menu",
    menuClose: "Close menu",
    mainNav: "Main navigation",
    mobileNav: "Mobile navigation",
    switchLang: "Change language",
  },
  home: {
    metaTitle: "Smart Point | POS, Accounting & Inventory Software in Egypt",
    metaDescription:
      "Smart Point delivers POS systems, accounting and inventory software, restaurant and cafe management, cafe card systems, computers, laptops and CCTV across Egypt — with nationwide shipping and remote technical support.",
    badge: "Smart Solutions for Your Business",
    h1a: "All your business technology in",
    h1b: "one place",
    lead: "Smart Point provides integrated technology solutions for businesses in Egypt: POS and cashier software, accounting and inventory systems, restaurant and cafe management with cafe card systems, plus computers, laptops, CCTV and security solutions.",
    heroAlt: "Digital network illustration representing Smart Point technology solutions",
    servicesKicker: "Our Services",
    servicesTitle: "Technology solutions for every business",
    servicesText:
      "Choose the solution that fits your business — we handle installation, setup and training.",
    services: [
      {
        t: "POS & Cashier Software",
        d: "Fast invoicing, barcode support and real-time sales reporting for shops and supermarkets.",
        slug: "pos-systems",
      },
      {
        t: "Accounting & Inventory",
        d: "Complete accounting: suppliers, customers, balances, stock counts and profit reports.",
        slug: "accounting-inventory",
      },
      {
        t: "Restaurant & Cafe Systems",
        d: "Dine-in, takeaway and delivery orders, kitchen display and accurate recipe costing.",
        slug: "restaurants-cafes",
      },
      {
        t: "Cafe Card Systems",
        d: "Time-based cafe cards that track session time and services, linked to the cashier.",
        slug: "cafe-card-systems",
      },
      {
        t: "Computers & Laptops",
        d: "Desktops, monitors, laptops and accessories suited to offices and points of sale.",
        slug: "computers-laptops",
      },
      {
        t: "CCTV & Security",
        d: "Supply and installation of high-definition surveillance with remote mobile viewing.",
        slug: "cctv-security",
      },
    ],
    softwareKicker: "Business Software",
    softwareTitle: "Business management: POS, accounting and inventory",
    softwareText:
      "One system connecting sales, stock and accounts, with clear reporting on profit and item movement, user permissions and multi-branch support.",
    dashboardAlt: "Smart Point sales and inventory software dashboard interface",
    restaurantsKicker: "Restaurants & Cafes",
    restaurantsTitle: "Restaurant, cafe and cafe card systems",
    restaurantsText:
      "End-to-end order, delivery and kitchen management, plus a card system for time-based cafe sessions.",
    restaurants: [
      { t: "Order management", d: "Dine-in, takeaway and delivery on a single screen." },
      { t: "Kitchen display", d: "Track preparation and reduce customer waiting time." },
      { t: "Cafe cards", d: "Session time and services calculated automatically on the bill." },
    ],
    hardwareKicker: "Hardware",
    hardwareTitle: "POS terminals, computers, laptops and monitors",
    hardwareText:
      "Hardware selected for daily business use, shipped to every governorate in Egypt.",
    hardware: [
      { t: "POS terminals", d: "Complete cashier stations, receipt printers, cash drawers and scanners." },
      { t: "Desktop computers", d: "Reliable office builds for business and accounting work." },
      { t: "Laptops", d: "Business laptops in a range of specifications." },
      { t: "Monitors", d: "Multiple screen sizes for offices and points of sale." },
      { t: "Accessories", d: "Keyboards, mice, cables and operating essentials." },
    ],
    cctvKicker: "CCTV & Security",
    cctvTitle: "Surveillance and security systems for businesses",
    cctvText:
      "We supply and install surveillance systems for shops, restaurants, warehouses and companies, selecting cameras and recorders that match the site.",
    cctvAlt: "Professional surveillance camera installed inside a commercial facility",
    cctvPoints: [
      "High-definition indoor and outdoor cameras",
      "Recorders and storage sized to your required retention period",
      "Live remote viewing from your mobile phone",
    ],
    whyKicker: "Why Smart Point",
    whyTitle: "A technology partner you can rely on",
    why: [
      { t: "Integrated solutions", d: "Software, hardware and installation from one source." },
      { t: "Remote support", d: "Issues resolved quickly without waiting for a site visit." },
      { t: "Nationwide shipping", d: "Delivery to every governorate in Egypt." },
      { t: "After-sales support", d: "Ongoing follow-up and training on your system." },
      { t: "Fits every business", d: "From a small shop to companies and warehouses." },
      { t: "Software and hardware", d: "Full compatibility between the two, guaranteed." },
    ],
    ctaTitle: "Not sure which system fits your business?",
    ctaText:
      "Tell us your business type and size and we will recommend the right software and hardware at the best cost — including installation, training and support.",
  },
  footer: {
    about:
      "POS, accounting and inventory software, restaurant and cafe systems, computers, laptops and CCTV — all from one place.",
    quickLinks: "Quick links",
    contact: "Contact",
    shipping: "Shipping all over Egypt",
    support: "Remote technical support",
    whatsappLabel: "WhatsApp",
    linksNav: "Site links",
    logoAlt: "Smart Point logo",
  },
  pages: {
    "pos-systems": {
      title: "POS Systems & Cashier Software",
      metaTitle: "POS Systems & Cashier Software for Retail in Egypt | Smart Point",
      metaDescription:
        "POS and cashier software for shops and supermarkets in Egypt: fast invoicing, barcode support, promotions and real-time sales reports, with installation, training and support.",
      intro:
        "A fast, easy point-of-sale system for shops, supermarkets and multi-branch retailers, connected directly to inventory and accounting.",
      points: [
        { t: "Fast invoicing", d: "A simple sales screen that shortens queues and reduces errors." },
        { t: "Barcode & units", d: "Barcodes, multiple units and separate wholesale and retail pricing." },
        { t: "Shifts & permissions", d: "Shift closing per cashier with granular user permissions." },
        { t: "Real-time reports", d: "Track sales, profit and best-selling items as they happen." },
        { t: "Multi-branch", d: "Manage several branches and warehouses from one system." },
        { t: "Compatible hardware", d: "Receipt printers, cash drawers, scanners and touch screens." },
      ],
    },
    "accounting-inventory": {
      title: "Accounting & Inventory Software",
      metaTitle: "Accounting & Inventory Software for Businesses in Egypt | Smart Point",
      metaDescription:
        "Integrated accounting and inventory software: customers and suppliers, balances, stock counts, issue and receipt notes, and profit and loss reporting with remote support.",
      intro:
        "A practical accounting system that links stock to sales and purchases, giving you a clear view of profit and balances at any time.",
      points: [
        { t: "Customers & suppliers", d: "Statements, balances and collection follow-up." },
        { t: "Warehouse control", d: "Receipt, issue and transfer notes with reorder levels." },
        { t: "Stock counting", d: "Periodic and spot counts with automatic variance adjustment." },
        { t: "Purchasing", d: "Purchase orders, supplier invoices and returns." },
        { t: "Financial reports", d: "Profit and loss, expenses, cash and bank movement." },
        { t: "Secure permissions", d: "Control what each user can see and protect financial data." },
      ],
    },
    "restaurants-cafes": {
      title: "Restaurant & Cafe Management Systems",
      metaTitle: "Restaurant & Cafe Management System with Delivery & KDS | Smart Point",
      metaDescription:
        "Restaurant and cafe management in Egypt: dine-in, takeaway and delivery orders, kitchen display screens, menu pricing, recipe costing and accurate sales reporting.",
      intro:
        "A complete operating system for restaurants and cafes, from taking the order to delivering it, with precise cost control.",
      points: [
        { t: "Dine-in orders", d: "Table plans, bill splitting and moving orders between tables." },
        { t: "Takeaway & delivery", d: "Customer records, addresses and driver tracking." },
        { t: "Kitchen display", d: "Send orders straight to the kitchen and cut waiting time." },
        { t: "Recipe costing", d: "Link ingredients to stock to cost every menu item accurately." },
        { t: "Offers & discounts", d: "Combos, promotions and add-ons with flexible pricing." },
        { t: "Operational reports", d: "Best sellers, peak hours and branch performance." },
      ],
    },
    "cafe-card-systems": {
      title: "Cafe Card Systems",
      metaTitle: "Cafe Card System: Internet by Card, Not Password | Smart Point",
      metaDescription:
        "Smart Point Cafe Card System manages cafe Wi-Fi with prepaid access cards: control time, speed, pricing, users and view usage and sales reports — shipped across Egypt.",
      intro:
        "Built for cafes that charge by time: one card per customer or table, with the bill calculated automatically on checkout.",
      points: [
        { t: "Automatic timing", d: "Precise session start and end with accurate tariff calculation." },
        { t: "Services on the card", d: "Add drinks and food to the same card." },
        { t: "Cashier integration", d: "The final bill appears directly in the POS." },
        { t: "Flexible tariffs", d: "Different rates by time, session type or promotion." },
        { t: "Tamper protection", d: "Permissions and a log for every card opened or closed." },
        { t: "Session reports", d: "Average session length and revenue per table and per shift." },
      ],
    },
    "computers-laptops": {
      title: "Computers & Laptops",
      metaTitle: "Computers, Laptops, Monitors & POS Hardware in Egypt | Smart Point",
      metaDescription:
        "Supply of desktop computers, laptops, monitors, POS terminals, receipt printers, barcode scanners and accessories, shipped to every governorate in Egypt.",
      intro:
        "We supply hardware built for daily business use and guarantee full compatibility with the software we install.",
      points: [
        { t: "POS terminals", d: "Complete cashier stations, receipt printers, cash drawers and scanners." },
        { t: "Desktop computers", d: "Reliable office builds for business and accounting work." },
        { t: "Laptops", d: "Business laptops in a range of specifications." },
        { t: "Monitors", d: "Multiple screen sizes for offices and points of sale." },
        { t: "Accessories", d: "Keyboards, mice, cables and operating essentials." },
        { t: "Shipping & setup", d: "Nationwide delivery with devices prepared before handover." },
      ],
    },
    "cctv-security": {
      title: "CCTV & Security Solutions",
      metaTitle: "CCTV Installation for Shops & Companies in Egypt | Smart Point",
      metaDescription:
        "Supply and installation of high-definition indoor and outdoor CCTV cameras, recorders and storage, with live mobile viewing for shops, restaurants, warehouses and companies.",
      intro:
        "We design the surveillance system around your site size and coverage points, then handle installation, maintenance and follow-up.",
      points: [
        { t: "High-definition cameras", d: "Indoor and outdoor cameras with clear day and night imaging." },
        { t: "Recorders", d: "Storage capacity sized to your required retention period." },
        { t: "Remote viewing", d: "Live mobile access to your cameras at any time." },
        { t: "Professional installation", d: "Organised, safe camera placement and cabling." },
        { t: "Solutions for facilities", d: "Shops, restaurants, warehouses and corporate offices." },
        { t: "Maintenance & support", d: "Regular checks and fast fault resolution." },
      ],
    },
    about: {
      title: "About Smart Point",
      metaTitle: "About Smart Point | Technology Solutions in Giza, Egypt",
      metaDescription:
        "Smart Point is an Egyptian technology solutions company based in Giza: POS, accounting and inventory software, restaurant systems, hardware and CCTV, with nationwide shipping and remote support.",
      intro:
        "Smart Point is an Egyptian company specialised in technology solutions for businesses — software, hardware, installation and support from a single provider.",
      points: [
        { t: "Integrated solutions", d: "Software, hardware, installation and training in one place." },
        { t: "Local market expertise", d: "Systems tuned to how Egyptian shops and restaurants operate." },
        { t: "Remote support", d: "Fast issue resolution without waiting for a site visit." },
        { t: "Nationwide shipping", d: "Hardware delivered to every governorate." },
        { t: "After-sales support", d: "Continuous follow-up and system training." },
        { t: "Our base", d: "Giza, Egypt — serving clients across the country." },
      ],
    },
    contact: {
      title: "Contact Smart Point",
      metaTitle: "Contact Smart Point | WhatsApp 01005459464",
      metaDescription:
        "Contact Smart Point for POS systems, accounting and inventory software, business hardware and CCTV. Reach us on WhatsApp at 01005459464 — Giza, Egypt.",
      intro:
        "Tell us your business type and size and we will recommend the right software and hardware at the best cost.",
      points: [
        { t: "WhatsApp", d: "01005459464 — the fastest way to reach us." },
        { t: "Website", d: "smartpoint-eg.com" },
        { t: "Location", d: "Giza, Egypt" },
        { t: "Coverage", d: "Shipping to every governorate in Egypt." },
        { t: "Support", d: "Remote technical support for our clients." },
        { t: "Consultation", d: "We help you choose the right system before you buy." },
      ],
    },
  },
  cafeCard: {
    metaTitle: "Cafe Card System: Internet by Card, Not Password | Smart Point",
    metaDescription:
      "Smart Point Cafe Card System manages cafe Wi-Fi with prepaid access cards: control time, speed, pricing, users and view usage and sales reports — shipped across Egypt.",
    badge: "Internet by Card, Not Password",
    h1: "Turn Your Cafe Wi-Fi Into an Additional Revenue Stream",
    sub: "Smart Point Cafe Card System",
    lead: "A smart Wi-Fi management solution for cafes and coffee shops using prepaid access cards. Control usage time, speed, pricing and customer access without sharing one Wi-Fi password with everyone.",
    visualAlt: "Smart Point prepaid internet access cards beside a network management dashboard in a cafe",
    featuresKicker: "System Features",
    featuresTitle: "Full Control Over Your Cafe Network",
    features: [
      { t: "Prepaid Access Cards", d: "A dedicated card per customer for better control of usage time and service." },
      { t: "Time Control", d: "Set the internet duration for each card with ease." },
      { t: "Speed Control", d: "Assign different speeds based on the card type." },
      { t: "Flexible Pricing", d: "Create packages and price tiers that fit your business." },
      { t: "Usage & Sales Reports", d: "Track cards, consumption and sales from one place." },
      { t: "Better Network Control", d: "No more sharing one Wi-Fi password with every customer." },
    ],
    stepsKicker: "How It Works",
    stepsTitle: "A Simple System, Even Simpler to Run",
    steps: [
      "Create Package",
      "Generate Cards",
      "Customer Buys Card",
      "Customer Connects",
    ],
    benefitsTitle: "Why Use a Cafe Card System?",
    benefits: [
      "Better control over internet usage",
      "An additional revenue stream for your cafe",
      "Flexible packages for different customers",
      "Less random, uncontrolled network usage",
      "Clear usage and sales tracking",
      "A more professional customer experience",
    ],
    ctaTitle: "Want Cafe Card System for Your Business?",
    ctaText: "Contact Smart Point and discover the right system and packages for your venue.",
    ctaPrimary: "Order the System Now",
    ctaSecondary: "Contact Smart Point",
  },
};

export const dictionaries: Record<Lang, Dict> = { ar, en };
export const t = (lang: Lang) => dictionaries[lang];

export const pathFor = (lang: Lang, slug: PageSlug | "" = "") =>
  slug ? `/${lang}/${slug}` : `/${lang}`;

export const altLang = (lang: Lang): Lang => (lang === "ar" ? "en" : "ar");
