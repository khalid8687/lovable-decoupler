import { createFileRoute, notFound } from "@tanstack/react-router";
import { CheckCircle2, MessageCircle } from "lucide-react";
import { isLang, pageSlugs, site, t, type Lang, type PageSlug } from "@/lib/i18n";
import { CafeCardPage } from "@/components/site/CafeCardPage";

const isSlug = (v: string): v is PageSlug => (pageSlugs as readonly string[]).includes(v);

export const Route = createFileRoute("/$lang/$slug")({
  beforeLoad: ({ params }) => {
    if (!isLang(params.lang) || !isSlug(params.slug)) throw notFound();
  },
  component: ServicePage,
  head: ({ params }) => {
    const lang: Lang = isLang(params.lang) ? params.lang : "ar";
    if (!isSlug(params.slug)) {
      return { meta: [{ title: "Smart Point" }, { name: "robots", content: "noindex" }] };
    }
    const page = t(lang).pages[params.slug];
    const url = `/${lang}/${params.slug}`;
    return {
      meta: [
        { title: page.metaTitle },
        { name: "description", content: page.metaDescription },
        { property: "og:title", content: page.metaTitle },
        { property: "og:description", content: page.metaDescription },
        { property: "og:type", content: "website" },
        { property: "og:url", content: url },
        { property: "og:locale", content: lang === "ar" ? "ar_EG" : "en_US" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
      links: [
        { rel: "canonical", href: url },
        { rel: "alternate", hrefLang: "ar", href: `/ar/${params.slug}` },
        { rel: "alternate", hrefLang: "en", href: `/en/${params.slug}` },
        { rel: "alternate", hrefLang: "x-default", href: `/ar/${params.slug}` },
      ],
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Service",
            name: page.title,
            description: page.metaDescription,
            url: `https://${site.domain}${url}`,
            areaServed: "EG",
            provider: {
              "@type": "LocalBusiness",
              name: "Smart Point",
              telephone: "+201005459464",
              url: `https://${site.domain}/${lang}`,
            },
          }),
        },
      ],
    };
  },
});

function ServicePage() {
  const params = Route.useParams();
  const lang: Lang = isLang(params.lang) ? params.lang : "ar";
  const slug = isSlug(params.slug) ? params.slug : "about";
  const d = t(lang);
  const page = d.pages[slug];

  if (slug === "cafe-card-systems") return <CafeCardPage lang={lang} />;

  return (
    <main>
      <section className="relative overflow-hidden hero-surface">
        <div className="absolute inset-0 surface-grid" aria-hidden="true" />
        <div className="relative mx-auto max-w-4xl px-4 py-16 text-center lg:px-8 lg:py-20">
          <p className="text-xs font-bold uppercase tracking-[0.25em] text-primary">
            {site.tagline}
          </p>
          <h1 className="mt-4 text-3xl font-extrabold leading-[1.3] sm:text-4xl md:text-5xl">
            {page.title}
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-sm leading-8 text-muted-foreground sm:text-base">
            {page.intro}
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 lg:px-8 lg:py-20">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {page.points.map((p) => (
            <article key={p.t} className="card-premium rounded-2xl p-6">
              <CheckCircle2 className="h-6 w-6 text-primary" />
              <h2 className="mt-4 text-lg font-bold">{p.t}</h2>
              <p className="mt-2 text-sm leading-7 text-muted-foreground">{p.d}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 pb-16 lg:px-8 lg:pb-24">
        <div className="relative overflow-hidden rounded-3xl border border-border p-8 text-center hero-surface sm:p-14">
          <div className="absolute inset-0 surface-grid" aria-hidden="true" />
          <div className="relative">
            <h2 className="text-2xl font-extrabold sm:text-3xl">{d.home.ctaTitle}</h2>
            <p className="mx-auto mt-4 max-w-2xl text-sm leading-8 text-muted-foreground sm:text-base">
              {d.home.ctaText}
            </p>
            <a
              href={site.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-8 inline-flex items-center gap-2 rounded-lg bg-primary px-7 py-3.5 text-sm font-bold text-primary-foreground shadow-[var(--shadow-glow)] transition-opacity hover:opacity-90"
            >
              <MessageCircle className="h-4 w-4" />
              {d.cta.whatsapp} <span dir="ltr">{site.phoneDisplay}</span>
            </a>
          </div>
        </div>
      </section>
    </main>
  );
}
