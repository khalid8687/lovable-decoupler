import { useEffect, useState } from "react";
import { createFileRoute, notFound, redirect, useNavigate } from "@tanstack/react-router";
import { LogOut, MessageCircle, Pencil, Inbox, LifeBuoy, User as UserIcon } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { displayName, useAuth, useProfile } from "@/hooks/useAuth";
import { authT } from "@/lib/auth-i18n";
import { isLang, site, type Lang } from "@/lib/i18n";

export const Route = createFileRoute("/$lang/account")({
  ssr: false,
  beforeLoad: async ({ params }) => {
    if (!isLang(params.lang)) throw notFound();
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) {
      throw redirect({ to: "/$lang/login", params: { lang: params.lang } });
    }
  },
  head: ({ params }) => {
    const lang = (isLang(params.lang) ? params.lang : "ar") as Lang;
    const d = authT(lang);
    return {
      meta: [
        { title: d.accountMeta.title },
        { name: "description", content: d.accountMeta.description },
        { property: "og:title", content: d.accountMeta.title },
        { property: "og:description", content: d.accountMeta.description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "robots", content: "noindex, nofollow" },
      ],
    };
  },
  component: AccountPage,
});

function AccountPage() {
  const { lang } = Route.useParams();
  const l = (isLang(lang) ? lang : "ar") as Lang;
  const d = authT(l);
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const { profile, setProfile, loading: profileLoading } = useProfile(user?.id);

  const [editing, setEditing] = useState(false);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [status, setStatus] = useState<"idle" | "saving" | "saved" | "error">("idle");

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/$lang/login", params: { lang: l }, replace: true });
  }, [loading, user, l, navigate]);

  useEffect(() => {
    if (profile) {
      setName(profile.full_name ?? "");
      setPhone(profile.phone ?? "");
    }
  }, [profile]);

  const fullName = displayName(profile, user);
  const avatar =
    profile?.avatar_url ??
    ((user?.user_metadata as { avatar_url?: string } | undefined)?.avatar_url ?? null);

  async function save() {
    if (!user) return;
    setStatus("saving");
    const { data, error } = await supabase
      .from("profiles")
      .update({
        full_name: name.trim() || null,
        phone: phone.trim() || null,
        preferred_language: l,
      })
      .eq("id", user.id)
      .select("id, full_name, email, avatar_url, phone, preferred_language, created_at")
      .maybeSingle();

    if (error || !data) {
      setStatus("error");
      return;
    }
    setProfile(data as never);
    setStatus("saved");
    setEditing(false);
  }

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/$lang", params: { lang: l }, replace: true });
  }

  if (loading || profileLoading) {
    return (
      <main className="flex min-h-[60vh] items-center justify-center px-4">
        <p className="text-sm text-muted-foreground">{d.loading}</p>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-5xl px-4 py-12 lg:px-8">
      <h1 className="text-2xl font-extrabold tracking-tight sm:text-3xl">{d.myAccount}</h1>

      <section className="mt-8 rounded-2xl border border-border/70 bg-card/60 p-6 backdrop-blur-xl">
        <div className="flex flex-wrap items-center gap-4">
          {avatar ? (
            <img
              src={avatar}
              alt={fullName}
              width={72}
              height={72}
              referrerPolicy="no-referrer"
              className="h-18 w-18 rounded-full border border-border object-cover"
              style={{ height: 72, width: 72 }}
            />
          ) : (
            <span className="flex h-[72px] w-[72px] items-center justify-center rounded-full border border-border bg-secondary">
              <UserIcon className="h-8 w-8 text-muted-foreground" />
            </span>
          )}
          <div className="min-w-0">
            <p className="truncate text-lg font-bold">{fullName}</p>
            <p className="truncate text-sm text-muted-foreground" dir="ltr">
              {profile?.email ?? user?.email}
            </p>
          </div>
          <button
            type="button"
            onClick={() => setEditing((v) => !v)}
            className="ms-auto inline-flex items-center gap-2 rounded-lg border border-border px-3 py-2 text-sm font-bold transition-colors hover:bg-secondary"
          >
            <Pencil className="h-4 w-4" />
            {editing ? d.cancel : d.editProfile}
          </button>
        </div>

        {editing ? (
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            <label className="grid gap-2 text-sm">
              <span className="font-bold">{d.fullName}</span>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
              />
            </label>
            <label className="grid gap-2 text-sm">
              <span className="font-bold">{d.phone}</span>
              <input
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder={d.phonePlaceholder}
                dir="ltr"
                inputMode="tel"
                className="rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
              />
            </label>
            <div className="sm:col-span-2">
              <button
                type="button"
                onClick={save}
                disabled={status === "saving"}
                className="rounded-lg bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground disabled:opacity-60"
              >
                {status === "saving" ? d.saving : d.save}
              </button>
              {status === "error" && (
                <span className="ms-3 text-sm text-destructive">{d.saveError}</span>
              )}
            </div>
          </div>
        ) : (
          <dl className="mt-6 grid gap-4 sm:grid-cols-3">
            <div>
              <dt className="text-xs text-muted-foreground">{d.phone}</dt>
              <dd className="mt-1 text-sm font-bold" dir="ltr">
                {profile?.phone || d.noPhone}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">{d.language}</dt>
              <dd className="mt-1 text-sm font-bold uppercase">{profile?.preferred_language ?? l}</dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">{d.memberSince}</dt>
              <dd className="mt-1 text-sm font-bold" dir="ltr">
                {profile?.created_at ? new Date(profile.created_at).toLocaleDateString(l) : "—"}
              </dd>
            </div>
          </dl>
        )}
        {status === "saved" && <p className="mt-4 text-sm text-primary">{d.saved}</p>}
      </section>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <section className="rounded-2xl border border-border/70 bg-card/60 p-6 backdrop-blur-xl">
          <h2 className="flex items-center gap-2 text-lg font-bold">
            <Inbox className="h-5 w-5 text-primary" />
            {d.requestsTitle}
          </h2>
          <div className="mt-6 rounded-xl border border-dashed border-border/70 p-8 text-center">
            <p className="text-sm font-bold">{d.noRequests}</p>
            <p className="mt-2 text-xs text-muted-foreground">{d.noRequestsHint}</p>
          </div>
        </section>

        <section className="rounded-2xl border border-border/70 bg-card/60 p-6 backdrop-blur-xl">
          <h2 className="flex items-center gap-2 text-lg font-bold">
            <LifeBuoy className="h-5 w-5 text-primary" />
            {d.supportTitle}
          </h2>
          <p className="mt-4 text-sm text-muted-foreground">{d.supportText}</p>
          <a
            href={site.whatsapp}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-6 inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground"
          >
            <MessageCircle className="h-4 w-4" />
            <span dir="ltr">{site.phoneDisplay}</span>
          </a>
        </section>
      </div>

      <button
        type="button"
        onClick={signOut}
        className="mt-8 inline-flex items-center gap-2 rounded-lg border border-border px-4 py-2.5 text-sm font-bold transition-colors hover:bg-secondary"
      >
        <LogOut className="h-4 w-4" />
        {d.logout}
      </button>
    </main>
  );
}
