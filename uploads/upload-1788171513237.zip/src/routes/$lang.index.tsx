import { createFileRoute, Link } from "@tanstack/react-router";
import {
  MessageCircle,
  ArrowLeft,
  ArrowRight,
  Monitor,
  Calculator,
  UtensilsCrossed,
  CreditCard,
  Laptop,
  ShieldCheck,
  Boxes,
  Truck,
  Headset,
  LifeBuoy,
  Layers,
  Building2,
  Cpu,
  Keyboard,
  ScanLine,
  Video,
  HardDrive,
  Bell,
} from "lucide-react";
import { isLang, site, t, type Lang } from "@/lib/i18n";
import heroImg from "@/assets/hero-tech.jpg";
import dashboardImg from "@/assets/dashboard.jpg";
import cctvImg from "@/assets/cctv.jpg";

export const Route = createFileRoute("/$lang/")({
  component: Home,
  head: ({ params }) => {
    const lang: Lang = isLang(params.lang) ? params.lang : "ar";
    const d = t(lang).home;
    return {
      meta: [
        { title: d.metaTitle },
        { name: "description", content: d.metaDescription },
        { property: "og:title", content: d.metaTitle },
        { property: "og:description", content: d.metaDescription },
        { property: "og:type", content: "website" },
        { property: "og:url", content: `/${lang}` },
        { property: "og:locale", content: lang === "ar" ? "ar_EG" : "en_US" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
      links: [
        { rel: "canonical", href: `/${lang}` },
        { rel: "alternate", hrefLang: "ar", href: "/ar" },
        { rel: "alternate", hrefLang: "en", href: "/en" },
        { rel: "alternate", hrefLang: "x-default", href: "/ar" },
      ],
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "LocalBusiness",
            name: "Smart Point",
            alternateName: "سمارت بوينت",
            description: d.metaDescription,
            url: `https://${site.domain}/${lang}`,
            telephone: "+201005459464",
            areaServed: "EG",
            address: {
              "@type": "PostalAddress",
              addressLocality: "Giza",
              addressCountry: "EG",
            },
          }),
        },
      ],
    };
  },
});

const serviceIcons = [Monitor, Calculator, UtensilsCrossed, CreditCard, Laptop, ShieldCheck];
const restaurantIcons = [UtensilsCrossed, Bell, CreditCard];
const hardwareIcons = [ScanLine, Cpu, Laptop, Monitor, Keyboard];
const whyIcons = [Layers, Headset, Truck, LifeBuoy, Building2, Boxes];
const cctvIcons = [Video, HardDrive, ShieldCheck];
const softwareModules = [
  { icon: Monitor, label: "POS" },
  { icon: Calculator, label: "Accounting" },
  { icon: Boxes, label: "Inventory" },
  { icon: UtensilsCrossed, label: "Restaurants" },
  { icon: CreditCard, label: "Cafes" },
];

function SectionTitle({ kicker, title, text }: { kicker: string; title: string; text?: string }) {
  return (
    <div className="mx-auto max-w-2xl text-center">
      <p className="text-xs font-bold uppercase tracking-[0.25em] text-primary">{kicker}</p>
      <h2 className="mt-3 text-2xl font-extrabold sm:text-3xl md:text-4xl">{title}</h2>
      {text && <p className="mt-4 text-sm leading-8 text-muted-foreground sm:text-base">{text}</p>}
    </div>
  );
}

function Home() {
  const { lang: raw } = Route.useParams();
  const lang: Lang = isLang(raw) ? raw : "ar";
  const d = t(lang).home;
  const cta = t(lang).cta;
  const Arrow = lang === "ar" ? ArrowLeft : ArrowRight;

  return (
    <main>
      {/* HERO */}
      <section className="relative overflow-hidden hero-surface">
        <div className="absolute inset-0 surface-grid" aria-hidden="true" />
        <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-4 py-16 lg:grid-cols-2 lg:px-8 lg:py-24">
          <div>
            <p className="inline-flex items-center gap-2 rounded-full border border-border bg-secondary/60 px-4 py-1.5 text-xs text-muted-foreground">
              {d.badge}
            </p>
            <h1 className="mt-5 text-3xl font-extrabold leading-[1.25] sm:text-5xl">
              {d.h1a} <span className="text-gradient">{d.h1b}</span>
            </h1>
            <p className="mt-5 max-w-xl text-sm leading-8 text-muted-foreground sm:text-base">
              {d.lead}
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a
                href={site.whatsapp}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-primary-foreground shadow-[var(--shadow-glow)] transition-opacity hover:opacity-90"
              >
                <MessageCircle className="h-4 w-4" />
                {cta.whatsapp}
              </a>
              <a
                href="#services"
                className="inline-flex items-center gap-2 rounded-lg border border-border px-6 py-3 text-sm font-bold text-foreground transition-colors hover:bg-secondary"
              >
                {cta.explore}
                <Arrow className="h-4 w-4" />
              </a>
            </div>
          </div>
          <div className="relative">
            <img
              src={heroImg}
              alt={d.heroAlt}
              width={1600}
              height={1200}
              className="w-full rounded-2xl border border-border object-cover shadow-[var(--shadow-glow)]"
            />
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="mx-auto max-w-7xl px-4 py-16 lg:px-8 lg:py-24">
        <SectionTitle
          kicker={d.servicesKicker}
          title={d.servicesTitle}
          text={d.servicesText}
        />
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {d.services.map((s, i) => {
            const Icon = serviceIcons[i] ?? Monitor;
            return (
              <article key={s.slug} className="card-premium rounded-2xl p-6">
                <span className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-secondary text-primary">
                  <Icon className="h-6 w-6" />
                </span>
                <h3 className="mt-5 text-lg font-bold">{s.t}</h3>
                <p className="mt-3 text-sm leading-7 text-muted-foreground">{s.d}</p>
                <Link
                  to="/$lang/$slug"
                  params={{ lang, slug: s.slug }}
                  className="mt-5 inline-flex items-center gap-1.5 text-sm font-bold text-primary"
                >
                  {cta.learnMore}
                  <Arrow className="h-4 w-4" />
                </Link>
              </article>
            );
          })}
        </div>
      </section>

      {/* SOFTWARE */}
      <section className="border-y border-border/60 bg-surface-deep">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-16 lg:grid-cols-2 lg:px-8 lg:py-24">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.25em] text-primary">
              {d.softwareKicker}
            </p>
            <h2 className="mt-3 text-2xl font-extrabold sm:text-3xl md:text-4xl">
              {d.softwareTitle}
            </h2>
            <p className="mt-4 text-sm leading-8 text-muted-foreground sm:text-base">
              {d.softwareText}
            </p>
            <ul className="mt-8 flex flex-wrap gap-3">
              {softwareModules.map((m) => (
                <li
                  key={m.label}
                  className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-4 py-2 text-sm"
                >
                  <m.icon className="h-4 w-4 text-primary" />
                  {m.label}
                </li>
              ))}
            </ul>
          </div>
          <img
            src={dashboardImg}
            alt={d.dashboardAlt}
            width={1400}
            height={1000}
            loading="lazy"
            className="w-full rounded-2xl border border-border object-cover shadow-[var(--shadow-card)]"
          />
        </div>
      </section>

      {/* RESTAURANTS */}
      <section className="mx-auto max-w-7xl px-4 py-16 lg:px-8 lg:py-24">
        <SectionTitle
          kicker={d.restaurantsKicker}
          title={d.restaurantsTitle}
          text={d.restaurantsText}
        />
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {d.restaurants.map((c, i) => {
            const Icon = restaurantIcons[i] ?? UtensilsCrossed;
            return (
              <article key={c.t} className="card-premium rounded-2xl p-6">
                <Icon className="h-6 w-6 text-primary" />
                <h3 className="mt-4 text-lg font-bold">{c.t}</h3>
                <p className="mt-2 text-sm leading-7 text-muted-foreground">{c.d}</p>
              </article>
            );
          })}
        </div>
      </section>

      {/* HARDWARE */}
      <section className="border-y border-border/60 bg-surface-deep">
        <div className="mx-auto max-w-7xl px-4 py-16 lg:px-8 lg:py-24">
          <SectionTitle
            kicker={d.hardwareKicker}
            title={d.hardwareTitle}
            text={d.hardwareText}
          />
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {d.hardware.map((h, i) => {
              const Icon = hardwareIcons[i] ?? Cpu;
              return (
                <article key={h.t} className="card-premium rounded-2xl p-6">
                  <h3 className="flex items-center gap-3 text-lg font-bold">
                    <Icon className="h-5 w-5 shrink-0 text-primary" />
                    {h.t}
                  </h3>
                  <p className="mt-3 text-sm leading-7 text-muted-foreground">{h.d}</p>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      {/* CCTV */}
      <section className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-16 lg:grid-cols-2 lg:px-8 lg:py-24">
        <img
          src={cctvImg}
          alt={d.cctvAlt}
          width={1200}
          height={900}
          loading="lazy"
          className="w-full rounded-2xl border border-border object-cover shadow-[var(--shadow-card)]"
        />
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.25em] text-primary">
            {d.cctvKicker}
          </p>
          <h2 className="mt-3 text-2xl font-extrabold sm:text-3xl md:text-4xl">{d.cctvTitle}</h2>
          <p className="mt-4 text-sm leading-8 text-muted-foreground sm:text-base">{d.cctvText}</p>
          <ul className="mt-8 space-y-4">
            {d.cctvPoints.map((p, i) => {
              const Icon = cctvIcons[i] ?? ShieldCheck;
              return (
                <li key={p} className="flex items-start gap-3 text-sm text-muted-foreground">
                  <Icon className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
                  {p}
                </li>
              );
            })}
          </ul>
        </div>
      </section>

      {/* WHY */}
      <section className="border-y border-border/60 bg-surface-deep">
        <div className="mx-auto max-w-7xl px-4 py-16 lg:px-8 lg:py-24">
          <SectionTitle kicker={d.whyKicker} title={d.whyTitle} />
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {d.why.map((w, i) => {
              const Icon = whyIcons[i] ?? Layers;
              return (
                <article key={w.t} className="card-premium rounded-2xl p-6">
                  <Icon className="h-6 w-6 text-primary" />
                  <h3 className="mt-4 text-base font-bold">{w.t}</h3>
                  <p className="mt-2 text-sm leading-7 text-muted-foreground">{w.d}</p>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 py-16 lg:px-8 lg:py-24">
        <div className="relative overflow-hidden rounded-3xl border border-border p-8 text-center hero-surface sm:p-14">
          <div className="absolute inset-0 surface-grid" aria-hidden="true" />
          <div className="relative">
            <h2 className="text-2xl font-extrabold sm:text-3xl md:text-4xl">{d.ctaTitle}</h2>
            <p className="mx-auto mt-4 max-w-2xl text-sm leading-8 text-muted-foreground sm:text-base">
              {d.ctaText}
            </p>
            <a
              href={site.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-8 inline-flex items-center gap-2 rounded-lg bg-primary px-7 py-3.5 text-sm font-bold text-primary-foreground shadow-[var(--shadow-glow)] transition-opacity hover:opacity-90"
            >
              <MessageCircle className="h-4 w-4" />
              {cta.whatsapp} <span dir="ltr">{site.phoneDisplay}</span>
            </a>
          </div>
        </div>
      </section>
    </main>
  );
}
