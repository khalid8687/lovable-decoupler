import { useEffect, useState } from "react";
import { createFileRoute, notFound, useNavigate } from "@tanstack/react-router";
import { lovable } from "@/integrations/lovable/index";
import { GoogleIcon } from "@/components/site/GoogleIcon";
import { useAuth } from "@/hooks/useAuth";
import { authT } from "@/lib/auth-i18n";
import { isLang, site, type Lang } from "@/lib/i18n";

export const Route = createFileRoute("/$lang/login")({
  beforeLoad: ({ params }) => {
    if (!isLang(params.lang)) throw notFound();
  },
  head: ({ params }) => {
    const lang = (isLang(params.lang) ? params.lang : "ar") as Lang;
    const d = authT(lang);
    return {
      meta: [
        { title: d.signInMeta.title },
        { name: "description", content: d.signInMeta.description },
        { property: "og:title", content: d.signInMeta.title },
        { property: "og:description", content: d.signInMeta.description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "robots", content: "noindex, follow" },
      ],
    };
  },
  component: LoginPage,
});

function LoginPage() {
  const { lang } = Route.useParams();
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const d = authT(isLang(lang) ? lang : "ar");

  useEffect(() => {
    if (!loading && user) {
      navigate({ to: "/$lang/account", params: { lang }, replace: true });
    }
  }, [loading, user, lang, navigate]);

  async function onGoogle() {
    setBusy(true);
    setError(null);
    try {
      const result = await lovable.auth.signInWithOAuth("google", {
        redirect_uri: `${window.location.origin}/${lang}/login`,
      });
      if (result.error) {
        setError(d.signInError);
        setBusy(false);
        return;
      }
      if (result.redirected) return;
      navigate({ to: "/$lang/account", params: { lang }, replace: true });
    } catch {
      setError(d.signInError);
      setBusy(false);
    }
  }

  return (
    <main className="relative flex min-h-[70vh] items-center justify-center px-4 py-16">
      <div className="pointer-events-none absolute inset-0 opacity-40 [background:radial-gradient(60%_50%_at_50%_0%,hsl(var(--primary)/0.18),transparent_70%)]" />
      <section className="relative w-full max-w-md rounded-2xl border border-border/70 bg-card/70 p-8 shadow-[var(--shadow-glow)] backdrop-blur-xl">
        <h1 className="text-2xl font-extrabold tracking-tight sm:text-3xl">{d.welcome}</h1>
        <p className="mt-3 text-sm text-muted-foreground">{d.welcomeSub}</p>

        <button
          type="button"
          onClick={onGoogle}
          disabled={busy}
          className="mt-8 flex w-full items-center justify-center gap-3 rounded-xl border border-border bg-secondary px-4 py-3 text-sm font-bold text-foreground transition-colors hover:bg-secondary/70 disabled:opacity-60"
        >
          <GoogleIcon />
          {busy ? d.signingIn : d.continueGoogle}
        </button>

        {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

        <p className="mt-6 text-xs leading-relaxed text-muted-foreground">{d.legal}</p>
        <p className="mt-2 text-xs text-muted-foreground">
          {site.name} — {site.tagline}
        </p>
      </section>
    </main>
  );
}
