import { createFileRoute, notFound, Outlet } from "@tanstack/react-router";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { dirOf, isLang } from "@/lib/i18n";

export const Route = createFileRoute("/$lang")({
  beforeLoad: ({ params }) => {
    if (!isLang(params.lang)) throw notFound();
  },
  component: LangLayout,
});

function LangLayout() {
  const { lang } = Route.useParams();
  if (!isLang(lang)) return null;

  return (
    <div className="min-h-screen" dir={dirOf(lang)} lang={lang}>
      <Header lang={lang} />
      <Outlet />
      <Footer lang={lang} />
    </div>
  );
}
