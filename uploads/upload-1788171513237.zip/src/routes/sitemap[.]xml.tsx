import { createFileRoute } from "@tanstack/react-router";
import { LANGS, pageSlugs } from "@/lib/i18n";

function buildSitemap(origin: string) {
  const paths = LANGS.flatMap((lang) => [`/${lang}`, ...pageSlugs.map((s) => `/${lang}/${s}`)]);

  const urls = paths
    .map((path) => {
      const [, lang, slug] = path.split("/");
      const alternates = LANGS.map(
        (l) =>
          `    <xhtml:link rel="alternate" hreflang="${l}" href="${origin}/${l}${slug ? `/${slug}` : ""}" />`,
      ).join("\n");
      return `  <url>
    <loc>${origin}${path}</loc>
${alternates}
    <xhtml:link rel="alternate" hreflang="x-default" href="${origin}/ar${slug ? `/${slug}` : ""}" />
    <changefreq>monthly</changefreq>
    <priority>${slug ? "0.8" : "1.0"}</priority>
  </url>`;
    })
    .join("\n");

  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">
${urls}
</urlset>`;
}

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: ({ request }) => {
        const url = new URL(request.url);
        const forwardedHost =
          url.hostname === "localhost" ? request.headers.get("x-forwarded-host") : null;
        const origin = forwardedHost ? `https://${forwardedHost}` : url.origin;
        return new Response(buildSitemap(origin), {
          headers: { "Content-Type": "application/xml; charset=utf-8" },
        });
      },
    },
  },
});
