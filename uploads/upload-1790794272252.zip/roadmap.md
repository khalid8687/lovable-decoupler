# Roadmap

- [ ] Expand the paint catalogue with many more real shades from company websites (SCIB, Jotun, GLC, Sipes, Pachin, Al Jazeera), including navy/dark blues — current 21-shape demo set is far too small.
- [ ] Translate all added shade names to English and keep the catalogue client-side.
