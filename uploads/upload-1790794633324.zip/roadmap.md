# Roadmap

- [x] Expand the paint catalogue with many more real shades from company websites (SCIB, Jotun, GLC, Sipes, Pachin, Al Jazeera), including navy/dark blues.
- [x] Translate all added shade names to English and keep the catalogue client-side.
- [x] Apply OLTANI Colors branding, logo, favicon, website, and phone details.
