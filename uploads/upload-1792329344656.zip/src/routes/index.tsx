import { createFileRoute } from "@tanstack/react-router";
import {
  BookOpen, Users, Cpu, Bell, HandHeart, Share2, Home, Globe2, Building2, Sparkles,
  Headphones, Award, LayoutDashboard, Smartphone, WifiOff, Zap, Link2, RefreshCw,
  ShieldCheck, CheckCircle2, ArrowLeft, Download, Lock,
} from "lucide-react";
import logo from "@/assets/oltani-logo.webp";
import heroImg from "@/assets/hero-mushaf.jpg";
import heroVideo from "@/assets/hero-video.mp4";
import globalVideo from "@/assets/global-video.mp4";
import globalImg from "@/assets/global.jpg";
import mockup from "@/assets/app-mockup.jpg";
import family from "@/assets/family.jpg";
import dua from "@/assets/dua.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ختمة — منصة الختمات الجماعية للقرآن الكريم | OLTANI" },
      { name: "description", content: "عرض منصة ختمة: اطلب ختمة، يتوزع القرآن على القراء بدقة الآية، ويصلك إشعار بإتمام الختمة والدعاء." },
      { property: "og:title", content: "ختمة — منصة الختمات الجماعية | OLTANI" },
      { property: "og:description", content: "توزيع ذكي للأجزاء، ضمان اكتمال الختمة، دعاء الختام وإشعار صاحب الطلب." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const features = [
  { icon: BookOpen, t: "إنشاء الختمات", d: "ختمة للمتوفى، بنية الدعاء، جماعية، دورية، شخصية، ومفتوحة." },
  { icon: HandHeart, t: "طالب الختمة", d: "إنشاء الطلب، تحديد النية، متابعة التقدم، مشاركة الرابط، واستقبال إشعار الإتمام." },
  { icon: Users, t: "القرّاء", d: "اختيار جزء أو نصف جزء أو ربع حزب أو عدد صفحات، والقراءة وحفظ التقدم وتأكيد الإنجاز." },
  { icon: BookOpen, t: "المصحف الإلكتروني", d: "القرآن كاملاً، تحديد بداية ونهاية الورد، خطوط مصحفية، علامات مرجعية، ووضع ليلي." },
  { icon: Cpu, t: "المحرك الذكي", d: "توزيع الأجزاء، منع تضارب الحجوزات، إعادة توزيع غير المكتمل، وكشف الفجوات." },
  { icon: Bell, t: "الإشعارات", d: "تذكير القرّاء، انتهاء مهلة الحجز، تقدم الختمة، واكتمال القراءة والدعاء." },
  { icon: Sparkles, t: "دعاء الختام", d: "مرحلة مستقلة بعد اكتمال الأجزاء، مع إمكانية تكليف شخص بالدعاء." },
  { icon: Share2, t: "مشاركة الختمة", d: "واتساب، تليجرام، رابط مباشر، و QR Code." },
  { icon: Home, t: "ختمات العائلة", d: "مساحات عائلية، ختمات متكررة، وأرشيف ختمات الأحبّة." },
  { icon: Globe2, t: "الختمات العالمية", d: "مشاركة القراءة من دول مختلفة مع تعدد اللغات والمناطق الزمنية." },
  { icon: Building2, t: "المؤسسات", d: "ختمات المساجد والمراكز الإسلامية والمجموعات المنظمة." },
  { icon: Cpu, t: "المساعد الذكي", d: "اقتراح توزيع الأجزاء، توقع التأخير، وإدارة التذكيرات." },
  { icon: Headphones, t: "القراءة الصوتية", d: "الاستماع إلى التلاوات، وتسجيل القراءة اختيارياً للمراجعة." },
  { icon: Award, t: "بطاقات الإتمام", d: "بطاقة بتاريخ انتهاء الختمة وعدد المشاركين وفق تأكيداتهم." },
  { icon: LayoutDashboard, t: "لوحة الإدارة", d: "إدارة الختمات والحجوزات والقرّاء والبلاغات والصلاحيات والتحليلات." },
];

const steps = [
  { n: "١", t: "اطلب الختمة", d: "يحدد صاحب الطلب النية — على روح متوفى أو لنيل الثواب — ويشارك الرابط." },
  { n: "٢", t: "يحجز القرّاء وردهم", d: "كل قارئ يختار جزءاً أو نطاقاً محدداً من آية كذا إلى آية كذا." },
  { n: "٣", t: "قراءة وتأكيد", d: "القارئ يقرأ داخل المصحف ويؤكد ما أتمّه آيةً بآية." },
  { n: "٤", t: "اكتمال بلا فجوات", d: "المحرك يتأكد من تغطية كل آيات القرآن ويعيد توزيع أي جزء متبقٍ." },
  { n: "٥", t: "دعاء الختام والبشرى", d: "تبدأ مرحلة الدعاء، ثم يصل صاحب الطلب إشعار بإتمام الختمة." },
];

const pwa = [
  { icon: Link2, t: "فتح مباشر من الرابط", d: "بدون تثبيت أو متجر تطبيقات." },
  { icon: Download, t: "إضافة للشاشة الرئيسية", d: "يعمل كتطبيق حقيقي على أي جهاز." },
  { icon: WifiOff, t: "قراءة بدون إنترنت", d: "حفظ التقدم محلياً ومزامنته عند عودة الاتصال." },
  { icon: Bell, t: "إشعارات فورية", d: "Web Push حسب الجهاز وموافقة المستخدم." },
  { icon: Smartphone, t: "iOS و Android والمتصفح", d: "واجهة Mobile-first قريبة جداً من التطبيقات الأصلية." },
  { icon: RefreshCw, t: "تحديث تلقائي", d: "دون قطع جلسة القراءة." },
  { icon: Zap, t: "أداء سريع", d: "تحميل تدريجي للمصحف." },
  { icon: Link2, t: "روابط عميقة", d: "تفتح الختمة أو الورد المطلوب مباشرة." },
];

const tech = [
  ["Frontend PWA", "Next.js + TypeScript"], ["UI Framework", "Tailwind CSS + shadcn/ui"],
  ["Animations", "Motion"], ["PWA & Offline", "Service Worker + IndexedDB"],
  ["Backend", "Django + DRF"], ["Database", "PostgreSQL"], ["Task Queue", "Celery + Redis"],
  ["Live Updates", "WebSockets / SSE"], ["Notifications", "Web Push"],
  ["Admin Dashboard", "Next.js"], ["Deployment", "Docker + Nginx + CDN"],
];

const screens = ["الصفحة الرئيسية", "إنشاء ختمة", "تفاصيل الختمة", "متابعة الإنجاز", "المصحف", "الورد الحالي", "ختماتي", "الدعوات", "الإشعارات", "الختام", "الملف الشخصي", "الإعدادات"];

function SectionTitle({ k, t, d }: { k: string; t: string; d?: string }) {
  return (
    <div className="mx-auto mb-12 max-w-2xl text-center">
      <span className="text-sm font-bold tracking-widest text-gold">{k}</span>
      <h2 className="mt-3 font-display text-4xl font-bold leading-tight md:text-5xl">{t}</h2>
      {d && <p className="mt-4 text-lg leading-relaxed text-muted-foreground">{d}</p>}
    </div>
  );
}

function Index() {
  return (
    <div className="overflow-x-hidden">
      {/* nav */}
      <header className="fixed inset-x-0 top-0 z-50 border-b border-border bg-background/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3">
          <div className="flex items-center gap-3">
            <span className="font-display text-3xl font-bold text-gold-gradient">ختمة</span>
            <span className="hidden text-xs text-muted-foreground sm:inline">بواسطة OLTANI</span>
          </div>
          <nav className="hidden gap-7 text-sm text-muted-foreground md:flex">
            <a href="#how" className="hover:text-gold">كيف تعمل</a>
            <a href="#features" className="hover:text-gold">المميزات</a>
            <a href="#guarantee" className="hover:text-gold">ضمان الاكتمال</a>
            <a href="#tech" className="hover:text-gold">التقنية</a>
          </nav>
          <a href="#contact" className="rounded-full bg-gold-gradient px-5 py-2 text-sm font-bold text-primary-foreground shadow-gold">اطلب العرض</a>
        </div>
      </header>

      {/* hero */}
      <section className="relative flex min-h-[100svh] items-center justify-center">
        <video className="absolute inset-0 h-full w-full object-cover" src={heroVideo} poster={heroImg} autoPlay muted loop playsInline />
        <div className="absolute inset-0 bg-hero-fade" />
        <div className="relative z-10 mx-auto max-w-4xl px-5 pt-24 text-center animate-rise">
          <p className="font-display text-xl text-gold-soft md:text-2xl">﴿ وَرَتِّلِ الْقُرْآنَ تَرْتِيلًا ﴾</p>
          <h1 className="mt-6 font-display text-7xl font-bold leading-none text-gold-gradient md:text-9xl">ختمة</h1>
          <p className="mx-auto mt-6 max-w-2xl text-xl leading-relaxed text-ivory md:text-2xl">
            منصة عالمية تجمع القرّاء حول ختم القرآن الكريم — على روح من نحب، أو ابتغاء الثواب — بتنظيم دقيق حتى آخر آية.
          </p>
          <div className="mt-10 flex flex-wrap justify-center gap-4">
            <a href="#how" className="inline-flex items-center gap-2 rounded-full bg-gold-gradient px-8 py-4 text-lg font-bold text-primary-foreground shadow-gold">
              اكتشف المنصة <ArrowLeft className="h-5 w-5" />
            </a>
            <a href="#features" className="rounded-full border border-gold/40 px-8 py-4 text-lg font-bold text-gold-soft backdrop-blur hover:bg-gold/10">المميزات</a>
          </div>
          <div className="mx-auto mt-16 grid max-w-2xl grid-cols-3 gap-4">
            {[["٦٢٣٦", "آية مُتتبَّعة"], ["٣٠", "جزءاً موزّعاً"], ["١٠٠٪", "ضمان الاكتمال"]].map(([a, b]) => (
              <div key={b} className="rounded-2xl border border-border bg-background/40 p-4 backdrop-blur">
                <div className="font-display text-3xl font-bold text-gold md:text-4xl">{a}</div>
                <div className="mt-1 text-xs text-muted-foreground md:text-sm">{b}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* idea */}
      <section className="pattern-bg py-24">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 md:grid-cols-2">
          <div>
            <span className="text-sm font-bold tracking-widest text-gold">الفكرة</span>
            <h2 className="mt-3 font-display text-4xl font-bold leading-tight md:text-5xl">ختمة كاملة… بمشاركة الجميع</h2>
            <p className="mt-6 text-lg leading-loose text-muted-foreground">
              يطلب العميل ختمة بنيّة محددة، فيتوزّع القرآن على مجموعة من القرّاء. كل قارئ يحجز ورده من آية إلى آية، ويؤكد ما أتمّه، حتى يُختم المصحف كاملاً، ثم يُرفع دعاء الختام ويُبشَّر صاحب الطلب بإتمام الختمة.
            </p>
            <ul className="mt-8 space-y-3">
              {["بدون تكرار أو تضارب في الأجزاء", "متابعة لحظية لتقدم الختمة", "يعمل على الموبايل والكمبيوتر بدون تثبيت"].map((x) => (
                <li key={x} className="flex items-center gap-3 text-lg"><CheckCircle2 className="h-6 w-6 text-gold" />{x}</li>
              ))}
            </ul>
          </div>
          <img src={mockup} alt="واجهة تطبيق ختمة" width={1024} height={1280} loading="lazy" className="mx-auto w-full max-w-md rounded-3xl shadow-gold animate-floaty" />
        </div>
      </section>

      {/* how */}
      <section id="how" className="py-24">
        <div className="mx-auto max-w-7xl px-5">
          <SectionTitle k="رحلة الختمة" t="خمس خطوات من الطلب إلى البشرى" />
          <div className="grid gap-5 md:grid-cols-5">
            {steps.map((s) => (
              <div key={s.n} className="relative rounded-3xl border border-border bg-card-gradient p-6 transition hover:-translate-y-1 hover:shadow-gold">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gold-gradient font-display text-3xl font-bold text-primary-foreground">{s.n}</div>
                <h3 className="mt-5 text-xl font-bold">{s.t}</h3>
                <p className="mt-2 leading-relaxed text-muted-foreground">{s.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* features */}
      <section id="features" className="pattern-bg py-24">
        <div className="mx-auto max-w-7xl px-5">
          <SectionTitle k="المميزات" t="كل ما تحتاجه الختمة في منصة واحدة" d="خمسة عشر قسماً متكاملاً تغطي رحلة صاحب الطلب والقارئ والمؤسسة والإدارة." />
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((f) => (
              <div key={f.t} className="group rounded-3xl border border-border bg-card-gradient p-7 transition hover:-translate-y-1 hover:border-gold/50 hover:shadow-gold">
                <f.icon className="h-10 w-10 text-gold transition group-hover:scale-110" />
                <h3 className="mt-5 text-xl font-bold">{f.t}</h3>
                <p className="mt-2 leading-relaxed text-muted-foreground">{f.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* guarantee */}
      <section id="guarantee" className="py-24">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 md:grid-cols-2">
          <img src={dua} alt="دعاء الختام" width={1280} height={896} loading="lazy" className="w-full rounded-3xl object-cover shadow-gold" />
          <div>
            <span className="inline-flex items-center gap-2 text-sm font-bold tracking-widest text-gold"><ShieldCheck className="h-5 w-5" /> قلب المشروع</span>
            <h2 className="mt-3 font-display text-4xl font-bold leading-tight md:text-5xl">نظام ضمان اكتمال الختمة</h2>
            <div className="mt-8 space-y-5">
              {[
                ["كل آية معرّفة", "كل آية في القرآن مسجلة في قاعدة البيانات، وكل حجز له نطاق دقيق."],
                ["حفظ جزئي ذكي", "إذا أتمّ القارئ بعض الآيات تُحفظ، وإن اعتذر يعود الباقي فقط للتوزيع."],
                ["لا فجوات أبداً", "عند تأكيد جميع الآيات بلا فجوات تنتقل الختمة لمرحلة الدعاء."],
                ["البشرى لصاحب الطلب", "إشعار بإتمام الختمة وفق تأكيدات المشاركين."],
              ].map(([a, b]) => (
                <div key={a} className="flex gap-4 rounded-2xl border border-border bg-card/60 p-5">
                  <CheckCircle2 className="mt-1 h-6 w-6 shrink-0 text-gold" />
                  <div><h3 className="text-lg font-bold">{a}</h3><p className="mt-1 text-muted-foreground">{b}</p></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* global video */}
      <section className="relative flex min-h-[70vh] items-center overflow-hidden">
        <video className="absolute inset-0 h-full w-full object-cover" src={globalVideo} poster={globalImg} autoPlay muted loop playsInline />
        <div className="absolute inset-0 bg-background/60" />
        <div className="relative mx-auto max-w-3xl px-5 py-24 text-center">
          <Globe2 className="mx-auto h-14 w-14 text-gold" />
          <h2 className="mt-5 font-display text-4xl font-bold md:text-6xl">ختمة واحدة… من كل أنحاء العالم</h2>
          <p className="mt-5 text-lg leading-relaxed text-ivory md:text-xl">قرّاء من دول مختلفة، بلغات ومناطق زمنية متعددة، يجتمعون على ختمة واحدة — للعائلات والمساجد والمراكز الإسلامية.</p>
        </div>
      </section>

      {/* family */}
      <section className="py-24">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 md:grid-cols-2">
          <div>
            <span className="text-sm font-bold tracking-widest text-gold">ختمات العائلة</span>
            <h2 className="mt-3 font-display text-4xl font-bold leading-tight md:text-5xl">برٌّ يجمع العائلة</h2>
            <p className="mt-6 text-lg leading-loose text-muted-foreground">مساحات عائلية خاصة، ختمات متكررة شهرية أو سنوية، وأرشيف يحفظ ختمات الأحبّة مع بطاقات إتمام تُشارك بفخر.</p>
          </div>
          <img src={family} alt="عائلة تقرأ القرآن" width={1280} height={896} loading="lazy" className="w-full rounded-3xl object-cover shadow-gold" />
        </div>
      </section>

      {/* pwa */}
      <section className="pattern-bg py-24">
        <div className="mx-auto max-w-7xl px-5">
          <SectionTitle k="تطبيق ويب تقدّمي PWA" t="تطبيق حقيقي… بدون متجر" d="رابط واحد يفتح على أي موبايل أو كمبيوتر، ويضاف للشاشة الرئيسية كتطبيق أصلي." />
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {pwa.map((p) => (
              <div key={p.t} className="rounded-3xl border border-border bg-card-gradient p-6">
                <p.icon className="h-8 w-8 text-gold" />
                <h3 className="mt-4 text-lg font-bold">{p.t}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{p.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* design + screens */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-5">
          <SectionTitle k="التصميم" t="ثلاث هويات بصرية فاخرة" />
          <div className="grid gap-5 md:grid-cols-3">
            {[["Modern Premium", "أناقة عصرية بخطوط نظيفة"], ["Calm & Pure", "هدوء وصفاء يساعد على التدبر"], ["Royal Islamic", "زخارف إسلامية ولمسات ذهبية"]].map(([a, b]) => (
              <div key={a} className="rounded-3xl border border-gold/30 bg-card-gradient p-8 text-center">
                <div className="font-display text-3xl font-bold text-gold-gradient">ختمة</div>
                <div className="mt-2 text-lg font-bold" dir="ltr">{a}</div>
                <p className="mt-2 text-muted-foreground">{b}</p>
              </div>
            ))}
          </div>
          <div className="mt-12 flex flex-wrap justify-center gap-3">
            {screens.map((s) => (
              <span key={s} className="rounded-full border border-border bg-secondary px-5 py-2 text-sm">{s}</span>
            ))}
          </div>
        </div>
      </section>

      {/* tech */}
      <section id="tech" className="pattern-bg py-24">
        <div className="mx-auto max-w-5xl px-5">
          <SectionTitle k="البنية التقنية" t="هندسة قوية قابلة للتوسع" />
          <div className="grid gap-3 sm:grid-cols-2">
            {tech.map(([a, b]) => (
              <div key={a} dir="ltr" className="flex items-center justify-between rounded-2xl border border-border bg-card/70 px-5 py-4">
                <span className="text-muted-foreground">{a}</span>
                <span className="font-bold text-gold-soft">{b}</span>
              </div>
            ))}
          </div>
          <p className="mt-8 flex items-center justify-center gap-2 text-center text-muted-foreground"><Lock className="h-4 w-4 text-gold" /> صلاحيات، بلاغات، تحليلات، ونسخ احتياطي على مستوى المؤسسات.</p>
        </div>
      </section>

      {/* contact */}
      <section id="contact" className="py-24">
        <div className="mx-auto max-w-4xl px-5">
          <div className="rounded-[2.5rem] border border-gold/40 bg-card-gradient p-10 text-center shadow-gold md:p-16">
            <img src={logo} alt="OLTANI" width={200} height={200} loading="lazy" className="mx-auto h-36 w-36 rounded-3xl bg-ivory object-contain p-2" />
            <h2 className="mt-8 font-display text-4xl font-bold md:text-5xl">ابدأ مشروع ختمة مع OLTANI</h2>
            <p className="mx-auto mt-5 max-w-xl text-lg leading-relaxed text-muted-foreground">نحوّل التصور إلى منصة متكاملة بكل تفاصيلها — من التصميم إلى الإطلاق والدعم.</p>
            <a href="https://oltani.com" target="_blank" rel="noreferrer" className="mt-10 inline-flex items-center gap-2 rounded-full bg-gold-gradient px-10 py-4 text-lg font-bold text-primary-foreground">
              تواصل معنا — oltani.com <ArrowLeft className="h-5 w-5" />
            </a>
          </div>
        </div>
      </section>

      <footer className="border-t border-border py-8 text-center text-sm text-muted-foreground">
        © {new Date().getFullYear()} OLTANI — Open Link Technologies & Artificial Network Intelligence
      </footer>
    </div>
  );
}
