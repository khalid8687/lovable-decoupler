import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import logo from "@/assets/oltani-logo.png";
import mark from "@/assets/oltani-mark.png";
import heroImg from "@/assets/hero-lobby.jpg";
import heroVideo from "@/assets/hero-video.mp4";
import roomImg from "@/assets/guest-room.jpg";
import techImg from "@/assets/technician.jpg";
import dashImg from "@/assets/dashboard.jpg";
import diningImg from "@/assets/dining.jpg";
import spaImg from "@/assets/spa-tours.jpg";
import diningVideo from "@/assets/dining-video.mp4.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "OLTANI | نظام الضيافة الذكي للفنادق" },
      { name: "description", content: "عرض نظام OLTANI المتكامل لإدارة الفنادق: تجربة النزيل، تطبيق الفنيين، ولوحة الإدارة الذكية." },
      { property: "og:title", content: "OLTANI | نظام الضيافة الذكي للفنادق" },
      { property: "og:description", content: "منصة واحدة تربط النزيل والفريق والإدارة في الوقت الفعلي." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function useReveal() {
  useEffect(() => {
    const io = new IntersectionObserver(
      (es) => es.forEach((e) => e.isIntersecting && e.target.classList.add("in")),
      { threshold: 0.12 },
    );
    document.querySelectorAll(".reveal").forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
}

const guestModules = [
  { icon: "🔑", title: "إدارة الحجز والغرف", items: ["تأكيد الحجز ومراجعة تفاصيل ومواعيد الإقامة", "تسجيل وصول مسبق برفع الهوية / الجواز", "إصدار كارت الغرفة وتفعيله على باب الغرفة فوراً", "تسجيل مغادرة سريع ومراجعة الفاتورة بضغطة", "فاتورة لحظية موحدة (Live Guest Folio)"] },
  { icon: "🛠️", title: "الصيانة والدعم", items: ["تسجيل الأعطال وتحديد موقعها ونوعها", "تقييم جودة الخدمة وسرعة الفني بعد كل أوردر"] },
  { icon: "🛏️", title: "التدبير المنزلي", items: ["طلب تنظيف فوري (Make up Room)", "وضع عدم الإزعاج الرقمي (DND)", "مستلزمات سريعة: مناشف، وسائد، مياه، أدوات شخصية"] },
  { icon: "🍽️", title: "المطعم والأغذية", items: ["تصفح القوائم وتفاصيل الوجبات ومكوناتها", "Room Service مع تحديد الوقت وتتبع الطلب", "حجز طاولات مسبق في مطاعم الفندق"] },
  { icon: "👔", title: "المغسلة", items: ["غسيل، كي، تنظيف جاف Dry Clean", "تحديد توقيت الاستلام وملاحظات خاصة"] },
  { icon: "🧭", title: "الرحلات والأنشطة", items: ["عروض الرحلات اليومية والبرامج والأسعار والحجز", "تتبع باص الرحلات ومواعيد التجمع لحظياً", "حجز السبا، المساج، الجيم، البادل والتنس"] },
  { icon: "🛍️", title: "المتجر الداخلي", items: ["تسوق وتوصيل مباشر للغرفة", "منتجات الطوارئ: شواحن، محولات، واقي شمس", "هدايا تذكارية ومنتجات محلية وبراند الفندق", "باقات إعادة ملء الميني بار"] },
  { icon: "✨", title: "ميزات ذكية", items: ["يعمل فوراً بمسح QR بدون تنزيل (PWA)", "AI Concierge يرد فوراً بعدة لغات", "التحكم بالتكييف والإضاءة والستائر", "حفظ تفضيلات النزيل لزياراته القادمة"] },
];

const techFeatures = [
  ["توزيع ذكي", "استقبال الأوردرات أوتوماتيكياً حسب التخصص والموقع"],
  ["تحديث لحظي", "مستلم، قيد التنفيذ، تم الحل، معلق لقطع غيار"],
  ["توثيق بالصور", "صور قبل وبعد الإصلاح داخل تفاصيل الأوردر"],
  ["ملاحظات صوتية", "تسجيل صوتي بدل الكتابة في الميدان"],
  ["تقييم الزائر", "حماية المرافق والموظفين"],
  ["SLA Timer", "عداد الوقت المتبقي حسب معايير الاستجابة"],
];

const adminGroups = [
  { title: "الحجوزات والغرف", items: ["إدخال وتعديل الحجوزات والأسعار والتسكين", "خريطة غرف تفاعلية ملونة بالحالات"] },
  { title: "الخدمات والمبيعات", items: ["التحكم بالأقسام والقوائم والرحلات", "إدارة المتجر والمخزون والأسعار", "باقات المغسلة والخدمات الإضافية"] },
  { title: "المهام وفرق العمل", items: ["حسابات الفنيين والعمال والصلاحيات والورديات", "محرك تصعيد ذكي عند تأخر أي طلب"] },
  { title: "التقارير والجودة", items: ["تقييمات النزلاء وأداء الفنيين والالتزام بالمواعيد", "Heatmap للأعطال المتكررة", "تقارير مبيعات المتجر والمطعم والمغسلة والرحلات"] },
];

const timeline = [
  ["الأسبوع 1", "التحليل والتصميم", "ورش عمل، رحلة المستخدم، الهوية والواجهات"],
  ["الأسابيع 2–4", "واجهة النزيل", "الحجز، الخدمات، المطعم، المتجر، المساعد الذكي"],
  ["الأسابيع 4–6", "الفنيين والإدارة", "توزيع الأوردرات، SLA، لوحة التحكم والتقارير"],
  ["الأسابيع 7–8", "الاختبار والإطلاق", "اختبارات شاملة، تدريب الفريق، التشغيل الرسمي"],
];

const statuses = [
  { label: "مشغولة", cls: "bg-primary" },
  { label: "شاغرة", cls: "bg-success" },
  { label: "صيانة", cls: "bg-destructive" },
  { label: "تنظيف", cls: "bg-accent" },
  { label: "عدم إزعاج", cls: "bg-muted-foreground" },
];

function Section({ id, kicker, title, children }: { id: string; kicker: string; title: ReactNode; children: ReactNode }) {
  return (
    <section id={id} className="relative mx-auto max-w-7xl px-5 py-24 md:py-32">
      <div className="reveal mb-14 max-w-3xl">
        <span className="font-display text-sm font-bold tracking-[0.3em] text-accent">{kicker}</span>
        <h2 className="mt-4 text-4xl font-extrabold leading-tight md:text-6xl">{title}</h2>
      </div>
      {children}
    </section>
  );
}

function Index() {
  useReveal();
  const [tab, setTab] = useState(0);

  return (
    <main className="overflow-x-hidden">
      {/* NAV */}
      <header className="fixed inset-x-0 top-0 z-50 glass !border-x-0 !border-t-0">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 py-3">
          <img src={mark} alt="OLTANI" className="h-9 w-auto shrink-0" />
          <nav className="hidden gap-7 text-sm text-muted-foreground md:flex">
            <a href="#guest" className="hover:text-foreground">النزيل</a>
            <a href="#tech" className="hover:text-foreground">الفنيين</a>
            <a href="#admin" className="hover:text-foreground">الإدارة</a>
            <a href="#timeline" className="hover:text-foreground">الجدول الزمني</a>
          </nav>
          <a href="#cta" className="shrink-0 rounded-full bg-brand px-5 py-2 text-sm font-bold text-primary-foreground">ابدأ المشروع</a>
        </div>
      </header>

      {/* HERO */}
      <section className="relative flex min-h-screen items-end">
        <video className="absolute inset-0 h-full w-full object-cover" src={heroVideo} poster={heroImg} autoPlay muted loop playsInline />
        <div className="absolute inset-0 bg-fade" />
        <div className="relative mx-auto w-full max-w-7xl px-5 pb-20 pt-32">
          <span className="reveal inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-sm">
            <span className="pulse-dot h-2 w-2 rounded-full bg-success" /> منصة ضيافة ذكية متكاملة
          </span>
          <h1 className="reveal mt-6 max-w-4xl text-5xl font-extrabold leading-[1.1] md:text-8xl">
            فندقك بالكامل <span className="text-gradient">في راحة يد النزيل</span>
          </h1>
          <p className="reveal mt-6 max-w-2xl text-lg text-muted-foreground md:text-xl">
            نظام واحد يربط النزيل والفنيين والإدارة لحظياً — يرفع رضا الضيوف، يضاعف العوائد، ويجعل التشغيل أسرع وأذكى.
          </p>
          <div className="reveal mt-10 flex flex-wrap gap-4">
            <a href="#guest" className="rounded-full bg-brand px-8 py-4 font-bold text-primary-foreground shadow-ember">استكشف النظام</a>
            <a href="#timeline" className="rounded-full glass px-8 py-4 font-bold">جاهز خلال 8 أسابيع</a>
          </div>
          <div className="reveal mt-16 grid max-w-3xl grid-cols-3 gap-4">
            {[["3", "واجهات متكاملة"], ["40+", "ميزة ذكية"], ["24/7", "خدمة بلا توقف"]].map(([n, l]) => (
              <div key={l} className="glass rounded-2xl p-4 md:p-6">
                <div className="font-display text-3xl font-bold text-gradient md:text-5xl">{n}</div>
                <div className="mt-1 text-xs text-muted-foreground md:text-sm">{l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ECOSYSTEM */}
      <section className="relative grid-bg">
        <div className="mx-auto grid max-w-7xl gap-6 px-5 py-24 md:grid-cols-3">
          {[
            ["01", "واجهة النزيل", "تجربة إقامة رقمية فاخرة من الحجز حتى المغادرة", "text-accent"],
            ["02", "تطبيق الفنيين", "توزيع ذكي، تتبع لحظي، والتزام صارم بالوقت", "text-foreground"],
            ["03", "لوحة الإدارة", "رؤية كاملة، تصعيد ذكي، وتقارير تصنع القرار", "text-primary"],
          ].map(([n, t, d, c]) => (
            <div key={n} className="reveal glass rounded-3xl p-8 transition hover:-translate-y-1 hover:shadow-glow">
              <div className={`font-display text-6xl font-bold opacity-80 ${c}`}>{n}</div>
              <h3 className="mt-6 text-2xl font-bold">{t}</h3>
              <p className="mt-3 text-muted-foreground">{d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* GUEST */}
      <Section id="guest" kicker="01 — GUEST EXPERIENCE" title={<>تجربة إقامة <span className="text-gradient">لا تُنسى</span></>}>
        <div className="mb-16 grid items-center gap-8 md:grid-cols-2">
          <div className="reveal relative overflow-hidden rounded-3xl shadow-glow">
            <img src={roomImg} alt="غرفة النزلاء" width={1280} height={960} className="h-full w-full object-cover" />
          </div>
          <div className="reveal">
            <h3 className="text-3xl font-bold">تسجيل وصول سريع… <span className="text-gradient">وكارت غرفة جاهز</span></h3>
            <p className="mt-4 text-lg text-muted-foreground">
              من لحظة الحجز حتى المغادرة، كل شيء جاهز قبل وصول النزيل: وصول مسبق، كارت غرفة مفعّل على باب الغرفة، وفاتورة واضحة يراجعها في أي وقت — وداعاً لطوابير الاستقبال.
            </p>
            <div className="mt-8 grid grid-cols-2 gap-3">
              {["Digital Pre-Check-in", "Room Card Access", "Express Check-out", "Live Guest Folio"].map((x) => (
                <div key={x} className="glass rounded-xl px-4 py-3 font-display text-sm font-bold">{x}</div>
              ))}
            </div>
          </div>
        </div>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {guestModules.map((m) => (
            <div key={m.title} className="reveal glass rounded-2xl p-6 transition hover:-translate-y-1 hover:shadow-glow">
              <div className="text-3xl">{m.icon}</div>
              <h4 className="mt-4 text-xl font-bold">{m.title}</h4>
              <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                {m.items.map((i) => (
                  <li key={i} className="flex gap-2"><span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />{i}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-16 grid gap-6 md:grid-cols-2">
          {[[diningImg, "Room Service بتتبع لحظي", "من القائمة إلى باب الغرفة، مع وقت توصيل يحدده النزيل.", diningVideo.url], [spaImg, "رحلات، سبا، ونشاطات", "حجز مباشر وتتبع حي لباص الرحلة ومواعيد التجمع.", ""]].map(([img, t, d, v]) => (
            <div key={t} className="reveal group relative h-96 overflow-hidden rounded-3xl">
              {v ? (
                <video src={v} poster={img} autoPlay muted loop playsInline className="absolute inset-0 h-full w-full object-cover" />
              ) : (
                <img src={img} alt={t} loading="lazy" width={1280} height={960} className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-105" />
              )}
              <div className="absolute inset-0 bg-fade" />
              <div className="absolute bottom-0 p-8">
                <h4 className="text-2xl font-bold">{t}</h4>
                <p className="mt-2 text-muted-foreground">{d}</p>
              </div>
            </div>
          ))}
        </div>

        {/* AI concierge mock */}
        <div className="reveal mt-16 grid items-center gap-10 rounded-3xl glass p-8 md:grid-cols-2 md:p-12">
          <div>
            <span className="font-display text-sm font-bold text-primary">AI CONCIERGE</span>
            <h3 className="mt-3 text-3xl font-bold">مساعد ذكي يتحدث لغة كل نزيل</h3>
            <p className="mt-4 text-muted-foreground">إجابات فورية على مدار الساعة عن الواي فاي، المواعيد، والمعالم القريبة — يخفف الضغط عن الاستقبال ويرفع الرضا.</p>
          </div>
          <div className="floaty mx-auto w-full max-w-sm space-y-3 rounded-[2rem] border-4 border-secondary bg-background p-5">
            <div className="ms-auto w-fit max-w-[80%] rounded-2xl rounded-bl-sm bg-secondary px-4 py-2 text-sm">ما هي كلمة سر الواي فاي؟</div>
            <div className="w-fit max-w-[85%] rounded-2xl rounded-br-sm bg-brand px-4 py-2 text-sm font-medium text-primary-foreground">أهلاً بك! الشبكة: Hotel-Guest — كلمة السر في بطاقة غرفتك 312 🔐</div>
            <div className="ms-auto w-fit rounded-2xl rounded-bl-sm bg-secondary px-4 py-2 text-sm" dir="ltr">What time is breakfast?</div>
            <div className="w-fit max-w-[85%] rounded-2xl rounded-br-sm bg-brand px-4 py-2 text-sm font-medium text-primary-foreground" dir="ltr">Breakfast is served 6:30 – 10:30 AM ☕</div>
          </div>
        </div>
      </Section>

      {/* TECH */}
      <Section id="tech" kicker="02 — OPERATIONS APP" title={<>فريق عمل <span className="text-gradient">أسرع بـ 3 أضعاف</span></>}>
        <div className="grid items-center gap-10 md:grid-cols-2">
          <div className="reveal grid gap-4 sm:grid-cols-2">
            {techFeatures.map(([t, d]) => (
              <div key={t} className="glass rounded-2xl p-5">
                <h4 className="font-bold text-accent">{t}</h4>
                <p className="mt-2 text-sm text-muted-foreground">{d}</p>
              </div>
            ))}
          </div>
          <div className="reveal relative pb-10">
            <img src={techImg} alt="تطبيق الفنيين" loading="lazy" width={1200} height={896} className="aspect-[4/3] w-full rounded-3xl object-cover shadow-glow" />
            <div className="absolute bottom-0 end-4 w-64 max-w-[80%] rounded-2xl border bg-background/90 p-4 backdrop-blur">
              <div className="flex items-center justify-between text-xs text-muted-foreground"><span>أوردر #1207</span><span className="text-primary" dir="ltr">SLA 12:40</span></div>
              <div className="mt-2 font-bold">تكييف لا يعمل — غرفة 1207</div>
              <div className="mt-3 h-2 overflow-hidden rounded-full bg-secondary"><div className="h-full w-2/3 bg-brand" /></div>
              <div className="mt-2 flex items-center gap-1.5 text-xs text-success"><span className="pulse-dot h-2 w-2 rounded-full bg-success" />قيد التنفيذ</div>
            </div>
          </div>
        </div>
      </Section>

      {/* ADMIN */}
      <Section id="admin" kicker="03 — COMMAND CENTER" title={<>تحكم كامل <span className="text-gradient">من شاشة واحدة</span></>}>
        <div className="reveal relative mb-12 overflow-hidden rounded-3xl shadow-glow">
          <img src={dashImg} alt="لوحة الإدارة" loading="lazy" width={1280} height={960} className="max-h-[560px] w-full object-cover" />
          <div className="absolute inset-0 bg-fade" />
        </div>

        {/* Room grid demo */}
        <div className="reveal mb-12 glass rounded-3xl p-6 md:p-10">
          <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
            <h3 className="text-2xl font-bold">خريطة الغرف التفاعلية</h3>
            <div className="flex flex-wrap gap-3 text-xs">
              {statuses.map((s) => (<span key={s.label} className="flex items-center gap-1.5"><span className={`h-3 w-3 rounded ${s.cls}`} />{s.label}</span>))}
            </div>
          </div>
          <div className="grid grid-cols-6 gap-2 sm:grid-cols-10" dir="ltr">
            {Array.from({ length: 40 }).map((_, i) => {
              const s = statuses[(i * 7 + (i % 3)) % 5]!;
              return <div key={i} className={`${s.cls} flex aspect-square items-center justify-center rounded-lg font-display text-[10px] font-bold text-primary-foreground sm:text-xs`}>{400 - Math.floor(i / 10) * 100 + (i % 10) + 1}</div>;
            })}
          </div>
        </div>

        <div className="mb-6 flex flex-wrap gap-2">
          {adminGroups.map((g, i) => (
            <button key={g.title} onClick={() => setTab(i)} className={`rounded-full px-5 py-2 text-sm font-bold transition ${tab === i ? "bg-brand text-primary-foreground" : "glass text-muted-foreground"}`}>{g.title}</button>
          ))}
        </div>
        <div className="glass grid gap-4 rounded-3xl p-8 md:grid-cols-3">
          {adminGroups[tab]!.items.map((it) => (
            <div key={it} className="rounded-2xl bg-secondary p-5"><span className="text-primary">◆</span> <span className="ms-2">{it}</span></div>
          ))}
        </div>
      </Section>

      {/* TIMELINE */}
      <Section id="timeline" kicker="DELIVERY PLAN" title={<>جاهز للتشغيل خلال <span className="text-gradient">6 – 8 أسابيع</span></>}>
        <div className="relative grid gap-6 md:grid-cols-4">
          <div className="absolute inset-x-0 top-8 hidden h-0.5 bg-brand md:block" />
          {timeline.map(([w, t, d], i) => (
            <div key={w} className="reveal relative">
              <div className="relative z-10 flex h-16 w-16 items-center justify-center rounded-full bg-brand font-display text-2xl font-bold text-primary-foreground shadow-ember">{i + 1}</div>
              <div className="mt-5 text-sm font-bold text-accent">{w}</div>
              <h4 className="mt-1 text-xl font-bold">{t}</h4>
              <p className="mt-2 text-sm text-muted-foreground">{d}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* CTA */}
      <section id="cta" className="relative overflow-hidden">
        <div className="absolute inset-0 bg-brand opacity-20" />
        <div className="relative mx-auto max-w-4xl px-5 py-28 text-center">
          <img src={logo} alt="OLTANI" className="reveal mx-auto h-40 w-auto" />
          <h2 className="reveal mt-10 text-4xl font-extrabold md:text-6xl">لنحوّل فندقك إلى <span className="text-gradient">تجربة ذكية</span></h2>
          <p className="reveal mt-6 text-lg text-muted-foreground">نظام متكامل، تسليم خلال شهرين كحد أقصى، ودعم كامل من فريق OLTANI.</p>
          <a href="https://oltani.com" target="_blank" rel="noreferrer" className="reveal mt-10 inline-block rounded-full bg-brand px-10 py-4 text-lg font-bold text-primary-foreground shadow-ember">oltani.com</a>
        </div>
      </section>
      <footer className="border-t py-8 text-center text-sm text-muted-foreground">© {new Date().getFullYear()} OLTANI — Open Link Technologies & Artificial Network Intelligence</footer>
    </main>
  );
}
