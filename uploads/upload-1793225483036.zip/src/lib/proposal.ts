export type Lang = "ar" | "en";
type T = { ar: string; en: string };

export const meta = {
  ref: "ST-SG-2026-1028",
  date: { ar: "28 أكتوبر 2026", en: "October 28, 2026" },
  validity: { ar: "صالح لمدة 14 يوماً من تاريخه", en: "Valid for 14 days from issue" },
  client: "Mr. Ahmed Shawky",
  company: "Shawky Group",
  site: "shawkygroup.com",
};

export const ui = {
  download: { ar: "تحميل العرض PDF", en: "Download PDF" },
  toggle: { ar: "English", en: "عربي" },
  preparedFor: { ar: "عرض فني ومالي مُعدّ خصيصاً لـ", en: "Technical & financial proposal prepared for" },
  heroTitle: {
    ar: "منصّة موحّدة تحوّل كل رسالة عميل إلى فرصة بيع",
    en: "One unified platform that turns every customer message into revenue",
  },
  heroSub: {
    ar: "نظام احترافي لإدارة محادثات واتساب وماسنجر لحظياً، بتوزيع آلي عادل على فريقك، ورقابة كاملة للمشرفين — مبني خصيصاً لـ Shawky Group.",
    en: "A professional real-time system for WhatsApp & Messenger conversations, with fair automatic routing to your team and full supervisor control — built exclusively for Shawky Group.",
  },
  ctaPrice: { ar: "استعرض الاستثمار", en: "View investment" },
  ctaScope: { ar: "نطاق العمل", en: "Scope of work" },
  ref: { ar: "رقم العرض", en: "Ref." },
  date: { ar: "التاريخ", en: "Date" },
};

export const stats: { v: string; l: T }[] = [
  { v: "< 1s", l: { ar: "استقبال الرسائل لحظياً", en: "Real-time message delivery" } },
  { v: "100%", l: { ar: "توزيع عادل على الموظفين", en: "Fair agent distribution" } },
  { v: "3", l: { ar: "لوحات تحكم متكاملة", en: "Integrated dashboards" } },
  { v: "24/7", l: { ar: "مراقبة واستقرار السيرفرات", en: "Server monitoring" } },
];

export const challenge = {
  kicker: { ar: "التحدي", en: "The challenge" },
  title: { ar: "كل رسالة بدون رد… عميل بيروح للمنافس", en: "Every unanswered message is a customer lost to a competitor" },
  points: [
    { t: { ar: "رسائل متفرقة", en: "Scattered inboxes" }, d: { ar: "محادثات واتساب وماسنجر موزعة على أجهزة وأشخاص بدون سجل موحّد.", en: "WhatsApp and Messenger chats spread across phones and people with no single history." } },
    { t: { ar: "ضغط غير عادل", en: "Unbalanced workload" }, d: { ar: "موظف غرقان وموظف فاضي، والعميل بيستنى.", en: "One agent drowning, another idle — while the customer waits." } },
    { t: { ar: "غياب الرقابة", en: "Zero visibility" }, d: { ar: "الإدارة مش شايفة مين متأخر، ولا تقدر تتدخل في الوقت المناسب.", en: "Management can't see who's late or step in at the right moment." } },
  ],
  solution: {
    ar: "الحل: منظومة واحدة ذكية تجمع كل القنوات، توزّع تلقائياً، وتمنح الإدارة عيناً على كل محادثة لحظة بلحظة.",
    en: "The solution: one intelligent system that unifies every channel, routes automatically, and gives management eyes on every conversation in real time.",
  },
};

export type Module = { n: string; title: T; tag: string; items: T[]; cond: T; img: "engine" | "dashboard" | "cloud" | "meta" | "support" };

export const modules: Module[] = [
  {
    n: "01", tag: "Backend & Realtime Engine", img: "engine",
    title: { ar: "المحرك والربط الشبكي الأساسي", en: "Core Engine & Network Integration" },
    items: [
      { ar: "بناء قاعدة البيانات، مع تشفير وحفظ المحادثات وسجل العملاء.", en: "Database architecture with encrypted storage of conversations and customer history." },
      { ar: "سيرفر يستقبل ويعالج رسائل Webhooks من Meta (واتساب وماسنجر) لحظياً.", en: "Server that receives and processes Meta Webhooks (WhatsApp & Messenger) in real time." },
      { ar: "خوارزمية توزيع آلي بالتتابع العادل (Round Robin) على الموظفين المتاحين.", en: "Fair Round-Robin auto-assignment algorithm across available agents." },
    ],
    cond: { ar: "يُختبر ويُسلَّم على بيئة Sandbox تابعة لنا، ويُعتبر منجزاً بمجرد إثبات إرسال واستقبال الرسائل بنجاح.", en: "Tested and delivered on our own Sandbox environment; considered complete once sending and receiving are proven." },
  },
  {
    n: "02", tag: "User Interfaces & Dashboards", img: "dashboard",
    title: { ar: "واجهات الاستخدام ولوحات التحكم", en: "User Interfaces & Dashboards" },
    items: [
      { ar: "شاشة الموظف: نافذة محادثة نظيفة، سجل العميل، نصوص وميديا، الرد والتحويل.", en: "Agent App: clean chat window, customer history, text & media, reply and forward." },
      { ar: "شاشة المشرف: متابعة لايف، كشف المتأخرين، سحب وتحويل الشات، والتدخل الفوري.", en: "Supervisor Hub: live monitoring, late-agent detection, chat reassignment, instant intervention." },
      { ar: "شاشة الأدمن: إدارة الحسابات والصلاحيات وإعدادات النظام.", en: "Admin Console: accounts, permissions and system settings." },
    ],
    cond: { ar: "تُسلَّم بمطابقة الشاشات للديمو المتفق عليه، مع فترة فحص أخطاء تشغيلية 14 يوماً.", en: "Delivered on matching the agreed demo, with a 14-day operational bug-check period." },
  },
  {
    n: "03", tag: "Infrastructure & Dev Setup", img: "cloud",
    title: { ar: "خوادم التشغيل وموارد التطوير", en: "Cloud Servers & Development Pipeline" },
    items: [
      { ar: "إعداد السيرفر السحابي (VPS) والسيرفر الوسيط (Redis / Sockets).", en: "Cloud VPS setup plus realtime middleware (Redis / Sockets)." },
      { ar: "نظام تخزين سحابي للصور والملفات.", en: "Cloud storage for images and files." },
      { ar: "تغطية موارد التطوير والترميز الآلي حتى النسخة المستقرة.", en: "Covers development & automated-coding resources up to the stable release." },
    ],
    cond: { ar: "التكلفة تشمل التأسيس والاستضافة للشهر الأول، ورسائل Meta المدفوعة تُسدد مباشرة من بطاقة العميل لـ Meta.", en: "Includes setup and first-month hosting; paid Meta messages are billed directly to the client's card by Meta." },
  },
  {
    n: "04", tag: "Go-Live & Meta Integration", img: "meta",
    title: { ar: "التجهيز والربط مع حسابات الشركة الرسمية", en: "Go-Live & Official Meta Integration" },
    items: [
      { ar: "دعم فني لإعداد Meta Business Manager وإدخال بيانات السجل التجاري والبطاقة الضريبية.", en: "Technical help setting up Meta Business Manager with commercial & tax records." },
      { ar: "ربط خطوط وأرقام الشركة الرسمية بالمنصة بعد اعتماد Meta للـ WABA.", en: "Connecting the company's official numbers once Meta approves the WABA." },
    ],
    cond: { ar: "مرتبط بمتطلبات خارجية تفرضها Meta، وأي تأخير في اعتماد الأوراق أو المشاكل البنكية لا يعطل استحقاق دفعات البندين الأول والثاني بعد جاهزيتهما.", en: "Depends on external Meta requirements; delays in document approval or banking do not hold back payments for Items 1 and 2 once ready." },
  },
  {
    n: "05", tag: "Post-Launch Support & Iterations", img: "support",
    title: { ar: "الدعم الفني وباقة التعديلات الشهرية", en: "Post-Launch Support & Iterations" },
    items: [
      { ar: "دعم فني ومراقبة استقرار السيرفرات شهرياً.", en: "Monthly technical support and server stability monitoring." },
      { ar: "رصيد تطوير شهري ثابت (مثل 10 ساعات عمل) لتنفيذ الأفكار الجديدة بعد التشغيل.", en: "Fixed monthly development credit (e.g. 10 hours) for new ideas after launch." },
    ],
    cond: { ar: "أي طلبات أو إضافات بعد التسليم الرسمي تُخصم من الباقة، وعند استنفادها يصدر عرض سعر منفصل لكل ميزة قبل البدء.", en: "Any request after official handover is deducted from the package; once used up, each new feature gets a separate quote before work starts." },
  },
];

export const screens = {
  kicker: { ar: "تجربة الاستخدام", en: "The experience" },
  title: { ar: "ثلاث شاشات… منظومة واحدة متكاملة", en: "Three screens. One seamless system." },
  list: [
    { t: { ar: "الموظف", en: "Agent" }, d: { ar: "يركز على الرد فقط — كل التاريخ أمامه.", en: "Focuses on replying — full history at hand." } },
    { t: { ar: "المشرف", en: "Supervisor" }, d: { ar: "يرى كل محادثة لايف ويتدخل في ثانية.", en: "Sees every chat live and steps in within seconds." } },
    { t: { ar: "الأدمن", en: "Admin" }, d: { ar: "يتحكم في الفريق والصلاحيات والإعدادات.", en: "Controls team, permissions and settings." } },
  ],
};

export type PriceRow = { n: string; item: T; en: string; price: string; pay: T };
export const pricing = {
  kicker: { ar: "الاستثمار", en: "Investment" },
  title: { ar: "استثمار واضح… مرتبط بإنجاز حقيقي", en: "Transparent investment, tied to real milestones" },
  sub: { ar: "كل دفعة مرتبطة بمخرج ملموس تراه وتختبره بنفسك قبل السداد.", en: "Every payment is tied to a tangible deliverable you see and test yourself first." },
  head: { item: { ar: "البند / المكون", en: "Item / Component" }, price: { ar: "السعر", en: "Price" }, pay: { ar: "آلية الاستحقاق والسداد", en: "Milestone & payment" } },
  rows: [
    { n: "1", item: { ar: "محرك النظام والربط الشبكي والتوزيع الآلي", en: "System engine, networking & auto-routing" }, en: "Backend & Realtime Engine", price: "$950", pay: { ar: "دفعة مقدمة (عربون تعاقد لبدء العمل)", en: "Upfront (contract deposit to start work)" } },
    { n: "2", item: { ar: "الواجهات ولوحات التحكم (الموظف + المشرف + الأدمن)", en: "Interfaces & dashboards (Agent + Supervisor + Admin)" }, en: "User Interfaces & Dashboards", price: "$1,100", pay: { ar: "تُدفع فور العرض على بيئة الاختبار ومطابقة الفيديو", en: "Due on staging demo matching the agreed video" } },
    { n: "3", item: { ar: "تأسيس السيرفر وتجهيز بيئات التطوير الآلي", en: "Server setup & automated dev environments" }, en: "Infrastructure & Dev Setup", price: "$350", pay: { ar: "تُدفع مناصفة أو مدمجة مع تسليم الواجهات", en: "Split, or combined with interface delivery" } },
    { n: "4", item: { ar: "إعداد الحساب الرسمي والربط الحي مع Meta", en: "Official account setup & live Meta integration" }, en: "Onboarding & Live Integration", price: "$250", pay: { ar: "عند جلسة ربط الأرقام الرسمية بعد توثيقها", en: "At the official-number linking session after verification" } },
  ] as PriceRow[],
  total: { label: { ar: "إجمالي تكلفة التأسيس والتسليم البرمجي", en: "Total setup & software delivery" }, price: "$2,650", note: { ar: "إجمالي تكلفة النظام الجاهز للتسليم", en: "Total cost of the ready-to-deliver system" } },
  retainer: { n: "5", item: { ar: "الدعم الفني، استقرار السيرفرات، وباقة التعديلات الشهرية", en: "Support, server stability & monthly iterations" }, en: "Retainer", price: "$150 – $200", per: { ar: "شهرياً", en: "per month" }, pay: { ar: "اشتراك شهري مستمر يبدأ بعد أسبوعين من التسليم", en: "Ongoing monthly subscription starting two weeks after handover" } },
};

export const milestones = {
  kicker: { ar: "خارطة التنفيذ", en: "Delivery roadmap" },
  title: { ar: "رحلة واضحة من التعاقد إلى التشغيل", en: "A clear path from signature to go-live" },
  steps: [
    { t: { ar: "التعاقد والانطلاق", en: "Kick-off" }, d: { ar: "توقيع العرض وسداد العربون وبدء بناء المحرك.", en: "Sign, deposit and start building the engine." }, p: "$950" },
    { t: { ar: "إثبات المحرك", en: "Engine proof" }, d: { ar: "إرسال واستقبال الرسائل بنجاح على Sandbox.", en: "Messages sent & received on Sandbox." }, p: "" },
    { t: { ar: "عرض الواجهات", en: "Interfaces demo" }, d: { ar: "الشاشات الثلاث على بيئة الاختبار مطابقة للديمو.", en: "All three screens on staging, matching the demo." }, p: "$1,450" },
    { t: { ar: "الإطلاق الرسمي", en: "Go-live" }, d: { ar: "ربط أرقام Shawky Group الرسمية والتشغيل الحي.", en: "Shawky Group's official numbers go live." }, p: "$250" },
    { t: { ar: "الدعم المستمر", en: "Ongoing care" }, d: { ar: "مراقبة وتطوير شهري بعد أسبوعين من التسليم.", en: "Monitoring & iterations two weeks after handover." }, p: "$150–200/mo" },
  ],
};

export const why = {
  kicker: { ar: "لماذا Star Tech", en: "Why Star Tech" },
  title: { ar: "شريك تقني يبني لك أصلاً… مش مجرد برنامج", en: "A technology partner building you an asset — not just software" },
  list: [
    { t: { ar: "ملكية وتحكم", en: "Ownership & control" }, d: { ar: "نظام خاص بك على سيرفرك، بدون اشتراكات منصات خارجية مكلفة لكل موظف.", en: "Your own system on your server — no costly per-seat SaaS fees." } },
    { t: { ar: "أمان وتشفير", en: "Security & encryption" }, d: { ar: "محادثات وبيانات عملائك مشفّرة ومحفوظة باحترافية.", en: "Your conversations and customer data encrypted and safely stored." } },
    { t: { ar: "دفع مقابل إنجاز", en: "Pay per milestone" }, d: { ar: "لا تدفع إلا مقابل مخرج تراه وتختبره بنفسك.", en: "You only pay for what you see and test yourself." } },
    { t: { ar: "قابلية التوسع", en: "Built to scale" }, d: { ar: "بنية Realtime جاهزة لنمو فريقك وعدد محادثاتك.", en: "Realtime architecture ready for your team and volume to grow." } },
  ],
};

export const closing = {
  title: { ar: "جاهزين نبدأ مع Shawky Group", en: "Ready to start with Shawky Group" },
  sub: { ar: "بمجرد اعتماد العرض وسداد العربون، يبدأ فريق Star Tech فوراً في بناء المحرك.", en: "Once approved and the deposit is received, the Star Tech team starts building the engine immediately." },
  sign: { ar: "اعتماد العميل", en: "Client approval" },
  signBy: { ar: "عن Star Tech", en: "For Star Tech" },
};
