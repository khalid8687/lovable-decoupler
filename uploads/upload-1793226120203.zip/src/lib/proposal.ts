export type Lang = "ar" | "en";
type T = { ar: string; en: string };

export const meta = {
  ref: "ST-SG-AI-2026-1029",
  date: { ar: "29 أكتوبر 2026", en: "October 29, 2026" },
  validity: { ar: "صالح لمدة 14 يوماً من تاريخه", en: "Valid for 14 days from issue" },
  client: "Mr. Ahmed Shawky",
  company: "Shawky Group",
  site: "shawkygroup.com",
};

export const ui = {
  download: { ar: "تحميل العرض PDF", en: "Download PDF" },
  toggle: { ar: "English", en: "عربي" },
  preparedFor: { ar: "عرض فني ومالي مُعدّ خصيصاً لـ", en: "Technical & financial proposal prepared for" },
  heroTitle: {
    ar: "مساعد ذكي يسمع ويرى ويفهم بيانات شركتك",
    en: "An AI agent that hears, sees and truly knows your company",
  },
  heroSub: {
    ar: "منصّة ذكاء اصطناعي بمحادثة صوتية ورؤية بالكاميرا لحظياً، مدرّبة على مستندات Shawky Group، بشخصيات متخصصة (محاسب، محامي، مهندس، IT) — وتحت تحكم الإدارة بالكامل.",
    en: "A real-time AI platform with live voice and camera vision, trained on Shawky Group's own documents, with specialist personas (accountant, lawyer, engineer, IT) — fully under management control.",
  },
  ctaPrice: { ar: "استعرض الاستثمار", en: "View investment" },
  ctaScope: { ar: "نطاق العمل", en: "Scope of work" },
  ref: { ar: "رقم العرض", en: "Ref." },
  date: { ar: "التاريخ", en: "Date" },
  scopeKicker: { ar: "نطاق العمل", en: "Scope of work" },
  scopeTitle: { ar: "خمسة بنود… عقل رقمي متكامل لشركتك", en: "Five components. One complete digital brain." },
  cond: { ar: "شرط التسليم والاستحقاق", en: "Delivery condition" },
};

export const stats: { v: string; l: T }[] = [
  { v: "Live", l: { ar: "صوت وكاميرا لحظياً", en: "Real-time voice & vision" } },
  { v: "RAG", l: { ar: "إجابات من داتا شركتك فقط", en: "Answers from your own data" } },
  { v: "4+", l: { ar: "شخصيات متخصصة جاهزة", en: "Ready specialist personas" } },
  { v: "24/7", l: { ar: "خدمة مستقرة بتوزيع المفاتيح", en: "Stable service via key rotation" } },
];

export const challenge = {
  kicker: { ar: "التحدي", en: "The challenge" },
  title: { ar: "معرفة الشركة محبوسة في ملفات… ومحتاجة حد يسأل عليها", en: "Your company's knowledge is locked in files — and someone always has to ask" },
  points: [
    { t: { ar: "معلومات متفرقة", en: "Scattered knowledge" }, d: { ar: "اللوائح والعقود والأسعار والإجراءات موزعة في ملفات وأشخاص.", en: "Policies, contracts, prices and procedures spread across files and people." } },
    { t: { ar: "وقت ضائع", en: "Lost time" }, d: { ar: "الموظف بيستنى زميله أو المدير عشان يعرف معلومة بسيطة.", en: "Staff wait on colleagues or managers for simple answers." } },
    { t: { ar: "ذكاء عام غير دقيق", en: "Generic AI guesses" }, d: { ar: "أدوات الذكاء العامة لا تعرف بيانات شركتك وقد تخترع إجابات خاطئة.", en: "Generic AI tools don't know your data and can invent wrong answers." } },
  ],
  solution: {
    ar: "الحل: Agent ذكي خاص بـ Shawky Group، تكلمه بصوتك أو توريه بالكاميرا، فيرد فوراً من بيانات الشركة الحقيقية — والمدير يصحح أي معلومة لحظياً.",
    en: "The solution: a private Shawky Group AI agent you talk to by voice or show through the camera, answering instantly from real company data — with managers correcting any answer in real time.",
  },
};

export type ModuleImg = "voice" | "rag" | "admin" | "personas" | "api";
export type Module = { n: string; title: T; tag: string; items: T[]; cond: T; img: ModuleImg };

export const modules: Module[] = [
  {
    n: "01", tag: "Realtime Multimodal Engine", img: "voice",
    title: { ar: "محرك المحادثة الحية التفاعلية", en: "Realtime Multimodal Engine" },
    items: [
      { ar: "بناء خط الاتصال المباشر (WebRTC / Live Streaming) لدعم المحادثة الصوتية اللحظية والرؤية عبر الكاميرا.", en: "Direct live connection (WebRTC / Live Streaming) for real-time voice conversation and camera vision." },
      { ar: "منظومة توزيع المفاتيح وتقليل التكلفة (API Load Balancer & Key Rotation) لضمان استقرار الخدمة وتوفير الاستهلاك.", en: "API Load Balancer & Key Rotation to keep the service stable and cut consumption costs." },
    ],
    cond: { ar: "دفعة مقدمة (عربون تعاقد لبدء العمل).", en: "Upfront payment (contract deposit to start work)." },
  },
  {
    n: "02", tag: "RAG & Chunking System", img: "rag",
    title: { ar: "عقل الـ Agent ومنظومة المعرفة الداخلية", en: "Agent Brain & Internal Knowledge System" },
    items: [
      { ar: "محرك تقسيم المستندات والبيانات إلى (Chunks) وحفظها في قاعدة بيانات متجهات (Vector Database).", en: "Engine that splits documents and data into chunks stored in a Vector Database." },
      { ar: "ربط الـ API للبحث الذاتي داخل داتا الشركة وجلب المعلومة المحددة للموظف أو العميل أو المدير بدقة.", en: "Search API that retrieves the exact information from company data for staff, customers or managers." },
    ],
    cond: { ar: "تُدفع عند إثبات استرجاع بيانات الشركة في بيئة الاختبار.", en: "Due once company-data retrieval is proven in the test environment." },
  },
  {
    n: "03", tag: "Admin & Knowledge Correction", img: "admin",
    title: { ar: "لوحة تحكم الإدارة وتغذية وتصحيح المفاهيم", en: "Admin & Knowledge Correction Panel" },
    items: [
      { ar: "واجهة للمدير لرفع الملفات والبيانات وتحديثها لحظياً.", en: "Manager interface to upload and update files and data in real time." },
      { ar: "ميزة \"تصحيح المفاهيم\" (Knowledge Override / Feedback Loop) لتعديل أي إجابة خاطئة وإلزام الموديل بالمعلومة المصححة.", en: "\"Knowledge Override\" feedback loop to fix any wrong answer and bind the model to the corrected information." },
    ],
    cond: { ar: "تُدفع فور اكتمال لوحة المدير وتجربة رفع الملفات وتصحيحها.", en: "Due once the admin panel is complete and file upload & correction are tested." },
  },
  {
    n: "04", tag: "Multi-Agent Personas Hub", img: "personas",
    title: { ar: "منظومة الشخصيات المتعددة الجاهزة", en: "Multi-Agent Personas Hub" },
    items: [
      { ar: "بيئة التبديل بين الشخصيات المتخصصة (محاسب، محامي، مهندس، IT، إلخ).", en: "Switch between specialist personas (accountant, lawyer, engineer, IT, etc.)." },
      { ar: "قواعد توجيه وسياق (System Prompts) احترافية لكل تخصص.", en: "Professional routing rules and context (System Prompts) for each specialty." },
    ],
    cond: { ar: "تُدفع عند تسليم المنصة كاملة وتدريب المدير عليها.", en: "Due on full platform handover and manager training." },
  },
  {
    n: "05", tag: "API Consumption & Operations", img: "api",
    title: { ar: "باقة استهلاك ومعالجة الـ API (بند تشغيلي منفصل)", en: "API Consumption & Operations Package (separate)" },
    items: [
      { ar: "بند استهلاك شهري مستقل يغطي الترافيك وتشغيل الخوادم.", en: "Independent monthly item covering traffic and server operation." },
      { ar: "إدارة الـ Load Balancer وصيانة المفاتيح، ومنفصل تماماً عن تكلفة بناء وبرمجة السيستم.", en: "Load Balancer management and key maintenance — fully separate from build cost." },
    ],
    cond: { ar: "اشتراك تشغيل يُدفع شهرياً لتغطية السيرفر وصيانة المفاتيح.", en: "Monthly operating subscription covering the server and key maintenance." },
  },
];

export const screens = {
  kicker: { ar: "الشخصيات المتخصصة", en: "Specialist personas" },
  title: { ar: "خبير لكل قسم… في نفس المنصة", en: "An expert for every department — in one platform" },
  list: [
    { t: { ar: "المحاسب", en: "Accountant" }, d: { ar: "حسابات وفواتير وتقارير مالية من بيانات الشركة.", en: "Accounts, invoices and financial reports from company data." } },
    { t: { ar: "المحامي", en: "Lawyer" }, d: { ar: "قراءة العقود واللوائح وتوضيح البنود.", en: "Reads contracts and policies and explains clauses." } },
    { t: { ar: "المهندس", en: "Engineer" }, d: { ar: "مواصفات فنية ومراجعة مواقع بالكاميرا.", en: "Technical specs and on-site review via camera." } },
    { t: { ar: "خبير IT", en: "IT expert" }, d: { ar: "دعم تقني فوري للأنظمة والأجهزة.", en: "Instant tech support for systems and devices." } },
  ],
};

export type PriceRow = { n: string; item: T; en: string; price: string; pay: T };
export const pricing = {
  kicker: { ar: "الاستثمار", en: "Investment" },
  title: { ar: "استثمار واضح… مرتبط بإنجاز حقيقي", en: "Transparent investment, tied to real milestones" },
  sub: { ar: "كل دفعة مرتبطة بمخرج ملموس تراه وتختبره بنفسك قبل السداد.", en: "Every payment is tied to a tangible deliverable you see and test yourself first." },
  head: { item: { ar: "البند / المكون", en: "Item / Component" }, price: { ar: "السعر", en: "Price" }, pay: { ar: "آلية الاستحقاق والسداد", en: "Milestone & payment" } },
  rows: [
    { n: "1", item: { ar: "محرك الصوت والكاميرا الحي والـ Load Balancer", en: "Live voice & camera engine + Load Balancer" }, en: "Realtime Multimodal Engine", price: "$450", pay: { ar: "دفعة مقدمة (عربون تعاقد لبدء العمل)", en: "Upfront (contract deposit to start work)" } },
    { n: "2", item: { ar: "منظومة الـ RAG، تقسيم البيانات (Chunks)، والربط بالداتا بيز", en: "RAG system, data chunking & database integration" }, en: "RAG & Chunking System", price: "$400", pay: { ar: "تُدفع عند إثبات استرجاع بيانات الشركة في بيئة الاختبار", en: "Due once company-data retrieval is proven in testing" } },
    { n: "3", item: { ar: "لوحة التحكم وتغذية وتصحيح المفاهيم (Admin Panel)", en: "Admin panel, data feeding & knowledge correction" }, en: "Admin & Knowledge Correction", price: "$350", pay: { ar: "تُدفع فور اكتمال لوحة المدير وتجربة رفع الملفات وتصحيحها", en: "Due when the admin panel, upload & correction are tested" } },
    { n: "4", item: { ar: "حزمة الشخصيات المتخصصة (Multi-Agent Profiles)", en: "Specialist personas pack (Multi-Agent Profiles)" }, en: "Multi-Agent Personas Hub", price: "$200", pay: { ar: "تُدفع عند تسليم المنصة كاملة وتدريب المدير عليها", en: "Due on full handover and manager training" } },
  ] as PriceRow[],
  total: { label: { ar: "إجمالي تكلفة التأسيس والبرمجة", en: "Total setup & development" }, price: "$1,400", note: { ar: "إجمالي تكلفة النظام الجاهز للمشروع الثاني", en: "Total cost of the ready system for the second project" } },
  retainer: { n: "5", item: { ar: "باقة تشغيل واستهلاك الـ API وإدارة الـ Load Balancer", en: "API operations, consumption & Load Balancer management" }, en: "API Operations", price: "$50 – $80", per: { ar: "شهرياً", en: "per month" }, pay: { ar: "اشتراك تشغيل يُدفع شهرياً لتغطية السيرفر وصيانة المفاتيح", en: "Monthly subscription covering the server and key maintenance" } },
};

export const terms = {
  kicker: { ar: "شروط التعاقد", en: "Contract terms" },
  title: { ar: "شروط واضحة تحمي الطرفين", en: "Clear terms that protect both sides" },
  list: [
    {
      t: { ar: "شرط الاستهلاك العادل (Fair Usage Policy)", en: "Fair Usage Policy" },
      d: {
        ar: "منظومة الـ Load Balancer تضمن خفض التكلفة التشغيلية لأقصى حد بالاعتماد على الموارد المتاحة، وفي حال تخطي حدود الاستخدام المجاني للنماذج الخارجية نتيجة الاستخدام الكثيف للصوت والفيديو، يتحمل العميل الفارق الفعلي لتكلفة الـ API.",
        en: "The Load Balancer keeps operating costs as low as possible using available resources. If free usage limits of external models are exceeded due to heavy voice and video use, the client covers the actual API cost difference.",
      },
    },
    {
      t: { ar: "شرط تسليم الشخصيات الإضافية", en: "Personas delivery scope" },
      d: {
        ar: "تقتصر الشخصيات (المحاسب، المحامي، المهندس...) على إعداد الـ Prompting والتوجيه المعرفي الأساسي، وأي دمج لهذه الشخصيات بقواعد بيانات حكومية أو خارجية معقدة يخضع لعرض سعر مستقل.",
        en: "Personas (accountant, lawyer, engineer...) cover core prompting and knowledge guidance only. Any integration with government or complex external databases is quoted separately.",
      },
    },
  ],
};

export const milestones = {
  kicker: { ar: "خارطة التنفيذ", en: "Delivery roadmap" },
  title: { ar: "رحلة واضحة من التعاقد إلى التشغيل", en: "A clear path from signature to go-live" },
  steps: [
    { t: { ar: "التعاقد والانطلاق", en: "Kick-off" }, d: { ar: "توقيع العرض وسداد العربون وبناء محرك الصوت والكاميرا.", en: "Sign, deposit and build the voice & camera engine." }, p: "$450" },
    { t: { ar: "إثبات المعرفة", en: "Knowledge proof" }, d: { ar: "استرجاع بيانات الشركة بدقة في بيئة الاختبار.", en: "Accurate company-data retrieval in testing." }, p: "$400" },
    { t: { ar: "لوحة الإدارة", en: "Admin panel" }, d: { ar: "رفع الملفات وتصحيح المفاهيم لحظياً.", en: "Live file upload and knowledge correction." }, p: "$350" },
    { t: { ar: "التسليم والتدريب", en: "Handover" }, d: { ar: "تفعيل الشخصيات وتدريب المدير على المنصة.", en: "Personas live and manager trained." }, p: "$200" },
    { t: { ar: "التشغيل المستمر", en: "Operations" }, d: { ar: "استهلاك API وإدارة الخوادم والمفاتيح شهرياً.", en: "Monthly API, servers and key management." }, p: "$50–80/mo" },
  ],
};

export const why = {
  kicker: { ar: "لماذا Star Tech", en: "Why Star Tech" },
  title: { ar: "ذكاء اصطناعي خاص بشركتك… مش أداة عامة", en: "AI built for your company — not a generic tool" },
  list: [
    { t: { ar: "تكلفة تشغيل منخفضة", en: "Low running cost" }, d: { ar: "Load Balancer وتدوير مفاتيح يخفّض فاتورة الـ API لأقصى حد.", en: "Load balancing and key rotation minimise your API bill." } },
    { t: { ar: "خصوصية بياناتك", en: "Data privacy" }, d: { ar: "معرفة الشركة محفوظة في قاعدة بيانات خاصة بك.", en: "Company knowledge kept in your own private database." } },
    { t: { ar: "دقة قابلة للتصحيح", en: "Correctable accuracy" }, d: { ar: "المدير يصحح أي إجابة، والموديل يلتزم بها فوراً.", en: "Managers fix any answer and the model follows it instantly." } },
    { t: { ar: "دفع مقابل إنجاز", en: "Pay per milestone" }, d: { ar: "لا تدفع إلا مقابل مخرج تراه وتختبره بنفسك.", en: "You only pay for what you see and test yourself." } },
  ],
};

export const closing = {
  title: { ar: "جاهزين نبني عقل Shawky Group الرقمي", en: "Ready to build Shawky Group's digital brain" },
  sub: { ar: "بمجرد اعتماد العرض وسداد العربون، يبدأ فريق Star Tech فوراً في بناء محرك الصوت والكاميرا.", en: "Once approved and the deposit is received, Star Tech starts building the live voice & camera engine immediately." },
  sign: { ar: "اعتماد العميل", en: "Client approval" },
  signBy: { ar: "عن Star Tech", en: "For Star Tech" },
};
