import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Download, FileText, Clock, Scale, Languages, MessageCircle, Zap, Shield, Users, Check, ArrowDown, TrendingUp, Lock, Coins, Layers } from "lucide-react";
import logo from "@/assets/startech-logo.png";
import heroImg from "@/assets/ai-hero.jpg";
import heroVideo from "@/assets/ai-hero-loop.mp4";
import voiceImg from "@/assets/ai-voice.jpg";
import voiceVideo from "@/assets/ai-voice-loop.mp4";
import ragImg from "@/assets/ai-rag.jpg";
import ragVideo from "@/assets/ai-rag-loop.mp4";
import adminImg from "@/assets/ai-admin.jpg";
import personasImg from "@/assets/ai-personas.jpg";
import personasVideo from "@/assets/ai-personas-loop.mp4";
import apiImg from "@/assets/ai-api.jpg";
import closingImg from "@/assets/closing.jpg";
import closingVideo from "@/assets/closing-loop.mp4";
import { type Lang, meta, ui, stats, challenge, modules, screens, pricing, terms, milestones, why, closing, type ModuleImg } from "@/lib/proposal";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Star Tech × Shawky Group — AI Agent Platform Proposal" },
      { name: "description", content: "Star Tech proposal for Shawky Group: a live voice & camera AI agent trained on company data, with admin correction and specialist personas." },
      { property: "og:title", content: "Star Tech × Shawky Group — Proposal" },
      { property: "og:description", content: "Live voice & vision AI agent with RAG knowledge, admin correction and multi-agent personas." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const imgs: Record<ModuleImg, string> = { voice: voiceImg, rag: ragImg, admin: adminImg, personas: personasImg, api: apiImg };
const vids: Partial<Record<ModuleImg, string>> = { voice: voiceVideo, rag: ragVideo };
const whyIcons = [Coins, Lock, Shield, TrendingUp];

function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll(".reveal");
    const io = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && e.target.classList.add("in")), { threshold: 0.12 });
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
}

function Kicker({ children }: { children: React.ReactNode }) {
  return (
    <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-xs font-bold tracking-wider text-primary">
      <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse-ring" />
      {children}
    </div>
  );
}

function Index() {
  const [lang, setLang] = useState<Lang>("ar");
  const L = lang;
  const dir = lang === "ar" ? "rtl" : "ltr";
  useReveal();
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = dir;
  }, [lang, dir]);

  return (
    <div dir={dir} className="min-h-screen overflow-x-hidden">
      {/* Top bar: language toggle + logo */}
      <div className="fixed inset-x-0 top-0 z-50">
        <div className="mx-auto flex max-w-7xl items-center justify-end gap-3 px-4 py-3 sm:px-6" dir="ltr">
          <div className="glass flex items-center gap-2 rounded-full py-1.5 pl-1.5 pr-4">
            <button
              onClick={() => setLang(lang === "ar" ? "en" : "ar")}
              className="inline-flex items-center gap-1.5 rounded-full bg-secondary px-3 py-1.5 text-xs font-bold text-secondary-foreground transition hover:bg-muted"
            >
              <Languages className="h-3.5 w-3.5" /> {ui.toggle[L]}
            </button>
            <span className="rounded-full bg-paper px-2.5 py-1"><img src={logo} alt="Star Tech" className="h-6 w-auto sm:h-7" /></span>
          </div>
        </div>
      </div>

      {/* HERO */}
      <section className="relative flex min-h-[100svh] items-center overflow-hidden">
        <video className="absolute inset-0 h-full w-full object-cover" src={heroVideo} poster={heroImg} autoPlay muted loop playsInline />
        <div className="absolute inset-0 bg-background/70" />
        <div className="absolute inset-0 bg-hero-glow" />
        <div className="absolute inset-x-0 bottom-0 h-48 bg-fade" />
        <div className="relative mx-auto w-full max-w-7xl px-5 pb-20 pt-32 sm:px-6">
          <div className="max-w-4xl animate-rise">
            <p className="text-sm text-muted-foreground sm:text-base">{ui.preparedFor[L]}</p>
            <p className="mt-1 font-display text-xl font-bold sm:text-2xl" dir="ltr" style={{ textAlign: dir === "rtl" ? "right" : "left" }}>
              {meta.client} <span className="text-primary">·</span> {meta.company}
            </p>
            <h1 className="mt-6 text-4xl font-black leading-[1.15] sm:text-6xl lg:text-7xl">
              <span className="text-gradient">{ui.heroTitle[L]}</span>
            </h1>
            <p className="mt-6 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">{ui.heroSub[L]}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href="#pricing" className="rounded-full bg-primary px-6 py-3 font-bold text-primary-foreground shadow-glow transition hover:scale-105">{ui.ctaPrice[L]}</a>
              <a href="#scope" className="glass rounded-full px-6 py-3 font-bold transition hover:bg-secondary">{ui.ctaScope[L]}</a>
            </div>
          </div>
          <div className="mt-16 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
            {stats.map((s, i) => (
              <div key={i} className="glass rounded-2xl p-4 sm:p-6 animate-rise" style={{ animationDelay: `${0.2 + i * 0.1}s` }}>
                <div className="font-display text-3xl font-bold text-gradient sm:text-4xl" dir="ltr">{s.v}</div>
                <div className="mt-1 text-xs text-muted-foreground sm:text-sm">{s.l[L]}</div>
              </div>
            ))}
          </div>
          <div className="mt-6 flex flex-wrap gap-x-6 gap-y-1 text-xs text-muted-foreground">
            <span>{ui.ref[L]}: <b className="text-foreground" dir="ltr">{meta.ref}</b></span>
            <span>{ui.date[L]}: <b className="text-foreground">{meta.date[L]}</b></span>
            <span>{meta.validity[L]}</span>
          </div>
        </div>
        <ArrowDown className="absolute bottom-6 left-1/2 h-5 w-5 -translate-x-1/2 animate-bounce text-muted-foreground" />
      </section>

      {/* CHALLENGE */}
      <section className="relative py-24 sm:py-32">
        <div className="absolute inset-0 grid-lines opacity-60" />
        <div className="relative mx-auto max-w-7xl px-5 sm:px-6">
          <div className="reveal max-w-3xl">
            <Kicker>{challenge.kicker[L]}</Kicker>
            <h2 className="text-3xl font-black leading-tight sm:text-5xl">{challenge.title[L]}</h2>
          </div>
          <div className="mt-12 grid gap-4 md:grid-cols-3">
            {challenge.points.map((p, i) => {
              const Icon = [FileText, Clock, Zap][i]!;
              return (
                <div key={i} className="reveal glass rounded-3xl p-7 transition hover:-translate-y-1" style={{ transitionDelay: `${i * 0.1}s` }}>
                  <Icon className="h-8 w-8 text-destructive" />
                  <h3 className="mt-4 text-xl font-bold">{p.t[L]}</h3>
                  <p className="mt-2 text-muted-foreground">{p.d[L]}</p>
                </div>
              );
            })}
          </div>
          <div className="reveal mt-8 rounded-3xl border border-primary/30 bg-primary/10 p-7 text-lg font-bold sm:text-xl">
            <Check className="mb-3 h-7 w-7 text-primary" />
            {challenge.solution[L]}
          </div>
        </div>
      </section>

      {/* SCOPE */}
      <section id="scope" className="py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-5 sm:px-6">
          <div className="reveal mb-14 max-w-3xl">
            <Kicker>{ui.scopeKicker[L]}</Kicker>
            <h2 className="text-3xl font-black leading-tight sm:text-5xl">{ui.scopeTitle[L]}</h2>
          </div>
          <div className="space-y-8 sm:space-y-12">
            {modules.map((m, i) => (
              <article key={m.n} className={`reveal grid items-center gap-6 overflow-hidden rounded-[2rem] glass p-4 shadow-card sm:p-6 lg:grid-cols-2 lg:gap-10 lg:p-8`}>
                <div className={`relative overflow-hidden rounded-3xl ${i % 2 ? "lg:order-2" : ""}`}>
                  {vids[m.img] ? (<video src={vids[m.img]} poster={imgs[m.img]} autoPlay muted loop playsInline className="aspect-[4/3] w-full object-cover" />) : (<img src={imgs[m.img]} alt={m.title.en} loading="lazy" width={1280} height={960} className="aspect-[4/3] w-full object-cover transition duration-700 hover:scale-105" />)}
                  <div className="absolute start-4 top-4 rounded-full bg-background/80 px-3 py-1 font-display text-sm font-bold text-primary backdrop-blur" dir="ltr">{m.tag}</div>
                </div>
                <div className="p-2">
                  <div className="font-display text-6xl font-bold text-gradient opacity-90">{m.n}</div>
                  <h3 className="mt-2 text-2xl font-black sm:text-3xl">{m.title[L]}</h3>
                  <ul className="mt-5 space-y-3">
                    {m.items.map((it, j) => (
                      <li key={j} className="flex gap-3">
                        <Check className="mt-1 h-5 w-5 shrink-0 text-primary" />
                        <span className="text-muted-foreground">{it[L]}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="mt-6 rounded-2xl border-s-4 border-accent bg-secondary/60 p-4 text-sm">
                    <b className="text-accent">{ui.cond[L]}: </b>
                    <span className="text-muted-foreground">{m.cond[L]}</span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* SCREENS + VIDEO */}
      <section className="py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-5 sm:px-6">
          <div className="reveal mx-auto max-w-3xl text-center">
            <Kicker>{screens.kicker[L]}</Kicker>
            <h2 className="text-3xl font-black sm:text-5xl">{screens.title[L]}</h2>
          </div>
          <div className="reveal relative mt-12 overflow-hidden rounded-[2rem] border border-border shadow-glow">
            <video className="aspect-video w-full object-cover" src={personasVideo} poster={personasImg} autoPlay muted loop playsInline />
            <div className="absolute inset-x-0 bottom-0 h-1/2 bg-fade" />
          </div>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {screens.list.map((s, i) => (
              <div key={i} className="reveal glass rounded-3xl p-6">
                <Layers className="h-6 w-6 text-primary" />
                <h3 className="mt-3 text-xl font-bold">{s.t[L]}</h3>
                <p className="mt-1 text-muted-foreground">{s.d[L]}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section id="pricing" className="relative py-24 sm:py-32">
        <div className="absolute inset-0 bg-hero-glow" />
        <div className="relative mx-auto max-w-6xl px-5 sm:px-6">
          <div className="reveal mx-auto max-w-3xl text-center">
            <Kicker>{pricing.kicker[L]}</Kicker>
            <h2 className="text-3xl font-black sm:text-5xl">{pricing.title[L]}</h2>
            <p className="mt-4 text-muted-foreground">{pricing.sub[L]}</p>
          </div>

          <div className="mt-12 space-y-3">
            {pricing.rows.map((r) => (
              <div key={r.n} className="reveal glass grid gap-3 rounded-2xl p-5 sm:grid-cols-[3rem_1fr_auto] sm:items-center sm:gap-6 sm:p-6">
                <div className="font-display text-2xl font-bold text-primary">0{r.n}</div>
                <div>
                  <div className="text-lg font-bold">{r.item[L]}</div>
                  <div className="text-xs text-muted-foreground" dir="ltr" style={{ textAlign: dir === "rtl" ? "right" : "left" }}>{r.en}</div>
                  <div className="mt-2 inline-flex items-center gap-2 rounded-full bg-secondary px-3 py-1 text-xs text-muted-foreground">
                    <Check className="h-3.5 w-3.5 text-primary" /> {r.pay[L]}
                  </div>
                </div>
                <div className="font-display text-3xl font-bold sm:text-end" dir="ltr">{r.price}</div>
              </div>
            ))}

            <div className="reveal relative overflow-hidden rounded-3xl bg-gradient-brand p-7 text-primary-foreground shadow-glow sm:p-10">
              <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
                <div>
                  <div className="text-xl font-black sm:text-2xl">{pricing.total.label[L]}</div>
                  <div className="mt-1 opacity-80">{pricing.total.note[L]}</div>
                </div>
                <div className="font-display text-5xl font-bold sm:text-6xl" dir="ltr">{pricing.total.price}</div>
              </div>
            </div>

            <div className="reveal grid gap-3 rounded-2xl border border-accent/40 bg-accent/10 p-5 sm:grid-cols-[3rem_1fr_auto] sm:items-center sm:gap-6 sm:p-6">
              <div className="font-display text-2xl font-bold text-accent">05</div>
              <div>
                <div className="text-lg font-bold">{pricing.retainer.item[L]}</div>
                <div className="mt-2 text-sm text-muted-foreground">{pricing.retainer.pay[L]}</div>
              </div>
              <div className="sm:text-end"><div className="font-display text-2xl font-bold" dir="ltr">{pricing.retainer.price}</div><div className="text-xs text-muted-foreground">{pricing.retainer.per[L]}</div></div>
            </div>
          </div>
        </div>
      </section>

      {/* TERMS */}
      <section className="py-16 sm:py-20">
        <div className="mx-auto max-w-6xl px-5 sm:px-6">
          <div className="reveal max-w-3xl">
            <Kicker>{terms.kicker[L]}</Kicker>
            <h2 className="text-3xl font-black sm:text-5xl">{terms.title[L]}</h2>
          </div>
          <div className="mt-10 grid gap-4 md:grid-cols-2">
            {terms.list.map((t, i) => (
              <div key={i} className="reveal glass rounded-3xl border-s-4 border-s-primary p-7">
                <Scale className="h-7 w-7 text-primary" />
                <h3 className="mt-4 text-xl font-bold">{t.t[L]}</h3>
                <p className="mt-2 leading-relaxed text-muted-foreground">{t.d[L]}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* MILESTONES */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-5 sm:px-6">
          <div className="reveal max-w-3xl">
            <Kicker>{milestones.kicker[L]}</Kicker>
            <h2 className="text-3xl font-black sm:text-5xl">{milestones.title[L]}</h2>
          </div>
          <ol className="relative mt-12 grid gap-4 md:grid-cols-5">
            <div className="absolute inset-x-0 top-6 hidden h-px bg-gradient-brand md:block" />
            {milestones.steps.map((s, i) => (
              <li key={i} className="reveal relative" style={{ transitionDelay: `${i * 0.08}s` }}>
                <div className="relative z-10 flex h-12 w-12 items-center justify-center rounded-full bg-gradient-brand font-display text-lg font-bold text-primary-foreground shadow-glow">{i + 1}</div>
                <div className="glass mt-4 rounded-2xl p-5">
                  <h3 className="font-bold">{s.t[L]}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{s.d[L]}</p>
                  {s.p && <div className="mt-3 font-display font-bold text-primary" dir="ltr">{s.p}</div>}
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* WHY */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-5 sm:px-6">
          <div className="reveal max-w-3xl">
            <Kicker>{why.kicker[L]}</Kicker>
            <h2 className="text-3xl font-black leading-tight sm:text-5xl">{why.title[L]}</h2>
          </div>
          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {why.list.map((w, i) => {
              const Icon = whyIcons[i]!;
              return (
                <div key={i} className="reveal glass group rounded-3xl p-7 transition hover:-translate-y-1 hover:border-primary/50">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/15"><Icon className="h-6 w-6 text-primary" /></div>
                  <h3 className="mt-5 text-lg font-bold">{w.t[L]}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{w.d[L]}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CLOSING */}
      <section className="relative overflow-hidden py-28">
        <video src={closingVideo} poster={closingImg} autoPlay muted loop playsInline className="absolute inset-0 h-full w-full object-cover opacity-40" />
        <div className="absolute inset-0 bg-background/70" />
        <div className="reveal relative mx-auto max-w-3xl px-5 text-center">
          <div className="mx-auto w-fit rounded-3xl bg-paper px-6 py-4 shadow-glow"><img src={logo} alt="Star Tech" className="h-14 w-auto sm:h-16" /></div>
          <h2 className="mt-8 text-3xl font-black sm:text-5xl"><span className="text-gradient">{closing.title[L]}</span></h2>
          <p className="mt-4 text-lg text-muted-foreground">{closing.sub[L]}</p>
        </div>
      </section>

      <footer className="border-t border-border py-8 text-center text-xs text-muted-foreground" dir="ltr">
        © 2026 Star Tech — Smart Solutions. Stronger Future · Prepared for {meta.company} ({meta.site})
      </footer>
    </div>
  );
}
