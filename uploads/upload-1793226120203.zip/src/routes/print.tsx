import { createFileRoute } from "@tanstack/react-router";
import logo from "@/assets/startech-logo.png";
import { meta, ui, stats, screens, modules, pricing, terms, milestones, why, closing, challenge } from "@/lib/proposal";

export const Route = createFileRoute("/print")({
  head: () => ({
    meta: [
      { title: "Star Tech × Shawky Group — Printable Proposal" },
      { name: "description", content: "A4 printable proposal for the Shawky Group AI agent platform." },
      { property: "og:title", content: "Star Tech × Shawky Group — Printable Proposal" },
      { property: "og:description", content: "A4 printable proposal for the Shawky Group AI agent platform." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: PrintPage,
});

const a = "ar" as const;

function Page({ children, n }: { children: React.ReactNode; n: number }) {
  return (
    <section className="print-page relative mx-auto flex flex-col bg-paper text-paper-foreground">
      <header className="flex items-center justify-between border-b-2 border-primary px-[14mm] py-[6mm]">
        <img src={logo} alt="Star Tech" className="h-[11mm] w-auto" />
        <div className="text-left text-[9pt] leading-tight opacity-70" dir="ltr">
          <div>{meta.ref}</div>
          <div>{meta.date.en}</div>
        </div>
      </header>
      <div className="flex flex-1 flex-col px-[14mm] py-[8mm] [&>*:only-child]:flex-1">{children}</div>
      <footer className="flex items-center justify-between px-[14mm] py-[5mm] text-[8pt] opacity-60">
        <span dir="ltr">Star Tech — Smart Solutions. Stronger Future</span>
        <span dir="ltr">{n} / 3</span>
      </footer>
    </section>
  );
}

function H({ k, t }: { k: string; t: string }) {
  return (
    <div className="mb-[5mm]">
      <div className="text-[9pt] font-bold tracking-widest text-primary">{k}</div>
      <h2 className="text-[17pt] font-extrabold leading-snug">{t}</h2>
    </div>
  );
}

function PrintPage() {
  return (
    <div dir="rtl" lang="ar" className="print-root bg-muted py-6 print:bg-paper print:py-0">
      <style>{`
        @page { size: A4; margin: 0; }
        .print-page { width: 210mm; height: 297mm; overflow: hidden; margin-bottom: 8mm; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        @media print { .print-page { margin: 0; break-after: page; } }
      `}</style>

      <Page n={1}>
        <div className="relative mb-[7mm] overflow-hidden rounded-2xl border border-primary/30 px-[6mm] py-[6mm]" style={{ background: "oklch(0.985 0.012 152)" }}>
          <div className="absolute inset-y-0 right-0 w-[2.5mm] bg-primary" />
          <div className="text-[9.5pt] font-bold tracking-wide text-primary">{ui.preparedFor[a]}</div>
          <div className="mt-[2mm] text-[24pt] font-black leading-tight" dir="ltr" style={{ textAlign: "right" }}>
            {meta.client} <span className="text-primary">—</span> {meta.company}
          </div>
          <div className="mt-[2mm] text-[9pt] opacity-70" dir="ltr" style={{ textAlign: "right" }}>
            {meta.site} · {meta.ref} · {meta.date[a]}
          </div>
        </div>
        <h1 className="text-[22pt] font-black leading-tight">{ui.heroTitle[a]}</h1>
        <p className="mt-[4mm] text-[11pt] leading-relaxed opacity-80">{ui.heroSub[a]}</p>
        <div className="mt-[6mm] rounded-xl border-r-4 border-primary bg-muted/0 p-[5mm]" style={{ background: "oklch(0.97 0.02 152)" }}>
          <div className="text-[11pt] font-bold">{challenge.title[a]}</div>
          <ul className="mt-[3mm] space-y-[2mm] text-[10pt]">
            {challenge.points.map((p) => (
              <li key={p.t.en}><b className="text-primary">{p.t[a]}: </b>{p.d[a]}</li>
            ))}
          </ul>
          <p className="mt-[3mm] text-[10pt] font-semibold">{challenge.solution[a]}</p>
        </div>
        <div className="mt-[7mm] grid grid-cols-3 gap-[4mm] text-[9pt]">
          <Info l={ui.ref[a]} v={meta.ref} />
          <Info l={ui.date[a]} v={meta.date[a]} />
          <Info l="الصلاحية" v={meta.validity[a]} />
        </div>
        <div className="mt-[5mm] grid grid-cols-4 gap-[3mm]">
          {stats.map((s) => (
            <div key={s.l.en} className="rounded-xl border border-primary/25 p-[3.5mm] text-center" style={{ background: "oklch(0.985 0.012 152)" }}>
              <div className="text-[16pt] font-black leading-none text-primary" dir="ltr">{s.v}</div>
              <div className="mt-[1.5mm] text-[8pt] leading-snug opacity-75">{s.l[a]}</div>
            </div>
          ))}
        </div>
        <div className="mt-[7mm] rounded-xl border border-paper-foreground/15 p-[4mm]" style={{ breakInside: "avoid" }}>
          <div className="text-[10.5pt] font-extrabold">{screens.title[a]}</div>
          <div className="mt-[3mm] grid grid-cols-4 gap-[3mm] text-[8.5pt]">
            {screens.list.map((s) => (
              <div key={s.t.en} className="rounded-lg border border-primary/25 p-[3mm]" style={{ background: "oklch(0.985 0.012 152)" }}>
                <div className="text-[9.5pt] font-extrabold text-primary">{s.t[a]}</div>
                <div className="mt-[1mm] leading-snug opacity-75">{s.d[a]}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="mt-[7mm] flex items-center justify-between rounded-xl border border-paper-foreground/15 px-[5mm] py-[3.5mm] text-[9pt]">
          <span className="font-bold text-primary">{ui.ctaPrice[a]}</span>
          <span className="opacity-70">{pricing.rows.length} {pricing.head.item[a]} · {pricing.total.label[a]}</span>
        </div>
      </Page>

      <Page n={2}>
        <H k="نطاق العمل — SCOPE OF WORK" t="المخرجات التفصيلية لكل بند" />
        <div className="space-y-[3.5mm]">
          {modules.map((m) => (
            <div key={m.n} className="rounded-lg border border-paper-foreground/15 p-[3.5mm]" style={{ breakInside: "avoid" }}>
              <div className="flex items-baseline justify-between gap-2">
                <div className="text-[11.5pt] font-extrabold"><span className="text-primary">{m.n}. </span>{m.title[a]}</div>
                <div className="text-[8pt] font-semibold text-brand-blue" dir="ltr">{m.tag}</div>
              </div>
              <ul className="mt-[1.5mm] list-disc space-y-[0.8mm] pr-[5mm] text-[9pt] leading-snug">
                {m.items.map((i) => <li key={i.en}>{i[a]}</li>)}
              </ul>
              <div className="mt-[1.5mm] text-[8.5pt] leading-snug opacity-75"><b>شرط التسليم: </b>{m.cond[a]}</div>
            </div>
          ))}
        </div>
      </Page>

      <Page n={3}>
        <div className="flex h-full flex-col justify-between">
        <H k="الاستثمار — INVESTMENT" t={pricing.title[a]} />
        <table className="w-full border-collapse text-[9pt]">
          <thead>
            <tr className="bg-ink text-foreground">
              <th className="p-[2.5mm] text-right">#</th>
              <th className="p-[2.5mm] text-right">{pricing.head.item[a]}</th>
              <th className="p-[2.5mm] text-right">{pricing.head.price[a]}</th>
              <th className="p-[2.5mm] text-right">{pricing.head.pay[a]}</th>
            </tr>
          </thead>
          <tbody>
            {pricing.rows.map((r) => (
              <tr key={r.n} className="border-b border-paper-foreground/15">
                <td className="p-[2.5mm] font-bold text-primary">{r.n}</td>
                <td className="p-[2.5mm]"><div className="font-bold">{r.item[a]}</div><div className="text-[7.5pt] opacity-60" dir="ltr" style={{ textAlign: "right" }}>{r.en}</div></td>
                <td className="p-[2.5mm] text-[11pt] font-extrabold" dir="ltr" style={{ textAlign: "right" }}>{r.price}</td>
                <td className="p-[2.5mm]">{r.pay[a]}</td>
              </tr>
            ))}
            <tr className="bg-primary text-primary-foreground">
              <td className="p-[3mm]">—</td>
              <td className="p-[3mm] font-extrabold">{pricing.total.label[a]}</td>
              <td className="p-[3mm] text-[14pt] font-black" dir="ltr" style={{ textAlign: "right" }}>{pricing.total.price}</td>
              <td className="p-[3mm] font-semibold">{pricing.total.note[a]}</td>
            </tr>
            <tr className="border-b border-paper-foreground/15">
              <td className="p-[2.5mm] font-bold text-brand-blue">5</td>
              <td className="p-[2.5mm] font-bold">{pricing.retainer.item[a]}</td>
              <td className="whitespace-nowrap p-[2.5mm]"><div className="text-[11pt] font-extrabold" dir="ltr" style={{ textAlign: "right" }}>{pricing.retainer.price}</div><div className="text-[8pt] opacity-70">{pricing.retainer.per[a]}</div></td>
              <td className="p-[2.5mm]">{pricing.retainer.pay[a]}</td>
            </tr>
          </tbody>
        </table>

        <div className="mt-[4mm] text-[11pt] font-extrabold">{milestones.title[a]}</div>
        <ol className="mt-[2mm] grid grid-cols-5 gap-[2mm] text-[8pt]">
          {milestones.steps.map((s, i) => (
            <li key={i} className="rounded-md border-t-4 border-primary p-[2mm]" style={{ background: "oklch(0.97 0.01 240)" }}>
              <div className="font-bold">{i + 1}. {s.t[a]}</div>
              <div className="mt-[1mm] leading-snug opacity-75">{s.d[a]}</div>
              {s.p && <div className="mt-[1mm] font-extrabold text-primary" dir="ltr" style={{ textAlign: "right" }}>{s.p}</div>}
            </li>
          ))}
        </ol>

        <div className="mt-[5mm] space-y-[2mm] rounded-lg border border-primary/30 p-[3mm] text-[8.5pt] leading-snug">
          <div className="text-[10pt] font-extrabold">{terms.title[a]}</div>
          {terms.list.map((t) => <div key={t.t.en}><b className="text-primary">{t.t[a]}: </b>{t.d[a]}</div>)}
        </div>

        <div className="mt-[4mm] grid grid-cols-2 gap-[3mm] text-[8.5pt]">
          {why.list.map((w) => (
            <div key={w.t.en}><b className="text-primary">{w.t[a]}: </b>{w.d[a]}</div>
          ))}
        </div>

        <div className="mt-[5mm] grid grid-cols-2 gap-[10mm] text-[9pt]">
          {[closing.sign[a] + " — " + meta.client, closing.signBy[a]].map((l) => (
            <div key={l}>
              <div className="font-bold">{l}</div>
              <div className="mt-[9mm] border-b border-paper-foreground/40" />
              <div className="mt-[1mm] opacity-60">التوقيع / التاريخ</div>
            </div>
          ))}
        </div>
        </div>
      </Page>
    </div>
  );
}

function Info({ l, v }: { l: string; v: string }) {
  return (
    <div className="rounded-lg border border-paper-foreground/15 p-[3mm]">
      <div className="opacity-60">{l}</div>
      <div className="font-bold">{v}</div>
    </div>
  );
}
