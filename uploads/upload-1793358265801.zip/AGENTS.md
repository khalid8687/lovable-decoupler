<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep the paint catalogue client-side and label its RGB/HEX values as indicative demo data, because manufacturer screen colors are not purchase-grade formulas.
- All UI copy is English-only (user request, 2026-09-30) — no Arabic text anywhere in the interface, metadata, or catalogue.
- Brand the product as Shawky Group Colors (black/gold) and use the supplied Shawky Group logo; keep app media in src/assets, with only the required optimized favicon derivative in public.
- Source SCIB names, codes, families, and screen HEX values as one complete snapshot from SCIB's official shade JSON feed; do not hand-approximate individual SCIB shades.
- Source Nippon names, codes, and screen HEX values as one complete snapshot from Nippon Paint's official online colour library (nipponpaint.com.vn), listed first; families are derived from HEX.
