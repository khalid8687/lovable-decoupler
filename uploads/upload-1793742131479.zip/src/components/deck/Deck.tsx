import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft, ChevronRight, Maximize, Printer } from "lucide-react";
import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { SLIDES } from "./slides";

function Scaled({ children, fit = "contain" }: { children: ReactNode; fit?: "contain" | "width" }) {
  const ref = useRef<HTMLDivElement>(null);
  const [s, setS] = useState(0.3);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver(() => {
      const w = el.clientWidth / 1920, h = el.clientHeight / 1080;
      setS(fit === "width" ? w : Math.min(w, h));
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, [fit]);
  return (
    <div ref={ref} className="relative h-full w-full overflow-hidden">
      <div className="absolute left-1/2 top-1/2" style={{ width: 1920, height: 1080, marginLeft: -960, marginTop: -540, transform: `scale(${s})` }}>
        {children}
      </div>
    </div>
  );
}

const readHash = () => {
  const n = parseInt(window.location.hash.replace(/^#\/?/, ""), 10);
  return Number.isFinite(n) && n >= 1 && n <= SLIDES.length ? n - 1 : 0;
};

function MobileDeck() {
  const [z, setZ] = useState(0.4);
  useEffect(() => {
    const f = () => setZ(Math.min(window.innerWidth, 1100) / 900);
    f();
    window.addEventListener("resize", f);
    return () => window.removeEventListener("resize", f);
  }, []);
  return (
    <div className="m min-h-screen bg-navy-deep">
      <div className="sticky top-0 z-10 h-1 bg-gold-grad" />
      {SLIDES.map(({ C, title }, n) => (
        <section key={n} id={`m-${n + 1}`} aria-label={title} className="border-b-4 border-navy-deep" style={{ zoom: z }}>
          <C />
        </section>
      ))}
    </div>
  );
}

export function Deck() {
  const [i, setI] = useState(0);
  const [mobile, setMobile] = useState(false);
  const total = SLIDES.length;

  useEffect(() => {
    setI(readHash());
    const onHash = () => setI(readHash());
    const mq = window.matchMedia("(max-width: 767px), (max-width: 1100px) and (orientation: portrait)");
    const onMq = () => setMobile(mq.matches);
    onMq();
    window.addEventListener("hashchange", onHash);
    mq.addEventListener("change", onMq);
    return () => { window.removeEventListener("hashchange", onHash); mq.removeEventListener("change", onMq); };
  }, []);

  const go = useCallback((n: number) => {
    const t = Math.max(0, Math.min(total - 1, n));
    history.replaceState(null, "", `#/${t + 1}`);
    setI(t);
  }, [total]);

  useEffect(() => {
    document.title = `${i + 1}/${total} — ${SLIDES[i]!.title} | Cairo Code`;
  }, [i, total]);

  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (["ArrowLeft", " ", "PageDown"].includes(e.key)) { e.preventDefault(); go(i + 1); }
      if (["ArrowRight", "PageUp"].includes(e.key)) { e.preventDefault(); go(i - 1); }
      if (e.key === "Home") go(0);
      if (e.key === "End") go(total - 1);
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [i, go, total]);

  const touch = useRef<number | null>(null);
  const fs = () => (document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen());

  const Current = SLIDES[i]!.C;

  return (
    <>
      {/* screen */}
      <div className="no-print">
        {mobile ? (
          <MobileDeck />
        ) : (
          <div
            className="relative h-screen w-screen overflow-hidden bg-navy-deep"
            onTouchStart={(e) => (touch.current = e.touches[0]!.clientX)}
            onTouchEnd={(e) => {
              if (touch.current == null) return;
              const dx = e.changedTouches[0]!.clientX - touch.current;
              if (Math.abs(dx) > 50) go(dx > 0 ? i + 1 : i - 1);
              touch.current = null;
            }}
          >
            <AnimatePresence mode="wait">
              <motion.div key={i} className="absolute inset-0" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.35 }}>
                <Scaled><Current /></Scaled>
              </motion.div>
            </AnimatePresence>

            <div className="absolute inset-x-0 top-0 h-1.5 bg-primary-foreground/10">
              <motion.div className="h-full bg-gold-grad" animate={{ width: `${((i + 1) / total) * 100}%` }} />
            </div>

            <div className="absolute bottom-5 bg-navy-deep/85 backdrop-blur shadow-soft left-1/2 flex -translate-x-1/2 items-center gap-2 rounded-full px-3 py-2 text-primary-foreground">
              <button aria-label="السابق" onClick={() => go(i - 1)} className="rounded-full p-2 hover:bg-primary-foreground/15 disabled:opacity-30" disabled={i === 0}><ChevronRight /></button>
              <span className="num min-w-16 text-center font-bold">{i + 1} / {total}</span>
              <button aria-label="التالي" onClick={() => go(i + 1)} className="rounded-full p-2 hover:bg-primary-foreground/15 disabled:opacity-30" disabled={i === total - 1}><ChevronLeft /></button>
              <span className="mx-1 h-6 w-px bg-primary-foreground/25" />
              <button aria-label="ملء الشاشة" onClick={fs} className="rounded-full p-2 hover:bg-primary-foreground/15"><Maximize size={20} /></button>
              <button aria-label="طباعة / حفظ PDF" onClick={() => window.print()} className="rounded-full p-2 hover:bg-primary-foreground/15"><Printer size={20} /></button>
            </div>
          </div>
        )}
      </div>

      {/* print */}
      <div className="hidden print:block">
        {SLIDES.map(({ C }, n) => (
          <div key={n} className="print-page"><div className="scaler" style={{ width: 1920, height: 1080 }}><C /></div></div>
        ))}
      </div>
    </>
  );
}
