import { createFileRoute } from "@tanstack/react-router";
import { Deck } from "@/components/deck/Deck";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "منظومة الغربية الجديدة | عرض Cairo Code" },
      { name: "description", content: "عرض Cairo Code لشركة الغربية: نظام واحد يدير البيع والمخزون والحسابات أونلاين وأوفلاين." },
      { property: "og:title", content: "منظومة الغربية الجديدة | عرض Cairo Code" },
      { property: "og:description", content: "نظام واحد يدير البيع والمخزون والحسابات — أونلاين وأوفلاين." },
    ],
  }),
  component: Deck,
});
