import { useEffect, useRef, useState, type ReactNode } from "react";
import { SLIDES } from "./slides";
import logoLight from "@/assets/cairocode_logo_light.png";

function FitWidth({ children }: { children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  const [s, setS] = useState(0.5);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setS(el.clientWidth / 1920));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return (
    <div ref={ref} className="relative w-full overflow-hidden" style={{ height: 1080 * s }}>
      <div className="absolute right-0 top-0" style={{ width: 1920, height: 1080, transform: `scale(${s})`, transformOrigin: "top right" }}>
        {children}
      </div>
    </div>
  );
}

const NAV: [string, number][] = [
  ["الرؤية", 6], ["المزايا", 9], ["الخطة", 15], ["لماذا نحن", 16], ["الاستثمار", 17],
];

export function Deck() {
  const [mobile, setMobile] = useState(false);
  const [z, setZ] = useState(0.4);
  useEffect(() => {
    const mq = window.matchMedia("(max-width: 767px), (max-width: 1100px) and (orientation: portrait)");
    const f = () => { setMobile(mq.matches); setZ(Math.min(window.innerWidth, 1100) / 900); };
    f();
    window.addEventListener("resize", f);
    mq.addEventListener("change", f);
    return () => { window.removeEventListener("resize", f); mq.removeEventListener("change", f); };
  }, []);

  return (
    <>
      <div className="no-print min-h-screen bg-navy-deep">
        <header className="sticky top-0 z-50 border-b border-primary-foreground/10 bg-navy-deep/90 backdrop-blur">
          <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3">
            <a href="#s-1"><img src={logoLight} alt="Cairo Code" className="h-9 w-auto" /></a>
            <nav className="hidden items-center gap-6 text-primary-foreground/85 md:flex">
              {NAV.map(([l, n]) => <a key={l} href={`#s-${n + 1}`} className="font-semibold hover:text-gold">{l}</a>)}
            </nav>
            <a href={`#s-${SLIDES.length}`} className="rounded-full bg-gold-grad px-5 py-2 font-bold text-navy-deep">ابدأ معنا</a>
          </div>
        </header>
        <main className={mobile ? "m" : ""}>
          {SLIDES.map(({ C, title }, n) => (
            <section key={n} id={`s-${n + 1}`} aria-label={title} className="scroll-mt-16" style={mobile ? { zoom: z } : undefined}>
              {mobile ? <C /> : <FitWidth><C /></FitWidth>}
            </section>
          ))}
        </main>
        <footer className="py-8 text-center text-primary-foreground/60">© 2026 Cairo Code — جميع الحقوق محفوظة</footer>
      </div>
      <div className="hidden print:block">
        {SLIDES.map(({ C }, n) => (
          <div key={n} className="print-page"><div className="scaler" style={{ width: 1920, height: 1080 }}><C /></div></div>
        ))}
      </div>
    </>
  );
}
