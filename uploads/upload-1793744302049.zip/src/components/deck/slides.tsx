import { motion } from "framer-motion";
import {
  AlertTriangle, BadgeCheck, Banknote, BarChart3, Boxes, Brain, CalendarClock, CheckCircle2, ClipboardList,
  Cloud, CloudOff, Database, FileSpreadsheet, FileText, Gauge, GitMerge, HardDrive, Handshake, KeyRound, Layers,
  Lock, MessageCircle, Phone, Receipt, RefreshCw, ScanBarcode, Search, Server, Shield, ShieldCheck, Smartphone,
  Sparkles, Target, TrendingUp, Truck, Users, Warehouse, Wifi, Zap, Rocket, Trophy,
} from "lucide-react";
import type { ReactNode } from "react";
import { Card, Dark, Light, Logo, Media, fade } from "./parts";
import cover from "@/assets/cover_store.jpg";
import legacy from "@/assets/legacy_desk.jpg";
import iso from "@/assets/system_iso.jpg";
import warehouseVid from "@/assets/warehouse_flow.mp4";
import dashVid from "@/assets/manager_dashboard.mp4";

const N = ({ children }: { children: ReactNode }) => <span className="num">{children}</span>;

function Icon({ i: I, tone = "teal" }: { i: typeof Zap; tone?: "teal" | "gold" | "danger" | "navy" }) {
  const map = { teal: "bg-teal/10 text-teal", gold: "bg-gold/15 text-gold", danger: "bg-danger/10 text-danger", navy: "bg-navy/10 text-navy" };
  return <div className={`grid h-20 w-20 shrink-0 place-items-center rounded-2xl ${map[tone]}`}><I size={42} strokeWidth={1.8} /></div>;
}

/* 1 */
function Cover() {
  return (
    <Dark>
      <img src={cover} alt="" className="absolute inset-0 h-full w-full object-cover opacity-45" />
      <div className="absolute inset-0 bg-gradient-to-l from-navy-deep via-navy-deep/85 to-transparent" />
      <div className="relative flex h-full flex-col justify-between p-[110px]">
        <motion.div {...fade(0)} className="flex items-center justify-between">
          <Logo className="h-28" />
          <div className="glass rounded-full px-8 py-3 s-cap">عرض خاص لشركة الغربية لقطع غيار السيارات</div>
        </motion.div>
        <div className="max-w-[1150px]">
          <motion.div {...fade(0.1)} className="s-kicker mb-6 text-gold">نقلة كاملة… في شهر واحد فقط</motion.div>
          <motion.h1 {...fade(0.2)} className="s-title-lg">منظومة الغربية الجديدة</motion.h1>
          <motion.p {...fade(0.35)} className="s-sub mt-8 opacity-90">نظام واحد يدير البيع والمخزون والحسابات — أونلاين وأوفلاين</motion.p>
        </div>
        <motion.div {...fade(0.5)} className="flex items-center gap-4 s-body opacity-80">
          <span className="h-1 w-16 bg-gold-grad rounded-full" /> مقدَّم من Cairo Code — نوفمبر <N>2026</N>
        </motion.div>
      </div>
    </Dark>
  );
}

/* 2 */
function Agenda() {
  const items = [["أين نحن؟", Search], ["ماذا نخسر؟", AlertTriangle], ["إلى أين نذهب؟", Target], ["كيف ننفّذ؟", Rocket], ["ما الاستثمار؟", Banknote]] as const;
  return (
    <Light kicker="رحلة العرض" title="خمس محطات… تنتهي بقرار واضح">
      <div className="grid h-full grid-cols-5 items-center gap-8">
        {items.map(([t, I], i) => (
          <Card key={t} d={0.1 + i * 0.08} className="flex h-[440px] flex-col justify-between">
            <div className="text-[110px] font-black leading-none text-gold/40"><N>0{i + 1}</N></div>
            <I size={64} className="text-teal" strokeWidth={1.6} />
            <div className="s-sub text-navy">{t}</div>
          </Card>
        ))}
      </div>
    </Light>
  );
}

/* 3 */
function Kpis() {
  const k = [["39.2 مليون", "ج.م مبيعات مسجلة", TrendingUp], ["3,026", "فاتورة بيع", Receipt], ["18,195", "صنفًا في النظام", Boxes], ["12", "مخزنًا", Warehouse], ["88", "عميلًا", Users], ["14", "موظفًا", Handshake]] as const;
  return (
    <Light kicker="العميل في أرقام — فحص فعلي حتى 2-11-2026" title="شركة كبيرة تستحق نظامًا بحجمها">
      <div className="grid h-full grid-cols-3 grid-rows-2 gap-8">
        {k.map(([v, l, I], i) => (
          <Card key={l} d={0.1 + i * 0.07} className="flex items-center gap-8">
            <Icon i={I} tone={i % 2 ? "gold" : "teal"} />
            <div>
              <div className="text-[76px] font-black leading-none text-navy"><N>{v.split(" ")[0]}</N>{v.includes(" ") && <span className="s-sub mr-3">مليون</span>}</div>
              <div className="s-body mt-3 text-muted-foreground">{l}</div>
            </div>
          </Card>
        ))}
      </div>
    </Light>
  );
}

/* 4 */
function Today() {
  return (
    <Light kicker="الوضع الحالي" title="نظام يعمل… لكنه لا يساعد على القرار">
      <div className="grid h-full grid-cols-[1.3fr_1fr] gap-10">
        <Media src={legacy} className="h-full" label="ورق + شاشات قديمة + حسابات يدوية" />
        <div className="flex flex-col gap-6">
          {[["253 جدولًا", "73% منها فارغة"], ["285 تقريرًا", "بلا لوحة قرار واحدة"], ["237 شاشة", "تشتت الموظف بدل أن تخدمه"], ["44 نسخة احتياطية", "محلية فقط — على نفس الجهاز"]].map(([a = "", b], i) => (
            <Card key={a} d={0.15 + i * 0.08} className="flex-1 !p-7">
              <div className="s-sub text-navy"><N>{a.split(" ")[0]}</N> {a.split(" ").slice(1).join(" ")}</div>
              <div className="s-body text-muted-foreground">{b}</div>
            </Card>
          ))}
        </div>
      </div>
    </Light>
  );
}

/* 5 */
function Behind() {
  const c = [["44%", "فواتير آجلة غير مسددة", "1,340 فاتورة بلا متابعة", Banknote], ["17%", "فقط عليها ضريبة", "527 فاتورة من 3,026", Receipt], ["84%", "أصناف لم تُبع أبدًا", "82,711 سطر راكد", Boxes], ["نص صريح", "كلمات المرور", "قيود تقنية في الأمان", KeyRound], ["يدوي", "التقارير", "وقت ضائع كل شهر", FileSpreadsheet], ["127", "فاتورة شراء فقط", "مقابل 3,026 بيع", Truck]] as const;
  return (
    <Light kicker="ما وراء الشاشات" title="ستة أرقام تشرح الصورة كاملة">
      <div className="grid h-full grid-cols-3 grid-rows-2 gap-7">
        {c.map(([v, t, s, I], i) => (
          <Card key={t} d={0.1 + i * 0.07} className="flex flex-col justify-between border-r-8 !border-r-danger/70">
            <div className="flex items-center justify-between"><Icon i={I} tone="danger" /><div className="text-[68px] font-black text-danger"><N>{v}</N></div></div>
            <div><div className="s-sub text-navy">{t}</div><div className="s-cap text-muted-foreground">{s}</div></div>
          </Card>
        ))}
      </div>
    </Light>
  );
}

/* 6 */
function Waiting() {
  const c = [["تحصيل ضائع", "44% من الفواتير آجلة دون تنبيه أو متابعة", Banknote], ["مخاطر ضريبية", "83% من الفواتير بلا ضريبة مسجلة", AlertTriangle], ["رأس مال مجمّد", "15,320 صنفًا لم تتحرك أبدًا", Boxes], ["قرارات بلا أرقام", "لا لوحة تعرض الربح والمخزون لحظيًا", BarChart3]] as const;
  return (
    <Dark>
      <div className="flex h-full flex-col justify-center p-[110px]">
        <motion.div {...fade(0)} className="s-kicker text-gold">تكلفة الانتظار</motion.div>
        <motion.h2 {...fade(0.1)} className="s-title-lg mb-16">كل شهر بدون نظام حديث <span className="text-gold">له ثمن</span></motion.h2>
        <div className="grid grid-cols-4 gap-8">
          {c.map(([t, s, I], i) => (
            <motion.div key={t} {...fade(0.2 + i * 0.1)} className="glass rounded-3xl p-10">
              <I size={56} className="mb-8 text-gold" strokeWidth={1.6} />
              <div className="s-sub mb-4">{t}</div>
              <div className="s-body opacity-80">{s}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </Dark>
  );
}

/* 7 */
function Vision() {
  const l = [["الإدارة", "لوحة قرار + تنبيهات + ربحية", Gauge, "bg-gold/20"], ["المحاسبة", "قيود آلية + ضريبة + ميزان", Layers, "bg-teal/25"], ["التشغيل", "بيع + مخازن + مشتريات", Boxes, "glass"]] as const;
  return (
    <Dark>
      <div className="grid h-full grid-cols-2 items-center gap-20 p-[110px]">
        <div>
          <motion.div {...fade(0)} className="s-kicker text-gold">الرؤية</motion.div>
          <motion.h2 {...fade(0.1)} className="s-title-lg">من الفاتورة<br />إلى <span className="text-gold">القرار</span></motion.h2>
          <motion.p {...fade(0.2)} className="s-body-lg mt-10 opacity-85">كل فاتورة تُكتب تتحول تلقائيًا إلى قيد، ثم إلى رقم يراه المدير في نفس اللحظة.</motion.p>
        </div>
        <div className="flex flex-col gap-6">
          {l.map(([t, s, I, bg], i) => (
            <motion.div key={t} {...fade(0.2 + i * 0.12)} className={`${bg} flex items-center gap-8 rounded-3xl border border-primary-foreground/15 p-10`} style={{ marginRight: i * 50 }}>
              <I size={60} className="text-gold" strokeWidth={1.6} />
              <div><div className="s-sub">{t}</div><div className="s-body opacity-80">{s}</div></div>
            </motion.div>
          ))}
        </div>
      </div>
    </Dark>
  );
}

/* 8 */
function Principles() {
  const p = [["بسيط", "يتعلمه الموظف في يوم واحد", Sparkles], ["سريع", "فاتورة في ثوانٍ بالباركود", Zap], ["يعمل أوفلاين", "انقطع النت؟ البيع مستمر", CloudOff], ["يحوّل البيانات لقرار", "تقارير لحظية بدل اليدوي", BarChart3]] as const;
  return (
    <Light kicker="أربعة مبادئ" title="صُمم لطريقة عمل الغربية">
      <div className="grid h-full grid-cols-4 gap-8">
        {p.map(([t, s, I], i) => (
          <Card key={t} d={0.1 + i * 0.08} className="flex flex-col items-start justify-center gap-8">
            <Icon i={I} tone={i % 2 ? "gold" : "teal"} />
            <div className="s-sub text-navy">{t}</div>
            <div className="s-body text-muted-foreground">{s}</div>
          </Card>
        ))}
      </div>
    </Light>
  );
}

/* 9 */
function Architecture() {
  return (
    <Dark>
      <div className="grid h-full grid-cols-[1fr_1.2fr] items-center gap-16 p-[110px]">
        <div>
          <motion.div {...fade(0)} className="s-kicker text-gold">المعمارية</motion.div>
          <motion.h2 {...fade(0.1)} className="s-title">بياناتك تبقى <span className="text-gold">عندك</span></motion.h2>
          <div className="mt-12 flex flex-col gap-5">
            {[["أجهزة PC", HardDrive], ["تطبيق موبايل PWA", Smartphone], ["سيرفر الشركة On-Premise", Server], ["محرك مزامنة ذكي", RefreshCw]].map(([t, I], i) => {
              const Ic = I as typeof Zap;
              return <motion.div key={t as string} {...fade(0.2 + i * 0.08)} className="glass flex items-center gap-6 rounded-2xl px-8 py-5 s-body"><Ic size={40} className="text-gold" />{t as string}</motion.div>;
            })}
          </div>
        </div>
        <motion.div {...fade(0.3)}><Media src={iso} className="h-[760px]" /></motion.div>
      </div>
    </Dark>
  );
}

/* 10 */
function Offline() {
  const s = [["عمل محلي", "البيع يستمر بدون إنترنت", Wifi], ["طابور مزامنة", "كل عملية محفوظة بالترتيب", ClipboardList], ["دمج ذكي", "رجوع النت = رفع تلقائي", GitMerge], ["حل تعارضات", "قواعد واضحة، صفر تكرار", CheckCircle2]] as const;
  return (
    <Light kicker="أوفلاين بلا فقدان فاتورة" title="الإنترنت يقطع… الشغل لا يقف">
      <div className="flow flex h-full items-center gap-6">
        {s.map(([t, d, I], i) => (
          <div key={t} className="flex flex-1 items-center gap-6">
            <Card d={0.1 + i * 0.12} className="flex h-[480px] flex-1 flex-col items-center justify-center gap-8 text-center">
              <div className="grid h-28 w-28 place-items-center rounded-full bg-gold-grad text-navy-deep"><I size={54} /></div>
              <div className="s-sub text-navy">{t}</div>
              <div className="s-body text-muted-foreground">{d}</div>
            </Card>
            {i < 3 && <motion.div {...fade(0.2 + i * 0.12)} className="h-2 w-10 rounded-full bg-teal" />}
          </div>
        ))}
      </div>
    </Light>
  );
}

/* 11 */
function Accounting() {
  const flow = ["مستند", "قيد", "أستاذ", "ميزان", "قوائم"];
  return (
    <Light kicker="محاسبة قوية" title="كل رقم له أصل… وكل قيد آلي">
      <div className="flex h-full flex-col gap-12">
        <div className="flow flex items-center justify-between gap-4">
          {flow.map((f, i) => (
            <motion.div key={f} {...fade(0.1 + i * 0.1)} className="flex flex-1 items-center gap-4">
              <div className="flex-1 rounded-3xl bg-navy py-10 text-center s-sub text-primary-foreground shadow-soft">{f}</div>
              {i < 4 && <span className="s-title text-gold">←</span>}
            </motion.div>
          ))}
        </div>
        <div className="grid flex-1 grid-cols-3 gap-8">
          {[["ضريبة آلية", "على كل فاتورة بدل 17% فقط", Receipt], ["أعمار ديون", "تعرف مين متأخر ومن إمتى", CalendarClock], ["مراكز تكلفة", "ربحية كل فرع ومخزن", Target]].map(([t, s, I], i) => (
            <Card key={t as string} d={0.5 + i * 0.1} className="flex items-center gap-8">
              <Icon i={I as typeof Zap} tone="gold" />
              <div><div className="s-sub text-navy">{t as string}</div><div className="s-body text-muted-foreground">{s as string}</div></div>
            </Card>
          ))}
        </div>
      </div>
    </Light>
  );
}

/* 12 */
function Inventory() {
  return (
    <Light kicker="المخازن والمبيعات" title="من الكاشير إلى القرار">
      <div className="grid h-full grid-cols-[1.35fr_1fr] gap-10">
        <motion.div {...fade(0.1)}><Media video={warehouseVid} className="h-full" /></motion.div>
        <div className="grid grid-rows-4 gap-5">
          {[["باركود", "بيع واستلام في ثوانٍ", ScanBarcode], ["أرصدة لحظية", "12 مخزنًا على شاشة واحدة", Warehouse], ["حد طلب", "تنبيه قبل نفاد الصنف", AlertTriangle], ["ربحية صنف/عميل", "اعرف مين بيكسّبك فعلًا", TrendingUp]].map(([t, s, I], i) => (
            <Card key={t as string} d={0.2 + i * 0.08} className="flex items-center gap-6 !p-6">
              <Icon i={I as typeof Zap} />
              <div><div className="s-sub text-navy !text-[36px]">{t as string}</div><div className="s-cap text-muted-foreground">{s as string}</div></div>
            </Card>
          ))}
        </div>
      </div>
    </Light>
  );
}

/* 13 */
function Manager() {
  return (
    <Dark>
      <div className="grid h-full grid-cols-[1fr_1.1fr] items-center gap-16 p-[110px]">
        <div>
          <motion.div {...fade(0)} className="s-kicker text-gold">لوحة المدير + تطبيق الموبايل</motion.div>
          <motion.h2 {...fade(0.1)} className="s-title-lg">القرار <span className="text-gold">في جيبك</span></motion.h2>
          <div className="mt-12 grid grid-cols-2 gap-6">
            {[["مبيعات اليوم", TrendingUp], ["الآجل المستحق", Banknote], ["الأصناف الراكدة", Boxes], ["أفضل العملاء", Users]].map(([t, I], i) => {
              const Ic = I as typeof Zap;
              return <motion.div key={t as string} {...fade(0.2 + i * 0.08)} className="glass flex items-center gap-5 rounded-2xl p-7 s-body"><Ic size={40} className="text-gold" />{t as string}</motion.div>;
            })}
          </div>
        </div>
        <motion.div {...fade(0.3)}><Media video={dashVid} className="h-[760px]" /></motion.div>
      </div>
    </Dark>
  );
}

/* 14 */
function AI() {
  const c = [["استيراد Excel وتنقيته", "أي شيت يدخل النظام نظيف", FileSpreadsheet], ["مطابقة التكرار", "صنف واحد بدل خمس نسخ", GitMerge], ["كشف الشذوذ", "تنبيه لأي فاتورة أو سعر غريب", AlertTriangle], ["مساعد أسئلة", "«كام بعنا الشهر ده؟» بالعربي", MessageCircle]] as const;
  return (
    <Light kicker="الذكاء الاصطناعي العملي" title="ذكاء اصطناعي يشتغل لصالحك يوميًا">
      <div className="grid h-full grid-cols-2 grid-rows-2 gap-8">
        {c.map(([t, s, I], i) => (
          <Card key={t} d={0.1 + i * 0.08} className="flex items-center gap-8">
            <div className="grid h-24 w-24 shrink-0 place-items-center rounded-3xl bg-dark-grad text-gold"><I size={48} /></div>
            <div><div className="s-sub text-navy">{t}</div><div className="s-body text-muted-foreground">{s}</div></div>
            <Brain className="mr-auto text-teal/20" size={90} />
          </Card>
        ))}
      </div>
    </Light>
  );
}

/* 15 */
function Security() {
  const c = [["تشفير كامل", "كلمات المرور والبيانات الحساسة", Lock], ["صلاحيات لكل عملية", "كل موظف يرى ما يخصه فقط", KeyRound], ["سجل تدقيق", "مين عمل إيه وإمتى", FileText], ["نسخ داخل وخارج السيرفر", "لا خوف من عطل جهاز", Cloud]] as const;
  return (
    <Light kicker="الأمان" title="بياناتك محمية… بأربع طبقات">
      <div className="grid h-full grid-cols-[1fr_2fr] items-center gap-12">
        <motion.div {...fade(0.1)} className="grid h-[600px] place-items-center rounded-[48px] bg-dark-grad shadow-soft"><ShieldCheck size={300} strokeWidth={1} className="text-gold" /></motion.div>
        <div className="grid grid-cols-2 gap-7">
          {c.map(([t, s, I], i) => (
            <Card key={t} d={0.2 + i * 0.08} className="flex h-[280px] flex-col justify-center gap-5">
              <Icon i={I} tone="navy" />
              <div className="s-sub text-navy !text-[38px]">{t}</div>
              <div className="s-body text-muted-foreground">{s}</div>
            </Card>
          ))}
        </div>
      </div>
    </Light>
  );
}

/* 16 */
function Plan() {
  const p = [["تحليل وتصميم", 3, "من 1 إلى 3"], ["النواة المحاسبية", 8, "من 4 إلى 11"], ["مبيعات ومخازن", 6, "من 12 إلى 17"], ["مزامنة وتطبيق", 6, "من 18 إلى 23"], ["ترحيل وتدريب", 5, "من 24 إلى 28"]] as const;
  const T = 28;
  let start = 0;
  return (
    <Light kicker="خطة التنفيذ — ديسمبر 2026" title={<>شهر واحد… والتسليم قبل <N>31</N> ديسمبر</>}>
      <div className="flex h-full flex-col justify-center gap-7">
        <div className="hide-m flex justify-between pr-[360px] s-cap text-muted-foreground">{["الأسبوع 1", "الأسبوع 2", "الأسبوع 3", "الأسبوع 4"].map((w) => <span key={w} className="flex-1 text-center">{w}</span>)}</div>
        {p.map(([t, d, r], i) => {
          const s = start; start += d;
          return (
            <div key={t} className="gantt-row flex items-center gap-8">
              <div className="w-[330px] shrink-0"><div className="s-sub text-navy !text-[34px]">{t}</div><div className="s-cap text-muted-foreground">{r} ديسمبر</div></div>
              <div className="relative h-20 flex-1 rounded-2xl bg-muted">
                <motion.div initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: 0.2 + i * 0.15, duration: 0.6 }} style={{ right: `${(s / T) * 100}%`, width: `${(d / T) * 100}%`, transformOrigin: "right" }}
                  className={`absolute inset-y-0 grid place-items-center rounded-2xl s-cap font-bold ${i % 2 ? "bg-gold-grad text-navy-deep" : "bg-teal text-primary-foreground"}`}>
                  <span><N>{d}</N> أيام</span>
                </motion.div>
              </div>
            </div>
          );
        })}
        <motion.div {...fade(1)} className="mt-4 flex items-center gap-4 self-start rounded-full bg-gold-grad px-8 py-4 s-body font-bold text-navy-deep"><CalendarClock /> تسليم كامل يوم <N>28</N> ديسمبر <N>2026</N> — قبل نهاية السنة</motion.div>
      </div>
    </Light>
  );
}

/* 17 */
function WhyUs() {
  const c = [["فهمنا نظامكم بالتفصيل", "فحصنا 253 جدولًا و380,418 سجلًا قبل أن نكتب هذا العرض", Search], ["نبني على بياناتكم", "18,195 صنفًا و88 عميلًا ينتقلون كما هم", Database], ["تسليم مرحلي قابل للقياس", "تدفع على مراحل بعد ما تشوف الشغل بعينك", BadgeCheck], ["دعم بلغتكم", "فريق مصري، تواصل مباشر، 3 شهور دعم", Phone]] as const;
  return (
    <Light kicker="لماذا Cairo Code" title="شريك فاهم شغلك… مش مجرد مبرمج">
      <div className="grid h-full grid-cols-2 grid-rows-2 gap-8">
        {c.map(([t, s, I], i) => (
          <Card key={t} d={0.1 + i * 0.08} className="flex items-center gap-8">
            <Icon i={I} tone={i % 2 ? "gold" : "teal"} />
            <div><div className="s-sub text-navy !text-[40px]">{t}</div><div className="s-body text-muted-foreground"><span className="num-inline">{s}</span></div></div>
          </Card>
        ))}
      </div>
    </Light>
  );
}

/* 18 */
const PRICES = [
  ["التحليل وتصميم التجربة", "خرائط العمليات + تصميم كل الشاشات", 12000],
  ["النواة المحاسبية", "قيود آلية، أستاذ، ميزان، ضريبة، أعمار ديون", 22000],
  ["المبيعات والمخازن والمشتريات", "باركود، 12 مخزنًا، حد طلب، موردين", 20000],
  ["محرك الأوفلاين والمزامنة", "بيع بدون إنترنت + دمج آمن", 18000],
  ["تطبيق الموبايل PWA ولوحة المدير", "مؤشرات لحظية على موبايل المالك", 12000],
  ["الذكاء الاصطناعي (Excel + فحص)", "استيراد وتنقية وكشف شذوذ", 10000],
  ["ترحيل البيانات", "18,195 صنفًا / 577 حسابًا / 380 ألف سجل", 6000],
  ["التدريب والتشغيل ودعم 3 شهور", "تدريب 14 موظفًا + دعم مباشر", 5000],
] as const;
const fmt = (n: number) => n.toLocaleString("en-US");

function Investment() {
  return (
    <Light kicker="الاستثمار" title="سعر واحد… واضح وشامل">
      <div className="grid h-full grid-cols-[1.7fr_1fr] gap-10">
        <motion.div {...fade(0.1)} className="overflow-hidden rounded-3xl border border-border bg-card shadow-soft">
          {PRICES.map(([t, d, p], i) => (
            <div key={t} className={`flex items-center gap-6 px-9 py-[13px] ${i % 2 ? "bg-surface" : ""}`}>
              <span className="num w-10 s-cap font-bold text-gold">{i + 1}</span>
              <div className="flex-1"><div className="s-body font-bold text-navy !text-[28px]">{t}</div><div className="s-cap text-muted-foreground !text-[20px]">{d}</div></div>
              <span className="num s-body font-bold text-navy">{fmt(p)}</span>
            </div>
          ))}
        </motion.div>
        <div className="flex flex-col gap-6">
          <motion.div {...fade(0.3)} className="flex flex-1 flex-col justify-center rounded-3xl bg-dark-grad p-10 text-primary-foreground shadow-soft">
            <div className="s-body opacity-80">الإجمالي</div>
            <div className="my-4 text-[120px] font-black leading-none text-gold"><N>105,000</N></div>
            <div className="s-sub">جنيه مصري</div>
            <div className="s-body mt-6 opacity-85">سعر واحد شامل التنفيذ والترحيل والتدريب ودعم 3 شهور</div>
          </motion.div>
          <div className="s-cap text-muted-foreground !text-[19px]">لا يشمل السعر: أجهزة/سيرفر، اشتراكات الرسائل، أي وحدة غير مطلوبة (تصنيع/بسكول/تصدير).</div>
        </div>
      </div>
    </Light>
  );
}

/* 19 */
function Payment() {
  const p = [["30%", "عند التوقيع", 31500], ["30%", "تسليم النواة المحاسبية", 31500], ["30%", "بدء التشغيل", 31500], ["10%", "بعد 30 يوم استقرار", 10500]] as const;
  return (
    <Light kicker="طريقة الدفع" title="تدفع مع كل مرحلة تشوفها بعينك">
      <div className="flex h-full flex-col gap-10">
        <div className="grid grid-cols-4 gap-7">
          {p.map(([pc, t, v], i) => (
            <Card key={t} d={0.1 + i * 0.08} className="text-center">
              <div className="text-[84px] font-black leading-none text-teal"><N>{pc}</N></div>
              <div className="s-body my-4 text-navy font-bold">{t}</div>
              <div className="s-sub text-gold"><N>{fmt(v)}</N> <span className="s-cap">ج.م</span></div>
            </Card>
          ))}
        </div>
        <motion.div {...fade(0.5)} className="flex flex-1 items-center justify-around rounded-3xl bg-dark-grad p-10 text-primary-foreground">
          <div className="text-center"><div className="s-body opacity-75">لو قسمناها على سنة</div><div className="text-[96px] font-black text-gold"><N>8,750</N></div><div className="s-body">ج.م / شهر</div></div>
          <div className="s-title-lg text-gold/60">≈</div>
          <div className="text-center"><div className="s-body opacity-75">يعني تقريبًا</div><div className="text-[96px] font-black text-gold"><N>292</N></div><div className="s-body">ج.م / يوم — أقل من راتب موظف واحد</div></div>
        </motion.div>
      </div>
    </Light>
  );
}

/* 20 */
function ROI() {
  const s = [["تحصيل 1% فقط من الآجل", "1,340 فاتورة آجلة متابعة آليًا", Banknote], ["تقليل الراكد 5% فقط", "من 15,320 صنفًا لم يتحرك", Boxes], ["ضبط ضريبة شهر واحد", "بدل تسجيلها على 17% فقط", Receipt]] as const;
  return (
    <Dark>
      <div className="flex h-full flex-col justify-center p-[110px]">
        <motion.div {...fade(0)} className="s-kicker text-gold">العائد</motion.div>
        <motion.h2 {...fade(0.1)} className="s-title-lg">عرض <span className="text-gold">لا يمكن رفضه</span></motion.h2>
        <motion.p {...fade(0.2)} className="s-body-lg mb-14 mt-6 opacity-85">أي سيناريو واحد من الثلاثة — بمفرده — يغطي تكلفة المشروع بالكامل.</motion.p>
        <div className="grid grid-cols-3 gap-8">
          {s.map(([t, d, I], i) => (
            <motion.div key={t} {...fade(0.3 + i * 0.12)} className="glass rounded-3xl p-10">
              <I size={56} className="mb-6 text-gold" />
              <div className="s-sub mb-3">{t}</div>
              <div className="s-body opacity-75">{d}</div>
              <div className="mt-8 flex items-center gap-3 rounded-full bg-gold-grad px-6 py-3 s-body font-bold text-navy-deep"><Trophy size={30} /> يغطي التكلفة</div>
            </motion.div>
          ))}
        </div>
      </div>
    </Dark>
  );
}

/* 21 */
function Next() {
  const s = [["ورشة 60 دقيقة", "نراجع معكم الأولويات"], ["عرض تفصيلي", "شاشات وخطة نهائية"], ["عقد وبدء 1 ديسمبر", "تسليم كامل قبل 31 ديسمبر 2026"]];
  return (
    <Dark>
      <img src={cover} alt="" className="absolute inset-0 h-full w-full object-cover opacity-20" />
      <div className="relative flex h-full flex-col justify-between p-[110px]">
        <div className="flex items-center justify-between">
          <motion.div {...fade(0)} className="s-kicker text-gold">الخطوات القادمة</motion.div>
          <Logo className="h-24" />
        </div>
        <div className="grid grid-cols-3 gap-8">
          {s.map(([t, d], i) => (
            <motion.div key={t} {...fade(0.1 + i * 0.12)} className="glass rounded-3xl p-10">
              <div className="mb-6 grid h-20 w-20 place-items-center rounded-full bg-gold-grad text-[40px] font-black text-navy-deep"><N>{i + 1}</N></div>
              <div className="s-sub">{t}</div>
              <div className="s-body opacity-75">{d}</div>
            </motion.div>
          ))}
        </div>
        <div className="flex items-end justify-between">
          <motion.h2 {...fade(0.5)} className="text-[150px] font-black leading-none">شكرًا <span className="text-gold">لكم</span></motion.h2>
          <motion.div {...fade(0.6)} className="flex flex-col items-center gap-1 text-center">
            <div className="signature text-[88px] leading-[1.25] text-gold">عادل رجب</div>
            <svg viewBox="0 0 320 22" className="h-6 w-[290px] text-gold/70" fill="none" aria-hidden="true">
              <path d="M6 15C58 4 108 20 160 11S262 4 314 13" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
            </svg>
            <a href="tel:+201002646533" className="mt-4 flex items-center gap-4 s-body opacity-90 hover:opacity-100">
              <Phone className="text-gold" size={34} /> <span className="num">+20 100 264 6533</span>
            </a>
          </motion.div>
        </div>
      </div>
    </Dark>
  );
}

export const SLIDES: { title: string; C: () => ReactNode }[] = [
  { title: "الغلاف", C: Cover }, { title: "الأجندة", C: Agenda }, { title: "العميل في أرقام", C: Kpis },
  { title: "كيف تعمل الشركة اليوم", C: Today }, { title: "ما وراء الشاشات", C: Behind }, { title: "تكلفة الانتظار", C: Waiting },
  { title: "الرؤية", C: Vision }, { title: "أربعة مبادئ", C: Principles }, { title: "المعمارية", C: Architecture },
  { title: "أوفلاين بلا فقدان فاتورة", C: Offline }, { title: "محاسبة قوية", C: Accounting }, { title: "المخازن والمبيعات", C: Inventory },
  { title: "لوحة المدير", C: Manager }, { title: "الذكاء الاصطناعي", C: AI }, { title: "الأمان", C: Security },
  { title: "خطة شهر واحد", C: Plan }, { title: "لماذا Cairo Code", C: WhyUs }, { title: "الاستثمار", C: Investment },
  { title: "طريقة الدفع", C: Payment }, { title: "العائد", C: ROI }, { title: "الخطوات القادمة", C: Next },
];
