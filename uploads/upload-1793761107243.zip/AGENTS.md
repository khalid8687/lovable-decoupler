<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep quotation arithmetic in `src/lib/quote-pricing.ts` and reuse it for page and PDF; authoritative final prices avoid double-discounting and rounding drift.
- Keep user-supplied product photos as local source-controlled assets because this quotation must not depend on online image hosting.
